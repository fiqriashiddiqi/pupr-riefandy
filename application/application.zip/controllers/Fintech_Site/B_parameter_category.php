<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_parameter_category extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '4');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['title'] = "Paremeter Category";
		$data['brd_title_main'] = "Paremeter Category";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter_category');

		$data['create_url'] = site_url('Fintech_Site/B_parameter_category/create_parameter_category');
		$data['delete_url'] = site_url('Fintech_Site/B_parameter_category/delete_parameter_category');
		$data['info_url'] = site_url('Fintech_Site/B_parameter_category/update_parameter_category');
		
		// $data['data_parameter_category'] = $this->param_model->get_parameter_category();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/category/parameter-category-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function create_parameter_category()
	{
		
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Category";
		$data['brd_title_main'] = "Category Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter_category');
		$data['brd_title_sub'] = "Add Category";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_parameter_category/create_parameter_category');
		$data['back_url'] = site_url('Fintech_Site/B_parameter_category');

		$data['form_url'] = site_url('Fintech_Site/B_parameter_category/create_parameter_category');
		$data['data_parameter_category'] = $this->param_model->get_parameter_category();

		$this->form_validation->set_rules("category_name", "Nama Category", "trim|required");
	
		if ($this->form_validation->run() == true){
			$category_name = $this->input->post('category_name');

						$data_parameter_category = array(
						'category_name' => $category_name,
						);

						$insert_cateory = $this->crud_model->insert('tb_parameter_category',$data_parameter_category);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_parameter_category/create_parameter_category');
						die();
		
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/category/parameter-category-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function update_parameter_category()
	{

		$id_category = $this->uri->segment(4);
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Update Category";
		$data['brd_title_main'] = "Category Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter_category');
		$data['brd_title_sub'] = "Update Category";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_parameter_category/update_parameter_category')."/".$id_category;

		$data['form_url'] = site_url('Fintech_Site/B_parameter_category/update_parameter_category');
		$data['back_url'] = site_url('Fintech_Site/B_parameter_category');

		$data['data_parameter_category'] = $this->param_model->get_parameter_category($id_category);

		$this->form_validation->set_rules("id_category", "id Category", "trim|required");
		$this->form_validation->set_rules("category_name", "Nama Category", "trim|required");
	
		if ($this->form_validation->run() == true){

			$id_category = $this->input->post('id_category');
			$category_name = $this->input->post('category_name');
			
						$data_parameter_category = array(

						'id_category' => $id_category,
						'category_name' => $category_name,
						);

						$update_category = $this->crud_model->update('tb_parameter_category','id_category',$id_category,$data_parameter_category);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_parameter_category/update_parameter_category/'.$id_category);
						die();

		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/category/parameter-category-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function delete_parameter_category()
	{
		$id_category = $this->uri->segment(4);
		$where = array('id_category' => $id_category);
        $data_check = $this->param_model->get_data("tb_parameter")->num_rows();
		
		if (!empty($id_category)){

                if($data_check == 0){

					$this->crud_model->delete('tb_parameter_category','id_category',$id_category);
					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'Fintech_Site/B_parameter_category');
					die();

                } else {

                    $this->session->set_flashdata('alert_error', 'Data failed to Delete, Becouse this data has been store for other data!');
                    redirect(base_url().'Fintech_Site/B_parameter_category');
                    die();
                }


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Fintech_Site/B_parameter_category');
			die();
		}
	}

}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_setting extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
   	 	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '4');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }

	public function index()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Setting";
		$data['brd_title_main'] = "Setting";
		$data['brd_title_url'] = site_url('Fintech_Site/B_setting');

		$data['form_url'] = site_url('Fintech_Site/B_setting');
		$data['data_contact'] = $this->crud_model->get_setting();
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		$this->form_validation->set_rules("id_setting", "", "trim|required");
		$this->form_validation->set_rules("setting_pagination", " ", "trim|required");
		$this->form_validation->set_rules("reg_ID", "", "trim|required");
		$this->form_validation->set_rules("point_reference", "", "trim|required");
		$this->form_validation->set_rules("point_invest", "", "trim|required");
		$this->form_validation->set_rules("point_exchange", "", "trim|required");
		$this->form_validation->set_rules("commision_borrower", "", "trim|required");
		$this->form_validation->set_rules("commision_lender", "", "trim|required");
		$this->form_validation->set_rules("penalty", "", "trim|required");
		$this->form_validation->set_rules("fee_pg", "", "trim|required");
		
		
		if ($this->form_validation->run() == true){
			$id_setting = $this->input->post('id_setting');
			$setting_pagination = $this->input->post('setting_pagination');
			$reg_ID = $this->input->post('reg_ID');
			$point_reference = $this->input->post('point_reference');
			$point_invest = $this->input->post('point_invest');
			$point_exchange = $this->input->post('point_exchange');
			$commision_borrower = $this->input->post('commision_borrower');
			$commision_lender = $this->input->post('commision_lender');
			$penalty = $this->input->post('penalty');
			$fee_pg = $this->input->post('fee_pg');

			$_POST['fee_pg'] = $fee_pg;
            $clean = preg_replace('/\D/','',$_POST['fee_pg']);

						$data_contact = array(
						'id_setting' => $id_setting,
						'setting_pagination' => $setting_pagination,
						'reg_ID' => $reg_ID,
						'point_reference' => $point_reference,
						'point_invest' => $point_invest,
						'point_exchange' => $point_exchange,
						'commision_borrower' => $commision_borrower,
						'commision_lender'	=> $commision_lender,
						'penalty' => $penalty,
						'fee_pg' => $clean
						);

						$update_contact = $this->crud_model->update('tb_setting','id_setting',$id_setting,$data_contact,$clean);
							$this->session->set_flashdata('alert_success', 'Setting successfully changed.');
							redirect(base_url().'Fintech_Site/B_setting');
							die();


		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/setting/setting_form_detail', $data);
		$this->load->view('backend-web/partial/footer');
	}

	
}

?>
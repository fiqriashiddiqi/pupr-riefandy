<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_parameter_all extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Parameter/parameter_all_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '4');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }
	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Parameter Consumtive";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter_all');
		$data['brd_title_main'] = "Faq";
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		// $data['create_url'] = site_url('Fintech_Site/B_parameter_all/create_parameter_all');
		$data['delete_url'] = site_url('Fintech_Site/B_parameter_all/delete_parameter_all');
		$data['update_url'] = site_url('Fintech_Site/B_parameter_all/update_parameter_all');

        // $data['data_parameter_all'] = $this->parameter_all_model->get_parameter_all();
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter-all/parameter-all-list', $data);
		$this->load->view('backend-web/partial/footer');
	}

    public function commercial()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $data['title'] = "Parameter Commercial";
        $data['brd_title_url'] = site_url('Fintech_Site/B_parameter_all/commercial');
        $data['brd_title_main'] = "Faq";
        $data['users_last_signin'] = $check_access[0]->users_last_signin;

        // $data['create_url'] = site_url('Fintech_Site/B_parameter_all/create_parameter_all');
        $data['delete_url'] = site_url('Fintech_Site/B_parameter_all/delete_parameter_all');
        $data['update_url'] = site_url('Fintech_Site/B_parameter_all/update_parameter_all');

        // $data['data_parameter_all'] = $this->parameter_all_model->get_parameter_all();
        $data['data_groups'] = $this->groups_model->get_groups($access_groups);

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-fintech/parameter-all/parameter-all-list-commercial', $data);
        $this->load->view('backend-web/partial/footer');
    }

	public function access_status_exchange()
	{

		$id_parameter_all = $this->input->post('id_parameter_all');
		$data_parameter_all = $this->parameter_all_model->get_parameter_all_by_id($id_parameter_all);
		$parameter_all_access_status = $data_parameter_all[0]->parameter_all_access_status;

		if ($parameter_all_access_status == "Deactivated"){

			$data_exchange = array(
			'parameter_all_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'parameter_all_access_status' => 'Deactivated'
			);

		}
							
		$update_parameter_all = $this->crud_model->update('tb_parameter_all','id_parameter_all',$id_parameter_all,$data_exchange);

	}

	public function create_parameter_all()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Parameter All";
		$data['brd_title_main'] = "Parameter All";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter_all/index');
		$data['brd_title_sub'] = "Add Parameter All";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_parameter_all/create_parameter_all');
		// $data['back_url'] = site_url('Fintech_Site/B_parameter_all');

		$data['form_url'] = site_url('Fintech_Site/B_parameter_all/create_parameter_all');
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		$this->form_validation->set_rules("parameter_all_name", "name", "trim|required");
		$this->form_validation->set_rules("parameter_all_math", "math", "trim|required");
		$this->form_validation->set_rules("parameter_all_score", "score", "trim|required");
		$this->form_validation->set_rules("parameter_all_status", "status", "trim|required");
		$this->form_validation->set_rules("parameter_all_access_status", "Access Status ", "trim|required");
	

		if ($this->form_validation->run() == true){
			$parameter_all_name = $this->input->post('parameter_all_name');
			$parameter_all_math = $this->input->post('parameter_all_math');
			$parameter_all_score = $this->input->post('parameter_all_score');
			$parameter_all_status = $this->input->post('parameter_all_status');
			$parameter_all_mandatori = $this->input->post('parameter_all_mandatori');
			$parameter_all_access_status = $this->input->post('parameter_all_access_status');

						$data_parameter_all = array(
						'parameter_all_name' => $parameter_all_name,
						'parameter_all_math' => $parameter_all_math,
						'parameter_all_score' => $parameter_all_score,
						'parameter_all_status' => $parameter_all_status,
						'parameter_all_mandatori' => 'Non Mandatori',
						'parameter_all_access_status' => $parameter_all_access_status

						);

						$insert_parameter_all = $this->crud_model->insert('tb_parameter_all',$data_parameter_all);
						$this->session->set_flashdata('alert_success', 'Data successfully changed.');
						redirect(base_url().'Fintech_Site/B_parameter_all/create_parameter_all');
						die();
							
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter-all/parameter-all-form', $data);
		$this->load->view('backend-web/partial/footer');
		
	}

	public function update_parameter_all()
	{

		$id_parameter_all = $this->uri->segment(4);
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

        $data_parameter = $this->parameter_all_model->get_parameter_all_by_id($id_parameter_all);

        if($data_parameter[0]->parameter_all_status == "Consumtive"){
            $status = "/index";
        } else {
            $status = "/commercial";
        }

		$data['title'] = "Detail Parameter";
		$data['brd_title_main'] = "Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter_all'.$status);
		$data['brd_title_sub'] = "Detail Parameter";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_parameter_all/update_parameter_all')."/".$id_parameter_all;

		$data['form_url'] = site_url('Fintech_Site/B_parameter_all/update_parameter_all');
		$data['back_url'] = site_url('Fintech_Site/B_parameter_all'.$status);

		$data['data_parameter'] = $this->parameter_all_model->get_parameter_all_by_id($id_parameter_all);
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		$this->form_validation->set_rules("id_parameter_all", "id", "trim|required");
		$this->form_validation->set_rules("parameter_all_name", "name", "trim|required");
		$this->form_validation->set_rules("parameter_all_math", "math", "trim|required");
		$this->form_validation->set_rules("parameter_all_score", "score", "trim|required");
		$this->form_validation->set_rules("parameter_all_status", "status", "trim|required");
		$this->form_validation->set_rules("parameter_all_access_status", "Access Status ", "trim|required");

		if ($this->form_validation->run() == true){
			$id_parameter_all = $this->input->post('id_parameter_all');
			$parameter_all_name = $this->input->post('parameter_all_name');
			$parameter_all_math = $this->input->post('parameter_all_math');
			$parameter_all_score = $this->input->post('parameter_all_score');
			$parameter_all_status = $this->input->post('parameter_all_status');
			$parameter_all_access_status = $this->input->post('parameter_all_access_status');

						$data_parameter_all = array(
                        'id_parameter_all' => $id_parameter_all,
						'parameter_all_name' => $parameter_all_name,
						'parameter_all_math' => $parameter_all_math,
						'parameter_all_score' => $parameter_all_score,
						'parameter_all_status' => $parameter_all_status,
						'parameter_all_access_status' => $parameter_all_access_status
						);

						$update_faq = $this->crud_model->update('tb_parameter_all','id_parameter_all',$id_parameter_all, $data_parameter_all);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_parameter_all/update_parameter_all/'.$id_parameter_all);
						die();
		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter-all/parameter-all-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

    public function change_order()
    {

        $id_parameter_all = $this->input->post('id_parameter_all');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'parameter_all_orders' => $value_order
        );
                            
        $update_parameter_all = $this->crud_model->update('tb_parameter_all','id_parameter_all',$id_parameter_all, $data_order);

    }

	public function delete_parameter_all()
	{
		$id_parameter_all = $this->uri->segment(4);
        $data_parameter = $this->parameter_all_model->get_parameter_all_by_id($id_parameter_all);

        if($data_parameter[0]->parameter_all_status == "Consumtive"){
            $status = "/index";
        } else {
            $status = "/commercial";
        }
		
		if (!empty($id_parameter_all)){

				$this->crud_model->delete('tb_parameter_all','id_parameter_all',$id_parameter_all);
				$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
				redirect(base_url().'Fintech_Site/B_parameter_all'.$status);
				die();


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Fintech_Site/B_parameter_all'.$status);
			die();
		}
	}

}

?>
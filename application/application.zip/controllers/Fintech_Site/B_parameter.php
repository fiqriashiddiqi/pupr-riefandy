<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_parameter extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '4');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['title'] = "Parameter ";
		$data['brd_title_main'] = "Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter');

		$data['create_url'] = site_url('Fintech_Site/B_parameter/create_parameter');
		$data['delete_url'] = site_url('Fintech_Site/B_parameter/delete_parameter');
		$data['info_url'] = site_url('Fintech_Site/B_parameter/update_parameter');
		
		// $data['data_parameter'] = $this->param_model->get_parameter();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/category/parameter-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function access_status_exchange()
	{

		$id_parameter = $this->input->post('id_parameter');

		$data_parameter = $this->param_model->get_parameter_by_id($id_parameter);
		$parameter_access_status = $data_parameter[0]->parameter_access_status;

		if ($parameter_access_status == "Deactivated"){

			$data_exchange = array(
			'parameter_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'parameter_access_status' => 'Deactivated'
			);

		}
							
		$update_parameter = $this->crud_model->update('tb_parameter','id_parameter',$id_parameter,$data_exchange);

	}

	public function create_parameter()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Parameter";
		$data['brd_title_main'] = "Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter');
		$data['brd_title_sub'] = "Add Parameter";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_parameter/create_parameter');
		$data['back_url'] = site_url('Fintech_Site/B_parameter');

		$data['form_url'] = site_url('Fintech_Site/B_parameter/create_parameter');

		$data['dropdown_category'] = $this->param_model->get_parameter_category();

		$this->form_validation->set_rules("id_category", "Id Category", "trim|required");
		$this->form_validation->set_rules("parameter_name", "nama parameter", "trim|required");
		$this->form_validation->set_rules("parameter_access_status", "Access status", "trim|required");
	
		if ($this->form_validation->run() == true){
			$id_category = $this->input->post('id_category');
			$parameter_name = $this->input->post('parameter_name');
			$parameter_access_status = $this->input->post('parameter_access_status');

						$data_parameter = array(
						'id_category' => $id_category,
						'parameter_name' => $parameter_name,
						'parameter_access_status' => $parameter_access_status,
						);

						$insert_parameter = $this->crud_model->insert('tb_parameter',$data_parameter);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_parameter/create_parameter');
						die();
		
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/category/parameter-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function update_parameter()
	{

		$id_category = $this->uri->segment(4);
		$id_parameter = $this->uri->segment(5);

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Update Parameter";
		$data['brd_title_main'] = "Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter/create_parameter');
		$data['brd_title_sub'] = "Update Parameter";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_parameter/update_parameter')."/".$id_category."/".$id_parameter;

		$data['form_url'] = site_url('Fintech_Site/B_parameter/update_parameter')."/".$id_category."/".$id_parameter;
		$data['back_url'] = site_url('Fintech_Site/B_parameter');
		$data['delete_url'] = site_url('Fintech_Site/B_parameter/delete_parameter_option')."/".$id_category."/".$id_parameter;
		$data['create_url'] = site_url('Fintech_Site/B_parameter/create_parameter_option')."/".$id_category."/".$id_parameter;

		$data['default_category'] = $this->param_model->get_parameter_category($id_category);
		$data['dropdown_category'] = $this->param_model->get_parameter_category();

		$data['data_parameter'] = $this->param_model->get_parameter($id_parameter);
		$data['data_parameter_option'] = $this->param_model->get_parameter_option($id_parameter);
		// $data['get_category'] =  $id_category;
		// $data['get_parameter'] =  $id_parameter;


		$this->form_validation->set_rules("id_category", "id category", "trim|required");
		$this->form_validation->set_rules("id_parameter", "id parameter", "trim|required");
		$this->form_validation->set_rules("parameter_name", "parameter_name", "trim|required");
		$this->form_validation->set_rules("parameter_access_status", "access status", "trim|required");

	
		if ($this->form_validation->run() == true){
			$id_category = $this->input->post('id_category');
			$id_parameter = $this->input->post('id_parameter');
			$parameter_name = $this->input->post('parameter_name');
			$parameter_access_status = $this->input->post('parameter_access_status');
			
						$data_parameter = array(
						'id_category' => $id_category,
						'id_parameter' => $id_parameter,
						'parameter_name' => $parameter_name,
						'parameter_access_status' => $parameter_access_status
						);

						$update_parameter = $this->crud_model->update('tb_parameter','id_parameter',$id_parameter,$data_parameter);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_parameter/update_parameter/'.$id_category."/".$id_parameter);
						die();

		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/category/parameter-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function create_parameter_option()
	{
		$id_category = $this->uri->segment(4);
		$id_parameter = $this->uri->segment(5);

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Parameter Option";
		$data['brd_title_main'] = "Parameter Option";
		$data['brd_title_url'] = site_url('Fintech_Site/B_parameter');
		$data['brd_title_sub'] = "Add Parameter Option";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_parameter/create_parameter_option')."/".$id_parameter;
		$data['back_url'] = site_url('Fintech_Site/B_parameter/update_parameter')."/".$id_category."/".$id_parameter;
		$data['form_url'] = site_url('Fintech_Site/B_parameter/create_parameter_option')."/".$id_category."/".$id_parameter;

		$data['data_parameter'] = $this->param_model->get_parameter($id_parameter);

		$this->form_validation->set_rules("id_parameter", "Id parameter", "trim|required");
		$this->form_validation->set_rules("option_name", "nama parameter", "trim|required");
		$this->form_validation->set_rules("option_math", "nama parameter", "trim|required");
		$this->form_validation->set_rules("option_score", "nama parameter", "trim|required");
		
	
		if ($this->form_validation->run() == true){
			$id_parameter = $this->input->post('id_parameter');
			$option_name = $this->input->post('option_name');
			$option_math = $this->input->post('option_math');
			$option_score = $this->input->post('option_score');

						$data_parameter_option = array(
						'id_parameter' => $id_parameter,
						'option_name' => $option_name,
						'option_math' => $option_math,
						'option_score' => $option_score,
						);

						$insert_parameter_option = $this->crud_model->insert('tb_parameter_option', $data_parameter_option);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_parameter/create_parameter_option/'.$id_category."/".$id_parameter);
						die();
		
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/category/parameter-option-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function delete_parameter()
	{
		$id_parameter = $this->uri->segment(4);

        $where = array('id_parameter' => $id_parameter);
        $data_check = $this->crud_model->get_data("tb_parameter_option", $where)->num_rows();
		
		if (!empty($id_parameter)){

                if($data_check == 0){

					$this->crud_model->delete('tb_parameter','id_parameter',$id_parameter);
					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'Fintech_Site/B_parameter');
					die();

                } else {

                    $this->session->set_flashdata('alert_error', 'Data failed to Delete, Because this data has been store for other data!');
                    redirect(base_url().'Fintech_Site/B_parameter');
                    die();
                }


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Fintech_Site/B_parameter');
			die();
		}
	}

	public function delete_parameter_option()
    {
        $id_parameter = $this->uri->segment(4);
        $id_parameter_option = $this->uri->segment(5);
        
        if (!empty($id_parameter) AND !empty($id_parameter_option)){

                    $this->crud_model->delete('tb_parameter_option','id_parameter_option',$id_parameter_option);
                    $this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
                    redirect(base_url().'Fintech_Site/B_parameter/update_parameter/'.$id_parameter."/".$id_parameter_option);
                    die();


        } else {
            $this->session->set_flashdata('alert_error', 'Data failed to Delete !');
            redirect(base_url().'Fintech_Site/B_parameter/update_parameter/'.$id_parameter."/".$id_parameter_option);
            die();
        }
    }

}

?>
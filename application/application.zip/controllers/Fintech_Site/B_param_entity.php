<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_param_entity extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '4');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['title'] = "Purpose Of Loan";
		$data['brd_title_main'] = "Purpose Of Loan";
		$data['brd_title_url'] = site_url('Fintech_Site/B_param_entity');

		$data['create_url'] = site_url('Fintech_Site/B_param_entity/create_entity');
		$data['delete_url'] = site_url('Fintech_Site/B_param_entity/delete_entity');
		$data['info_url'] = site_url('Fintech_Site/B_param_entity/update_entity');
		$data['update_url'] = site_url('Fintech_Site/B_param_entity/update_entity');
		$data['excel_url'] = site_url('Report/B_report/excel_entity');


		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/entity/entity-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function access_status_exchange()
	{

		$id_param_entity = $this->input->post('id_param_entity');

		$data_entity = $this->param_model->get_entity_by_id($id_param_entity);
		$entity_access_status = $data_entity[0]->entity_access_status;

		if ($entity_access_status == "Deactivated"){

			$data_exchange = array(
			'entity_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'entity_access_status' => 'Deactivated'
			);

		}
							
		$update_entity = $this->crud_model->update('tb_param_type_entity','id_param_entity',$id_param_entity,$data_exchange);

	}

	public function create_entity()
	{
		
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Purpose Of Loan";
		$data['brd_title_main'] = "Purpose Of Loan";
		$data['brd_title_url'] = site_url('Fintech_Site/B_param_entity');
		$data['brd_title_sub'] = "Add Purpose Of Loan";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_param_entity/create_entity');
		$data['back_url'] = site_url('Fintech_Site/B_param_entity');

		$data['form_url'] = site_url('Fintech_Site/B_param_entity/create_entity');
		$data['data_entity'] = $this->param_model->get_entity();
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		
		$this->form_validation->set_rules("entity_name", "Nama entity", "trim|required");
		$this->form_validation->set_rules("entity_access_status", "Posting Status", "trim|required");
	
		if ($this->form_validation->run() == true){
			
			$entity_name = $this->input->post('entity_name');
			$entity_score = $this->input->post('entity_score');	
			$entity_access_status = $this->input->post('entity_access_status');

				
						$data_entity = array(
						'entity_name' => $entity_name,		
						'entity_score' => $entity_score,
						'entity_access_status' => $entity_access_status,
						);

						$insert_entity = $this->crud_model->insert('tb_param_type_entity',$data_entity);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_param_entity/create_entity');
						die();
					

				}
		
		

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/entity/entity-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function update_entity()
	{

		$id_param_entity = $this->uri->segment(4);
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Update Purpose Of Loan";
		$data['brd_title_main'] = "Purpose Of Loan";
		$data['brd_title_url'] = site_url('Fintech_Site/B_param_entity');
		$data['brd_title_sub'] = "Update Purpose Of Loan";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_param_entity/update_entity')."/".$id_param_entity;

		$data['form_url'] = site_url('Fintech_Site/B_param_entity/update_entity');
		$data['back_url'] = site_url('Fintech_Site/B_param_entity');

		$data['profile_true'] = "backdoor";

		$where_entity = array('id_param_entity' => $id_param_entity);

		$data['data_entity'] = $this->crud_model->get_data('tb_param_type_entity', $where_entity)->result();

		$this->form_validation->set_rules("id_param_entity", "", "trim|required");
		$this->form_validation->set_rules("entity_name", "", "trim|required");
	
		if ($this->form_validation->run() == true){

			$id_param_entity = $this->input->post('id_param_entity');
			$entity_name = $this->input->post('entity_name');
			$entity_score = $this->input->post('entity_score');	
			$entity_access_status = $this->input->post('entity_access_status');
		
			
						$data_entity = array(

						'id_param_entity' => $id_param_entity,
						'entity_name' => $entity_name,		
						'entity_score' => $entity_score,
						'entity_access_status' => $entity_access_status,
						);

						$update_entity = $this->crud_model->update('tb_param_type_entity','id_param_entity',$id_param_entity,$data_entity);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_param_entity/update_entity/'.$id_param_entity);
						die();

		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/entity/entity-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function delete_entity()
	{
		$id_param_entity = $this->uri->segment(4);
		
		if (!empty($id_param_entity)){

					$this->crud_model->delete('tb_param_type_entity','id_param_entity',$id_param_entity);
					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'Fintech_Site/B_param_entity');
					die();


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Fintech_Site/B_param_entity');
			die();
		}
	}

}

?>
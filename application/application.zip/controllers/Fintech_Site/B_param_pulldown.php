<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_param_pulldown extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '4');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['title'] = "Pulldown Parameter";
		$data['brd_title_main'] = "Pulldown Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_param_pulldown');

		$data['create_url'] = site_url('Fintech_Site/B_param_pulldown/create_pulldown');
		$data['delete_url'] = site_url('Fintech_Site/B_param_pulldown/delete_pulldown');
		$data['info_url'] = site_url('Fintech_Site/B_param_pulldown/update_pulldown');
		
		$data['data_pulldown'] = $this->param_model->get_data("tb_param_pulldown")->result();


		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/pulldown/pulldown-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

		public function access_status_exchange()
	{

		$id_param_pulldown = $this->input->post('id_param_pulldown');

		$data_pulldown = $this->param_model->get_pulldown_by_id($id_param_pulldown);
		$pulldown_access_status = $data_pulldown[0]->pulldown_access_status;

		if ($pulldown_access_status == "Deactivated"){

			$data_exchange = array(
			'pulldown_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'pulldown_access_status' => 'Deactivated'
			);

		}
							
		$update_pulldown = $this->crud_model->update('tb_param_pulldown','id_param_pulldown',$id_param_pulldown,$data_exchange);

	}

	public function create_pulldown()
	{
		
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Pulldown";
		$data['brd_title_main'] = "Pulldown Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_param_pulldown');
		$data['brd_title_sub'] = "Add Pulldown";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_param_pulldown/create_pulldown');
		$data['back_url'] = site_url('Fintech_Site/B_param_pulldown');

		$data['form_url'] = site_url('Fintech_Site/B_param_pulldown/create_pulldown');

		$data['data_pulldown'] = $this->param_model->get_pulldown();
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

	
		$this->form_validation->set_rules("pulldown_name", "Nama pulldown", "trim|required");
		$this->form_validation->set_rules("pulldown_access_status", "akses status pulldown", "trim|required");
	
		if ($this->form_validation->run() == true){
			
			$pulldown_name = $this->input->post('pulldown_name');
			$pulldown_access_status = $this->input->post('pulldown_access_status');

						$data_pulldown = array(
						'id_param_pulldown' => $id_param_pulldown,
						'pulldown_name' => $pulldown_name,
						'pulldown_access_status' => $pulldown_access_status
						);

						$insert_pulldown = $this->crud_model->insert('tb_param_pulldown',$data_pulldown);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_param_pulldown/create_pulldown');
						die();
		
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/pulldown/pulldown-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

    public function create_pulldown_option()
    {
        
        $id_param_pulldown = $this->uri->segment(4);   
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $navigation['users_active'] = 'active';

        $data['title'] = "Add Pulldown Option";
        $data['brd_title_main'] = "Pulldown Parameter";
        $data['brd_title_url'] = site_url('Fintech_Site/B_param_pulldown');
        $data['brd_title_sub'] = "Detail Pulldown";
        $data['brd_title_url_sub'] = site_url('Fintech_Site/B_param_pulldown/update_pulldown')."/".$id_param_pulldown;
        $data['brd_title_sub2'] = "Add Option";
        $data['brd_title_url_sub2'] = site_url('Fintech_Site/B_param_pulldown/create_pulldown_option')."/".$id_param_pulldown;
        
        $data['back_url'] = site_url('Fintech_Site/B_param_pulldown/update_pulldown')."/".$id_param_pulldown;
        $data['form_url'] = site_url('Fintech_Site/B_param_pulldown/create_pulldown_option')."/".$id_param_pulldown;

        $data['data_pulldown'] = $this->param_model->get_pulldown_by_id($id_param_pulldown);
        $data['data_groups'] = $this->groups_model->get_groups($access_groups);

    
        $this->form_validation->set_rules("pulldown_option_description", "Nama pulldown", "trim|required");
        $this->form_validation->set_rules("id_param_pulldown", "id pulldown", "trim|required");
   
        if ($this->form_validation->run() == true){
            
            $id_param_pulldown = $this->input->post('id_param_pulldown');
            $pulldown_option_description = $this->input->post('pulldown_option_description');
        
                        $data_pulldown_option = array(
                        'id_param_pulldown' => $id_param_pulldown,
                        'pulldown_option_description' => $pulldown_option_description
                        );

                        $insert_pulldown = $this->crud_model->insert('tb_param_pulldown_option',$data_pulldown_option);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Fintech_Site/B_param_pulldown/create_pulldown_option/'.$id_param_pulldown);
                        die();
                    
        
        }

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-fintech/parameter/pulldown/pulldown-option-form', $data);
        $this->load->view('backend-web/partial/footer');

    }

	public function update_pulldown()
	{

		$id_param_pulldown = $this->uri->segment(4);
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Detail Pulldown";
		$data['brd_title_main'] = "Pulldown Parameter";
		$data['brd_title_url'] = site_url('Fintech_Site/B_param_pulldown');
		$data['brd_title_sub'] = "Detail Pulldown";
		$data['brd_title_url_sub'] = site_url('Fintech_Site/B_param_pulldown/update_pulldown')."/".$id_param_pulldown;

		$data['form_url'] = site_url('Fintech_Site/B_param_pulldown/update_pulldown');
		$data['back_url'] = site_url('Fintech_Site/B_param_pulldown');

        $data['create_url'] = site_url('Fintech_Site/B_param_pulldown/create_pulldown_option')."/".$id_param_pulldown;
        $data['delete_url'] = site_url('Fintech_Site/B_param_pulldown/delete_pulldown_option');

		$data['data_pulldown'] = $this->param_model->get_pulldown_by_id($id_param_pulldown);
        $data['data_pulldown_option'] = $this->param_model->get_pulldown_option($id_param_pulldown);

		$this->form_validation->set_rules("id_param_pulldown", "id parameter pulldown", "trim|required");
		$this->form_validation->set_rules("pulldown_name", "Nama pulldown", "trim|required");
	
		if ($this->form_validation->run() == true){

			$id_param_pulldown = $this->input->post('id_param_pulldown');
			$pulldown_name = $this->input->post('pulldown_name');
			$pulldown_access_status = $this->input->post('pulldown_access_status');
			
						$data_pulldown = array(

						'id_param_pulldown' => $id_param_pulldown,
						'pulldown_name' => $pulldown_name,
						'pulldown_access_status' => $pulldown_access_status
						);

						$update_pulldown = $this->crud_model->update('tb_param_pulldown','id_param_pulldown',$id_param_pulldown,$data_pulldown);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_param_pulldown/update_pulldown/'.$id_param_pulldown);
						die();

		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/parameter/pulldown/pulldown-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function delete_pulldown()
	{
		$id_param_pulldown = $this->uri->segment(4);
		
		if (!empty($id_param_pulldown)){

					$this->crud_model->delete('tb_param_pulldown','id_param_pulldown',$id_param_pulldown);
					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'Fintech_Site/B_param_pulldown');
					die();


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Fintech_Site/B_param_pulldown');
			die();
		}
	}

    public function delete_pulldown_option()
    {
        $id_param_pulldown = $this->uri->segment(4);
        $id_param_pulldown_option = $this->uri->segment(5);
        
        if (!empty($id_param_pulldown) AND !empty($id_param_pulldown_option)){

                    $this->crud_model->delete('tb_param_pulldown_option','id_param_pulldown_option',$id_param_pulldown_option);
                    $this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
                    redirect(base_url().'Fintech_Site/B_param_pulldown/update_pulldown/'.$id_param_pulldown);
                    die();


        } else {
            $this->session->set_flashdata('alert_error', 'Data failed to Delete !');
            redirect(base_url().'Fintech_Site/B_param_pulldown/update_pulldown/'.$id_param_pulldown);
            die();
        }
    }

}

?>
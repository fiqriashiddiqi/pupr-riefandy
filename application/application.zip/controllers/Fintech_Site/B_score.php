<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_score extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Front_Fintech/score_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '4');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }
	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Score Pages";
		$data['brd_title_url'] = site_url('Fintech_Site/B_score');
		$data['brd_title_main'] = "Score";
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['update_url'] = site_url('Fintech_Site/B_score/update_score');

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/score/score_list', $data);
		$this->load->view('backend-web/partial/footer');
	}

	public function access_status_exchange()
	{

		$id_score = $this->input->post('id_score');
		$data_score = $this->score_model->get_score_by_id($id_score);
		$score_status = $data_score[0]->score_status;

		if ($score_status == "Deactivated"){

			$data_exchange = array(
			'score_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'score_status' => 'Deactivated'
			);

		}
							
		$update_score = $this->crud_model->update('tb_param_score','id_score',$id_score,$data_exchange);

	}

	public function update_score()
	{

		$id_score = $this->uri->segment(4);
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Detail Score";
		$data['brd_title_main'] = "Score";
		$data['brd_title_url'] = site_url('Fintech_Site/B_score');
		$data['brd_title_sub'] = "Detail Score";

		$data['form_url'] = site_url('Fintech_Site/B_score/update_score');
		$data['back_url'] = site_url('Fintech_Site/B_score');

		$data['profile_true'] = "backdoor";

		$where_score = array('id_score' => $id_score);
		$data['data_score'] = $this->crud_model->get_data('tb_param_score', $where_score)->result();


		$this->form_validation->set_rules("id_score", "id", "trim|required");
		$this->form_validation->set_rules("score_description", "", "trim|required");
		$this->form_validation->set_rules("score_startrate", "", "trim|required");
		$this->form_validation->set_rules("score_endrate", "", "trim|required");
		$this->form_validation->set_rules("score_rating", "", "trim|required");
		$this->form_validation->set_rules("interest_rate", "", "trim|required");
		$this->form_validation->set_rules("score_status", "Access Status ", "trim|required");


		if ($this->form_validation->run() == true){

			$id_score = $this->input->post('id_score');
			$score_description = $this->input->post('score_description');
			$score_startrate = $this->input->post('score_startrate');
			$score_endrate = $this->input->post('score_endrate');
			$score_rating = $this->input->post('score_rating');
			$interest_rate = $this->input->post('interest_rate');
			$score_status = $this->input->post('score_status');



						$data_score = array(
                        'id_score' => $id_score,
						'score_description' => $score_description,
						'score_startrate' => $score_startrate,
						'score_endrate' => $score_endrate,
						'score_rating' => $score_rating,
						'interest_rate' => $interest_rate,
						'score_status' => $score_status
						);

						$update_score = $this->crud_model->update('tb_param_score','id_score',$id_score, $data_score);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_score/update_score/'.$id_score);
						die();
		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/score/score_form_update', $data);
		$this->load->view('backend-web/partial/footer');

	}


}

?>
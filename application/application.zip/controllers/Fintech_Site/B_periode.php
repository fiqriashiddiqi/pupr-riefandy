<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_periode extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Front_Fintech/periode_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '4');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }
	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Periode Pages";
		$data['brd_title_url'] = site_url('Fintech_Site/B_periode');
		$data['brd_title_main'] = "Score";
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['update_url'] = site_url('Fintech_Site/B_periode/update_periode');

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/periode/periode-list', $data);
		$this->load->view('backend-web/partial/footer');
	}

	public function access_status_exchange()
	{

		$id_periode = $this->input->post('id_periode');
		$data_periode = $this->periode_model->get_periode_by_id($id_periode);
		$periode_access_status = $data_periode[0]->periode_access_status;

		if ($periode_access_status == "Deactivated"){

			$data_exchange = array(
			'periode_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'periode_access_status' => 'Deactivated'
			);

		}
							
		$update_periode = $this->crud_model->update('tb_fintech_periode','id_periode',$id_periode,$data_exchange);

	}

	public function update_periode()
	{

		$id_periode = $this->uri->segment(4);
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Detail Periode";
		$data['brd_title_main'] = "Periode";
		$data['brd_title_url'] = site_url('Fintech_Site/B_periode');
		$data['brd_title_sub'] = "Detail Periode";

		$data['form_url'] = site_url('Fintech_Site/B_periode/update_periode');
		$data['back_url'] = site_url('Fintech_Site/B_periode');

		$data['profile_true'] = "backdoor";

		$where_score = array('id_periode' => $id_periode);
		$data['data_periode'] = $this->crud_model->get_data('tb_fintech_periode', $where_score)->result();


		$this->form_validation->set_rules("id_periode", "id", "trim|required");
		$this->form_validation->set_rules("periode", "", "trim|required");
		$this->form_validation->set_rules("score", "", "trim|required");
		$this->form_validation->set_rules("periode_access_status", "Access Status ", "trim|required");


		if ($this->form_validation->run() == true){

			$id_periode = $this->input->post('id_periode');
			$periode = $this->input->post('periode');
			$score = $this->input->post('score');
			$periode_access_status = $this->input->post('periode_access_status');



						$data_periode = array(
                        'id_periode' => $id_periode,
						'periode' => $periode,
						'score' => $score,
						'periode_access_status' => $periode_access_status
						);

						$update_periode = $this->crud_model->update('tb_fintech_periode','id_periode',$id_periode, $data_periode);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Fintech_Site/B_periode/update_periode/'.$id_periode);
						die();
		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-fintech/periode/periode-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}


}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_login extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('Website/artikel_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/slideshow_model');
        $this->load->model('Front_Fintech/auth_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('crud_model');
        $this->load->library('form_validation');

        date_default_timezone_set("Asia/Jakarta");
        $url = site_url();
    }

    public function auth()
	{	

        // $this->form_validation->set_rules("reg_email", "Email", "trim|required");
		$this->form_validation->set_rules("reg_code", "User ID", "trim|required");
		$this->form_validation->set_rules("reg_password", "Password", "trim|required");

		if ($this->form_validation->run() == true){

            $db = get_instance()->db->conn_id;

            // $reg_email = mysqli_real_escape_string($db, $this->input->post('reg_email'));    
			$reg_code = mysqli_real_escape_string($db, $this->input->post('reg_code'));
			$reg_password = mysqli_real_escape_string($db, sha1($this->input->post('reg_password')));

			$check_validation = $this->auth_model->check_validate($reg_code, $reg_password)->num_rows();

				if($check_validation > 0){

					$data = $this->auth_model->data_validate($reg_code, $reg_password);

                    if ($data[0]->register_status == 'Lender'){
                        $data_session = array(
                            // 'reg_email' => $data[0]->register_email,
                            'reg_code' => $data[0]->register_code,
                            'reg_password' => $data[0]->register_password,
                            'reg_access_status' => $data[0]->register_access_status,
                            'reg_activation_status' => $data[0]->register_activation_status,
                            'reg_status' => $data[0]->register_status
                        );

                    } else if ($data[0]->register_status == 'Borrower'){
                        $data_session = array(
                            // 'reg_email' => $data[0]->register_email,
                            'reg_code' => $data[0]->register_code,
                            'reg_password' => $data[0]->register_password,
                            'reg_access_status' => $data[0]->register_access_status,
                            'reg_activation_status' => $data[0]->register_activation_status,
                            'reg_status' => $data[0]->register_status
                        );
                    } else {
                        $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                        $this->session->set_flashdata('alert_error', 'Your not have access !!');
                        redirect(base_url().'Finance/F_login/login');
                        die();
                    }

					$this->session->set_userdata($data_session);
					$date = date('Y-m-d H:i:s');
                    $reg_code = $data[0]->register_code;
                    $data_users_update = array('register_last_signin' => $date);
                    $update_users = $this->crud_model->update('tb_fintech_register', 'register_code', $reg_code, $data_users_update);

                        if($data[0]->register_status == 'Lender'){
                            $flashDate = date("h:i:s - d/m/Y", strtotime($date));
                            $this->session->set_flashdata('alert_success', 'Your sign in date is : '.$flashDate);
                            redirect(base_url().'Finance/f_lender');
                            die();
                        } else {
                            $flashDate = date("h:i:s - d/m/Y", strtotime($date));
                            $this->session->set_flashdata('alert_success', 'Your sign in date is : '.$flashDate);
                            redirect(base_url().'Finance/f_borrower');
                            die();
                        }

                } else {

                        $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                        $this->session->set_flashdata('alert_error', 'The account you entered is wrong, try again !');
                        redirect(base_url().'Finance/F_login/login');
                        die();

                }
		} else {
            $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
            $this->session->set_flashdata('alert_error', 'The account you entered is wrong, try again !');
            redirect(base_url().'Finance/F_login/login');
            die();
        }
    }

    public function login()
    {
        $navigation['lender_active'] = "";
        $navigation['style_login'] = "orange";

        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Home');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['form_url'] = site_url('Finance/F_login/auth');
        $data['forgot_url'] = site_url('Finance/F_login/forgot_password');
        
        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-web/partial/navigation' , $navigation);
        $this->load->view('frontend-fintech/login' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar');

    }

    public function forgot_password()
    {
        $navigation['lender_active'] = "";

        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Home');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['form_url'] = site_url('Finance/F_login/forgot_password');

        $this->form_validation->set_rules("reg_email", "Email", "trim|required");

        if ($this->form_validation->run() == true){
            $db = get_instance()->db->conn_id;
            $reg_email =  mysqli_real_escape_string($db, $this->input->post('reg_email'));

            $where = array('register_email' => $reg_email, 'register_access_status' => 'Activated', 'register_activation_status' => 'Activated');
            $check_email = $this->crud_model->get_data("tb_fintech_register",$where)->num_rows();

            if($check_email > 0){
                $data_reg = $this->crud_model->get_data("tb_fintech_register",$where)->result();

                $title = "Sanders Fintech Reset Password";

                $register_code = $data_reg[0]->register_code;
                $code = $data_reg[0]->register_code; 
                $email = $data_reg[0]->register_email;
                $code = rand(100000,99999999);

                // $message = "
                //     Visit the link below to change your password with a new one. \n\n
                //     https://www.sanders.co.id/Finance/F_login/new_pass?SA=".$code.". \n\n
                //     \n\n MESSAGE NO-REPLY";

                // $header = "From: sanders@sanders.co.id<no-reply@sanders.co.id>";

                // mail($email, $title, $message, $header);
                $config = array();
                                    $config['charset'] = 'iso-8859-1';
                                    $config['useragent'] = 'Codeigniter';
                                    $config['protocol']= 'smtp';
                                    $config['mailtype']= 'html';
                                    $config['smtp_host']= 'ssl://mail.heatcliffs31.com';//pengaturan smtp
                                    $config['smtp_port']= 465;
                                    $config['smtp_timeout']= 400;
                                    $config['smtp_user']= 'sanders@heatcliffs31.com'; // isi dengan email kamu
                                    $config['smtp_pass']= '1q2w3e4r5t'; // isi dengan password kamu
                                    $config['crlf']="\r\n"; 
                                    $config['newline']="\r\n"; 
                                    $config['wordwrap'] = TRUE;
                                    //memanggil library email dan set konfigurasi untuk pengiriman email
                                   $this->load->library('email',$config);
                                    $this->email->initialize($config);
                                    $data_users_update = array(
                                        'register_activation_code' => $code,
                                    );
                                    //konfigurasi pengiriman
                                    $this->email->from($config['smtp_user']);
                                    $this->email->to($email);
                                    $this->email->subject($title);
                                    $body = $this->load->view('frontend-fintech/email_changepass.php',$data_users_update,TRUE);
                                    $this->email->message($body);
                                    $this->email->send();
                

                $update_users = $this->crud_model->update('tb_fintech_register', 'register_code', $register_code, $data_users_update);
                $this->session->set_flashdata('alert_success', 'We send an email, please check your email to reset your password.');
                redirect(base_url().'Finance/F_login/login');
                die();

            } else {
                $this->session->set_flashdata('alert_error', 'Your email was not found !');
                redirect(base_url().'Finance/F_login/forgot_password');
                die();
            }
        } 

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-web/partial/navigation' , $navigation);
        $this->load->view('frontend-fintech/forgot' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar');

    }

    public function new_pass()
    {
        $navigation['lender_active'] = "";

        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Home');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $code = isset($_REQUEST['SA']) ? $_REQUEST['SA'] : NULL;

        $data['code'] = $code;
        $data['form_url'] = site_url("Finance/F_login/new_pass");

        $this->form_validation->set_rules("code", "", "trim|required");
        $this->form_validation->set_rules("reg_password", "password", "trim|required");
        $this->form_validation->set_rules("reg_password_verify", "password", "trim|required");

        if ($this->form_validation->run() == true){
            $db = get_instance()->db->conn_id;

            $code = $this->input->post('code');

            $reg_password =  mysqli_real_escape_string($db, sha1($this->input->post('reg_password')));
            $reg_password_verify =  mysqli_real_escape_string($db, sha1($this->input->post('reg_password_verify')));

            $where_check = array('register_activation_code' => $code, 'register_access_status' => 'Activated', 'register_activation_status' => 'Activated');

            $check = $this->crud_model->get_data("tb_fintech_register",$where_check)->num_rows();
            $check_data = $this->crud_model->get_data("tb_fintech_register",$where_check)->result();

            $reg_code = $check_data[0]->register_code;
            
            if($check == 1){
                if($reg_password == $reg_password_verify){

                    $data_users_update = array(
                        'register_password' => $reg_password 
                    );

                    $update_users = $this->crud_model->update('tb_fintech_register', 'register_code', $reg_code, $data_users_update);
                    $this->session->set_flashdata('alert_success', 'You have successfully changed your password. please login with your new password');
                    redirect(base_url().'Finance/F_login/login');
                    die();

                } else {
                    $this->session->set_flashdata('alert_error', 'Your Password Not Same !');
                    redirect(base_url()."Finance/F_login/new_pass?SA=".$code);
                    die();
                }
            } else {
                    $this->session->set_flashdata('alert_error', 'your data is not found !');
                    redirect(base_url()."Finance/F_login/new_pass?SA=".$code);
                    die();
            }

        } 

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-web/partial/navigation' , $navigation);
        $this->load->view('frontend-fintech/new_pass', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar');

    }

    public function signout()
    {   

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');



        if (isset($reg_code) AND isset($reg_password) AND isset($reg_access_status) AND isset($reg_activation_status) AND isset($reg_status)){
            $data = $this->auth_model->data_validate($reg_code, $reg_password);

            $date = date('Y-m-d H:i:s');

            $register_code = $data[0]->register_code;
            $data_users_update = array('register_last_signout' => $date);
            $update_users = $this->crud_model->update('tb_fintech_register', 'register_code', $register_code, $data_users_update);

        }

        $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
        $this->session->sess_destroy();

        redirect(base_url().'Finance/F_login/login');
        die();
        
    }
}
?>
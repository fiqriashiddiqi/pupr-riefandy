<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_borrower extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Website/artikel_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/slideshow_model');
        $this->load->model('Website/video_model');
        $this->load->model('Website/users_model');
        $this->load->model('Website/management_model');
        $this->load->model('Front_Fintech/personal_info_model');
        $this->load->model('Front_Fintech/auth_model');
        $this->load->model('Front_Fintech/indonesia_model');
        $this->load->model('Front_Fintech/bank_model');
        $this->load->model('Front_Fintech/register_model');
        $this->load->model('Front_Fintech/loan_model');
        $this->load->model('Front_Fintech/score_model');
        $this->load->model('Front_Fintech/payment_model');
        $this->load->model('Front_Fintech/account_model');
        $this->load->model('Front_Fintech/connection_model');
        $this->load->model('Parameter/parameter_all_model');
        $this->load->model('Parameter/param_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('crud_model');

        date_default_timezone_set("Asia/Jakarta");
        

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);


            if (!isset($reg_code) && !isset($reg_password) && !isset($reg_access_status) && !isset($reg_activation_status) && !isset($reg_status)){
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'Finance/F_login/login');
                die();
            }

            if($check_access[0]->register_activation_status != "Activated"){
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_error', 'You do not have access to this page, Or your account not yet activated !');
                redirect(base_url().'Finance/F_login/login');
                die();
            }

            if($check_access[0]->register_access_status != "Activated"){
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'Finance/F_login/login');
                die();
            }

            if($check_access[0]->register_status != "Borrower"){
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'Finance/F_login/login');
                die();
            }
    }

    public function index()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $data['get_code'] = $register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['htgs_active'] = "active";

        $data['data_video'] = $this->video_model->get_video();
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'HTGS Borrower');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/htgs' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

   public function personal_info_borrower()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();

        $navigation['personal_info_borrower_active'] = "active";
        $data['edit_url'] = site_url('Finance/F_borrower/personal_update');

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);

        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/personal_info_borrower',$data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function personal_update()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');
        
        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();

        $navigation['borrower_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('borrower');
        $footer['data_contact'] = $this->contact_model->get_contact();
        
        $data['form_url'] = site_url('Finance/F_borrower/personal_update');
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['get_code'] = $register_code;

        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);
        $data['data_indonesia'] = $this->indonesia_model->get_province();

        $this->load->helper('file');
        
        $this->form_validation->set_rules("bio_fullname", "", "required");
        $this->form_validation->set_rules("bio_place_birth_date", "", "trim|required");
        $this->form_validation->set_rules("bio_birth_date", "", "trim|required");
        $this->form_validation->set_rules("bio_gender", "", "trim|required");
        $this->form_validation->set_rules("bio_phone", "", "trim|required");
        $this->form_validation->set_rules("bio_marriage_status", "", "trim|required");
        $this->form_validation->set_rules("bio_occupation", "", "trim|required");
        $this->form_validation->set_rules("bio_address", "", "trim|required");
        $this->form_validation->set_rules("bio_post_code", "", "trim|required");
        $this->form_validation->set_rules("bio_mother_name", "", "trim|required");
        $this->form_validation->set_rules("bio_last_education", "last education", "trim|required");
        $this->form_validation->set_rules("bio_cityzenship", "cityzenship", "trim|required");       

        if ($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');
            $bio_fullname = $this->input->post('bio_fullname');
            $bio_place_birth_date = $this->input->post('bio_place_birth_date');
            $bio_birth_date = $this->input->post('bio_birth_date');
            $bio_gender = $this->input->post('bio_gender');
            $bio_phone = $this->input->post('bio_phone');
            $bio_marriage_status = $this->input->post('bio_marriage_status');
            $bio_spouse_name = $this->input->post('bio_spouse_name');
            $bio_spouse_phone = $this->input->post('bio_spouse_phone');
            $bio_occupation = $this->input->post('bio_occupation');
            $bio_occupation_others = $this->input->post('bio_occupation_others');
            $bio_address = $this->input->post('bio_address');
            $bio_post_code = $this->input->post('bio_post_code');    
            $bio_mother_name = $this->input->post('bio_mother_name'); 
            $bio_last_education = $this->input->post('bio_last_education');
            $bio_cityzenship = $this->input->post('bio_cityzenship'); 

            if ($bio_cityzenship == 'WNI'){
                // $bio_nik = $this->input->post('bio_nik');  
                $bio_province = $this->input->post('bio_province_select');
                $bio_city = $this->input->post('bio_city_select');
                $bio_district = $this->input->post('bio_district_select');
                $bio_village = $this->input->post('bio_village_select');
                $bio_upload_nik = $this->input->post('bio_upload_nik'); 

                
            } else {
                // $bio_passport = $this->input->post('bio_passport');  
                $bio_province = $this->input->post('bio_province');
                $bio_city = $this->input->post('bio_city');
                $bio_upload_passport = $this->input->post('bio_upload_passport');   
            }

            if ($bio_occupation == "Others" And !empty($bio_occupation_others)){
                $bio_occupation = $bio_occupation_others;
            }

            if (empty($bio_reference_code)){
                 $bio_reference_code = "-";
            }

            if ($bio_marriage_status == "Single"){
                 $bio_spouse_name = "-";
                 $bio_spouse_phone = "-";
            }

            if ($bio_cityzenship == 'WNI'){
                if(!empty($_FILES['bio_upload_nik']['name'])){
                    $name_file = $bio_fullname."_".time();
                    $config['upload_path'] = './uploads/Fintech/ktp_borrower';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size']     = '5120';
                    $config['file_name'] = $name_file;

                    $this->load->library('upload', $config);

                    if(!$this->upload->do_upload('bio_upload_nik')){
                        $this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
                        redirect(base_url().'Finance/F_borrower/personal_update/'.$register_code);
                        die();
                    } else {
                        $file_data = $this->upload->data();
                        $data_bio= $this->personal_info_model->get_bio_borrower_by_id($register_code);
                        $file_path= './uploads/Fintech/ktp_borrower/'.$data_bio[0]->bio_upload_nik;

                        @unlink($file_path);
                          $data_bio = array(
                            'register_code' => $register_code,
                            'bio_fullname' => $bio_fullname,
                            'bio_place_birth_date' => $bio_place_birth_date,
                            'bio_birth_date' => $bio_birth_date,
                            'bio_gender' => $bio_gender,
                            'bio_phone' => $bio_phone,
                            'bio_marriage_status' => $bio_marriage_status,
                            'bio_spouse_name' => $bio_spouse_name,
                            'bio_spouse_phone' => $bio_spouse_phone,
                            'bio_occupation' => $bio_occupation,
                            'bio_address' => $bio_address,
                            'bio_province' => $bio_province,
                            'bio_city' => $bio_city,
                            'bio_district' => $bio_district,
                            'bio_village' => $bio_village,
                            'bio_post_code' => $bio_post_code,
                            'bio_mother_name' => $bio_mother_name,
                            'bio_last_education' => $bio_last_education,
                            // 'bio_nik' => $bio_nik,
                            'bio_upload_nik' => $file_data['file_name']
                            );

                        $update_bio = $this->crud_model->update('tb_fintech_borrower_bio', 'register_code', $register_code, $data_bio);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_borrower/personal_info_borrower');
                        die();
                 }

             }else{


                          $data_bio = array(
                            'register_code' => $register_code,
                            'bio_fullname' => $bio_fullname,
                            'bio_place_birth_date' => $bio_place_birth_date,
                            'bio_birth_date' => $bio_birth_date,
                            'bio_gender' => $bio_gender,
                            'bio_phone' => $bio_phone,
                            'bio_marriage_status' => $bio_marriage_status,
                            'bio_spouse_name' => $bio_spouse_name,
                            'bio_spouse_phone' => $bio_spouse_phone,
                            'bio_occupation' => $bio_occupation,
                            'bio_address' => $bio_address,
                            'bio_province' => $bio_province,
                            'bio_city' => $bio_city,
                            'bio_district' => $bio_district,
                            'bio_village' => $bio_village,
                            'bio_post_code' => $bio_post_code,
                            'bio_reference_code' => $bio_reference_code,
                            'bio_mother_name' => $bio_mother_name,
                            'bio_last_education' => $bio_last_education
                            // 'bio_nik' => $bio_nik
                            // 'bio_upload_nik' => $file_data['file_name']
                            );

                        $update_bio = $this->crud_model->update('tb_fintech_borrower_bio', 'register_code', $register_code, $data_bio);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_borrower/personal_info_borrower');
                        die();

             }
        } else {
                if(!empty($_FILES['bio_upload_passport']['name'])){
                    $name_file = $bio_fullname."_".time();
                    $config['upload_path'] = './uploads/Fintech/passport_borrower';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size']     = '5120';
                    $config['file_name'] = $name_file;

                    $this->load->library('upload', $config);

                    if(!$this->upload->do_upload('bio_upload_passport')){
                        $this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
                        redirect(base_url().'Finance/F_borrower/personal_update/'.$register_code);
                        die();
                    } else {
                        $file_data = $this->upload->data();
                        $data_bio= $this->personal_info_model->get_bio_borrower_by_id($register_code);
                        $file_path= './uploads/Fintech/passport_borrower/'.$data_bio[0]->bio_upload_passport;

                        @unlink($file_path);
                        $data_bio = array(
                                'register_code' => $register_code,
                                'bio_fullname' => $bio_fullname,
                                'bio_place_birth_date' => $bio_place_birth_date,
                                'bio_birth_date' => $bio_birth_date,
                                'bio_gender' => $bio_gender,
                                'bio_phone' => $bio_phone,
                                'bio_marriage_status' => $bio_marriage_status,
                                'bio_spouse_name' => $bio_spouse_name,
                                'bio_spouse_phone' => $bio_spouse_phone,
                                'bio_occupation' => $bio_occupation,
                                'bio_address' => $bio_address,
                                'bio_province' => $bio_province,
                                'bio_city' => $bio_city,
                                'bio_mother_name' => $bio_mother_name,
                                'bio_post_code' => $bio_post_code,
                                'bio_last_education' => $bio_last_education,
                                // 'bio_passport' => $bio_passport,
                                'bio_upload_passport' => $file_data['file_name']
                        );
                        $update_bio = $this->crud_model->update('tb_fintech_borrower_bio', 'register_code', $register_code,  $data_bio);
                        print_r($data_bio);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_borrower/personal_info_borrower');

                        die();
                    }

                } else {
                     $data_bio = array(
                                'register_code' => $register_code,
                                'bio_fullname' => $bio_fullname,
                                'bio_place_birth_date' => $bio_place_birth_date,
                                'bio_birth_date' => $bio_birth_date,
                                'bio_gender' => $bio_gender,
                                'bio_phone' => $bio_phone,
                                'bio_marriage_status' => $bio_marriage_status,
                                'bio_spouse_name' => $bio_spouse_name,
                                'bio_spouse_phone' => $bio_spouse_phone,
                                'bio_occupation' => $bio_occupation,
                                'bio_mother_name' => $bio_mother_name,
                                'bio_address' => $bio_address,
                                'bio_province' => $bio_province,
                                'bio_city' => $bio_city,
                                'bio_post_code' => $bio_post_code,
                                'bio_last_education' => $bio_last_education
                        );
                        $update_bio = $this->crud_model->update('tb_fintech_borrower_bio', 'register_code', $register_code,  $data_bio);
                        print_r($data_bio);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_borrower/personal_info_borrower');

                        die();

                }
            }
        }
        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2',$navigation);
        $this->load->view('frontend-fintech/borrower/personal_update_borrower', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function data_bank_borrower()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();

        $navigation['personal_info_borrower_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['data_code'] = $this->bank_model->get_bank_borrower($register_code);
        $data['edit_url'] = site_url('Finance/F_borrower/bank_update_borrower');

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/data_bank_borrower' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function bank_update_borrower()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');
        
        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        
        $navigation['borrower_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('borrower');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['form_url'] = site_url('Finance/F_borrower/bank_update_borrower');
        $data['data_code'] = $this->bank_model->get_bank_borrower($register_code);

        $this->form_validation->set_rules("register_code", "", "required");
        $this->form_validation->set_rules("your_bank_name", "", "required");
        $this->form_validation->set_rules("bank_account", "", "required");
        $this->form_validation->set_rules("bank_name", "", "trim|required");
        $this->form_validation->set_rules("bank_branch", "", "trim|required");
     

        if ($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');
            $your_bank_name = $this->input->post('your_bank_name');
            $bank_account = $this->input->post('bank_account');
            $bank_name = $this->input->post('bank_name');
            $bank_branch = $this->input->post('bank_branch');   

            $where = array('register_code' => $register_code);
            $data_check = $this->crud_model->get_data("tb_fintech_borrower_bank", $where)->num_rows();

            if($data_check == 0){
                $data_bank = array(
                    'register_code' => $register_code,
                    'your_bank_name' => $your_bank_name,
                    'bank_account' => $bank_account,
                    'bank_name' => $bank_name,
                    'bank_branch' => $bank_branch
                            
                    );

                $insert_bank = $this->crud_model->insert('tb_fintech_borrower_bank', $data_bank);
                $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                redirect(base_url().'Finance/F_borrower/data_bank_borrower');
                die();

            } else {
                $data_bank = array(
                    'bank_account' => $bank_account,
                    'your_bank_name' => $your_bank_name,
                    'bank_name' => $bank_name,
                    'bank_branch' => $bank_branch
                            
                    );

                $update_bank = $this->crud_model->update('tb_fintech_borrower_bank', 'register_code', $register_code,  $data_bank);
                $this->session->set_flashdata('alert_success', 'Data successfully Updated.');
                redirect(base_url().'Finance/F_borrower/data_bank_borrower');
                die();
            }                 
        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2',$navigation);
        $this->load->view('frontend-fintech/borrower/bank_update_borrower', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function change_password_borrower()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);
        $register_code = $check_access[0]->register_code;

        $data['get_code'] = $register_code;
        $where = array('register_code' => $register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['personal_info_borrower_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();
        $data['form_url'] = site_url('Finance/F_borrower/change_password_borrower');

        $data['data_code'] = $this->register_model->get_register_by_id($register_code);

        $this->form_validation->set_rules("register_code", "", "required");
        $this->form_validation->set_rules("old_register_password", "", "trim|required");
        $this->form_validation->set_rules("new_register_password", "", "trim|required");
        $this->form_validation->set_rules("new_register_re_password", "", "trim|required");
     

        if ($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');
            $old_register_password = sha1($this->input->post('old_register_password'));
            $new_register_password = sha1($this->input->post('new_register_password'));
            $new_register_re_password = sha1($this->input->post('new_register_re_password'));

            $where = array('register_password' => $old_register_password ,'register_code' => $register_code) ;
            $data_check = $this->crud_model->get_data("tb_fintech_register", $where)->num_rows();

            if($data_check == 1){
                if ($new_register_password == $new_register_re_password ) {

                $data_register = array(
                    'register_password' => $new_register_password
                    );

                $update_bank = $this->crud_model->update('tb_fintech_register', 'register_code', $register_code,  $data_register);
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_success', 'Password Has Been Changed, Please Login With New Password');
                redirect(base_url().'Finance/F_login/login');
                die();

                }else{

                $this->session->set_flashdata('alert_error', 'Password Not Match .');
                redirect(base_url().'Finance/F_borrower/change_password_borrower');
                }
            } else{

                $this->session->set_flashdata('alert_error', 'wrong old-password .');
                redirect(base_url().'Finance/F_borrower/change_password_borrower');

            }              
        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/change_password_borrower' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function payment()
    {  

        $navigation['payment_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        // $data['data_code'] = $this->bank_model->get_bank_borrower($register_code);
        $data['edit_url'] = site_url('Finance/F_borrower/bank_update_borrower');
        $data['data_contact'] = $this->contact_model->get_contact(); 

        $footer['data_contact'] = $this->contact_model->get_contact();
        

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2', $navigation);
        $this->load->view('frontend-fintech/borrower/payment' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function withdrawal_borrower()
    {
        $navigation['withdrawal_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_code'] = $this->bank_model->get_bank_borrower($register_code);
        $data['edit_url'] = site_url('Finance/F_borrower/withdrawal_prosses');
         

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/withdrawal_borrower' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function withdrawal_prosses()
    {
        $navigation['withdrawal_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_code'] = $this->bank_model->get_bank_borrower($register_code);
        $data['form_url'] = site_url('Finance/F_borrower/withdrawal_prosses');
         
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->form_validation->set_rules("withdrawal_amount", "", "trim|required");
        //$this->form_validation->set_rules("withdrawal_reason", "", "trim|required");
        $this->form_validation->set_rules("your_bank_name", "", "trim|required");
        $this->form_validation->set_rules("bank_account", "", "trim|required");
        $this->form_validation->set_rules("bank_name", "", "trim|required");
        $this->form_validation->set_rules("bank_branch", "", "trim|required");
     

        if ($this->form_validation->run() == true){
            $withdrawal_amount  = $this->input->post('withdrawal_amount');
            $withdrawal_reason = "-";
            $your_bank_name = $this->input->post('your_bank_name');
            $bank_account = $this->input->post('bank_account');
            $bank_name = $this->input->post('bank_name');
            $bank_branch = $this->input->post('bank_branch');

            $where = array('register_code' => $register_code) ;
            $data_check = $this->crud_model->get_data("tb_fintech_borrower_fund", $where)->num_rows();
            $fund_data = $this->crud_model->get_data("tb_fintech_borrower_fund", $where)->result();

            $date = date('Y-m-d H:i:s');

            $_POST['withdrawal_amount'] = $withdrawal_amount;
            $clean = preg_replace('/\D/','',$_POST['withdrawal_amount']);

            $data_setting = $this->crud_model->get_setting();
            $fee_pg = $data_setting[0]->fee_pg;
            $clean_amount = $clean - $fee_pg;

            if($clean < $fee_pg) {
                $this->session->set_flashdata('alert_error', 'Withdrawal Failed!!, your withdrawal amount must be more than Rp'.number_format($fee_pg,0,".",".").'');
                redirect(base_url().'Finance/F_borrower/withdrawal_borrower');
                die();
            }

            if($data_check == 1 AND $fund_data[0]->amount >= $clean){

                $data_withdraw = array(
                    'register_code' => $register_code,
                    'withdrawal_amount' => $clean,
                    'withdrawal_reason' => $withdrawal_reason,
                    'withdrawal_date' => $date,
                    'your_bank_name' => $your_bank_name,
                    'bank_account' => $bank_account,
                    'bank_name' => $bank_name,
                    'bank_branch' => $bank_branch,
                    'withdrawal_status' => 'Success'
                            
                    );

                $insert_withdraw = $this->crud_model->insert('tb_fintech_borrower_withdrawal', $data_withdraw);

                // // GL OTOMATIS
                // // Kode Jurnal
                $idMaxgl = $this->journal_model->journal_code();
                $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                $noUrutgl ++;
                $date_codegl = date('m/y');
                $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;

                // Drawdown Pinjaman (Pemindahan dana Pinjaman dari VA Peminjam ke Rek Pribadi Peminjam) debit
                $data_journal1 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 130, // cek lagi ID coa E nya Takut belum benar daftar coa belum komplit
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Drawdown Pinjaman (Pemindahan dana Pinjaman  dari VA Peminjam ke Rek Pribadi Peminjam)'.'-'.$register_code,
                            // 'journal_description_form' => 'Drawdown - '.$register_code,
                            'journal_debit' => $clean,
                            'journal_kredit' => 0,
                            'cashflow_code_status' => '0',
                            'journal_status' => '0'
                            );

                $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                // Drawdown Pinjaman (Pemindahan dana Pinjaman dari VA Peminjam ke Rek Pribadi Peminjam) credit
                $data_journal2 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 131, // cek lagi ID coa E nya Takut belum benar daftar coa belum komplit
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Drawdown Pinjaman (Pemindahan dana Pinjaman dari VA Peminjam ke Rek Pribadi Peminjam)'.'-'.$register_code,
                            // 'journal_description_form' => 'Biaya PG - '.'-'.$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $fee_pg,
                            'cashflow_code_status' => '0',
                            'journal_status' => '0'
                            );

                $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);

                // Drawdown Pinjaman (Pemindahan dana Pinjaman dari VA Peminjam ke Rek Pribadi Peminjam) credit
                $data_journal3 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 128, // cek lagi ID coa E nya Takut belum benar daftar coa belum komplit
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Drawdown Pinjaman (Pemindahan dana Pinjaman dari VA Peminjam ke Rek Pribadi Peminjam)'.'-'.$register_code,
                            // 'journal_description_form' => 'Escrow' .$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $clean_amount,
                            'cashflow_code_status' => '0',
                            'journal_status' => '0'
                            );

                $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                // Kode Jurnal 2
                $idMaxgl2 = $this->journal_model->journal_code();
                $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                $noUrutgl2 ++;
                $date_codegl2 = date('m/y');
                $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                // Pemindahan Dana PG debit
                $data_journal4 = array(
                            'journal_no' => $newIDgl2,
                            'id_param_coa_e' => 2, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Pemindahan Dana PG ke Rek Ops'.'-'.$register_code,
                            // 'journal_description_form' => 'Biaya PG - '.$register_code,
                            'journal_debit' => $fee_pg,
                            'journal_kredit' => 0,
                            'cashflow_code_status' => 'OTD',
                            'journal_status' => '0'
                            );

                $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);

                // Pemindahan Dana PG credit
                $data_journal5 = array(
                            'journal_no' => $newIDgl2,
                            'id_param_coa_e' => 128, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Pemindahan Dana PG ke Rek Ops'.'-'.$register_code,
                            // 'journal_description_form' => 'Biaya PG - ' .$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $fee_pg,
                            'cashflow_code_status' => 'OTC',
                            'journal_status' => '0'
                            );

                $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                $amount = $fund_data[0]->amount - $clean;

                $data_fund = array(
                    'amount' => $amount,
                );

                $update_fund = $this->crud_model->update('tb_fintech_borrower_fund','register_code',$register_code,$data_fund);

                $this->session->set_flashdata('alert_success', 'Withdrawal Success.');
                redirect(base_url().'Finance/F_borrower/withdrawal_borrower');
                
            } else {

                $this->session->set_flashdata('alert_error', 'withdrawal Proses failed.');
                redirect(base_url().'Finance/F_borrower/withdrawal_borrower');

            }              
        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/withdrawal_borrower_prosses' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function withdrawal_prosses_get_same_data(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $data['data_code'] = $this->bank_model->get_bank_borrower($register_code);
        echo json_encode($data['data_code'][0]);
        
    }

    public function social_point_borrower()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['social_point_borrower_active'] = "active";

        $data['get_code'] = $register_code;
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'home');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/social_point_borrower' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function account_borrower()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['account_active'] = "active";

        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['data_loan'] = $this->loan_model->get_all_loan(null, $register_code);
        
        $data['data_disbursed'] = $this->loan_model->get_ongoing_list(null,null, $register_code)->result();
        $data['data_crowdfunding'] = $this->loan_model->get_crowdfunding_list(null,null, $register_code)->result();
        
        $data['avg_loan'] = $this->loan_model->get_avg_loan($register_code);
        $data['sum_loan'] = $this->loan_model->get_sum_loan($register_code);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/account_borrower' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function crowdfunding()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['account_active'] = "active";

        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['data_loan'] = $this->loan_model->get_all_loan(null, $register_code);
        $data['data_crowdfunding'] = $this->loan_model->get_crowdfunding_list(null,null, $register_code)->result();
        $data['avg_interest'] = $this->loan_model->get_avg_interest($register_code);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/crowdfunding' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function browse_loan()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['purpose_new_loan_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['data_register'] = $this->register_model->get_register_by_id($register_code);
        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_consumtive'] = $this->personal_info_model->get_consumtive_borrower($register_code);
        
        $data['data_industry'] = $this->personal_info_model->get_industry_borrower();
        $industry_type = ((array)@$data['data_consumtive'][0]);
        $data['data_industry_type'] = $this->param_model->get_industry_by_id(@$industry_type['borrower_industry_type']);
        $data['data_industry_cons'] = $this->param_model->get_industry();

        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);

        $prov_consumtive = ((array)@$data['data_consumtive'][0]);
        $data['data_province_consumtive'] = $this->indonesia_model->get_province_business_by_id(@$prov_consumtive['borrower_province_company']);
        $data['data_city_consumtive'] = $this->indonesia_model->get_city_business_by_id(@$prov_consumtive['borrower_city_company']);
        $data['data_district_consumtive'] = $this->indonesia_model->get_district_business_by_id(@$prov_consumtive['borrower_district_company']);
        $data['data_village_consumtive'] = $this->indonesia_model->get_village_business_by_id(@$prov_consumtive['borrower_village_company']);

        $footer['data_contact'] = $this->contact_model->get_contact();


        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/browse_loan' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function new_loan_consumtive()
    {
        $this->load->helper(array('form', 'url'));
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['purpose_new_loan_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['check_data'] = $this->crud_model->get_data("tb_fintech_register",$where)->result();
        $data['data_periode'] = $this->loan_model->get_periode();
        $data['form_url'] = site_url('Finance/F_borrower/propose_loan');
        $data['data_contact'] = $this->contact_model->get_contact();
        $data['data_direk'] = $this->management_model->get_managementmenu_direk();
        $data['data_bio'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $footer['data_contact'] = $this->contact_model->get_contact();
        

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/new_loan_consumtive' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function new_loan_commercial()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['purpose_new_loan_active'] = "active";

        $data['check_data'] = $this->crud_model->get_data("tb_fintech_register",$where)->result();
        $data['data_contact'] = $this->contact_model->get_contact();
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['data_periode'] = $this->loan_model->get_periode();
        $data['form_url'] = site_url('Finance/F_borrower/propose_loan');
        $data['data_bio'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_direk'] = $this->management_model->get_managementmenu_direk();

        $data['data_commercial'] = $this->personal_info_model->get_commercial_borrower($register_code);
        $prov_commercial = ((array)@$data['data_commercial'][0]);
        $data['data_province_commercial'] = $this->indonesia_model->get_province_business_by_id(@$prov_commercial['borrower_province_company']);
        $data['data_city_commercial'] = $this->indonesia_model->get_city_business_by_id(@$prov_commercial['borrower_city_company']);
        $data['data_district_commercial'] = $this->indonesia_model->get_district_business_by_id(@$prov_commercial['borrower_district_company']);
        $data['data_village_commercial'] = $this->indonesia_model->get_village_business_by_id(@$prov_commercial['borrower_village_company']);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/new_loan_commercial' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function check_score()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

            $register_code  = $register_code;

            $input_type = $this->input->post('type_loan');
            $input_amount = $this->input->post('amount');
            $input_tenor = $this->input->post('periode');

            $input_amount = preg_replace('/\D/','',$input_amount);


            // validasi di bawah 500.000
            if($input_amount > 0){
                if($input_amount < '500000'){
                    $alert_error = true;
                    $alert_message = 'mohon masukan nominal pengajuan pinjaman di atas 500,000.!';

                    $result = array(
                        'alert_error' => $alert_error,
                        'alert_message' => $alert_message,
                    );

                    echo json_encode($result);
                    die();
                } 
            } else {
                $alert_error = true;
                $alert_message = 'mohon masukan nominal pengajuan pinjaman yang sesuai / tidak sama dengan 0.!';

                $result = array(
                    'alert_error' => $alert_error,
                    'alert_message' => $alert_message,
                );

                echo json_encode($result);
                die();
            }
           // validasi di bawah 500.000 end

            if($input_type == "Personal Loan"){
                $data_personal = $this->personal_info_model->get_personal_info_borrower($register_code);
                $data_consumtive = $this->personal_info_model->get_consumtive_borrower($register_code);
                $data_industry = $this->param_model->get_industry_by_id($data_consumtive[0]->borrower_industry_type);
                $data_entity = $this->personal_info_model->get_entity_borrower_by_id($data_consumtive[0]->borrower_entity_type);
                $data_loan_before = $this->loan_model->get_loan_scoring($register_code,null);
                $data_loan_closed = $this->loan_model->get_check_closed($register_code)->num_rows();
                $data_periode = $this->loan_model->get_periode_scoring_by_periode($input_tenor);

                if ($data_consumtive == null){
                    $alert_error = true;
                    $alert_message = 'Your personal data is empty, please back to step 1.!';

                    $result = array(
                        'alert_error' => $alert_error,
                        'alert_message' => $alert_message,
                    );

                    echo json_encode($result);
                    die();
                }

                if ($data_loan_before != null){
                    $loan_total = $data_loan_before[0]->loan_total;
                } else {
                    $loan_total = 0;
                }

                $pay_cap = $data_consumtive[0]->borrower_montly_income / 3;
                $montly_income = $pay_cap - $loan_total;

                $data_count = $this->personal_info_model->get_file_consumtive($register_code);
                $data_count = count($data_count);

                $loan_needs = $data_consumtive[0]->borrower_entity_type;

                $all_score = 0;
                $all_score = $all_score + $data_industry[0]->industry_score;
                $all_score = $all_score + $data_entity[0]->entity_score;
                $all_score = $all_score + $data_periode[0]->score;
                //var_dump($data_loan_closed);
                if ($data_loan_closed > 0){
                    $all_score = $all_score + 999;
                } else {
                    $all_score = $all_score + 0;
                }

                    if ($data_personal[0]->bio_cityzenship == "WNI"){
                        @@$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("1");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("2");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                    if( $data_count == '5'){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("71");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }elseif ($data_count <= '4'  AND $data_count != '0') {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("67");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }else{
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("65");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                    if ($data_consumtive[0]->borrower_collectibility_bi == "1"){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("51");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("53");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }
      
                    if ($data_consumtive[0]->borrower_employe_status == "Permanent"){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("59");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("60");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                    if ($data_consumtive[0]->borrower_status_owner == "Pribadi"){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("63");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("64");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                if($all_score >= 99){
                    $alert_error = true;
                    $alert_message = "Your data is not possible to make a loan!";
                    $loan_rating = "-";
                    $loan_rate = "0";
                    $alert_error_income = false; 
                    $alert_message_income = ""; 
                } else { 
                    $alert_error = false; $alert_message = ""; 

                    $data_scoring = $this->score_model->get_score('Activated');

                    foreach ($data_scoring as $scorig_entry) {
                        if($all_score >= $scorig_entry->score_startrate AND $all_score <= $scorig_entry->score_endrate){
                            $loan_rating = $scorig_entry->score_rating;
                            $loan_rate = $scorig_entry->interest_rate;
                        }
                    }

                    $loan = $input_amount *($loan_rate/100);
                    $loan2 = ($input_amount + $loan) / $input_tenor;
                    $payment_cap = $montly_income /$loan2 ;

                    if ($payment_cap < 1){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("73");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("79");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                    if($all_score >= 99){
                        $alert_error = true;
                        $alert_message = "Your data is not possible to make a loan!";
                        $loan_rating = "-";
                        $loan_rate = "0";
                        $alert_error_income = false; 
                        $alert_message_income = ""; 

                    } else { 
                        $alert_error = false; $alert_message = ""; 

                        $data_scoring = $this->score_model->get_score('Activated');

                        foreach ($data_scoring as $scorig_entry) {
                            if($all_score >= $scorig_entry->score_startrate AND $all_score <= $scorig_entry->score_endrate){
                                $loan_rating = $scorig_entry->score_rating;
                                $loan_rate = $scorig_entry->interest_rate;
                            }
                        }

                        if($loan2 >= $montly_income){
                            $alert_error_income = true;
                            $alert_message_income = "Your data is not possible to make a loan, Your installment exceeds the income, allowing to change the loan amount or increase the tenor!";
                        } else { 
                            $alert_error_income = false; $alert_message_income = ""; 
                        }
                    }
                    
                        if($all_score >= 99){
                            $alert_error = true;
                            $alert_message = "Your data is not possible to make a loan!";
                            $loan_rating = "-";
                            $loan_rate = "0";
                            $alert_error_income = false; 
                            $alert_message_income = ""; 
                        } else { 
                            $alert_error = false; $alert_message = ""; 
                        }

                }

            } else {
                $data_personal = $this->personal_info_model->get_personal_info_borrower($register_code);
                $data_commercial = $this->personal_info_model->get_commercial_borrower($register_code);

                if ($data_commercial == null){
                    $alert_error = true;
                    $alert_message = 'Your commercial data is empty, please back to step 1.!';

                    $result = array(
                        'alert_error' => $alert_error,
                        'alert_message' => $alert_message,
                    );

                    echo json_encode($result);
                    die();
                }

                $data_industry = $this->param_model->get_industry_by_id($data_commercial[0]->borrower_industry_type);
                $data_entity = $this->personal_info_model->get_business_entity_borrower_by_id($data_commercial[0]->borrower_business_form);
                $data_loan_before = $this->loan_model->get_loan_scoring($register_code,1);
                $data_loan_closed = $this->loan_model->get_check_closed($register_code)->num_rows();
                $data_periode = $this->loan_model->get_periode_scoring_by_periode($input_tenor);

                if ($data_loan_before != null){
                    $loan_total = $data_loan_before[0]->loan_total;
                } else {
                    $loan_total = 0;
                }

                $industry_hpp = $data_industry[0]->industry_hpp / 100;
                $pay_ind = $data_commercial[0]->borrower_montly_income * $industry_hpp;
                $pay_cap = $data_commercial[0]->borrower_montly_income - $pay_ind;
                $total_paycap = ($pay_cap - $data_commercial[0]->borrower_operating_costs) - $data_commercial[0]->borrower_additional_costs;

                $montly_income = $total_paycap - $loan_total;

                //var_dump($montly_income);

                $data_count = $this->personal_info_model->get_file_commercial($register_code);
                $data_count = count($data_count);

                $loan_needs = $data_commercial[0]->borrower_business_form;

                $all_score = 0;
                $all_score = $all_score + $data_industry[0]->industry_score;
                $all_score = $all_score + $data_entity[0]->entity_business_score;
                $all_score = $all_score + $data_periode[0]->score;

                if ($data_loan_closed > 0){
                    $all_score = $all_score + 999;
                } else {
                    $all_score = $all_score + 0;
                }

                    if ($data_personal[0]->bio_cityzenship == "WNI"){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("3");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("4");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                    if ($data_commercial[0]->borrower_collectibility_bi == "1"){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("52");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("54");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                    if ($data_commercial[0]->borrower_long_entrepreneurship < 2){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("55");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else if ($data_commercial[0]->borrower_long_entrepreneurship >= 2 AND $data_commercial[0]->borrower_long_entrepreneurship < 5){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("56");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else if ($data_commercial[0]->borrower_long_entrepreneurship >= 5 AND $data_commercial[0]->borrower_long_entrepreneurship <= 10){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("57");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("58");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                    if( $data_count == '6'){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("72");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }elseif ($data_count <= '5'  AND $data_count != '0') {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("68");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }else{
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("66");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                if($all_score >= 99){
                    $alert_error = true;
                    $alert_message = "Your data is not possible to make a loan!";
                    $loan_rating = "-";
                    $loan_rate = "0";
                    $alert_error_income = false; 
                    $alert_message_income = ""; 
                } else { 
                    $alert_error = false; $alert_message = ""; 

                    $data_scoring = $this->score_model->get_score('Activated');

                    foreach ($data_scoring as $scorig_entry) {
                        if($all_score >= $scorig_entry->score_startrate AND $all_score <= $scorig_entry->score_endrate){
                            $loan_rating = $scorig_entry->score_rating;
                            $loan_rate = $scorig_entry->interest_rate;
                        }
                    }

                    $loan = $input_amount *($loan_rate/100);
                    $loan2 = ($input_amount + $loan) / $input_tenor;
                    $payment_cap = $montly_income /$loan2 ;

                    if ($payment_cap < 1){
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("74");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    } else {
                        @$data_parameter = $this->parameter_all_model->get_parameter_all_by_id("80");
                        $all_score = $all_score + (int)@$data_parameter[0]->parameter_all_score;
                    }

                    if($all_score >= 99){
                        $alert_error = true;
                        $alert_message = "Your data is not possible to make a loan!";
                        $loan_rating = "-";
                        $loan_rate = "0";
                        $alert_error_income = false; 
                        $alert_message_income = ""; 
                    } else { 
                        $alert_error = false; $alert_message = ""; 

                        $data_scoring = $this->score_model->get_score('Activated');

                        foreach ($data_scoring as $scorig_entry) {
                            if($all_score >= $scorig_entry->score_startrate AND $all_score <= $scorig_entry->score_endrate){
                                $loan_rating = $scorig_entry->score_rating;
                                $loan_rate = $scorig_entry->interest_rate;
                            }
                        }
                    
                        if($loan2 >= $montly_income){
                            $alert_error_income = true;
                            $alert_message_income = "Your data is not possible to make a loan, Your installment exceeds the income, allowing to change the loan amount or increase the tenor!";
                        } else { $alert_error_income = false; $alert_message_income = ""; }
                    }

                        if($all_score >= 99){
                            $alert_error = true;
                            $alert_message = "Your data is not possible to make a loan!";
                            $loan_rating = "-";
                            $loan_rate = "0";
                            $alert_error_income = false; 
                            $alert_message_income = ""; 
                        } else { 
                            $alert_error = false; $alert_message = ""; 
                        }
                }
            }

            $result = array(
                'register_code' => $register_code, 
                'loan_type' => $input_type, 
                'loan_needs' => $loan_needs, 
                'loan_amount' => $input_amount, 
                'loan_tenor' => $input_tenor, 
                'loan_rating' => $loan_rating, 
                'loan_rate' => $loan_rate,
                'alert_error' => $alert_error,
                'alert_error_income' => $alert_error_income,
                'alert_message' => $alert_message,
                'alert_message_income' => $alert_message_income,
            );

            echo json_encode($result);
                      
    }

    public function propose_loan()
    {
        
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $email_manager = $this->users_model->get_user_email();
        // $email_manager = array_merge($email_manager);
        $email_borrower = $this->personal_info_model->get_email_borrower($register_code);
        

        $emails = array_map(function($value){
            return $value->users_email;
        }, $email_manager);

        $emails_bor = array_map(function($value){
            return $value->register_email;
        }, $email_borrower);

        $email_crowdfunding = array_merge($emails,$emails_bor);

        $idMax = $this->loan_model->loan_code();
        $noUrut =(int) substr($idMax[0]->maxID,3,9);
        $noUrut ++;
        $newID="LN".sprintf("%09s",$noUrut);

        $this->form_validation->set_rules("loan_type", "", "trim|required");
        $this->form_validation->set_rules("description", "", "trim|required");
        $this->form_validation->set_rules("amount", "", "trim|required");
        $this->form_validation->set_rules("needs", "", "trim|required");
        $this->form_validation->set_rules("periode", "", "trim|required");
        $this->form_validation->set_rules("rating", "", "trim|required");
        $this->form_validation->set_rules("rate", "", "trim|required");
        $this->form_validation->set_rules("principal", "", "trim|required");
        $this->form_validation->set_rules("interest", "", "trim|required");
        $this->form_validation->set_rules("montly", "", "trim|required");

        if ($this->form_validation->run() == true){
            $loan_type = $this->input->post('loan_type');
            $description = $this->input->post('description');
            $amount = $this->input->post('amount');
            $needs = $this->input->post('needs');
            $periode = $this->input->post('periode');
            $rating = $this->input->post('rating');
            $rate = $this->input->post('rate');
            $principal = $this->input->post('principal');
            $interest = $this->input->post('interest');
            $montly = $this->input->post('montly');

            $payment_estimate = $montly * $periode;

            $flat_rate = $rate * 2;
                       
            $data_loan = array(
                    'id_borrower_loan' => $newID, 
                    'register_code' => $register_code, 
                    'loan_date' => date("Y-m-d"), 
                    'loan_type' => $loan_type, 
                    'loan_needs' => $needs, 
                    'loan_amount' => $amount, 
                    'loan_tenor' => $periode, 
                    'loan_rating' => $rating, 
                    'loan_rate' => $rate,
                    'loan_flat_rate' => $flat_rate,
                    'loan_principal' => $principal, 
                    'loan_interest' => $interest,
                    'loan_montly' => $montly,  
                    'loan_note' => $description,
                    'loan_payment' => "Not Yet Paid", 
                    'loan_status' => "Crowdfunding", 
                    'amount_left' => $amount,
                    'time_left' => "23:59:00",  
                    'payment_estimate' => $payment_estimate, 
                    'payment_realization' => 0, 
                    'completion' => 0, 
                    'loan_start_date' => "0000-00-00",
            );
            $insert_loan = $this->crud_model->insert('tb_fintech_borrower_loan', $data_loan);
            
            // $idMax = $this->register_model->term_code_borrower();
            // $noUrut = (int) substr($idMax[0]->maxID,4,8);
            // $noUrut ++;
            $term_id = $newID."/SA/".date('m')."/".date('Y');
            $no_sk = $newID."/SK/".date('m/Y');
            $date = date('Y-m-d H:i:s');
            $data_term_borrower = array(
                'term_id' => $term_id,
                'term_date' => $date,
                'no_surat_kuasa' => $no_sk,
                'register_code' => $register_code,
                'id_borrower_loan' => $newID,
                'term_status' => "Yes",
             );
            $insert_term = $this->crud_model->insert('tb_fintech_term_borrower',$data_term_borrower);

            
            foreach ($email_crowdfunding as $email_entry) {
                $config = array();
                $config['charset'] = 'iso-8859-1';
                $config['useragent'] = 'Codeigniter';
                $config['protocol']= 'smtp';
                $config['mailtype']= 'html';
                $config['smtp_host']= 'ssl://mail.heatcliffs31.com';//pengaturan smtp
                $config['smtp_port']= 465;
                $config['smtp_timeout']= 400;
                $config['smtp_user']= 'sanders@heatcliffs31.com'; // isi dengan email kamu
                $config['smtp_pass']= '1q2w3e4r5t'; // isi dengan password kamu
                $config['crlf']="\r\n"; 
                $config['newline']="\r\n"; 
                $config['wordwrap'] = TRUE;
                //memanggil library email dan set konfigurasi untuk pengiriman email
                $this->load->library('email',$config);
                $this->email->initialize($config);

                //konfigurasi pengiriman
                $this->email->from($config['smtp_user']);
                $this->email->to($email_entry);
                $this->email->subject("Notificaton Crowdfunding");
                $body = $this->load->view('frontend-fintech/email_crowdfunding.php','',TRUE);
                $this->email->message($body);
                                
                $this->email->send();
            }
                
                
            $this->session->set_flashdata('alert_success', 'Your data successfully entered data into our Crowdfunding, we will send you email if the loan has been fulfilled');
            redirect(base_url().'Finance/F_borrower/account_borrower');
            die(); 
        } else {
            echo "<script>history.back(1)</script>"; 
        }
    }

    public function borrower_konsumtif()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['purpose_new_loan_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['data_register'] = $this->register_model->get_register_by_id($register_code);
        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_consumtive'] = $this->personal_info_model->get_consumtive_borrower($register_code);
        
        $data['data_industry'] = $this->personal_info_model->get_industry_borrower();
        $industry_type = ((array)@$data['data_consumtive'][0]);
        $data['data_industry_type'] = $this->param_model->get_industry_by_id(@$industry_type['borrower_industry_type']);
        $data['data_industry_cons'] = $this->param_model->get_industry();

        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);

        $data['data_entity'] = $this->personal_info_model->get_entity_borrower();
        $entity_type = ((array)@$data['data_consumtive'][0]);
        $data['data_entity_type'] = $this->param_model->get_entity_by_id(@$entity_type['borrower_entity_type']);
        $data['data_entity_cons'] = $this->param_model->get_entity();

        $prov_consumtive = ((array)@$data['data_consumtive'][0]);
        $data['data_province_consumtive'] = $this->indonesia_model->get_province_business_by_id(@$prov_consumtive['borrower_province_company']);
        $data['data_city_consumtive'] = $this->indonesia_model->get_city_business_by_id(@$prov_consumtive['borrower_city_company']);
        $data['data_district_consumtive'] = $this->indonesia_model->get_district_business_by_id(@$prov_consumtive['borrower_district_company']);
        $data['data_village_consumtive'] = $this->indonesia_model->get_village_business_by_id(@$prov_consumtive['borrower_village_company']);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/borrower_konsumtif' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function borrower_update_konsumtif()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');
        
        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['purpose_new_loan_active'] = "active";
        $navigation['borrower_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('borrower');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['get_code'] = $register_code;
        $data['form_url'] = site_url('Finance/F_borrower/borrower_update_konsumtif');
        $data['data_register'] = $this->register_model->get_register_by_id($register_code);
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);

        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);
        $data['data_indonesia'] = $this->indonesia_model->get_province();

        $data['data_consumtive'] = $this->personal_info_model->get_consumtive_borrower($register_code);
        $prov_consumtive = ((array)@$data['data_consumtive'][0]);
        $data['data_province_consumtive'] = $this->indonesia_model->get_province_business_by_id(@$prov_consumtive['borrower_province_company']);
        $data['data_city_consumtive'] = $this->indonesia_model->get_city_business_by_id(@$prov_consumtive['borrower_city_company']);
        $data['data_district_consumtive'] = $this->indonesia_model->get_district_business_by_id(@$prov_consumtive['borrower_district_company']);
        $data['data_village_consumtive'] = $this->indonesia_model->get_village_business_by_id(@$prov_consumtive['borrower_village_company']);
        $data['data_indonesia_consumtive'] = $this->indonesia_model->get_province();

        $data['data_industry'] = $this->personal_info_model->get_industry_borrower($register_code);
        $industry_type = ((array)@$data['data_consumtive'][0]);
        $data['data_industry_type'] = $this->param_model->get_industry_by_id(@$industry_type['borrower_industry_type']);
        $data['data_industry_cons'] = $this->param_model->get_industry();

        $data['data_entity'] = $this->personal_info_model->get_entity_borrower();

        $this->form_validation->set_rules("register_code", "", "required");
        $this->form_validation->set_rules("borrower_employe_status", "", "required");
        // $this->form_validation->set_rules("borrower_repayment_capacity", "", "required");
        $this->form_validation->set_rules("borrower_montly_income", "", "required");
        $this->form_validation->set_rules("borrower_collectibility_bi", "", "required");
        $this->form_validation->set_rules("borrower_loc_residen", "", "required");
        $this->form_validation->set_rules("borrower_status_owner", "", "required");
        $this->form_validation->set_rules("borrower_dependents", "", "trim|required");
        $this->form_validation->set_rules("borrower_name_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_phone_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_province_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_city_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_district_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_village_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_address_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_industry_type", "", "trim|required");
        $this->form_validation->set_rules("borrower_entity_type", "", "trim|required");

        if ($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');
            $borrower_employe_status = $this->input->post('borrower_employe_status');
            $borrower_montly_income = $this->input->post('borrower_montly_income');
            $borrower_collectibility_bi = $this->input->post('borrower_collectibility_bi');
            $borrower_loc_residen = $this->input->post('borrower_loc_residen');
            $borrower_status_owner = $this->input->post('borrower_status_owner');
            $borrower_account_type = $this->input->post('borrower_account_type');
            $borrower_age_retirement = $this->input->post('borrower_age_retirement');
            $borrower_dependents = $this->input->post('borrower_dependents'); 
            $borrower_name_company = $this->input->post('borrower_name_company'); 
            $borrower_phone_company = $this->input->post('borrower_phone_company');
            $borrower_province_company = $this->input->post('borrower_province_company');  
            $borrower_city_company = $this->input->post('borrower_city_company'); 
            $borrower_district_company = $this->input->post('borrower_district_company'); 
            $borrower_village_company = $this->input->post('borrower_village_company');   
            $borrower_address_company = $this->input->post('borrower_address_company');   
            $borrower_rekening_type = $this->input->post('borrower_rekening_type'); 
            $borrower_industry_type = $this->input->post('borrower_industry_type');
            $borrower_entity_type = $this->input->post('borrower_entity_type');

            $_POST['borrower_montly_income'] = $borrower_montly_income;
            $clean = preg_replace('/\D/','',$_POST['borrower_montly_income']);

            $where = array('register_code' => $register_code);
            $data_check = $this->crud_model->get_data("tb_fintech_borrower_detail_consumtive", $where)->num_rows();

            if($data_check == 0){
                $data_konsumtif = array(
                    'register_code' => $register_code,
                    'borrower_employe_status' => $borrower_employe_status,
                    'borrower_montly_income' => $clean,
                    'borrower_collectibility_bi' => $borrower_collectibility_bi,
                    'borrower_loc_residen' => $borrower_loc_residen,
                    'borrower_status_owner' => $borrower_status_owner,
                    'borrower_age_retirement' => $borrower_age_retirement,
                    'borrower_dependents' => $borrower_dependents,
                    'borrower_name_company' => $borrower_name_company,
                    'borrower_phone_company' => $borrower_phone_company,
                    'borrower_province_company' => $borrower_province_company,
                    'borrower_city_company' => $borrower_city_company,
                    'borrower_district_company' => $borrower_district_company,
                    'borrower_village_company' => $borrower_village_company,
                    'borrower_address_company' => $borrower_address_company,
                    'borrower_industry_type' => $borrower_industry_type,
                    'borrower_entity_type' => $borrower_entity_type
                            
                 );

                $insert_konsumtif = $this->crud_model->insert('tb_fintech_borrower_detail_consumtive', $data_konsumtif, $clean);
                $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                redirect(base_url().'Finance/F_borrower/borrower_konsumtif');
                die();

            } else {
                $data_konsumtif = array(
                    'borrower_employe_status' => $borrower_employe_status,
                    'borrower_montly_income' => $clean,
                    'borrower_collectibility_bi' => $borrower_collectibility_bi,
                    'borrower_loc_residen' => $borrower_loc_residen,
                    'borrower_status_owner' => $borrower_status_owner,
                    'borrower_age_retirement' => $borrower_age_retirement,
                    'borrower_dependents' => $borrower_dependents,
                    'borrower_name_company' => $borrower_name_company,
                    'borrower_phone_company' => $borrower_phone_company,
                    'borrower_province_company' => $borrower_province_company,
                    'borrower_city_company' => $borrower_city_company,
                    'borrower_district_company' => $borrower_district_company,
                    'borrower_village_company' => $borrower_village_company,
                    'borrower_address_company' => $borrower_address_company,
                    'borrower_industry_type' => $borrower_industry_type,
                    'borrower_entity_type' => $borrower_entity_type
                 );

                $update_konsumtif = $this->crud_model->update('tb_fintech_borrower_detail_consumtive', 'register_code',$register_code, $data_konsumtif, $clean);
                $this->session->set_flashdata('alert_success', 'Data successfully Updated.');
                redirect(base_url().'Finance/F_borrower/borrower_konsumtif');
                die();
            } 

                           
        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2',$navigation);
        $this->load->view('frontend-fintech/borrower/borrower_update_konsumtif', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function borrower_file_konsumtif()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['purpose_new_loan_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');

        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['get_code'] = $register_code;
        $data['form_url'] = site_url('Finance/F_borrower/borrower_file_konsumtif'); 

        $data['data_npwp'] = $this->personal_info_model->get_file_consumtive($register_code,'NPWP');
        $data['data_certificate'] = $this->personal_info_model->get_file_consumtive($register_code,'Certificate');
        $data['data_salary'] = $this->personal_info_model->get_file_consumtive($register_code,'Salary');
        $data['data_account'] = $this->personal_info_model->get_file_consumtive($register_code,'Account');
        $data['data_credit'] = $this->personal_info_model->get_file_consumtive($register_code,'Credit');

        $this->form_validation->set_rules("register_code", "", "required");

         if ($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');

            if(!empty($_FILES['file_npwp']['name'])){
                $file_upload_name1 = $this->input->post('npwp');
                $name_file1 = $file_upload_name1."_".time()."_".rand(0,1000);
                $config1['upload_path'] = './uploads/Fintech/file_borrower_consumtive';
                $config1['allowed_types'] = 'gif|jpg|png|jpeg';
                $config1['file_name'] = $name_file1;

                $this->load->library('upload', $config1);


                if(!$this->upload->do_upload('file_npwp')){

                    $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                    redirect(base_url().'Finance/F_borrower/borrower_file_konsumtif');
                    die();

                } else {

                    
                    $file_upload1 = $this->upload->data();

                    $data_konsumtif = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name1,
                        'file_upload' => $file_upload1['file_name'],
                    );


                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name1,);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->num_rows();
                    $this->upload->initialize($config1);

                    

                    if($data_check == 1){
                        $data_file = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->result();
                        $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_consumtive/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_konsumtif = $this->crud_model->update('tb_fintech_file_consumtive','id_file',$id_file, $data_konsumtif);
                    } else {
                        $insert_konsumtif = $this->crud_model->insert('tb_fintech_file_consumtive', $data_konsumtif);
                    }
                    
                }
            }

            if(!empty($_FILES['file_certificate']['name'])){
                $file_upload_name2 = $this->input->post('certificate');
                $name_file2 = $file_upload_name2."_".time()."_".rand(0,1000);
                $config2['upload_path'] = './uploads/Fintech/file_borrower_consumtive';
                $config2['allowed_types'] = 'gif|jpg|png|jpeg';
                $config2['file_name'] = $name_file2;

                $this->load->library('upload', $config2);

                if(!$this->upload->do_upload('file_certificate')){

                    $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                    redirect(base_url().'Finance/F_borrower/borrower_file_konsumtif');
                    die();

                } else {


                    $file_upload2 = $this->upload->data();
                    

                    $data_konsumtif = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name2,
                        'file_upload' => $file_upload2['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name2);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->num_rows();

                    $this->upload->initialize($config2);
                    

                    if($data_check == 1){

                        $data_file = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->result();
                        $id_file = $data_file[0]->id_file;

                        $file_path= './uploads/Fintech/file_borrower_consumtive/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_konsumtif = $this->crud_model->update('tb_fintech_file_consumtive','id_file',$id_file, $data_konsumtif);
                    } else {
                        $insert_konsumtif = $this->crud_model->insert('tb_fintech_file_consumtive', $data_konsumtif);
                    }
                    
                }
            }

            if(!empty($_FILES['file_salary']['name'])){
                $file_upload_name3 = $this->input->post('salary');
                $name_file3 = $file_upload_name3."_".time()."_".rand(0,1000);
                $config3['upload_path'] = './uploads/Fintech/file_borrower_consumtive';
                $config3['allowed_types'] = 'gif|jpg|png|jpeg';
                $config3['file_name'] = $name_file3;

                $this->load->library('upload', $config3);

                if(!$this->upload->do_upload('file_salary')){

                $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                redirect(base_url().'Finance/F_borrower/borrower_file_konsumtif');
                die();

                } else {

                    $file_upload3 = $this->upload->data();

                    $data_konsumtif = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name3,
                        'file_upload' => $file_upload3['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name3);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->num_rows();
                    $this->upload->initialize($config3);
                    

                    if($data_check == 1){
                       $data_file = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->result();
                       $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_consumtive/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_konsumtif = $this->crud_model->update('tb_fintech_file_consumtive','id_file',$id_file, $data_konsumtif);
                    } else {
                        $insert_konsumtif = $this->crud_model->insert('tb_fintech_file_consumtive', $data_konsumtif);
                    }
                    
                }
            }

            if(!empty($_FILES['file_account']['name'])){
                $file_upload_name4 = $this->input->post('account');
                $name_file4 = $file_upload_name4."_".time()."_".rand(0,1000);
                $config4['upload_path'] = './uploads/Fintech/file_borrower_consumtive';
                $config4['allowed_types'] = 'gif|jpg|png|jpeg';
                $config4['file_name'] = $name_file4;

                $this->load->library('upload', $config4);

                if(!$this->upload->do_upload('file_account')){

                $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                redirect(base_url().'Finance/F_borrower/borrower_file_konsumtif');
                die();

                } else {

                    $file_upload4 = $this->upload->data();

                    $data_konsumtif = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name4,
                        'file_upload' => $file_upload4['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name4);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->num_rows();
                    $this->upload->initialize($config4);
                    

                    if($data_check == 1){
                        $data_file = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->result();
                        $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_consumtive/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_konsumtif = $this->crud_model->update('tb_fintech_file_consumtive','id_file',$id_file, $data_konsumtif);
                    } else {
                        $insert_konsumtif = $this->crud_model->insert('tb_fintech_file_consumtive', $data_konsumtif);
                    }
                    
                }
            }

            if(!empty($_FILES['file_credit']['name'])){
                $file_upload_name5 = $this->input->post('credit');
                $name_file5 =  $file_upload_name5."_".time()."_".rand(0,1000);
                $config5['upload_path'] = './uploads/Fintech/file_borrower_consumtive';
                $config5['allowed_types'] = 'gif|jpg|png|jpeg';
                $config5['file_name'] = $name_file5;

                $this->load->library('upload', $config5);

                if(!$this->upload->do_upload('file_credit')){

                $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                redirect(base_url().'Finance/F_borrower/borrower_file_konsumtif');
                die();

                } else {
                    

                    $file_upload5 = $this->upload->data();
                    $data_konsumtif = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name5,
                        'file_upload' => $file_upload5['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name5);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->num_rows();
                    $this->upload->initialize($config5);
                   

                    if($data_check == 1){
                        $data_file = $this->crud_model->get_data("tb_fintech_file_consumtive", $where)->result();
                        $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_consumtive/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_konsumtif = $this->crud_model->update('tb_fintech_file_consumtive','id_file',$id_file, $data_konsumtif);
                    } else {
                        $insert_konsumtif = $this->crud_model->insert('tb_fintech_file_consumtive', $data_konsumtif);
                    }
                    
                }
            }

            $this->session->set_flashdata('alert_success', 'Data successfully saved.');
            redirect(base_url().'Finance/F_borrower/borrower_file_konsumtif');
            die();
        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/borrower_file_konsumtif' , $data);
        $this->load->view('frontend-fintech/partial/footer', $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function borrower_komersil()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['purpose_new_loan_active'] = "active";

        $data['data_register'] = $this->register_model->get_register_by_id($register_code);
        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);

        $data['data_industry'] = $this->personal_info_model->get_industry_borrower();
        $data['data_commercial'] = $this->personal_info_model->get_commercial_borrower($register_code);
        $industry_type = ((array)@$data['data_commercial'][0]);
        $data['data_industry_type'] = $this->param_model->get_industry_by_id(@$industry_type['borrower_industry_type']);
        $data['data_industry_cons'] = $this->param_model->get_industry();

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);

        $prov_commercial = ((array)@$data['data_commercial'][0]);
        $data['data_province_commercial'] = $this->indonesia_model->get_province_business_by_id(@$prov_commercial['borrower_province_company']);
        $data['data_city_commercial'] = $this->indonesia_model->get_city_business_by_id(@$prov_commercial['borrower_city_company']);
        $data['data_district_commercial'] = $this->indonesia_model->get_district_business_by_id(@$prov_commercial['borrower_district_company']);
        $data['data_village_commercial'] = $this->indonesia_model->get_village_business_by_id(@$prov_commercial['borrower_village_company']);

        $data['data_business_entity'] = $this->personal_info_model->get_business_entity_borrower($register_code);
        $business_entity = ((array)@$data['data_commercial'][0]);
        $data['data_business_entity_form'] = $this->param_model->get_entity_business_by_id(@$business_entity['borrower_business_form']);
        $data['data_business_entity_cons'] = $this->param_model->get_entity_business();

        $data['data_business_field'] = $this->personal_info_model->get_business_field_borrower($register_code);
        $business_field = ((array)@$data['data_commercial'][0]);
        $data['data_business_field_name'] = $this->param_model->get_field_business_by_id(@$business_field['borrower_business_field']);
        $data['data_business_field_cons'] = $this->param_model->get_field_business();

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/borrower_komersil' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function borrower_update_komersil()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');
        
        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        
        
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('borrower');
        $footer['data_contact'] = $this->contact_model->get_contact();
        $navigation['purpose_new_loan_active'] = "active";

        $data['get_code'] = $register_code;
        $data['form_url'] = site_url('Finance/F_borrower/borrower_update_komersil');
        $data['data_register'] = $this->register_model->get_register_by_id($register_code);
        $data['data_industry'] = $this->personal_info_model->get_industry_borrower();
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_commercial'] = $this->personal_info_model->get_commercial_borrower($register_code);

        $industry_type = ((array)@$data['data_commercial'][0]);
        $data['data_industry_type'] = $this->param_model->get_industry_by_id(@$industry_type['borrower_industry_type']);
        $data['data_industry_cons'] = $this->param_model->get_industry();

        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);
        $data['data_indonesia'] = $this->indonesia_model->get_province();

        $prov_commercial = ((array)@$data['data_commercial'][0]);
        $data['data_province_commercial'] = $this->indonesia_model->get_province_business_by_id(@$prov_commercial['borrower_province_company']);
        $data['data_city_commercial'] = $this->indonesia_model->get_city_business_by_id(@$prov_commercial['borrower_city_company']);
        $data['data_district_commercial'] = $this->indonesia_model->get_district_business_by_id(@$prov_commercial['borrower_district_company']);
        $data['data_village_commercial'] = $this->indonesia_model->get_village_business_by_id(@$prov_commercial['borrower_village_company']);
        $data['data_indonesia_commercial'] = $this->indonesia_model->get_province();

        $data['data_business_entity'] = $this->personal_info_model->get_business_entity_borrower($register_code);
        $business_entity = ((array)@$data['data_commercial'][0]);
        $data['data_business_entity_form'] = $this->param_model->get_entity_business_by_id(@$business_entity['borrower_business_form']);
        $data['data_business_entity_cons'] = $this->param_model->get_entity_business();

        $data['data_business_field'] = $this->personal_info_model->get_business_field_borrower($register_code);
        $business_field = ((array)@$data['data_commercial'][0]);
        $data['data_business_field_name'] = $this->param_model->get_field_business_by_id(@$business_field['borrower_business_field']);
        $data['data_business_field_cons'] = $this->param_model->get_field_business();

        $where = array('register_code' => $register_code);
        $data['data_check'] = $this->crud_model->get_data("tb_fintech_borrower_detail_commercial", $where)->num_rows();


        $this->form_validation->set_rules("register_code", "", "required");
        // $this->form_validation->set_rules("borrower_ktp_spouse", "", "required");
        // $this->form_validation->set_rules("borrower_ktp_spouse_picture", "", "required");
        //$this->form_validation->set_rules("borrower_repayment_capacity", "", "required");
        $this->form_validation->set_rules("borrower_montly_income", "", "required");
        $this->form_validation->set_rules("borrower_collectibility_bi", "", "required");
        $this->form_validation->set_rules("borrower_business_name", "", "required");
        $this->form_validation->set_rules("borrower_business_form", "", "required");
        $this->form_validation->set_rules("borrower_industry_type", "", "trim|required");
        $this->form_validation->set_rules("borrower_business_field", "", "trim|required");
        $this->form_validation->set_rules("borrower_long_entrepreneurship", "", "trim|required");
        $this->form_validation->set_rules("borrower_province_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_city_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_district_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_village_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_address_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_post_code_company", "", "trim|required");
        $this->form_validation->set_rules("borrower_office_number", "", "trim|required");
        $this->form_validation->set_rules("borrower_operating_costs", "", "trim|required");
        $this->form_validation->set_rules("borrower_additional_costs", "", "trim|required");

        if ($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');
            $bio_marriage_status = $this->input->post('bio_marriage_status');
            $borrower_ktp_spouse = $this->input->post('borrower_ktp_spouse');
            $borrower_ktp_spouse_picture = $this->input->post('borrower_ktp_spouse_picture');
            
            $borrower_montly_income = $this->input->post('borrower_montly_income');
            $borrower_collectibility_bi = $this->input->post('borrower_collectibility_bi');
            $borrower_business_name = $this->input->post('borrower_business_name');
            $borrower_business_form = $this->input->post('borrower_business_form');
            $borrower_industry_type = $this->input->post('borrower_industry_type');
            $borrower_business_field = $this->input->post('borrower_business_field'); 
            // $borrower_business_field_other = $this->input->post('borrower_business_field_other');
            $borrower_long_entrepreneurship = $this->input->post('borrower_long_entrepreneurship'); 
            $borrower_province_company = $this->input->post('borrower_province_company');  
            $borrower_city_company = $this->input->post('borrower_city_company'); 
            $borrower_district_company = $this->input->post('borrower_district_company'); 
            $borrower_village_company = $this->input->post('borrower_village_company');   
            $borrower_address_company = $this->input->post('borrower_address_company');   
            $borrower_post_code_company = $this->input->post('borrower_post_code_company'); 
            $borrower_office_number = $this->input->post('borrower_office_number');
            $borrower_operating_costs = $this->input->post('borrower_operating_costs');
            $borrower_additional_costs = $this->input->post('borrower_additional_costs'); 

            $_POST['borrower_montly_income'] = $borrower_montly_income;
            $clean = preg_replace('/\D/','',$_POST['borrower_montly_income']);

            $_POST['borrower_operating_costs'] = $borrower_operating_costs;
            $clean1 = preg_replace('/\D/','',$_POST['borrower_operating_costs']);

            $_POST['borrower_additional_costs'] = $borrower_additional_costs;
            $clean2 = preg_replace('/\D/','',$_POST['borrower_additional_costs']);
          
            $where = array('register_code' => $register_code);
            $data_check = $this->crud_model->get_data("tb_fintech_borrower_detail_commercial", $where)->num_rows();

            if($data_check == 0){       
                if($bio_marriage_status == 'Married' AND !empty($_FILES['borrower_ktp_spouse_picture']['name'])){
                    $name_file = $borrower_ktp_spouse."_".time();
                    $config['upload_path'] = './uploads/Fintech/ktp_spouse_borrower';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size']     = '5120';
                    $config['file_name'] = $name_file;

                    $this->load->library('upload', $config);

                    if(!$this->upload->do_upload('borrower_ktp_spouse_picture')){              
                        $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                        redirect(base_url().'Finance/F_borrower/borrower_update_komersil');
                        die();
                    } else {

                     $file_data = $this->upload->data();
                        $data_komersil = array(
                            'register_code' => $register_code,
                            'borrower_ktp_spouse' => $borrower_ktp_spouse,
                            'borrower_ktp_spouse_picture' => $file_data['file_name'],
                            
                            'borrower_montly_income' => $clean,
                            'borrower_collectibility_bi' => $borrower_collectibility_bi,
                            'borrower_business_name' => $borrower_business_name,
                            'borrower_business_form' => $borrower_business_form,
                            'borrower_industry_type' => $borrower_industry_type,
                            'borrower_business_field' => $borrower_business_field,
                            'borrower_long_entrepreneurship' => $borrower_long_entrepreneurship,
                            'borrower_province_company' => $borrower_province_company,
                            'borrower_city_company' => $borrower_city_company,
                            'borrower_district_company' => $borrower_district_company,
                            'borrower_village_company' => $borrower_village_company,
                            'borrower_address_company' => $borrower_address_company,
                            'borrower_post_code_company' => $borrower_post_code_company,
                            'borrower_office_number' => $borrower_office_number,
                            'borrower_operating_costs' => $clean1,
                            'borrower_additional_costs' => $clean2         
                            );

                        $insert_komersil = $this->crud_model->insert('tb_fintech_borrower_detail_commercial', $data_komersil);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_borrower/borrower_komersil');
                        die();
                    }
                } else { 

                    $data_komersil = array(
                            'register_code' => $register_code,
                            'borrower_ktp_spouse' => "-",
                            // 'borrower_ktp_spouse_picture' => $file_data['file_name'],
                            
                            'borrower_montly_income' => $clean,
                            'borrower_collectibility_bi' => $borrower_collectibility_bi,
                            'borrower_business_name' => $borrower_business_name,
                            'borrower_business_form' => $borrower_business_form,
                            'borrower_industry_type' => $borrower_industry_type,
                            'borrower_business_field' => $borrower_business_field,
                            'borrower_long_entrepreneurship' => $borrower_long_entrepreneurship,
                            'borrower_province_company' => $borrower_province_company,
                            'borrower_city_company' => $borrower_city_company,
                            'borrower_district_company' => $borrower_district_company,
                            'borrower_village_company' => $borrower_village_company,
                            'borrower_address_company' => $borrower_address_company,
                            'borrower_post_code_company' => $borrower_post_code_company,
                            'borrower_office_number' => $borrower_office_number,
                            'borrower_operating_costs' => $clean1,
                            'borrower_additional_costs' => $clean2         
                            );

                        $insert_komersil = $this->crud_model->insert('tb_fintech_borrower_detail_commercial', $data_komersil);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_borrower/borrower_komersil');
                        die();   

                }

            } else {

               if($bio_marriage_status == 'Married' AND !empty($_FILES['borrower_ktp_spouse_picture']['name'])){

                    $name_file = $borrower_ktp_spouse."_".time();
                    $config['upload_path'] = './uploads/Fintech/ktp_spouse_borrower';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size']     = '5120';
                    $config['file_name'] = $name_file;

                    $this->load->library('upload', $config);

                    if(!$this->upload->do_upload('borrower_ktp_spouse_picture')){
                                            
                      $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                      redirect(base_url().'Finance/F_borrower/borrower_update_komersil');
                      die();

                    } else {

                    $file_data = $this->upload->data();

                    $data_komersil= $this->personal_info_model->get_commercial_by_id($register_code);
                    $file_path= './uploads/Fintech/ktp_spouse_borrower/'.$data_commercial[0]->borrower_ktp_spouse_picture;

                    @unlink($file_path);

                        $data_komersil = array(
                            'borrower_ktp_spouse' => $borrower_ktp_spouse,
                            'borrower_ktp_spouse_picture' => $file_data['file_name'],
                            //'borrower_repayment_capacity' => $borrower_repayment_capacity,
                            'borrower_montly_income' => $clean,
                            'borrower_collectibility_bi' => $borrower_collectibility_bi,
                            'borrower_business_name' => $borrower_business_name,
                            'borrower_business_form' => $borrower_business_form,
                            'borrower_industry_type' => $borrower_industry_type,
                            'borrower_business_field' => $borrower_business_field,
                            'borrower_long_entrepreneurship' => $borrower_long_entrepreneurship,
                            'borrower_province_company' => $borrower_province_company,
                            'borrower_city_company' => $borrower_city_company,
                            'borrower_district_company' => $borrower_district_company,
                            'borrower_village_company' => $borrower_village_company,
                            'borrower_address_company' => $borrower_address_company,
                            'borrower_post_code_company' => $borrower_post_code_company,
                            'borrower_office_number' => $borrower_office_number,
                            'borrower_operating_costs' => $clean1,
                            'borrower_additional_costs' => $clean2
                                    
                            );

                        $update_komersil = $this->crud_model->update('tb_fintech_borrower_detail_commercial', 'register_code', $register_code,$data_komersil);
                        $this->session->set_flashdata('alert_success', 'Data successfully Updated.');
                        redirect(base_url().'Finance/F_borrower/borrower_komersil');
                        die();
                    }

                } else {     
                        $data_komersil = array(
                            'borrower_ktp_spouse' => $borrower_ktp_spouse,
                            // 'borrower_ktp_spouse_picture' => $file_data['file_name'],
                            
                            'borrower_montly_income' => $clean,
                            'borrower_collectibility_bi' => $borrower_collectibility_bi,
                            'borrower_business_name' => $borrower_business_name,
                            'borrower_business_form' => $borrower_business_form,
                            'borrower_industry_type' => $borrower_industry_type,
                            'borrower_business_field' => $borrower_business_field,
                            'borrower_long_entrepreneurship' => $borrower_long_entrepreneurship,
                            'borrower_province_company' => $borrower_province_company,
                            'borrower_city_company' => $borrower_city_company,
                            'borrower_district_company' => $borrower_district_company,
                            'borrower_village_company' => $borrower_village_company,
                            'borrower_address_company' => $borrower_address_company,
                            'borrower_post_code_company' => $borrower_post_code_company,
                            'borrower_office_number' => $borrower_office_number,
                            'borrower_operating_costs' => $clean1,
                            'borrower_additional_costs' => $clean2
                                    
                            );

                        $update_komersil = $this->crud_model->update('tb_fintech_borrower_detail_commercial', 'register_code', $register_code,$data_komersil);
                        $this->session->set_flashdata('alert_success', 'Data successfully Updated.');
                        redirect(base_url().'Finance/F_borrower/borrower_komersil');
                        die();
                }
            }
        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2',$navigation);
        $this->load->view('frontend-fintech/borrower/borrower_update_komersil', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function cek_nik_spouse(){
        $borrower_ktp_spouse = $this->input->post('borrower_ktp_spouse');

        $where = array('cek_ktp_nik' => $borrower_ktp_spouse );

        $check_validation_nik = $this->crud_model->get_data("tb_fintech_cek_ktp",$where)->num_rows();
        if($check_validation_nik!=0){
            $message = 'Nik Has Been Found';
            $is_success = true;

        }else{
            $message = 'Nik Not Found!';
            $is_success = false;
        }

        $result = array(
            'message' => $message,
            'is_success' => $is_success
        );

        echo json_encode($result);
       
    }


    public function borrower_file_komersil()
    {

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['purpose_new_loan_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');

        $footer['data_contact'] = $this->contact_model->get_contact();

        $navigation['purpose_new_loan_active'] = "active";

        $data['get_code'] = $register_code;
        $data['form_url'] = site_url('Finance/F_borrower/borrower_file_komersil'); 
        $data['data_siup'] = $this->personal_info_model->get_file_commercial($register_code,'SIUP');
        $data['data_npwp'] = $this->personal_info_model->get_file_commercial($register_code,'NPWP');
        $data['data_tdp'] = $this->personal_info_model->get_file_commercial($register_code,'TDP');
        $data['data_account'] = $this->personal_info_model->get_file_commercial($register_code,'Account');
        $data['data_certificate'] = $this->personal_info_model->get_file_commercial($register_code,'Certificate');
        $data['data_documentation'] = $this->personal_info_model->get_file_commercial($register_code,'Documentation');

        $this->form_validation->set_rules("register_code", "", "required");

        if ($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');

            if(!empty($_FILES['file_siup']['name'])){

                $file_upload_name1 = $this->input->post('siup');
                $name_file1 = $file_upload_name1."_".time()."_".rand(0,1000);
                $config1['upload_path'] = './uploads/Fintech/file_borrower_commercial';
                $config1['allowed_types'] = 'gif|jpg|png|jpeg';
                $config1['max_size']     = '5120';
                $config1['file_name'] = $name_file1;

                $this->load->library('upload', $config1);

                if(!$this->upload->do_upload('file_siup')){

                $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                redirect(base_url().'Finance/F_borrower/borrower_file_komersil');
                die();

                } else {
                   

                    $file_upload1 = $this->upload->data();

                    $data_komersil = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name1,
                        'file_upload' => $file_upload1['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name1);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->num_rows();
                    $this->upload->initialize($config1);
                    

                    if($data_check == 1){

                        $data_file = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->result();
                        $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_commercial/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_komersil = $this->crud_model->update('tb_fintech_file_commercial','id_file',$id_file, $data_komersil);
                    } else {
                        $insert_komersil = $this->crud_model->insert('tb_fintech_file_commercial', $data_komersil);
                    }
                      
                }
            }

            if(!empty($_FILES['file_npwp']['name'])){
                $file_upload_name2 = $this->input->post('npwp');
                $name_file2 = $file_upload_name2."_".time()."_".rand(0,1000);
                $config2['upload_path'] = './uploads/Fintech/file_borrower_commercial';
                $config2['allowed_types'] = 'gif|jpg|png|jpeg';
                $config2['max_size']     = '5120';
                $config2['file_name'] = $name_file2;

                $this->load->library('upload', $config2);


                if(!$this->upload->do_upload('file_npwp')){

                    $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                    redirect(base_url().'Finance/F_borrower/borrower_file_komersil');
                    die();

                } else {

                    
                    $file_upload2 = $this->upload->data();

                    $data_konsumtif = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name2,
                        'file_upload' => $file_upload2['file_name'],
                    );


                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name2);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->num_rows();
                    $this->upload->initialize($config2);

                    

                    if($data_check == 1){
                        $data_file = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->result();
                        $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_commercial/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_konsumtif = $this->crud_model->update('tb_fintech_file_commercial','id_file',$id_file, $data_konsumtif);
                    } else {
                        $insert_konsumtif = $this->crud_model->insert('tb_fintech_file_commercial', $data_konsumtif);
                    }
                    
                }
            }

            if(!empty($_FILES['file_tdp']['name'])){

                $file_upload_name3 = $this->input->post('tdp');
                $name_file3 =  $file_upload_name3."_".time()."_".rand(0,1000);
                $config3['upload_path'] = './uploads/Fintech/file_borrower_commercial';
                $config3['allowed_types'] = 'gif|jpg|png|jpeg';
                $config3['max_size']     = '5120';
                $config3['file_name'] = $name_file3;

                $this->load->library('upload', $config3);

                if(!$this->upload->do_upload('file_tdp')){

                $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                redirect(base_url().'Finance/F_borrower/borrower_file_komersil');
                die();

                } else {
                 
                    $file_upload3 = $this->upload->data();

                    $data_komersil = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name3,
                        'file_upload' => $file_upload3['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name3);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->num_rows();
                    $this->upload->initialize($config3);
                    

                    if($data_check == 1){

                        $data_file = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->result();
                         $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_commercial/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_komersil = $this->crud_model->update('tb_fintech_file_commercial','id_file',$id_file, $data_komersil);
                    } else {
                        $insert_komersil = $this->crud_model->insert('tb_fintech_file_commercial', $data_komersil);
                    }
                    
                }
            }

            if(!empty($_FILES['file_account']['name'])){

                $file_upload_name4 = $this->input->post('account');
                $name_file4 =  $file_upload_name4."_".time()."_".rand(0,1000);
                $config4['upload_path'] = './uploads/Fintech/file_borrower_commercial';
                $config4['allowed_types'] = 'gif|jpg|png|jpeg';
                $config4['max_size']     = '5120';
                $config4['file_name'] = $name_file4;

                $this->load->library('upload', $config4);

                if(!$this->upload->do_upload('file_account')){

                $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                redirect(base_url().'Finance/F_borrower/borrower_file_komersil');
                die();

                } else {
                 
                    $file_upload4 = $this->upload->data();

                    $data_komersil = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name4,
                        'file_upload' => $file_upload4['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name4);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->num_rows();
                    $this->upload->initialize($config4);
                    

                    if($data_check == 1){

                        $data_file = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->result();
                         $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_commercial/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_komersil = $this->crud_model->update('tb_fintech_file_commercial','id_file',$id_file, $data_komersil);
                    } else {
                        $insert_komersil = $this->crud_model->insert('tb_fintech_file_commercial', $data_komersil);
                    }
                    
                }
            }

            if(!empty($_FILES['file_certificate']['name'])){

                $file_upload_name5 = $this->input->post('certificate');
                $name_file5 =  $file_upload_name5."_".time()."_".rand(0,1000);
                $config5['upload_path'] = './uploads/Fintech/file_borrower_commercial';
                $config5['allowed_types'] = 'gif|jpg|png|jpeg';
                $config5['max_size']     = '5120';
                $config5['file_name'] = $name_file5;

                $this->load->library('upload', $config5);

                if(!$this->upload->do_upload('file_certificate')){

                $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                redirect(base_url().'Finance/F_borrower/borrower_file_komersil');
                die();

                } else {
                 
                    $file_upload5 = $this->upload->data();

                    $data_komersil = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name5,
                        'file_upload' => $file_upload5['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name5);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->num_rows();
                    $this->upload->initialize($config5);
                    

                    if($data_check == 1){

                        $data_file = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->result();
                         $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_commercial/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_komersil = $this->crud_model->update('tb_fintech_file_commercial','id_file',$id_file, $data_komersil);
                    } else {
                        $insert_komersil = $this->crud_model->insert('tb_fintech_file_commercial', $data_komersil);
                    }
                    
                }
            }

            if(!empty($_FILES['file_documentation']['name'])){

                $file_upload_name6 = $this->input->post('documentation');
                $name_file6 =  $file_upload_name6."_".time()."_".rand(0,1000);
                $config6['upload_path'] = './uploads/Fintech/file_borrower_commercial';
                $config6['allowed_types'] = 'gif|jpg|png|jpeg';
                $config6['max_size']     = '5120';
                $config6['file_name'] = $name_file6;

                $this->load->library('upload', $config6);

                if(!$this->upload->do_upload('file_documentation')){

                $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                redirect(base_url().'Finance/F_borrower/borrower_file_komersil');
                die();

                } else {
                 
                    $file_upload6 = $this->upload->data();

                    $data_komersil = array(
                        'register_code' => $register_code,
                        'file_upload_name' => $file_upload_name6,
                        'file_upload' => $file_upload6['file_name'],
                    );

                    $where = array('register_code' => $register_code, 'file_upload_name' => $file_upload_name6);
                    $data_check = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->num_rows();
                    $this->upload->initialize($config6);
                    

                    if($data_check == 1){

                        $data_file = $this->crud_model->get_data("tb_fintech_file_commercial", $where)->result();
                         $id_file = $data_file[0]->id_file;
                        
                        $file_path= './uploads/Fintech/file_borrower_commercial/'.$data_file[0]->file_upload;
                        @unlink($file_path);

                        $update_komersil = $this->crud_model->update('tb_fintech_file_commercial','id_file',$id_file, $data_komersil);
                    } else {
                        $insert_komersil = $this->crud_model->insert('tb_fintech_file_commercial', $data_komersil);
                    }
                    
                }
            }

            $this->session->set_flashdata('alert_success', 'Data successfully saved.');
            redirect(base_url().'Finance/F_borrower/borrower_file_komersil');
            die();
        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/borrower_file_komersil' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar_borrower');

    }

    public function dropdown_city_residence()
    {
      $id_indonesia_provinsi = $this->input->post('id_indonesia_provinsi');
      $data = $this->indonesia_model->get_city($id_indonesia_provinsi);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kota_kab>$value->nama</option>";
      }
    }

    public function dropdown_district()
    {
      $id_indonesia_kota_kab = $this->input->post('id_indonesia_kota_kab');

      $data = $this->indonesia_model->get_district($id_indonesia_kota_kab);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kec>$value->nama</option>";
      }
    }

    public function dropdown_village()
    {
      $id_indonesia_kec = $this->input->post('id_indonesia_kec');
      $data = $this->indonesia_model->get_village($id_indonesia_kec);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kel_des>$value->nama</option>";
      }
    }

    public function delete_temp_loan()
    {
        
        $id_borrower_temp_loan = $this->uri->segment(4);

        $data_temp_loan = $this->loan_model->get_all_temp_loan($id_borrower_temp_loan);

        if ($data_temp_loan[0]->loan_type == "Consumtive"){
            $url = "new_loan_consumtive";
        } else {
            $url = "new_loan_commercial";
        }
                    
        if (!empty($id_borrower_temp_loan)){

                $this->crud_model->delete('tb_fintech_borrower_temp_loan','id_borrower_temp_loan',$id_borrower_temp_loan);
                $this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
                redirect(base_url().'Finance/F_borrower/'.$url);
                die();

            } else {

                $this->session->set_flashdata('alert_error', 'Data failed to Delete !');
                redirect(base_url().'Finance/F_borrower/'.$url);
                die();

            }

    }

    public function detail($id_borrower_loan)
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['account_active'] = "active";

        // $data['export_pdf'] = site_url('Export_Pdf/pdf_accout_borrower');

        $data['get_code'] = $register_code;
        $data['get_id_borrower_loan'] = $id_borrower_loan;
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['data_loan'] = $this->loan_model->get_all_loan($id_borrower_loan, $register_code);
        $data['data_disbursed'] = $this->loan_model->get_ongoing_list(null,null, $register_code)->result();
        //$data['avg_interest'] = $this->loan_model->get_avg_interest($register_code);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        // $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/detail' , $data);
        // $this->load->view('frontend-fintech/partial/footer' , $footer);
        // $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function term_borrower($id_borrower_loan)
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['account_active'] = "active";

        $data['check_data'] = $this->crud_model->get_data("tb_fintech_register",$where)->result();


        $data['get_code'] = $register_code;
        $data['get_id_borrower_loan'] = $id_borrower_loan;
        $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        $data['data_register'] = $this->register_model->get_register_by_id($register_code);
        
        $data['data_consumtive'] = $this->personal_info_model->get_consumtive_borrower($register_code);
        $data['data_loan'] = $this->loan_model->get_loan_by_id($id_borrower_loan);
        $data['data_term'] = $this->account_model->get_term_by_id_nreg_borrower($id_borrower_loan);
        $data['data_contact'] = $this->contact_model->get_contact();
        $data['data_direk'] = $this->management_model->get_managementmenu_direk();
        $data['data_bio'] = $this->personal_info_model->get_personal_info_borrower($register_code);

        $prov_consumtive = ((array)@$data['data_consumtive'][0]);
        $data['data_province_consumtive'] = $this->indonesia_model->get_province_business_by_id(@$prov_consumtive['borrower_province_company']);
        $data['data_city_consumtive'] = $this->indonesia_model->get_city_business_by_id(@$prov_consumtive['borrower_city_company']);
        $data['data_district_consumtive'] = $this->indonesia_model->get_district_business_by_id(@$prov_consumtive['borrower_district_company']);
        $data['data_village_consumtive'] = $this->indonesia_model->get_village_business_by_id(@$prov_consumtive['borrower_village_company']);

        $data['data_commercial'] = $this->personal_info_model->get_commercial_borrower($register_code);

        $prov_commercial = ((array)@$data['data_commercial'][0]);
        $data['data_province_commercial'] = $this->indonesia_model->get_province_business_by_id(@$prov_commercial['borrower_province_company']);
        $data['data_city_commercial'] = $this->indonesia_model->get_city_business_by_id(@$prov_commercial['borrower_city_company']);
        $data['data_district_commercial'] = $this->indonesia_model->get_district_business_by_id(@$prov_commercial['borrower_district_company']);
        $data['data_village_commercial'] = $this->indonesia_model->get_village_business_by_id(@$prov_commercial['borrower_village_company']);

        //$data['avg_interest'] = $this->loan_model->get_avg_interest($register_code);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        // $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/borrower/term_borrower' , $data);
        // $this->load->view('frontend-fintech/partial/footer' , $footer);
        // $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

}
?>
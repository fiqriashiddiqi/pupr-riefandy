<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_register extends CI_Controller {

	function __construct()
    {
        
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('Website/artikel_model');
        $this->load->model('Parameter/param_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/slideshow_model');
        $this->load->model('Website/management_model');
        $this->load->model('Front_Fintech/register_model');
        $this->load->model('crud_model');
        $this->load->model('Front_Fintech/indonesia_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('Front_Fintech/personal_info_model');

        date_default_timezone_set("Asia/Jakarta");
    }


    public function register()
    {


        $navigation['lender_active'] = "";
        $navigation['style_register'] = "orange";
        $this->load->helper(array('form', 'url'));
        $this->load->helper('file');
       
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('investor');
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Home');
        $data['data_province'] = $this->indonesia_model->get_province();

        $footer['data_contact'] = $this->contact_model->get_contact();
     
        $data['form_url'] = site_url('Finance/F_register/register');
        
        $this->form_validation->set_rules("register_email", "email", "required");
        // $this->form_validation->set_rules("register_username", "username", "trim|required");
        $this->form_validation->set_rules("register_password", "password", "trim|required");
        $this->form_validation->set_rules("register_re_password", " re password", "trim|required");
        $this->form_validation->set_rules("register_how_know_sanders", "hks", "trim|required");

        if ($this->form_validation->run() == true){
                
            $register_email = $this->input->post('register_email');
            
            // $register_username = $this->input->post('register_username');
            $register_password = sha1($this->input->post('register_password'));
            $register_re_password = sha1($this->input->post('register_re_password'));
            $register_how_know_sanders = $this->input->post('register_how_know_sanders');
            $regiter_how_know_sanders_other = $this->input->post('regiter_how_know_sanders_other');

            $where = array('register_email' => $register_email );
            $check_validation_email = $this->crud_model->get_data("tb_fintech_register",$where)->num_rows();

            // $where_username = array('register_username' => $register_username );
            // $check_validation_username = $this->crud_model->get_data("tb_fintech_register",$where_username)->num_rows();
            


                if ($this->input->post('register_status') == "Lender"){
                    $register_status = "Lender";

                } else if($this->input->post('register_status') == "Borrower"){
                    $register_status = "Borrower";

                } else {
                    $register_status = "";

                }

                if (empty($register_status)){
                    $this->session->set_flashdata('alert_error', 'radio button fail.');
                    redirect(base_url().'Finance/F_register/register');     
                    die();
                }

                if (!empty($regiter_how_know_sanders_other)){
                    $register_how_know_sanders = $regiter_how_know_sanders_other;
                }

                if ($register_password != $register_re_password){
                    $this->session->set_flashdata('alert_error', ' password not same');
                    redirect(base_url().'Finance/F_register/register');     
                    die();
                }

                if($register_status == "Borrower"){
                    if ($this->input->post('borrower_bio_cityzenship') == "WNI"){
                        if (empty($_FILES['borrower_link_picture']['name'])){
                            $this->session->set_flashdata('alert_error', 'uploaded file ktp borrower empty !');
                            redirect(base_url().'Finance/F_register/register');
                            die();
                        }
                    } else {
                        if (empty($_FILES['borrower_bio_upload_passport']['name'])){
                            $this->session->set_flashdata('alert_error', 'uploaded file passport empty !');
                            redirect(base_url().'Finance/F_register/register');
                            die();
                        }
                    }
                } else {
                    if ($this->input->post('lender_bio_cityzenship') == "WNI"){
                        if (empty($_FILES['lender_link_picture']['name'])){
                            $this->session->set_flashdata('alert_error', 'uploaded file ktp investor empty !');
                            redirect(base_url().'Finance/F_register/register');
                            die();
                        }
                    } else {
                        if (empty($_FILES['lender_bio_upload_passport']['name'])){
                            $this->session->set_flashdata('alert_error', 'uploaded file passport empty !');
                            redirect(base_url().'Finance/F_register/register');
                            die();
                        }
                    }
                }

                $date = date('Y-m-d H:i:s');

                $reg_ID = $this->crud_model->get_setting();
                $idMax = $this->register_model->register_code($reg_ID[0]->reg_ID);
                $noUrut = (int) substr($idMax[0]->maxID,4,8);
                $noUrut ++;
                $newID = $reg_ID[0]->reg_ID.sprintf("%08s",$noUrut);

                $random_ref = mt_rand(10000000, 99999999);
                // $ref_code = $this->register_model->reference_code();
                $newref = "REF-".$random_ref;

                $random = rand(100000,99999999); 
        
                if($check_validation_email == 0){
                    // if($check_validation_username == 0){

                        $data_register = array(
                            'register_code' => $newID,
                            'register_email' => $register_email,
                            // 'register_username' => $register_username,
                            'register_password' => $register_password,
                            'register_how_know_sanders' => $register_how_know_sanders,
                            'register_last_signin' => $date,
                            'register_last_signout' => $date,
                            'register_activation_code' => $random,
                            'register_activation_status' => 'Deactivated',
                            'register_status' => $register_status,
                            'register_access_status' => 'Deactivated',
                            'term_status' => 'yes',
                            'reference_code' => $newref
                        );
                        
                        $insert_register = $this->crud_model->insert('tb_fintech_register',$data_register);

                        if($register_status == "Borrower"){
                            
                            $bio_fullname = $this->input->post('borrower_bio_fullname');
                            $bio_place_birth_date = $this->input->post('borrower_bio_place_birth_date');
                            $bio_birth_date = $this->input->post('borrower_bio_birth_date');
                            $bio_gender = $this->input->post('borrower_bio_gender');
                            $bio_phone = $this->input->post('borrower_bio_phone');
                            $bio_marriage_status = $this->input->post('borrower_bio_marriage_status');
                            $bio_spouse_name = $this->input->post('borrower_bio_spouse_name');
                            $bio_spouse_phone = $this->input->post('borrower_bio_spouse_phone');
                            $bio_occupation = $this->input->post('borrower_bio_occupation');
                            $bio_occupation_others = $this->input->post('borrower_bio_occupation_others');
                            $bio_country = $this->input->post('borrower_bio_country');
                            $bio_address = $this->input->post('borrower_bio_address');
                            $bio_post_code = $this->input->post('borrower_bio_post_code');
                            $bio_reference_code = $this->input->post('borrower_bio_reference_code');
                            $bio_mother_name = $this->input->post('borrower_bio_mother_name');
                            $bio_last_education = $this->input->post('borrower_bio_last_education');
                            $bio_cityzenship = $this->input->post('borrower_bio_cityzenship');
                            $bio_nik = $this->input->post('borrower_bio_nik');
                            $bio_upload_nik = $this->input->post('borrower_link_picture');
                            $bio_passport = $this->input->post('borrower_bio_passport');
                            $bio_upload_passport = $this->input->post('borrower_bio_upload_passport');

                            if ($bio_cityzenship == 'WNI'){
                            $bio_province = $this->input->post('borrower_bio_province_select');
                            $bio_city = $this->input->post('borrower_bio_city_select');
                            $bio_district = $this->input->post('borrower_bio_district_select');
                            $bio_village = $this->input->post('borrower_bio_village_select');
                            } else {
                            $bio_province = $this->input->post('borrower_bio_province');
                            $bio_city = $this->input->post('borrower_bio_city');
                            $bio_district = $this->input->post('borrower_bio_district');
                            $bio_village = $this->input->post('borrower_bio_village');  
                            }

                            $bio_birth_date = date ('Y-m-d', strtotime($bio_birth_date));

                            // $where = array('cek_ktp_nik' => $bio_nik );
                            // $check_validation_nik = $this->crud_model->get_data("tb_fintech_cek_ktp",$where)->num_rows();

                            if (!empty($bio_occupation_others)){
                                $bio_occupation = $bio_occupation_others;
                            }


                            if (empty($bio_reference_code)){
                                $bio_reference_code = "-";
                            } else {
                                $date = date('Y-m-d');

                                $data_setting = $this->crud_model->get_setting();
                                $point   = $data_setting[0]->point_reference;
                                $ref_code = $this->input->post('lender_bio_reference_code');

                                $where = array('reference_code' => $ref_code );
                                $check_validation_ref_code = $this->crud_model->get_data("tb_fintech_register",$where)->result();
                                // $get_ref_code = $this->crud_model->get_data_table("tb_fintech_register")->result();

                                
                                
                                $data_reference = array(
                                    'register_code' => $check_validation_ref_code[0]->register_code,
                                    'reference_name' => 'Reference Code From Register',
                                    'reference_point' => $point,
                                    'reference_date' => $date
                                );

                                $insert_bio = $this->crud_model->insert('tb_fintech_borrower_reference',$data_reference);
                            }

                            if ($bio_marriage_status == "Single"){
                                $bio_spouse_name = "-";
                                $bio_spouse_phone = "-";
                            }

                            if ($bio_cityzenship == "WNI"){

                                $name_file = $bio_fullname."_".time();
                                $config['upload_path'] = './uploads/Fintech/ktp_borrower';
                                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                                $config['file_name'] = $name_file;

                                $this->load->library('upload', $config);

                                if(!$this->upload->do_upload('borrower_link_picture')){
                                    
                                    $this->session->set_flashdata('alert_error', 'uploaded ktp borrower failed, file is too big or wrong file format !');
                                    redirect(base_url().'Finance/F_register/register');
                                    die();

                                } else {

                                // if($check_validation_nik == 1){

                                    $file_data = $this->upload->data();
                                    
                                    $data_bio = array(
                                        'register_code' => $newID,
                                        'bio_fullname' => $bio_fullname,
                                        'bio_place_birth_date' => $bio_place_birth_date,
                                        'bio_birth_date' => $bio_birth_date,
                                        'bio_gender' => $bio_gender,
                                        'bio_phone' => $bio_phone,
                                        'bio_marriage_status' => $bio_marriage_status,
                                        'bio_spouse_name' => $bio_spouse_name,
                                        'bio_spouse_phone' => $bio_spouse_phone,
                                        'bio_occupation' => $bio_occupation,
                                        'bio_country' => 'Indonesia',
                                        'bio_province' => $bio_province,
                                        'bio_city' => $bio_city,
                                        'bio_district' => $bio_district,
                                        'bio_village' => $bio_village,
                                        'bio_address' => $bio_address,
                                        'bio_post_code' => $bio_post_code,
                                        'bio_reference_code' => $bio_reference_code,
                                        'bio_mother_name' => $bio_mother_name,
                                        'bio_last_education' => $bio_last_education,
                                        'bio_cityzenship' => $bio_cityzenship,
                                        'bio_nik' => $bio_nik,
                                        'bio_upload_nik' => $file_data['file_name'],
                                        'bio_passport' => "-",
                                        'bio_upload_passport' => "-",
                                    );

                                    $insert_bio = $this->crud_model->insert('tb_fintech_borrower_bio',$data_bio);

                                // }else{

                                //     $this->session->set_flashdata('alert_error', 'NIK NOT FOUND');
                                //     redirect(base_url().'Finance/F_register/register');
                                //     die();

                                // }
                               
                             }

                            } else {
                                $name_file = $bio_fullname."_".time();
                                $config['upload_path'] = './uploads/Fintech/passport_borrower';
                                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                                $config['file_name'] = $name_file;

                                $this->load->library('upload', $config);

                                if(!$this->upload->do_upload('borrower_bio_upload_passport')){
                                    
                                    $this->session->set_flashdata('alert_error', 'uploaded passport borrower failed, file is too big or wrong file format !');
                                    redirect(base_url().'Finance/F_register/register');
                                    die();

                                } else {

                                    $file_data = $this->upload->data();
                                    
                                    $data_bio = array(
                                        'register_code' => $newID,
                                        'bio_fullname' => $bio_fullname,
                                        'bio_place_birth_date' => $bio_place_birth_date,
                                        'bio_birth_date' => $bio_birth_date,
                                        'bio_gender' => $bio_gender,
                                        'bio_phone' => $bio_phone,
                                        'bio_marriage_status' => $bio_marriage_status,
                                        'bio_spouse_name' => $bio_spouse_name,
                                        'bio_spouse_phone' => $bio_spouse_phone,
                                        'bio_occupation' => $bio_occupation,
                                        'bio_country' => $bio_country,
                                        'bio_province' => $bio_province,
                                        'bio_city' => $bio_city,
                                        'bio_district' => "-",
                                        'bio_village' => "-",
                                        'bio_address' => $bio_address,
                                        'bio_post_code' => $bio_post_code,
                                        'bio_reference_code' => $bio_reference_code,
                                        'bio_mother_name' => $bio_mother_name,
                                        'bio_last_education' => $bio_last_education,
                                        'bio_cityzenship' => $bio_cityzenship,
                                        'bio_nik' => "-",
                                        'bio_upload_nik' => "-",
                                        'bio_passport' => $bio_passport,
                                        'bio_upload_passport' => $file_data['file_name'],
                                    );

                                    $insert_bio = $this->crud_model->insert('tb_fintech_borrower_bio',$data_bio);

                                }

                            } 

                        } else {
                            
                            $bio_fullname = $this->input->post('lender_bio_fullname');
                            $bio_place_birth_date = $this->input->post('lender_bio_place_birth_date');
                            $bio_birth_date = $this->input->post('lender_bio_birth_date');
                            $bio_gender = $this->input->post('lender_bio_gender');
                            $bio_phone = $this->input->post('lender_bio_phone');
                            $bio_marriage_status = $this->input->post('lender_bio_marriage_status');
                            $bio_spouse_name = $this->input->post('lender_bio_spouse_name');
                            $bio_spouse_phone = $this->input->post('lender_bio_spouse_phone');
                            $bio_occupation = $this->input->post('lender_bio_occupation');
                            $bio_occupation_others = $this->input->post('lender_bio_occupation_others');
                            $bio_country = $this->input->post('lender_bio_country');
                            $bio_address = $this->input->post('lender_bio_address');
                            $bio_post_code = $this->input->post('lender_bio_post_code');
                            $bio_reference_code = $this->input->post('lender_bio_reference_code');
                            $bio_last_education = $this->input->post('lender_bio_last_education');
                            $bio_cityzenship = $this->input->post('lender_bio_cityzenship');
                            $bio_nik = $this->input->post('lender_bio_nik');
                            $bio_upload_nik = $this->input->post('lender_link_picture');
                            $bio_passport = $this->input->post('lender_bio_passport');
                            $bio_upload_passport = $this->input->post('lender_bio_upload_passport');
                            
                            if ($bio_cityzenship == 'WNI'){
                            $bio_province = $this->input->post('lender_bio_province_select');
                            $bio_city = $this->input->post('lender_bio_city_select');
                            $bio_district = $this->input->post('lender_bio_district_select');
                            $bio_village = $this->input->post('lender_bio_village_select');
                            } else {
                            $bio_province = $this->input->post('lender_bio_province');
                            $bio_city = $this->input->post('lender_bio_city');
                            $bio_district = $this->input->post('lender_bio_district');
                            $bio_village = $this->input->post('lender_bio_village');  
                            }

                            $bio_birth_date = date ('Y-m-d', strtotime($bio_birth_date));

                            if (!empty($bio_occupation_others)){
                                $bio_occupation = $bio_occupation_others;
                            }

                            if (empty($bio_reference_code)){
                                $bio_reference_code = "-";
                            } else {
                                $date = date('Y-m-d');

                                $data_setting = $this->crud_model->get_setting();
                                $point   = $data_setting[0]->point_reference;
                                $ref_code = $this->input->post('lender_bio_reference_code');

                                $where = array('reference_code' => $ref_code );
                                $check_validation_ref_code = $this->crud_model->get_data("tb_fintech_register",$where)->result();
                                // $get_ref_code = $this->crud_model->get_data_table("tb_fintech_register")->result();



                                $data_reference = array(
                                    'register_code' => $check_validation_ref_code[0]->register_code,
                                    'reference_name' => 'Reference Code From Register',
                                    'reference_point' => $point,
                                    'reference_date' => $date
                                );

                                $insert_bio = $this->crud_model->insert('tb_fintech_lender_reference',$data_reference);
                            }

                            if ($bio_marriage_status == "Single"){
                                $bio_spouse_name = "-";
                                $bio_spouse_phone = "-";
                            }

                            if ($bio_cityzenship == "WNI"){

                                $name_file = $bio_fullname."_".time();
                                $config['upload_path'] = './uploads/Fintech/ktp_lender';
                                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                                $config['max_size']     = '5120';
                                $config['file_name'] = $name_file;

                                $this->load->library('upload', $config);

                                if(!$this->upload->do_upload('lender_link_picture')){
                                    
                                    $this->session->set_flashdata('alert_error', 'uploaded ktp investor failed, file is too big or wrong file format !');
                                    redirect(base_url().'Finance/F_register/register');
                                    die();

                                } else {

                                    $file_data = $this->upload->data();
                                    
                                    $data_bio = array(
                                        'register_code' => $newID,
                                        'bio_fullname' => $bio_fullname,
                                        'bio_place_birth_date' => $bio_place_birth_date,
                                        'bio_birth_date' => $bio_birth_date,
                                        'bio_gender' => $bio_gender,
                                        'bio_phone' => $bio_phone,
                                        'bio_marriage_status' => $bio_marriage_status,
                                        'bio_spouse_name' => $bio_spouse_name,
                                        'bio_spouse_phone' => $bio_spouse_phone,
                                        'bio_occupation' => $bio_occupation,
                                        'bio_country' => 'Indonesia',
                                        'bio_province' => $bio_province,
                                        'bio_city' => $bio_city,
                                        'bio_district' => $bio_district,
                                        'bio_village' => $bio_village,
                                        'bio_address' => $bio_address,
                                        'bio_post_code' => $bio_post_code,
                                        'bio_reference_code' => $bio_reference_code,
                                        'bio_last_education' => $bio_last_education,
                                        'bio_cityzenship' => $bio_cityzenship,
                                        'bio_nik' => $bio_nik,
                                        'bio_upload_nik' => $file_data['file_name'],
                                        'bio_passport' => "-",
                                        'bio_upload_passport' => "-",
                                    );

                                    $insert_bio = $this->crud_model->insert('tb_fintech_lender_bio',$data_bio);

                                }

                            } else {
                                $name_file = $bio_fullname."_".time();
                                $config['upload_path'] = './uploads/Fintech/passport_lender';
                                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                                $config['file_name'] = $name_file;

                                $this->load->library('upload', $config);

                                if(!$this->upload->do_upload('lender_bio_upload_passport')){
                                    
                                    $this->session->set_flashdata('alert_error', 'uploaded passport investor failed, file is too big or wrong file format !');
                                    redirect(base_url().'Finance/F_register/register');
                                    die();

                                } else {

                                    $file_data = $this->upload->data();
                                    
                                    $data_bio = array(
                                        'register_code' => $newID,
                                        'bio_fullname' => $bio_fullname,
                                        'bio_place_birth_date' => $bio_place_birth_date,
                                        'bio_birth_date' => $bio_birth_date,
                                        'bio_gender' => $bio_gender,
                                        'bio_phone' => $bio_phone,
                                        'bio_marriage_status' => $bio_marriage_status,
                                        'bio_spouse_name' => $bio_spouse_name,
                                        'bio_spouse_phone' => $bio_spouse_phone,
                                        'bio_occupation' => $bio_occupation,
                                        'bio_country' => $bio_country,
                                        'bio_province' => $bio_province,
                                        'bio_city' => $bio_city,
                                        'bio_district' => "-",
                                        'bio_village' => "-",
                                        'bio_address' => $bio_address,
                                        'bio_post_code' => $bio_post_code,
                                        'bio_reference_code' => $bio_reference_code,
                                        'bio_last_education' => $bio_last_education,
                                        'bio_cityzenship' => $bio_cityzenship,
                                        'bio_nik' => "-",
                                        'bio_upload_nik' => "-",
                                        'bio_passport' => $bio_passport,
                                        'bio_upload_passport' => $file_data['file_name'],
                                    );

                                    $insert_bio = $this->crud_model->insert('tb_fintech_lender_bio',$data_bio);

                                }

                            } 

                        }

                        if($insert_bio === false){

                            $this->session->set_flashdata('alert_error', 'Data not saved. email not send');
                            redirect(base_url().'Finance/F_register/register');
                            die();  

                        } else {
                            
                            $config = array();
                            $config['charset'] = 'iso-8859-1';
                            $config['useragent'] = 'Codeigniter';
                            $config['protocol']= 'smtp';
                            $config['mailtype']= 'html';
                            $config['smtp_host']= 'ssl://mail.heatcliffs31.com';//pengaturan smtp
                            $config['smtp_port']= 465;
                            $config['smtp_timeout']= 400;
                            $config['smtp_user']= 'sanders@heatcliffs31.com'; // isi dengan email kamu
                            $config['smtp_pass']= '1q2w3e4r5t'; // isi dengan password kamu
                            $config['crlf']="\r\n"; 
                            $config['newline']="\r\n"; 
                            $config['wordwrap'] = TRUE;
                                    //memanggil library email dan set konfigurasi untuk pengiriman email
                            $this->load->library('email',$config);
                            $this->email->initialize($config);
                            $where_check = array('register_activation_code' => $random);

                                    //konfigurasi pengiriman
                            $this->email->from($config['smtp_user']);
                            $this->email->to($register_email);
                            $this->email->subject("Verifikasi Akun");
                            $body = $this->load->view('frontend-fintech/email_verify.php',$where_check,TRUE);
                            $this->email->message($body);
                            $this->email->send();

                            $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                            redirect(base_url().'Finance/F_register/check_activation');
                            die();  
                        }


                    // } else {

                        // $this->session->set_flashdata('alert_error', 'The username you entered has been already,please try again !');
                        // $this->session->set_flashdata('cache_username', $register_username);
                    //     $this->session->set_flashdata('cache_email', $register_email);
                    //     $this->session->set_flashdata('cache_hks', $register_how_know_sanders);
                    //     $this->session->set_flashdata('cache_status', $register_status);
                    //     redirect(base_url().'Finance/F_register/register');
                    //     die();
                    // }

                } else {

                    // $this->session->set_flashdata('alert_error', 'The email you entered has been already,please try again !');
                    // $this->session->set_flashdata('cache_username', $register_username);
                    $this->session->set_flashdata('cache_email', $register_email);
                    $this->session->set_flashdata('cache_hks', $register_how_know_sanders);
                    $this->session->set_flashdata('cache_status', $register_status);
                    redirect(base_url().'Finance/F_register/register');
                    die();
                }  

        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-web/partial/navigation' , $navigation);
        $this->load->view('frontend-fintech/register', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar');
        // $this->load->view('frontend-fintech/partial/endfooter');
    }

    public function cek_email(){
        $email = $this->input->post('register_email');

        $where = array('register_email' => $email );
        $check_validation_email = $this->crud_model->get_data("tb_fintech_register",$where)->num_rows();
        if($check_validation_email == 0){
            $message = 'Email is available';
            $is_success = true;

        }else{
            $message = 'Email not available';
            $is_success = false;
        }

        $result = array(
            'message' => $message,
            'is_success' => $is_success
        );

        echo json_encode($result);
       
    }

    public function cek_ref_code(){

        
        $random_ref = mt_rand(10000000, 99999999);
        $newref = "REF-".$random_ref;

        $check_reference_code = $this->crud_model->get_data_table("tb_fintech_register")->result();
        foreach ($check_reference_code as $entry_reference_code) {
           if($entry_reference_code->reference_code != $newref){
            $ref_code = $newref;

            } 
        }
        

        $result = array(
            'ref_code' => $ref_code
        );

        echo json_encode($result);
       
    }

    public function validation_ref_code_borrower(){

        $ref_code = $this->input->post('borrower_bio_reference_code');

        $where = array('reference_code' => $ref_code );
        $check_validation_ref_code = $this->crud_model->get_data("tb_fintech_register",$where)->num_rows();
        if($check_validation_ref_code!=0){
            $message = '';
            $is_success = true;

        }else{
            $message = 'Reference Code Invalid!';
            $is_success = false;
        }

        $result = array(
            'message' => $message,
            'is_success' => $is_success
        );

        echo json_encode($result);
       
    }

    public function validation_ref_code_lender(){

        $ref_code = $this->input->post('lender_bio_reference_code');

        $where = array('reference_code' => $ref_code );
        $check_validation_ref_code = $this->crud_model->get_data("tb_fintech_register",$where)->num_rows();
        if($check_validation_ref_code!=0){
            $message = '';
            $is_success = true;

        }else{
            $message = 'Reference Code Invalid!';
            $is_success = false;
        }

        $result = array(
            'message' => $message,
            'is_success' => $is_success
        );

        echo json_encode($result);
       
    }

    public function cek_nik_lender(){
        $nik = $this->input->post('lender_bio_nik');

        $where = array('bio_nik' => $nik );
        $check_validation_nik = $this->crud_model->get_data("tb_fintech_lender_bio",$where)->num_rows();
        
        if($check_validation_nik!=0){
            $message = 'Nik has been registered!';
            $is_success = true;

        } else {
            $message = 'nik';
            $is_success = false;
        }

        $result = array(
            'message' => $message,
            'is_success' => $is_success
        );

        echo json_encode($result);
       
    }

    public function cek_nik(){
        $nik = $this->input->post('borrower_bio_nik');

        $where_borrower = array('bio_nik' => $nik );
        $check_validation_nik_borrower = $this->crud_model->get_data("tb_fintech_borrower_bio",$where_borrower)->num_rows();
        if($check_validation_nik_borrower!=0){
            $message = 'Nik has been registered!';
            $is_success = true;

        } else {
            $message = 'nik';
            $is_success = false;
        }

        $result = array(
            'message' => $message,
            'is_success' => $is_success
        );

        echo json_encode($result);
       
    }

    public function activation()
    {

        $navigation['lender_active'] = "";
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Home');
        $footer['data_contact'] = $this->contact_model->get_contact();
         $data['data_contacts'] = $this->contact_model->get_contact();

        $random = isset($_REQUEST['SA']) ? $_REQUEST['SA'] : NULL;

        $data['register_activation_code'] = $random;
        $data['form_url'] = site_url("Finance/F_register/activation");
        $data['data_direk'] = $this->management_model->get_managementmenu_direk();
        

        $this->form_validation->set_rules("register_activation_code", "", "required");

        if ($this->form_validation->run() == true){

            $random = $this->input->post('register_activation_code');

            $where_check = array('register_activation_code' => $random);
            $check = $this->crud_model->get_data("tb_fintech_register",$where_check)->num_rows();
            $check_data = $this->crud_model->get_data("tb_fintech_register",$where_check)->result();

            $register_code = $check_data[0]->register_code;
            $where = array('register_code'=>$register_code);
            $data['data_bio'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
            $data['get_code'] = $register_code;
            $data['data_bio'] = $this->personal_info_model->get_personal_info_borrower($register_code);

            if($check == 1){
                    $data_users_update = array(
                        'register_activation_status' => 'Activated',
                        'register_access_status' => 'Activated'
                    );

                    $update_users = $this->crud_model->update('tb_fintech_register', 'register_code', $register_code, $data_users_update);

                if ($check_data[0]->register_status == "Lender") {
                    $idMax = $this->register_model->term_code();
                    $noUrut = (int) substr($idMax[0]->maxID,4,8);
                    $noUrut ++;
                    $term_id = $register_code."/SA/".date('m/Y');
                    $date = date('Y-m-d H:i:s');
                    $data_term_lender = array(
                        'term_id' => $term_id,
                        'term_date' => $date,
                        'register_code' => $register_code,
                        'term_status' => "Yes",
                     );
                    $insert_term = $this->crud_model->insert('tb_fintech_term_lender',$data_term_lender);
                }
                    
                    $this->session->set_flashdata('alert_success', 'Your account has activated, please login');
                    redirect(base_url().'Finance/f_login/login');
                    die();
            } else {
                $this->session->set_flashdata('alert_error', 'Your activated link is out to date !');
                redirect(base_url().'Finance/F_register/register');
                die();
            }

        } 

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-web/partial/navigation' , $navigation);
        $this->load->view('frontend-fintech/activation', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar');

    }

    public function check_activation()
    {
        $navigation['lender_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('investor');
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Home');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation_login',$navigation);
        $this->load->view('frontend-fintech/check_activation', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/endfooter');
    }

    public function dropdown_city_residence()
    {
      $id_indonesia_provinsi = $this->input->post('id_indonesia_provinsi');
      $data = $this->indonesia_model->get_city($id_indonesia_provinsi);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kota_kab>$value->nama</option>";
      }
    }

    public function dropdown_district()
    {
      $id_indonesia_kota_kab = $this->input->post('id_indonesia_kota_kab');

      $data = $this->indonesia_model->get_district($id_indonesia_kota_kab);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kec>$value->nama</option>";
      }
    }

    public function dropdown_village()
    {
      $id_indonesia_kec = $this->input->post('id_indonesia_kec');
      $data = $this->indonesia_model->get_village($id_indonesia_kec);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kel_des>$value->nama</option>";
      }
    }
}

?>
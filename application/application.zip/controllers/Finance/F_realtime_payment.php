<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_realtime_payment extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('Front_Fintech/payment_model');
        $this->load->model('crud_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('Front_Fintech/report_model');
        $this->load->model('General_Ledger/journal_model');

        date_default_timezone_set("Asia/Jakarta");

    }

    public function index()
    {

        $date_now = date("Y-m-d");
        $data_loan = $this->payment_model->get_realtime_loan();

            // memilih pinjaman start
            foreach ($data_loan as $loan_entry) {
               
                $loan_code = $loan_entry->id_borrower_loan;
                $loan_date = $loan_entry->loan_date;
                $loan_type = $loan_entry->loan_type;
                $loan_tenor = $loan_entry->loan_tenor;
                $loan_amount = $loan_entry->loan_amount;
                $borrower_code = $loan_entry->register_code;

                    // memilih type pinjaman start
                    if($loan_type == "Personal Loan" OR $loan_type == "Fixed Loan"){

                        // memilih payment start
                        $data_loan_payment = $this->payment_model->get_realtime_loan_payment($loan_code);

                            foreach ($data_loan_payment as $loan_payment_entry){

                                    // jika jika telat start
                                    if ($loan_payment_entry->payment_periode_date < $date_now AND $loan_payment_entry->payment_periode_status_principal != "On Time" AND $loan_payment_entry->payment_periode_status_principal != "Late, Already Paid"){

                                        // menghitung pinalty start
                                        $id_payment_periode_pinalty = $loan_payment_entry->id_payment_periode + 1;
                                        //var_dump($id_payment_periode_pinalty);

                                        $principal = $loan_payment_entry->payment_periode_principal; 
                                        $interest = $loan_payment_entry->payment_periode_interest; 
                                        $data_pinalty_rate = $this->payment_model->get_realtime_fee();
                                        $pinalty_rate = $data_pinalty_rate[0]->penalty / 100;
                                        $total_pinalty = ($principal + $interest) * $pinalty_rate;

                                        $date_start = date($loan_payment_entry->payment_periode_date);
                                        $date_end = $date_now;

                                        $dt1 = strtotime($date_start);
                                        $dt2 = strtotime($date_end);
                                        $diff = abs($dt2-$dt1);
                                        $late_day = $diff/86400;

                                        $total_day_to_pinalty = $total_pinalty * $late_day;

                                        $data_payment_periode_update_pinalty = array(
                                            "payment_periode_pinalty" => $total_day_to_pinalty,
                                        );

                                        $update_pinalty = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_payment_periode',$id_payment_periode_pinalty,$data_payment_periode_update_pinalty);
                                        // menghitung pinalty end
                                    }

                            }
                            // memilih payment end
                    }
                    // memilih type pinjaman end

                    // memilih type pinjaman start
                    if($loan_type == "Personal Loan" OR $loan_type == "Fixed Loan"){

                        // memilih payment start
                        $data_loan_payment = $this->payment_model->get_realtime_loan_payment($loan_code);

                            foreach ($data_loan_payment as $loan_payment_entry){
                                    // jika jika telat start pinalty
                                    if ($loan_payment_entry->payment_periode_date < $date_now AND $loan_payment_entry->payment_periode_status_principal != "On Time" AND $loan_payment_entry->payment_periode_status_principal != "Late, Already Paid"){

                                            $payment_periode_id = $loan_payment_entry->id_payment_periode;
                                            $payment_principal = $loan_payment_entry->payment_periode_principal;
                                            $payment_interest = $loan_payment_entry->payment_periode_interest;
                                            $payment_pinalty = $loan_payment_entry->payment_periode_pinalty;

                                            $data_setting = $this->crud_model->get_setting();
                                            $fee_pg = $data_setting[0]->fee_pg;
                                            $total_payment_amount = ($payment_principal + $payment_interest) + $payment_pinalty;
                                            $total_payment = $total_payment_amount + $fee_pg;

                                            $data_commision_payment_gl = $this->payment_model->get_realtime_fee();
                                            $commision_payment_gl = $data_commision_payment_gl[0]->commision_borrower / 100;
                                            $total_commision_payment_gl = $commision_payment_gl * $total_payment_amount;
                                            $total_commision_pinalty_gl = $commision_payment_gl * ($payment_pinalty);
                                            $total_pinalty_lender_gl = $payment_pinalty - $total_commision_pinalty_gl;

                                            $data_borrower_fund = $this->payment_model->get_realtime_borrower_fund($borrower_code);
                                            $avaible_fund_borrower = $data_borrower_fund[0]->amount;

                                            // jika borrower fund cek start
                                            if ($avaible_fund_borrower >= $total_payment){

                                                // update uang / avaible fund borrower start
                                                $fund_borrower = $avaible_fund_borrower - $total_payment;

                                                $data_fund_update = array(
                                                    "amount" => $fund_borrower,
                                                );

                                                $update_fund = $this->crud_model->update('tb_fintech_borrower_fund','register_code',$borrower_code,$data_fund_update);
                                                // update uang / avaible fund borrower end

                                                // memilih investor start
                                                $data_investment = $this->payment_model->get_realtime_investor($loan_code);

                                                    foreach ($data_investment as $investment_entry) {

                                                        $lender_code = $investment_entry->register_code;
                                                        $investment_code = $investment_entry->investment_code;
                                                        $invest_amount = $investment_entry->amount_invest;

                                                        $payment_to_lender = ($invest_amount / $loan_amount) * $total_payment_amount;

                                                        $data_commision_payment = $this->payment_model->get_realtime_fee();
                                                        $commision_payment = $data_commision_payment[0]->commision_borrower / 100;

                                                        $total_commision_payment = $commision_payment * $payment_to_lender;
                                                        $total_payment_to_lender = $payment_to_lender - $total_commision_payment;

                                                            // simpan ke masing masing investor start
                                                            $data_payment_insert_to_lender = array(
                                                                "investment_code" => $investment_code,
                                                                "payment_date" => $date_now,
                                                                "payment_amount" => $total_payment_to_lender,
                                                                "payment_fee" => $total_commision_payment,
                                                                "payment_status" => 'Success',
                                                            );

                                                            $insert_to_lender = $this->crud_model->insert('tb_fintech_lender_investment_payment',$data_payment_insert_to_lender);  
                                                            // simpan ke masing masing investor end 

                                                            // update uang / avaible fund lender start
                                                            $data_lender_fund = $this->payment_model->get_realtime_lender_fund($lender_code);
                                                            $avaible_fund_lender = $data_lender_fund[0]->amount;
                                                            $fund_lender = $avaible_fund_lender + $total_payment_to_lender;

                                                            $data_fund_lender_update = array(
                                                                "amount" => $fund_lender,
                                                            );

                                                            $update_fund_lender = $this->crud_model->update('tb_fintech_lender_fund','register_code',$lender_code,$data_fund_lender_update);
                                                            // update uang / avaible fund lender end

                                                            // cashflow
                                                            $Principal_cash = ($invest_amount / $loan_amount) * $payment_principal;
                                                            $Interest_cash = (($invest_amount / $loan_amount) * $payment_interest);
                                                            $Pinalty_cash = ($invest_amount / $loan_amount) * $payment_pinalty;
                                                            $Interest_cash_total = $Interest_cash + $Pinalty_cash;
                                                            $Tax_cash = $total_commision_payment; //pg

                                                            $data['data_total'] = $this->report_model->get_total_amount($lender_code);
                                                            $beginning = 0;
                                                            $beginning = (int)@$data['data_total'][0]->total_amount;
                                                            $ending = (int)$beginning + (int)$Principal_cash - $Tax_cash + (int)$Interest_cash;

                                                            $data_cashflow = array(
                                                                'register_code' => $lender_code,
                                                                'cashflow_date' => date('Y-m-d H:i:s'),
                                                                'beginning_amount' => $beginning,
                                                                'withdrawal_amount' => 0,
                                                                'deposit_amount' => 0,
                                                                'invest_amount' => 0,
                                                                'payment_pokok' => $Principal_cash,
                                                                'payment_tax' => $Tax_cash,
                                                                'payment_interest' =>$Interest_cash_total,
                                                                'total_amount' => $ending,
                                                                'cashflow_status' => "Payment"
                                                            );

                                                            $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_cashflow);
                                                            // cashflow

                                                    } 
                                                    // memilih investor end

                                                    // // GL OTOMATIS
                                                    // // Kode Jurnal
                                                    $idMaxgl = $this->journal_model->journal_code();
                                                    $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                                                    $noUrutgl ++;
                                                    $date_codegl = date('m/y');
                                                    $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;
                                
                                                    $data_journal1 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 128, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Cicilan + Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Escrow - '.$loan_code,
                                                                'journal_debit' => $total_payment,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'LR',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                                                    
                                                    $data_journal2 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 6,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Cicilan + Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $payment_principal,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);


                                                    $data_journal3 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 42,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Cicilan + Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Personal Loan - ' .$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $payment_interest,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                                                    $data_journal4 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 131,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Cicilan + Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - ' .$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $fee_pg,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);

                                                    if ($payment_pinalty > 0){
                                                        
                                                        $data_journal12 = array(
                                                                    'journal_no' => $newIDgl,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_pinalty_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal12 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal12);


                                                        $data_journal13 = array(
                                                                    'journal_no' => $newIDgl,
                                                                    'id_param_coa_e' => 42,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_pinalty_lender_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal13 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal13);

                                                    }

                                                    $idMaxgl2 = $this->journal_model->journal_code();
                                                    $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                                                    $noUrutgl2 ++;
                                                    $date_codegl2 = date('m/y');
                                                    $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                                                    $data_journal5 = array(
                                                                'journal_no' => $newIDgl2,
                                                                'id_param_coa_e' => 2, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                                'journal_debit' => $fee_pg,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'OTD',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                                                    
                                                    $data_journal6 = array(
                                                                'journal_no' => $newIDgl2,
                                                                'id_param_coa_e' => 128,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $fee_pg,
                                                                'cashflow_code_status' => 'OTC',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal6 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal6);

                                                    $idMaxgl3 = $this->journal_model->journal_code();
                                                    $noUrutgl3 = (int) substr($idMaxgl3[0]->maxID,0,4);
                                                    $noUrutgl3 ++;
                                                    $date_codegl3 = date('m/y');
                                                    $newIDgl3 = sprintf("%04s",$noUrutgl3).'/'.$date_codegl3;

                                                    $data_journal7 = array(
                                                                'journal_no' => $newIDgl3,
                                                                'id_param_coa_e' => 42, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                'journal_debit' => $total_commision_payment_gl,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal7 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal7);

                                                    if ($payment_pinalty > 0){

                                                        $data_journal15 = array(
                                                                        'journal_no' => $newIDgl3,
                                                                        'id_param_coa_e' => 62,
                                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                                        'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                        // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                                        'journal_debit' => 0,
                                                                        'journal_kredit' => $total_commision_pinalty_gl,
                                                                        'cashflow_code_status' => '0',
                                                                        'journal_status' => '0'
                                                                        );

                                                        $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);


                                                        $total_commision_payment_gl_min = $total_commision_payment_gl - $total_commision_pinalty_gl;
                                                        
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl3,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl_min,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    } else {
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl3,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    }

                                                    $idMaxgl4 = $this->journal_model->journal_code();
                                                    $noUrutgl4 = (int) substr($idMaxgl4[0]->maxID,0,4);
                                                    $noUrutgl4 ++;
                                                    $date_codegl4 = date('m/y');
                                                    $newIDgl4 = sprintf("%04s",$noUrutgl4).'/'.$date_codegl4;

                                                    $data_journal9 = array(
                                                                'journal_no' => $newIDgl4,
                                                                'id_param_coa_e' => 2, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'BRI Ops - '.$loan_code,
                                                                'journal_debit' => $total_commision_payment_gl,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'OTD',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal9 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal9);

                                                    if ($payment_pinalty > 0){

                                                        $data_journal15 = array(
                                                                        'journal_no' => $newIDgl4,
                                                                        'id_param_coa_e' => 128,
                                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                                        'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                        // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                                        'journal_debit' => 0,
                                                                        'journal_kredit' => $total_commision_pinalty_gl,
                                                                        'cashflow_code_status' => 'OTC',
                                                                        'journal_status' => '0'
                                                                        );

                                                        $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);


                                                        $total_commision_payment_gl_min = $total_commision_payment_gl - $total_commision_pinalty_gl;
                                                        
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl4,
                                                                    'id_param_coa_e' => 128,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl_min,
                                                                    'cashflow_code_status' => 'OTC',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    } else {
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl4,
                                                                    'id_param_coa_e' => 128,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl,
                                                                    'cashflow_code_status' => 'OTC',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);
                                                        
                                                    }

                                                    // if ($payment_pinalty > 0){

                                                    //     $idMaxgl5 = $this->journal_model->journal_code();
                                                    //     $noUrutgl5 = (int) substr($idMaxgl5[0]->maxID,0,4);
                                                    //     $noUrutgl5 ++;
                                                    //     $date_codegl5 = date('m/y');
                                                    //     $newIDgl5 = sprintf("%04s",$noUrutgl5).'/'.$date_codegl5;

                                                    //     $data_journal11 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 128, 
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                    //                 'journal_debit' => $payment_pinalty,
                                                    //                 'journal_kredit' => 0,
                                                    //                 'cashflow_code_status' => 'PEN'
                                                    //                 );

                                                    //     $insert_journal11 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal11);

                                                        
                                                    //     $data_journal12 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 62,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_commision_pinalty_gl,
                                                    //                 'cashflow_code_status' => '0',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal12 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal12);


                                                    //     $data_journal13 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 6,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_pinalty_lender_gl,
                                                    //                 'cashflow_code_status' => '0',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal13 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal13);


                                                    //     $idMaxgl6 = $this->journal_model->journal_code();
                                                    //     $noUrutgl6 = (int) substr($idMaxgl6[0]->maxID,0,4);
                                                    //     $noUrutgl6 ++;
                                                    //     $date_codegl6 = date('m/y');
                                                    //     $newIDgl6 = sprintf("%04s",$noUrutgl6).'/'.$date_codegl6;

                                                    //     $data_journal14 = array(
                                                    //                 'journal_no' => $newIDgl6,
                                                    //                 'id_param_coa_e' => 2, 
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Ops - '.$loan_code
                                                    //                 'journal_debit' => $total_commision_pinalty_gl,
                                                    //                 'journal_kredit' => 0,
                                                    //                 'cashflow_code_status' => 'OTD',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal14 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal14);

                                                        
                                                    //     $data_journal15 = array(
                                                    //                 'journal_no' => $newIDgl6,
                                                    //                 'id_param_coa_e' => 128,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_commision_pinalty_gl,
                                                    //                 'cashflow_code_status' => 'OTC',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);

                                                    // }

                                                    // masukan payment start
                                                    $data_payment_insert = array(
                                                        "id_borrower_loan" => $loan_code,
                                                        "register_code" => $borrower_code,
                                                        "id_payment_periode" => $payment_periode_id,
                                                        "payment_amount" => $total_payment_amount,
                                                        "payment_date" => $date_now,
                                                        "payment_status" => 'Success',
                                                    );

                                                    $insert_payment = $this->crud_model->insert('tb_fintech_borrower_payment',$data_payment_insert);
                                                    // masukan payment end

                                                    // masukan payment status start
                                                    $data_payment_periode_update = array(
                                                        "payment_periode_status_principal" => 'Late, Already Paid',
                                                        "payment_periode_status_interest" => 'Late, Already Paid',
                                                        "payment_periode_status_pinalty" => 'Late, Already Paid',
                                                    );

                                                    $update_fund = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_payment_periode',$payment_periode_id,$data_payment_periode_update);   
                                                    // masukan payment status end

                                                    //var_dump($total_payment_amount);

                                                    // email

                                            } else {

                                                // masukan payment status start
                                                $data_payment_periode_update = array(
                                                    "payment_periode_status_principal" => 'Late, Not Yet Paid',
                                                    "payment_periode_status_interest" => 'Late, Not Yet Paid',
                                                    "payment_periode_status_pinalty" => 'Late, Not Yet Paid',
                                                );

                                                $update_fund = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_payment_periode',$payment_periode_id,$data_payment_periode_update);
                                                // masukan payment status end

                                            }
                                            // jika borrower fund cek end
                                    }
                                    // jika jika telat end
                            }
                            // memilih payment end
                    }
                    // memilih type pinjaman end


                    // memilih type pinjaman start
                    if($loan_type == "Personal Loan" OR $loan_type == "Fixed Loan"){

                        // memilih payment start
                        $data_loan_payment = $this->payment_model->get_realtime_loan_payment($loan_code);

                            foreach ($data_loan_payment as $loan_payment_entry){
                                    // jika tepat waktu start ga ada pinalty
                                    if ($loan_payment_entry->payment_periode_date == $date_now AND $loan_payment_entry->payment_periode_status_principal != "On Time" AND $loan_payment_entry->payment_periode_status_principal != "Late, Already Paid"){

                                            $payment_periode_id = $loan_payment_entry->id_payment_periode;
                                            $payment_principal = $loan_payment_entry->payment_periode_principal;
                                            $payment_interest = $loan_payment_entry->payment_periode_interest;
                                            $payment_pinalty = $loan_payment_entry->payment_periode_pinalty;

                                            $data_setting = $this->crud_model->get_setting();
                                            $fee_pg = $data_setting[0]->fee_pg;
                                            $total_payment_amount = ($payment_principal + $payment_interest) + $payment_pinalty;
                                            $total_payment = $total_payment_amount + $fee_pg;

                                            $data_commision_payment_gl = $this->payment_model->get_realtime_fee();
                                            $commision_payment_gl = $data_commision_payment_gl[0]->commision_borrower / 100;
                                            $total_commision_payment_gl = $commision_payment_gl * $total_payment_amount;
                                            $total_commision_pinalty_gl = $commision_payment_gl * ($payment_pinalty);
                                            $total_pinalty_lender_gl = $payment_pinalty - $total_commision_pinalty_gl;

                                            $data_borrower_fund = $this->payment_model->get_realtime_borrower_fund($borrower_code);
                                            $avaible_fund_borrower = $data_borrower_fund[0]->amount;

                                            // jika borrower fund cek start
                                            if ($avaible_fund_borrower >= $total_payment){

                                                // update uang / avaible fund borrower start
                                                $fund_borrower = $avaible_fund_borrower - $total_payment;

                                                $data_fund_update = array(
                                                    "amount" => $fund_borrower,
                                                );

                                                $update_fund = $this->crud_model->update('tb_fintech_borrower_fund','register_code',$borrower_code,$data_fund_update);
                                                // update uang / avaible fund borrower end

                                                // memilih investor start
                                                $data_investment = $this->payment_model->get_realtime_investor($loan_code);

                                                    foreach ($data_investment as $investment_entry) {

                                                        $lender_code = $investment_entry->register_code;
                                                        $investment_code = $investment_entry->investment_code;
                                                        $invest_amount = $investment_entry->amount_invest;

                                                        $payment_to_lender = ($invest_amount / $loan_amount) * $total_payment_amount;

                                                        $data_commision_payment = $this->payment_model->get_realtime_fee();
                                                        $commision_payment = $data_commision_payment[0]->commision_borrower / 100;

                                                        $total_commision_payment = $commision_payment * $payment_to_lender;
                                                        $total_payment_to_lender = $payment_to_lender - $total_commision_payment;

                                                            // simpan ke masing masing investor start
                                                            $data_payment_insert_to_lender = array(
                                                                "investment_code" => $investment_code,
                                                                "payment_date" => $date_now,
                                                                "payment_amount" => $total_payment_to_lender,
                                                                "payment_fee" => $total_commision_payment,
                                                                "payment_status" => 'Success',
                                                            );

                                                            $insert_to_lender = $this->crud_model->insert('tb_fintech_lender_investment_payment',$data_payment_insert_to_lender);  
                                                            // simpan ke masing masing investor end 

                                                            // update uang / avaible fund lender start
                                                            $data_lender_fund = $this->payment_model->get_realtime_lender_fund($lender_code);
                                                            $avaible_fund_lender = $data_lender_fund[0]->amount;
                                                            $fund_lender = $avaible_fund_lender + $total_payment_to_lender;

                                                            $data_fund_lender_update = array(
                                                                "amount" => $fund_lender,
                                                            );

                                                            $update_fund_lender = $this->crud_model->update('tb_fintech_lender_fund','register_code',$lender_code,$data_fund_lender_update);
                                                            // update uang / avaible fund lender end

                                                            // cashflow
                                                            $Principal_cash = ($invest_amount / $loan_amount) * $payment_principal;
                                                            $Interest_cash = (($invest_amount / $loan_amount) * $payment_interest);
                                                            $Pinalty_cash = ($invest_amount / $loan_amount) * $payment_pinalty;
                                                            $Interest_cash_total = $Interest_cash + $Pinalty_cash;
                                                            $Tax_cash = $total_commision_payment; //pg

                                                            $data['data_total'] = $this->report_model->get_total_amount($lender_code);
                                                            $beginning = 0;
                                                            $beginning = (int)@$data['data_total'][0]->total_amount;
                                                            $ending = (int)$beginning + (int)$Principal_cash - $Tax_cash + (int)$Interest_cash;

                                                            $data_cashflow = array(
                                                                'register_code' => $lender_code,
                                                                'cashflow_date' => date('Y-m-d H:i:s'),
                                                                'beginning_amount' => $beginning,
                                                                'withdrawal_amount' => 0,
                                                                'deposit_amount' => 0,
                                                                'invest_amount' => 0,
                                                                'payment_pokok' => $Principal_cash,
                                                                'payment_tax' => $Tax_cash,
                                                                'payment_interest' =>$Interest_cash_total,
                                                                'total_amount' => $ending,
                                                                'cashflow_status' => "Payment"
                                                            );

                                                            $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_cashflow);
                                                            // cashflow

                                                    } 
                                                    // memilih investor end

                                                    // // GL OTOMATIS
                                                    // // Kode Jurnal
                                                    $idMaxgl = $this->journal_model->journal_code();
                                                    $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                                                    $noUrutgl ++;
                                                    $date_codegl = date('m/y');
                                                    $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;
                                
                                                    $data_journal1 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 128, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Cicilan + Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Escrow - '.$loan_code,
                                                                'journal_debit' => $total_payment,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'LR',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                                                    
                                                    $data_journal2 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 6,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Cicilan + Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $payment_principal,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);


                                                    $data_journal3 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 42,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Cicilan + Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Personal Loan - ' .$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $payment_interest,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                                                    $data_journal4 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 131,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Cicilan + Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - ' .$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $fee_pg,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);

                                                    if ($payment_pinalty > 0){
                                                        
                                                        $data_journal12 = array(
                                                                    'journal_no' => $newIDgl,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_pinalty_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal12 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal12);


                                                        $data_journal13 = array(
                                                                    'journal_no' => $newIDgl,
                                                                    'id_param_coa_e' => 42,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_pinalty_lender_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal13 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal13);

                                                    }

                                                    $idMaxgl2 = $this->journal_model->journal_code();
                                                    $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                                                    $noUrutgl2 ++;
                                                    $date_codegl2 = date('m/y');
                                                    $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                                                    $data_journal5 = array(
                                                                'journal_no' => $newIDgl2,
                                                                'id_param_coa_e' => 2, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                                'journal_debit' => $fee_pg,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'OTD',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                                                    
                                                    $data_journal6 = array(
                                                                'journal_no' => $newIDgl2,
                                                                'id_param_coa_e' => 128,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $fee_pg,
                                                                'cashflow_code_status' => 'OTC',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal6 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal6);

                                                    $idMaxgl3 = $this->journal_model->journal_code();
                                                    $noUrutgl3 = (int) substr($idMaxgl3[0]->maxID,0,4);
                                                    $noUrutgl3 ++;
                                                    $date_codegl3 = date('m/y');
                                                    $newIDgl3 = sprintf("%04s",$noUrutgl3).'/'.$date_codegl3;

                                                    $data_journal7 = array(
                                                                'journal_no' => $newIDgl3,
                                                                'id_param_coa_e' => 42, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                'journal_debit' => $total_commision_payment_gl,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal7 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal7);

                                                    
                                                    if ($payment_pinalty > 0){

                                                        $data_journal15 = array(
                                                                        'journal_no' => $newIDgl3,
                                                                        'id_param_coa_e' => 62,
                                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                                        'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                        // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                                        'journal_debit' => 0,
                                                                        'journal_kredit' => $total_commision_pinalty_gl,
                                                                        'cashflow_code_status' => '0',
                                                                        'journal_status' => '0'
                                                                        );

                                                        $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);


                                                        $total_commision_payment_gl_min = $total_commision_payment_gl - $total_commision_pinalty_gl;
                                                        
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl3,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl_min,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    } else {
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl3,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);
                                                        
                                                    }

                                                    $idMaxgl4 = $this->journal_model->journal_code();
                                                    $noUrutgl4 = (int) substr($idMaxgl4[0]->maxID,0,4);
                                                    $noUrutgl4 ++;
                                                    $date_codegl4 = date('m/y');
                                                    $newIDgl4 = sprintf("%04s",$noUrutgl4).'/'.$date_codegl4;

                                                    $data_journal9 = array(
                                                                'journal_no' => $newIDgl4,
                                                                'id_param_coa_e' => 2, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'BRI Ops - '.$loan_code,
                                                                'journal_debit' => $total_commision_payment_gl,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'OTD',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal9 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal9);

                                                    
                                                    if ($payment_pinalty > 0){

                                                        $data_journal15 = array(
                                                                        'journal_no' => $newIDgl4,
                                                                        'id_param_coa_e' => 128,
                                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                                        'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                        // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                                        'journal_debit' => 0,
                                                                        'journal_kredit' => $total_commision_pinalty_gl,
                                                                        'cashflow_code_status' => 'OTC',
                                                                        'journal_status' => '0'
                                                                        );

                                                        $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);


                                                        $total_commision_payment_gl_min = $total_commision_payment_gl - $total_commision_pinalty_gl;
                                                        
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl4,
                                                                    'id_param_coa_e' => 128,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl_min,
                                                                    'cashflow_code_status' => 'OTC',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    } else {
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl4,
                                                                    'id_param_coa_e' => 128,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl,
                                                                    'cashflow_code_status' => 'OTC',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);
                                                        
                                                    }

                                                    // if ($payment_pinalty > 0){

                                                    //     $idMaxgl5 = $this->journal_model->journal_code();
                                                    //     $noUrutgl5 = (int) substr($idMaxgl5[0]->maxID,0,4);
                                                    //     $noUrutgl5 ++;
                                                    //     $date_codegl5 = date('m/y');
                                                    //     $newIDgl5 = sprintf("%04s",$noUrutgl5).'/'.$date_codegl5;

                                                    //     $data_journal11 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 128, 
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                    //                 'journal_debit' => $payment_pinalty,
                                                    //                 'journal_kredit' => 0,
                                                    //                 'cashflow_code_status' => 'PEN'
                                                    //                 );

                                                    //     $insert_journal11 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal11);

                                                        
                                                    //     $data_journal12 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 62,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_commision_pinalty_gl,
                                                    //                 'cashflow_code_status' => '0',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal12 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal12);


                                                    //     $data_journal13 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 6,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_pinalty_lender_gl,
                                                    //                 'cashflow_code_status' => '0',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal13 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal13);


                                                    //     $idMaxgl6 = $this->journal_model->journal_code();
                                                    //     $noUrutgl6 = (int) substr($idMaxgl6[0]->maxID,0,4);
                                                    //     $noUrutgl6 ++;
                                                    //     $date_codegl6 = date('m/y');
                                                    //     $newIDgl6 = sprintf("%04s",$noUrutgl6).'/'.$date_codegl6;

                                                    //     $data_journal14 = array(
                                                    //                 'journal_no' => $newIDgl6,
                                                    //                 'id_param_coa_e' => 2, 
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Ops - '.$loan_code
                                                    //                 'journal_debit' => $total_commision_pinalty_gl,
                                                    //                 'journal_kredit' => 0,
                                                    //                 'cashflow_code_status' => 'OTD',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal14 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal14);

                                                        
                                                    //     $data_journal15 = array(
                                                    //                 'journal_no' => $newIDgl6,
                                                    //                 'id_param_coa_e' => 128,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_commision_pinalty_gl,
                                                    //                 'cashflow_code_status' => 'OTC',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);

                                                    // }

                                                    // masukan payment start
                                                    $data_payment_insert = array(
                                                        "id_borrower_loan" => $loan_code,
                                                        "register_code" => $borrower_code,
                                                        "id_payment_periode" => $payment_periode_id,
                                                        "payment_amount" => $total_payment_amount,
                                                        "payment_date" => $date_now,
                                                        "payment_status" => 'Success',
                                                    );

                                                    $insert_payment = $this->crud_model->insert('tb_fintech_borrower_payment',$data_payment_insert);
                                                    // masukan payment end

                                                    // masukan payment status start
                                                    $data_payment_periode_update = array(
                                                        "payment_periode_status_principal" => 'On Time',
                                                        "payment_periode_status_interest" => 'On Time',
                                                        "payment_periode_status_pinalty" => 'On Time',
                                                    );

                                                    $update_fund = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_payment_periode',$payment_periode_id,$data_payment_periode_update);   
                                                    // masukan payment status end

                                                    //var_dump($total_payment_amount);
                                                    // email
                                            } 
                                            // jika borrower fund cek end
                                    }
                                    // jika tepat waktu end
                            }
                            // memilih payment end
                    }
                    // memilih type pinjaman end



                    // memilih type pinjaman start
                    if($loan_type == "Flexible Loan"){

                        // memilih payment start
                        $data_loan_payment = $this->payment_model->get_realtime_loan_payment($loan_code);

                            foreach ($data_loan_payment as $loan_payment_entry){

                                    // jika jika telat start
                                    if ($loan_payment_entry->payment_periode_date < $date_now AND $loan_payment_entry->payment_periode_status_principal != "On Time" AND $loan_payment_entry->payment_periode_status_principal != "Late, Already Paid"){

                                        // menghitung pinalty start
                                        $id_payment_periode_pinalty = $loan_payment_entry->id_payment_periode + 1;
                                        $principal = $loan_payment_entry->payment_periode_principal; 
                                        $interest = $loan_payment_entry->payment_periode_interest; 
                                        $data_pinalty_rate = $this->payment_model->get_realtime_fee();
                                        $pinalty_rate = $data_pinalty_rate[0]->penalty / 100;
                                        $total_pinalty = ($principal + $interest) * $pinalty_rate;

                                        $date_start = date($loan_payment_entry->payment_periode_date);
                                        $date_end = $date_now;

                                        $dt1 = strtotime($date_start);
                                        $dt2 = strtotime($date_end);
                                        $diff = abs($dt2-$dt1);
                                        $late_day = $diff/86400;

                                        $total_day_to_pinalty = $total_pinalty * $late_day;

                                        $data_payment_periode_update_pinalty = array(
                                            "payment_periode_pinalty" => $total_day_to_pinalty,
                                        );

                                        $update_pinalty = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_payment_periode',$id_payment_periode_pinalty,$data_payment_periode_update_pinalty);
                                        // menghitung pinalty end
                                    }
                                    // jika jika telat end
                            }
                            // memilih payment end
                    }
                    // memilih type pinjaman end



                    // memilih type pinjaman start bayar perbulan bunga saja dan kalo ada pinalty
                    if($loan_type == "Flexible Loan"){

                        // memilih payment start
                        $data_loan_payment = $this->payment_model->get_realtime_loan_payment($loan_code);

                            foreach ($data_loan_payment as $loan_payment_entry){

                                    // jika jika telat start pinalty
                                    if ($loan_payment_entry->payment_periode_date < $date_now AND $loan_payment_entry->payment_periode_status_interest != "On Time" AND $loan_payment_entry->payment_periode_status_interest != "Late, Already Paid"){

                                            $payment_periode_id = $loan_payment_entry->id_payment_periode;
                                            $payment_principal = $loan_payment_entry->payment_periode_principal;
                                            $payment_interest = $loan_payment_entry->payment_periode_interest;
                                            $payment_pinalty = $loan_payment_entry->payment_periode_pinalty;

                                            $data_setting = $this->crud_model->get_setting();
                                            $fee_pg = $data_setting[0]->fee_pg;
                                            $total_payment_amount_no_principal = ($payment_interest) + $payment_pinalty;
                                            $total_payment_amount = ($payment_principal + $payment_interest) + $payment_pinalty;
                                            $total_payment = $total_payment_amount_no_principal + $fee_pg;

                                            $data_commision_payment_gl = $this->payment_model->get_realtime_fee();
                                            $commision_payment_gl = $data_commision_payment_gl[0]->commision_borrower / 100;
                                            $total_commision_payment_gl = $commision_payment_gl * $total_payment_amount;
                                            $total_commision_pinalty_gl = $commision_payment_gl * ($payment_pinalty);
                                            $total_pinalty_lender_gl = $payment_pinalty - $total_commision_pinalty_gl;

                                            $data_borrower_fund = $this->payment_model->get_realtime_borrower_fund($borrower_code);
                                            $avaible_fund_borrower = $data_borrower_fund[0]->amount;

                                            // jika borrower fund cek start
                                            if ($avaible_fund_borrower >= $total_payment){

                                                // update uang / avaible fund borrower start
                                                $fund_borrower = $avaible_fund_borrower - $total_payment;

                                                $data_fund_update = array(
                                                    "amount" => $fund_borrower,
                                                );

                                                $update_fund = $this->crud_model->update('tb_fintech_borrower_fund','register_code',$borrower_code,$data_fund_update);
                                                // update uang / avaible fund borrower end

                                                // memilih investor start
                                                $data_investment = $this->payment_model->get_realtime_investor($loan_code);

                                                    foreach ($data_investment as $investment_entry) {

                                                        $lender_code = $investment_entry->register_code;
                                                        $investment_code = $investment_entry->investment_code;
                                                        $invest_amount = $investment_entry->amount_invest;

                                                        $payment_to_lender = ($invest_amount / $loan_amount) * $total_payment_amount;
                                                        $payment_to_lender_no_principal = ($invest_amount / $loan_amount) * $total_payment_amount_no_principal;

                                                        $data_commision_payment = $this->payment_model->get_realtime_fee();
                                                        $commision_payment = $data_commision_payment[0]->commision_borrower / 100;

                                                        $total_commision_payment = $commision_payment * $payment_to_lender;
                                                        $total_payment_to_lender = $payment_to_lender_no_principal - $total_commision_payment;

                                                        // simpan ke masing masing investor start
                                                        $data_payment_insert_to_lender = array(
                                                            "investment_code" => $investment_code,
                                                            "payment_date" => $date_now,
                                                            "payment_amount" => $total_payment_to_lender,
                                                            "payment_fee" => $total_commision_payment,
                                                            "payment_status" => 'Success',
                                                        );

                                                        $insert_to_lender = $this->crud_model->insert('tb_fintech_lender_investment_payment',$data_payment_insert_to_lender);  
                                                        // simpan ke masing masing investor end 

                                                        // update uang / avaible fund lender start
                                                        $data_lender_fund = $this->payment_model->get_realtime_lender_fund($lender_code);
                                                        $avaible_fund_lender = $data_lender_fund[0]->amount;
                                                        $fund_lender = $avaible_fund_lender + $total_payment_to_lender;

                                                        $data_fund_lender_update = array(
                                                            "amount" => $fund_lender,
                                                        );

                                                        $update_fund_lender = $this->crud_model->update('tb_fintech_lender_fund','register_code',$lender_code,$data_fund_lender_update);
                                                        // update uang / avaible fund lender end

                                                        // cashflow
                                                        $Principal_cash = ($invest_amount / $loan_amount) * $payment_principal;
                                                        $Interest_cash = (($invest_amount / $loan_amount) * $payment_interest);
                                                        $Pinalty_cash = ($invest_amount / $loan_amount) * $payment_pinalty;
                                                        $Interest_cash_total = $Interest_cash + $Pinalty_cash;
                                                        $Tax_cash = $total_commision_payment; //pg

                                                        $data['data_total'] = $this->report_model->get_total_amount($lender_code);
                                                        $beginning = 0;
                                                        $beginning = (int)@$data['data_total'][0]->total_amount;

                                                        $ending = (int)$beginning - $Tax_cash + (int)$Interest_cash_total;
                                                        
                                                        $data_cashflow = array(
                                                            'register_code' => $lender_code,
                                                            'cashflow_date' => date('Y-m-d H:i:s'),
                                                            'beginning_amount' => $beginning,
                                                            'withdrawal_amount' => 0,
                                                            'deposit_amount' => 0,
                                                            'invest_amount' => 0,
                                                            'payment_pokok' => 0,
                                                            'payment_tax' => $Tax_cash,
                                                            'payment_interest' =>$Interest_cash_total,
                                                            'total_amount' => $ending,
                                                            'cashflow_status' => "Payment Interest"
                                                        );

                                                        $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_cashflow);
                                                        // cashflow

                                                    } 
                                                    // memilih investor end

                                                    // // GL OTOMATIS
                                                    // // Kode Jurnal
                                                    $idMaxgl = $this->journal_model->journal_code();
                                                    $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                                                    $noUrutgl ++;
                                                    $date_codegl = date('m/y');
                                                    $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;
                                
                                                    $data_journal1 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 128, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Escrow - '.$loan_code,
                                                                'journal_debit' => $total_payment,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'LIP'
                                                                );

                                                    $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                                                    
                                                    $data_journal2 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 42,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $payment_interest,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);


                                                    $data_journal4 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 131,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - ' .$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $fee_pg,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);

                                                    if ($payment_pinalty > 0){
                                                        
                                                        $data_journal12 = array(
                                                                    'journal_no' => $newIDgl,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_pinalty_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal12 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal12);


                                                        $data_journal13 = array(
                                                                    'journal_no' => $newIDgl,
                                                                    'id_param_coa_e' => 42,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_pinalty_lender_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal13 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal13);

                                                    }

                                                    $idMaxgl2 = $this->journal_model->journal_code();
                                                    $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                                                    $noUrutgl2 ++;
                                                    $date_codegl2 = date('m/y');
                                                    $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                                                    $data_journal5 = array(
                                                                'journal_no' => $newIDgl2,
                                                                'id_param_coa_e' => 2, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                                'journal_debit' => $fee_pg,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'OTD',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                                                    
                                                    $data_journal6 = array(
                                                                'journal_no' => $newIDgl2,
                                                                'id_param_coa_e' => 128,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $fee_pg,
                                                                'cashflow_code_status' => 'OTC',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal6 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal6);

                                                    $idMaxgl3 = $this->journal_model->journal_code();
                                                    $noUrutgl3 = (int) substr($idMaxgl3[0]->maxID,0,4);
                                                    $noUrutgl3 ++;
                                                    $date_codegl3 = date('m/y');
                                                    $newIDgl3 = sprintf("%04s",$noUrutgl3).'/'.$date_codegl3;

                                                    $data_journal7 = array(
                                                                'journal_no' => $newIDgl3,
                                                                'id_param_coa_e' => 42, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                'journal_debit' => $total_commision_payment_gl,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal7 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal7);

                                                    
                                                    if ($payment_pinalty > 0){

                                                        $data_journal15 = array(
                                                                        'journal_no' => $newIDgl3,
                                                                        'id_param_coa_e' => 62,
                                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                                        'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                        // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                                        'journal_debit' => 0,
                                                                        'journal_kredit' => $total_commision_pinalty_gl,
                                                                        'cashflow_code_status' => '0',
                                                                        'journal_status' => '0'
                                                                        );

                                                        $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);


                                                        $total_commision_payment_gl_min = $total_commision_payment_gl - $total_commision_pinalty_gl;
                                                        
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl3,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl_min,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    } else {
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl3,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);
                                                        
                                                    }

                                                    $idMaxgl4 = $this->journal_model->journal_code();
                                                    $noUrutgl4 = (int) substr($idMaxgl4[0]->maxID,0,4);
                                                    $noUrutgl4 ++;
                                                    $date_codegl4 = date('m/y');
                                                    $newIDgl4 = sprintf("%04s",$noUrutgl4).'/'.$date_codegl4;

                                                    $data_journal9 = array(
                                                                'journal_no' => $newIDgl4,
                                                                'id_param_coa_e' => 2, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'BRI Ops - '.$loan_code,
                                                                'journal_debit' => $total_commision_payment_gl,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'OTD',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal9 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal9);

                                                    
                                                    if ($payment_pinalty > 0){

                                                        $data_journal15 = array(
                                                                        'journal_no' => $newIDgl4,
                                                                        'id_param_coa_e' => 128,
                                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                                        'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                        // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                                        'journal_debit' => 0,
                                                                        'journal_kredit' => $total_commision_pinalty_gl,
                                                                        'cashflow_code_status' => 'OTC',
                                                                        'journal_status' => '0'
                                                                        );

                                                        $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);


                                                        $total_commision_payment_gl_min = $total_commision_payment_gl - $total_commision_pinalty_gl;
                                                        
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl4,
                                                                    'id_param_coa_e' => 128,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl_min,
                                                                    'cashflow_code_status' => 'OTC',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    } else {
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl4,
                                                                    'id_param_coa_e' => 128,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl,
                                                                    'cashflow_code_status' => 'OTC',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);
                                                        
                                                    }

                                                    // if ($payment_pinalty > 0){

                                                    //     $idMaxgl5 = $this->journal_model->journal_code();
                                                    //     $noUrutgl5 = (int) substr($idMaxgl5[0]->maxID,0,4);
                                                    //     $noUrutgl5 ++;
                                                    //     $date_codegl5 = date('m/y');
                                                    //     $newIDgl5 = sprintf("%04s",$noUrutgl5).'/'.$date_codegl5;

                                                    //     $data_journal11 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 128, 
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                    //                 'journal_debit' => $payment_pinalty,
                                                    //                 'journal_kredit' => 0,
                                                    //                 'cashflow_code_status' => 'PEN'
                                                    //                 );

                                                    //     $insert_journal11 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal11);

                                                        
                                                    //     $data_journal12 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 62,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_commision_pinalty_gl,
                                                    //                 'cashflow_code_status' => '0',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal12 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal12);


                                                    //     $data_journal13 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 6,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_pinalty_lender_gl,
                                                    //                 'cashflow_code_status' => '0',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal13 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal13);


                                                    //     $idMaxgl6 = $this->journal_model->journal_code();
                                                    //     $noUrutgl6 = (int) substr($idMaxgl6[0]->maxID,0,4);
                                                    //     $noUrutgl6 ++;
                                                    //     $date_codegl6 = date('m/y');
                                                    //     $newIDgl6 = sprintf("%04s",$noUrutgl6).'/'.$date_codegl6;

                                                    //     $data_journal14 = array(
                                                    //                 'journal_no' => $newIDgl6,
                                                    //                 'id_param_coa_e' => 2, 
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Ops - '.$loan_code,
                                                    //                 'journal_debit' => $total_commision_pinalty_gl,
                                                    //                 'journal_kredit' => 0,
                                                    //                 'cashflow_code_status' => 'OTD',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal14 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal14);

                                                        
                                                    //     $data_journal15 = array(
                                                    //                 'journal_no' => $newIDgl6,
                                                    //                 'id_param_coa_e' => 128,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_pinalty_lender_gl,
                                                    //                 'cashflow_code_status' => 'OTC',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);

                                                    // }

                                                    // masukan payment start
                                                    $data_payment_insert = array(
                                                        "id_borrower_loan" => $loan_code,
                                                        "register_code" => $borrower_code,
                                                        "id_payment_periode" => $payment_periode_id,
                                                        "payment_amount" => $total_payment_amount_no_principal,
                                                        "payment_date" => $date_now,
                                                        "payment_status" => 'Success',
                                                    );

                                                    $insert_payment = $this->crud_model->insert('tb_fintech_borrower_payment',$data_payment_insert);
                                                    // masukan payment end

                                                    // masukan payment status start
                                                    $data_payment_periode_update = array(
                                                        "payment_periode_status_interest" => 'Late, Already Paid',
                                                        "payment_periode_status_pinalty" => 'Late, Already Paid',
                                                    );

                                                    $update_fund = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_payment_periode',$payment_periode_id,$data_payment_periode_update);   
                                                    // masukan payment status end

                                                    //var_dump($total_payment_amount);

                                                    // email

                                            } else {

                                                // masukan payment status start
                                                $data_payment_periode_update = array(
                                                    "payment_periode_status_interest" => 'Late, Not Yet Paid',
                                                    "payment_periode_status_pinalty" => 'Late, Not Yet Paid',
                                                );

                                                $update_fund = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_payment_periode',$payment_periode_id,$data_payment_periode_update);
                                                // masukan payment status end

                                            }
                                            // jika borrower fund cek end
                                    }
                                    // jika jika telat end
                    
                            }
                            // memilih payment end

                    }
                    // memilih type pinjaman end


                    // memilih type pinjaman start bayar perbulan bunga saja dan kalo ada pinalty
                    if($loan_type == "Flexible Loan"){

                        // memilih payment start
                        $data_loan_payment = $this->payment_model->get_realtime_loan_payment($loan_code);

                            foreach ($data_loan_payment as $loan_payment_entry){

                                    // jika tepat waktu start oontime ga ada pinalty
                                    if ($loan_payment_entry->payment_periode_date == $date_now AND $loan_payment_entry->payment_periode_status_interest != "On Time" AND $loan_payment_entry->payment_periode_status_interest != "Late, Already Paid"){

                                            $payment_periode_id = $loan_payment_entry->id_payment_periode;
                                            $payment_principal = $loan_payment_entry->payment_periode_principal;
                                            $payment_interest = $loan_payment_entry->payment_periode_interest;
                                            $payment_pinalty = $loan_payment_entry->payment_periode_pinalty;

                                            $data_setting = $this->crud_model->get_setting();
                                            $fee_pg = $data_setting[0]->fee_pg;
                                            $total_payment_amount_no_principal = ($payment_interest) + $payment_pinalty;
                                            $total_payment_amount = ($payment_principal + $payment_interest) + $payment_pinalty;
                                            $total_payment = $total_payment_amount_no_principal + $fee_pg;

                                            $data_commision_payment_gl = $this->payment_model->get_realtime_fee();
                                            $commision_payment_gl = $data_commision_payment_gl[0]->commision_borrower / 100;
                                            $total_commision_payment_gl = $commision_payment_gl * $total_payment_amount;
                                            $total_commision_pinalty_gl = $commision_payment_gl * ($payment_pinalty);
                                            $total_pinalty_lender_gl = $payment_pinalty - $total_commision_pinalty_gl;

                                            $data_borrower_fund = $this->payment_model->get_realtime_borrower_fund($borrower_code);
                                            $avaible_fund_borrower = $data_borrower_fund[0]->amount;

                                            // jika borrower fund cek start
                                            if ($avaible_fund_borrower >= $total_payment){

                                                // update uang / avaible fund borrower start
                                                $fund_borrower = $avaible_fund_borrower - $total_payment;

                                                $data_fund_update = array(
                                                    "amount" => $fund_borrower,
                                                );

                                                $update_fund = $this->crud_model->update('tb_fintech_borrower_fund','register_code',$borrower_code,$data_fund_update);
                                                // update uang / avaible fund borrower end

                                                // memilih investor start
                                                $data_investment = $this->payment_model->get_realtime_investor($loan_code);

                                                    foreach ($data_investment as $investment_entry) {

                                                        $lender_code = $investment_entry->register_code;
                                                        $investment_code = $investment_entry->investment_code;
                                                        $invest_amount = $investment_entry->amount_invest;

                                                        $payment_to_lender = ($invest_amount / $loan_amount) * $total_payment_amount;
                                                        $payment_to_lender_no_principal = ($invest_amount / $loan_amount) * $total_payment_amount_no_principal;

                                                        $data_commision_payment = $this->payment_model->get_realtime_fee();
                                                        $commision_payment = $data_commision_payment[0]->commision_borrower / 100;

                                                        $total_commision_payment = $commision_payment * $payment_to_lender;
                                                        $total_payment_to_lender = $payment_to_lender_no_principal - $total_commision_payment;


                                                            // simpan ke masing masing investor start
                                                            $data_payment_insert_to_lender = array(
                                                                "investment_code" => $investment_code,
                                                                "payment_date" => $date_now,
                                                                "payment_amount" => $total_payment_to_lender,
                                                                "payment_fee" => $total_commision_payment,
                                                                "payment_status" => 'Success',
                                                            );

                                                            $insert_to_lender = $this->crud_model->insert('tb_fintech_lender_investment_payment',$data_payment_insert_to_lender);  
                                                            // simpan ke masing masing investor end 

                                                            // update uang / avaible fund lender start
                                                            $data_lender_fund = $this->payment_model->get_realtime_lender_fund($lender_code);
                                                            $avaible_fund_lender = $data_lender_fund[0]->amount;
                                                            $fund_lender = $avaible_fund_lender + $total_payment_to_lender;

                                                            $data_fund_lender_update = array(
                                                                "amount" => $fund_lender,
                                                            );

                                                            $update_fund_lender = $this->crud_model->update('tb_fintech_lender_fund','register_code',$lender_code,$data_fund_lender_update);
                                                            // update uang / avaible fund lender end


                                                            // cashflow
                                                            $Principal_cash = ($invest_amount / $loan_amount) * $payment_principal;
                                                            $Interest_cash = (($invest_amount / $loan_amount) * $payment_interest);
                                                            $Pinalty_cash = ($invest_amount / $loan_amount) * $payment_pinalty;
                                                            $Interest_cash_total = $Interest_cash + $Pinalty_cash;
                                                            $Tax_cash = $total_commision_payment; //pg

                                                            $data['data_total'] = $this->report_model->get_total_amount($lender_code);
                                                            $beginning = 0;
                                                            $beginning = (int)@$data['data_total'][0]->total_amount;

                                                            $ending = (int)$beginning - $Tax_cash + (int)$Interest_cash_total;
                                                            
                                                            $data_cashflow = array(
                                                                'register_code' => $lender_code,
                                                                'cashflow_date' => date('Y-m-d H:i:s'),
                                                                'beginning_amount' => $beginning,
                                                                'withdrawal_amount' => 0,
                                                                'deposit_amount' => 0,
                                                                'invest_amount' => 0,
                                                                'payment_pokok' => 0,
                                                                'payment_tax' => $Tax_cash,
                                                                'payment_interest' =>$Interest_cash_total,
                                                                'total_amount' => $ending,
                                                                'cashflow_status' => "Payment Interest"
                                                            );

                                                            $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_cashflow);
                                                            // cashflow
                                                            
                                                    } 
                                                    // memilih investor end

                                                    // // GL OTOMATIS
                                                    // // Kode Jurnal
                                                    $idMaxgl = $this->journal_model->journal_code();
                                                    $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                                                    $noUrutgl ++;
                                                    $date_codegl = date('m/y');
                                                    $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;
                                
                                                    $data_journal1 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 128, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Escrow - '.$loan_code,
                                                                'journal_debit' => $total_payment,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'LIP'
                                                                );

                                                    $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                                                    
                                                    $data_journal2 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 42,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $payment_interest,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);


                                                    $data_journal4 = array(
                                                                'journal_no' => $newIDgl,
                                                                'id_param_coa_e' => 131,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Penerimaan (Bunga)'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - ' .$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $fee_pg,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);

                                                    if ($payment_pinalty > 0){
                                                        
                                                        $data_journal12 = array(
                                                                    'journal_no' => $newIDgl,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_pinalty_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal12 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal12);


                                                        $data_journal13 = array(
                                                                    'journal_no' => $newIDgl,
                                                                    'id_param_coa_e' => 42,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_pinalty_lender_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal13 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal13);

                                                    }

                                                    $idMaxgl2 = $this->journal_model->journal_code();
                                                    $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                                                    $noUrutgl2 ++;
                                                    $date_codegl2 = date('m/y');
                                                    $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                                                    $data_journal5 = array(
                                                                'journal_no' => $newIDgl2,
                                                                'id_param_coa_e' => 2, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                                'journal_debit' => $fee_pg,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'OTD',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                                                    
                                                    $data_journal6 = array(
                                                                'journal_no' => $newIDgl2,
                                                                'id_param_coa_e' => 128,
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                                'journal_debit' => 0,
                                                                'journal_kredit' => $fee_pg,
                                                                'cashflow_code_status' => 'OTC',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal6 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal6);

                                                    $idMaxgl3 = $this->journal_model->journal_code();
                                                    $noUrutgl3 = (int) substr($idMaxgl3[0]->maxID,0,4);
                                                    $noUrutgl3 ++;
                                                    $date_codegl3 = date('m/y');
                                                    $newIDgl3 = sprintf("%04s",$noUrutgl3).'/'.$date_codegl3;

                                                    $data_journal7 = array(
                                                                'journal_no' => $newIDgl3,
                                                                'id_param_coa_e' => 42, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                                'journal_debit' => $total_commision_payment_gl,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => '0',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal7 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal7);

                                                    
                                                    if ($payment_pinalty > 0){

                                                        $data_journal15 = array(
                                                                        'journal_no' => $newIDgl3,
                                                                        'id_param_coa_e' => 62,
                                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                                        'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                        // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                                        'journal_debit' => 0,
                                                                        'journal_kredit' => $total_commision_pinalty_gl,
                                                                        'cashflow_code_status' => '0',
                                                                        'journal_status' => '0'
                                                                        );

                                                        $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);


                                                        $total_commision_payment_gl_min = $total_commision_payment_gl - $total_commision_pinalty_gl;
                                                        
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl3,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl_min,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    } else {
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl3,
                                                                    'id_param_coa_e' => 62,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pengakuan Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl,
                                                                    'cashflow_code_status' => '0',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);
                                                        
                                                    }

                                                    $idMaxgl4 = $this->journal_model->journal_code();
                                                    $noUrutgl4 = (int) substr($idMaxgl4[0]->maxID,0,4);
                                                    $noUrutgl4 ++;
                                                    $date_codegl4 = date('m/y');
                                                    $newIDgl4 = sprintf("%04s",$noUrutgl4).'/'.$date_codegl4;

                                                    $data_journal9 = array(
                                                                'journal_no' => $newIDgl4,
                                                                'id_param_coa_e' => 2, 
                                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                                'journal_date' => date('Y-m-d H:i:s'),
                                                                'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                // 'journal_description_form' => 'BRI Ops - '.$loan_code,
                                                                'journal_debit' => $total_commision_payment_gl,
                                                                'journal_kredit' => 0,
                                                                'cashflow_code_status' => 'OTD',
                                                                'journal_status' => '0'
                                                                );

                                                    $insert_journal9 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal9);

                                                    
                                                    if ($payment_pinalty > 0){

                                                        $data_journal15 = array(
                                                                        'journal_no' => $newIDgl4,
                                                                        'id_param_coa_e' => 128,
                                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                                        'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                        // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                                        'journal_debit' => 0,
                                                                        'journal_kredit' => $total_commision_pinalty_gl,
                                                                        'cashflow_code_status' => 'OTC',
                                                                        'journal_status' => '0'
                                                                        );

                                                        $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);


                                                        $total_commision_payment_gl_min = $total_commision_payment_gl - $total_commision_pinalty_gl;
                                                        
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl4,
                                                                    'id_param_coa_e' => 128,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl_min,
                                                                    'cashflow_code_status' => 'OTC',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);

                                                    } else {
                                                        $data_journal8 = array(
                                                                    'journal_no' => $newIDgl4,
                                                                    'id_param_coa_e' => 128,
                                                                    'journal_entry' => date('Y-m-d H:i:s'),
                                                                    'journal_date' => date('Y-m-d H:i:s'),
                                                                    'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                                    // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                                    'journal_debit' => 0,
                                                                    'journal_kredit' => $total_commision_payment_gl,
                                                                    'cashflow_code_status' => 'OTC',
                                                                    'journal_status' => '0'
                                                                    );

                                                        $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);
                                                        
                                                    }

                                                    // if ($payment_pinalty > 0){

                                                    //     $idMaxgl5 = $this->journal_model->journal_code();
                                                    //     $noUrutgl5 = (int) substr($idMaxgl5[0]->maxID,0,4);
                                                    //     $noUrutgl5 ++;
                                                    //     $date_codegl5 = date('m/y');
                                                    //     $newIDgl5 = sprintf("%04s",$noUrutgl5).'/'.$date_codegl5;

                                                    //     $data_journal11 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 128, 
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                    //                 'journal_debit' => $payment_pinalty,
                                                    //                 'journal_kredit' => 0,
                                                    //                 'cashflow_code_status' => 'PEN'
                                                    //                 );

                                                    //     $insert_journal11 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal11);

                                                        
                                                    //     $data_journal12 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 62,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'Commission - Investor - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_commision_pinalty_gl,
                                                    //                 'cashflow_code_status' => '0',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal12 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal12);


                                                    //     $data_journal13 = array(
                                                    //                 'journal_no' => $newIDgl5,
                                                    //                 'id_param_coa_e' => 6,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Penerimaan Denda Keterlambatan Cicilan (Cash Basis)'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'Investor Fund - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_pinalty_lender_gl,
                                                                    // 'cashflow_code_status' => '0',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal13 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal13);


                                                    //     $idMaxgl6 = $this->journal_model->journal_code();
                                                    //     $noUrutgl6 = (int) substr($idMaxgl6[0]->maxID,0,4);
                                                    //     $noUrutgl6 ++;
                                                    //     $date_codegl6 = date('m/y');
                                                    //     $newIDgl6 = sprintf("%04s",$noUrutgl6).'/'.$date_codegl6;

                                                    //     $data_journal14 = array(
                                                    //                 'journal_no' => $newIDgl6,
                                                    //                 'id_param_coa_e' => 2, 
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Ops - '.$loan_code,
                                                    //                 'journal_debit' => $total_commision_pinalty_gl,
                                                    //                 'journal_kredit' => 0,
                                                    //                 'cashflow_code_status' => 'OTD',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal14 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal14);

                                                        
                                                    //     $data_journal15 = array(
                                                    //                 'journal_no' => $newIDgl6,
                                                    //                 'id_param_coa_e' => 128,
                                                    //                 'journal_entry' => date('Y-m-d H:i:s'),
                                                    //                 'journal_date' => date('Y-m-d H:i:s'),
                                                    //                 'journal_description' => 'Pemindahan Uang Komisi dari Investor'.'-'.$borrower_code.'-'.$loan_code,
                                                    //                 // 'journal_description_form' => 'BRI Escrow - '.$loan_code,
                                                    //                 'journal_debit' => 0,
                                                    //                 'journal_kredit' => $total_pinalty_lender_gl,
                                                    //                 'cashflow_code_status' => 'OTC',
                                                    // 'journal_status' => '0'
                                                    //                 );

                                                    //     $insert_journal15 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal15);

                                                    // }

                                                    // masukan payment start
                                                    $data_payment_insert = array(
                                                        "id_borrower_loan" => $loan_code,
                                                        "register_code" => $borrower_code,
                                                        "id_payment_periode" => $payment_periode_id,
                                                        "payment_amount" => $total_payment_amount_no_principal,
                                                        "payment_date" => $date_now,
                                                        "payment_status" => 'Success',
                                                    );

                                                    $insert_payment = $this->crud_model->insert('tb_fintech_borrower_payment',$data_payment_insert);
                                                    // masukan payment end

                                                    // masukan payment status start
                                                    $data_payment_periode_update = array(
                                                        "payment_periode_status_interest" => 'On Time',
                                                        "payment_periode_status_pinalty" => 'On Time',
                                                    );

                                                    $update_fund = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_payment_periode',$payment_periode_id,$data_payment_periode_update);   
                                                    // masukan payment status end

                                                    //var_dump($total_payment_amount);
                                                    
                                                    // email
                                            } 
                                            // jika borrower fund cek end
                                            
                                    }
                                    // jika tepat waktu end
                    
                            }
                            // memilih payment end

                    }
                    // memilih type pinjaman end

                    // memilih type pinjaman start pokoknya aja 
                    if($loan_type == "Flexible Loan"){

                        // memilih cek status pembayaran start
                        $data_loan_payment_count = $this->payment_model->get_realtime_loan_payment_count($loan_code)->num_rows();
                        $data_loan_payment_date = $this->payment_model->get_realtime_loan_payment_count($loan_code)->result();

                        if ($data_loan_payment_count == $loan_tenor AND @$data_loan_payment_date[0]->payment_periode_date <= $date_now){

                            $principal_amount = $this->payment_model->get_realtime_loan_payment_sum_principal($loan_code);

                            $data_setting = $this->crud_model->get_setting();
                            $fee_pg = $data_setting[0]->fee_pg;

                            $total_principal = $principal_amount[0]->principal;
                            $total_payment = $total_principal + $fee_pg;

                            $data_borrower_fund = $this->payment_model->get_realtime_borrower_fund($borrower_code);
                            $avaible_fund_borrower = $data_borrower_fund[0]->amount;

                            // jika borrower fund cek start
                            if ($avaible_fund_borrower >= $total_payment){
                                //var_dump('expression');
                                // update uang / avaible fund borrower start
                                $fund_borrower = $avaible_fund_borrower - $total_payment;

                                $data_fund_update = array(
                                    "amount" => $fund_borrower,
                                );

                                $update_fund = $this->crud_model->update('tb_fintech_borrower_fund','register_code',$borrower_code,$data_fund_update);
                                // update uang / avaible fund borrower end

                                // memilih investor start
                                $data_investment = $this->payment_model->get_realtime_investor($loan_code);

                                    foreach ($data_investment as $investment_entry) {

                                        $lender_code = $investment_entry->register_code;
                                        $investment_code = $investment_entry->investment_code;
                                        $invest_amount = $investment_entry->amount_invest;

                                        $total_payment_to_lender = ($invest_amount / $loan_amount) * $total_principal;

                                        // simpan ke masing masing investor start
                                        $data_payment_insert_to_lender = array(
                                            "investment_code" => $investment_code,
                                            "payment_date" => $date_now,
                                            "payment_amount" => $total_payment_to_lender,
                                            "payment_fee" => 0,
                                            "payment_status" => 'Success',
                                        );

                                        $insert_to_lender = $this->crud_model->insert('tb_fintech_lender_investment_payment',$data_payment_insert_to_lender);  
                                        // simpan ke masing masing investor end 

                                        // update uang / avaible fund lender start
                                        $data_lender_fund = $this->payment_model->get_realtime_lender_fund($lender_code);
                                        $avaible_fund_lender = $data_lender_fund[0]->amount;
                                        $fund_lender = $avaible_fund_lender + $total_payment_to_lender;

                                        $data_fund_lender_update = array(
                                            "amount" => $fund_lender,
                                        );

                                        $update_fund_lender = $this->crud_model->update('tb_fintech_lender_fund','register_code',$lender_code,$data_fund_lender_update);
                                        // update uang / avaible fund lender end

                                        $data['data_total'] = $this->report_model->get_total_amount($lender_code);
                                        $beginning = 0;
                                        $beginning = (int)@$data['data_total'][0]->total_amount;

                                        $ending = (int)$beginning + (int)$total_payment_to_lender;

                                        $data_cashflow = array(
                                            'register_code' => $lender_code,
                                            'cashflow_date' => date('Y-m-d H:i:s'),
                                            'beginning_amount' => $beginning,
                                            'withdrawal_amount' => 0,
                                            'deposit_amount' => 0,
                                            'invest_amount' => 0,
                                            'payment_pokok' => $total_payment_to_lender,
                                            'payment_tax' => 0,
                                            'payment_interest' =>0,
                                            'total_amount' => $ending,
                                            'cashflow_status' => "All Principal"
                                        );

                                        $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_cashflow);
                                            

                                    } 
                                    // memilih investor end

                                    // // GL OTOMATIS
                                    // // Kode Jurnal
                                    $idMaxgl = $this->journal_model->journal_code();
                                    $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                                    $noUrutgl ++;
                                    $date_codegl = date('m/y');
                                    $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;
                
                                    $data_journal1 = array(
                                                'journal_no' => $newIDgl,
                                                'id_param_coa_e' => 128, 
                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                'journal_date' => date('Y-m-d H:i:s'),
                                                'journal_description' => 'Penerimaan (Pokok Akhir Pinjaman)'.'-'.$borrower_code.'-'.$loan_code,
                                                // 'journal_description_form' => 'Escrow - '.$loan_code,
                                                'journal_debit' => $total_payment,
                                                'journal_kredit' => 0,
                                                'cashflow_code_status' => 'LR',
                                                'journal_status' => '0'
                                                );

                                    $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                                    $data_journal3 = array(
                                                'journal_no' => $newIDgl,
                                                'id_param_coa_e' => 6,
                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                'journal_date' => date('Y-m-d H:i:s'),
                                                'journal_description' => 'Penerimaan (Pokok Akhir Pinjaman)'.'-'.$borrower_code.'-'.$loan_code,
                                                // 'journal_description_form' => 'Personal Loan - ' .$loan_code,
                                                'journal_debit' => 0,
                                                'journal_kredit' => $total_principal,
                                                'cashflow_code_status' => '0',
                                                'journal_status' => '0'
                                                );

                                    $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                                    $data_journal4 = array(
                                                'journal_no' => $newIDgl,
                                                'id_param_coa_e' => 131,
                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                'journal_date' => date('Y-m-d H:i:s'),
                                                'journal_description' => 'Penerimaan (Pokok Akhir Pinjaman)'.'-'.$borrower_code.'-'.$loan_code,
                                                // 'journal_description_form' => 'Biaya PG - ' .$loan_code,
                                                'journal_debit' => 0,
                                                'journal_kredit' => $fee_pg,
                                                'cashflow_code_status' => '0',
                                                'journal_status' => '0'
                                                );

                                    $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);

                                    $idMaxgl2 = $this->journal_model->journal_code();
                                    $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                                    $noUrutgl2 ++;
                                    $date_codegl2 = date('m/y');
                                    $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                                    $data_journal5 = array(
                                                'journal_no' => $newIDgl2,
                                                'id_param_coa_e' => 2, 
                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                'journal_date' => date('Y-m-d H:i:s'),
                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                'journal_debit' => $fee_pg,
                                                'journal_kredit' => 0,
                                                'cashflow_code_status' => 'OTD',
                                                'journal_status' => '0'
                                                );

                                    $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                                    
                                    $data_journal6 = array(
                                                'journal_no' => $newIDgl2,
                                                'id_param_coa_e' => 128,
                                                'journal_entry' => date('Y-m-d H:i:s'),
                                                'journal_date' => date('Y-m-d H:i:s'),
                                                'journal_description' => 'Pemindahan Dana Titipan PG'.'-'.$borrower_code.'-'.$loan_code,
                                                // 'journal_description_form' => 'Biaya PG - '.$loan_code,
                                                'journal_debit' => 0,
                                                'journal_kredit' => $fee_pg,
                                                'cashflow_code_status' => 'OTC',
                                                'journal_status' => '0'
                                                );

                                    // masukan payment start
                                    $data_payment_insert = array(
                                        "id_borrower_loan" => $loan_code,
                                        "register_code" => $borrower_code,
                                        "id_payment_periode" => 0,
                                        "payment_amount" => $total_principal,
                                        "payment_date" => $date_now,
                                        "payment_status" => 'Success',
                                    );

                                    $insert_payment = $this->crud_model->insert('tb_fintech_borrower_payment',$data_payment_insert);
                                    // masukan payment end

                                    // masukan payment status start
                                    $data_payment_periode_update = array(
                                        "payment_periode_status_principal" => 'On Time',
                                    );

                                    $update_fund = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_borrower_loan',$loan_code,$data_payment_periode_update);   
                                    // masukan payment status end

                                    //var_dump($total_payment_amount);

                                    // email
                              
                            } else {

                                $data_payment_periode_update = array(
                                        "payment_periode_status_principal" => 'Late, Not Yet Paid',
                                    );

                                    $update_fund = $this->crud_model->update('tb_fintech_borrower_payment_periode','id_borrower_loan',$loan_code,$data_payment_periode_update);   
                            }

                        }
                        // memilih cek status pembayaran start

                    }
                    // memilih type pinjaman end


                    // menutup pinjaman macet
                    if($loan_type == "Personal Loan" OR $loan_type == "Fixed Loan"){
                        $data_loan_payment_count_1 = $this->payment_model->get_realtime_loan_payment_count_mct_1($loan_code,$date_now)->num_rows();

                        if ($loan_tenor < 12){
                            $limit = $loan_tenor / 2;
                        } else {
                            $limit = 6;
                        }

                        $data_loan_payment = $this->payment_model->get_realtime_loan_payment($loan_code);

                        if ($data_loan_payment_count_1 >= $limit){
                            $data_borrower_loan = array(
                                "loan_status" => 'Closed',
                            );

                            $update_fund = $this->crud_model->update('tb_fintech_borrower_loan','id_borrower_loan',$loan_code,$data_borrower_loan); 

                            // // // GL OTOMATIS
                            // // // Kode Jurnal
                            // $idMaxgl = $this->journal_model->journal_code();
                            // $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                            // $noUrutgl ++;
                            // $date_codegl = date('m/y');
                            // $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;

                            // // Drawdown Pinjaman (Pemindahan dana Pinjaman dari VA Peminjam ke Rek Pribadi Peminjam) debit
                            // $data_journal1 = array(
                            //             'journal_no' => $newIDgl,
                            //             'id_param_coa_e' => 130, // cek lagi ID coa E nya Takut belum benar daftar coa belum komplit
                            //             'journal_entry' => date('Y-m-d H:i:s'),
                            //             'journal_date' => date('Y-m-d H:i:s'),
                            //             'journal_description' => 'Hapus Buku Pinjaman Macet',
                            //             'journal_description_form' => 'Investor Fund - '.$loan_code,
                            //             'journal_debit' => $clean,
                            //             'journal_kredit' => 0
                            //             );

                            // $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                            // // Drawdown Pinjaman (Pemindahan dana Pinjaman dari VA Peminjam ke Rek Pribadi Peminjam) credit
                            // $data_journal2 = array(
                            //             'journal_no' => $newIDgl,
                            //             'id_param_coa_e' => 131, // cek lagi ID coa E nya Takut belum benar daftar coa belum komplit
                            //             'journal_entry' => date('Y-m-d H:i:s'),
                            //             'journal_date' => date('Y-m-d H:i:s'),
                            //             'journal_description' => 'Hapus Buku Pinjaman Macet',
                            //             'journal_description_form' => 'Personal Loan - '.$loan_code,
                            //             'journal_debit' => 0,
                            //             'journal_kredit' => $fee_pg
                            //             );

                            // $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);

                            // // Drawdown Pinjaman (Pemindahan dana Pinjaman dari VA Peminjam ke Rek Pribadi Peminjam) credit
                            // $data_journal3 = array(
                            //             'journal_no' => $newIDgl,
                            //             'id_param_coa_e' => 128, // cek lagi ID coa E nya Takut belum benar daftar coa belum komplit
                            //             'journal_entry' => date('Y-m-d H:i:s'),
                            //             'journal_date' => date('Y-m-d H:i:s'),
                            //             'journal_description' => 'Hapus Buku Pinjaman Macet',
                            //             'journal_description_form' => 'Interest Receivable - ' .$loan_code,
                            //             'journal_debit' => 0,
                            //             'journal_kredit' => $clean_amount
                            //             );

                            // $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                        }

                    }

                    if($loan_type == "Flexible Loan"){
                        $data_loan_payment_count_2 = $this->payment_model->get_realtime_loan_payment_count_mct_2($loan_code,$date_now)->num_rows();

                        if ($loan_tenor < 12){
                            $limit = $loan_tenor / 2;
                        } else {
                            $limit = 6;
                        }

                        if ($data_loan_payment_count_2 >= $limit){
                            $data_borrower_loan = array(
                                "loan_status" => 'Closed',
                            );

                            $update_fund = $this->crud_model->update('tb_fintech_borrower_loan','id_borrower_loan',$loan_code,$data_borrower_loan); 

                        }


                    }
                    // menutup pinjaman macet

            }
            // memilih pinjaman end
        echo" DONE <BR><BR><BR><BR>";
    }

}


?>
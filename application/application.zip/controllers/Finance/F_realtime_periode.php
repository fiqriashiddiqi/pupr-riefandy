<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_realtime_periode extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('crud_model');
        $this->load->model('Front_Fintech/payment_model');
        $this->load->model('Front_Fintech/manually_model');

        date_default_timezone_set("Asia/Jakarta");

    }

    public function index()
    {    
        //while (1) {
            // sleep($detik); // komen ketika online

            $data_loan = $this->payment_model->get_realtime_loan_payment_periode();
            

            $tempo = 3; //hari
            foreach ($data_loan as $loan_entry) {

                $loan_code = $loan_entry->id_borrower_loan;


                // var_dump(@$data_email[0]->register_email);
                $periode_id = $loan_entry->id_payment_periode;
                $periode_date = $loan_entry->payment_periode_date;

                $date_now = date('Y-m-d');
                $date = date_create($date_now);

                date_add($date, date_interval_create_from_date_string("+".$tempo." days"));

                $date_tempo = date_format($date, 'Y-m-d');
                // echo "<pre>";
                // var_dump($periode_date);
                if ($periode_date == $date_tempo){
                    var_dump($loan_code);
                    echo "<pre>";
                    var_dump("Tes");
                    $data_periode = array(
                        'status_periode_email' => 'Yes' //status di tambahakan di table nya. terkirim dan belum. enum
                    );
                
                    // $update_periode = $this->crud_model->update('tb_fintech_borrower_payment_periode', 'id_payment_periode', $periode_id,  $data_periode);


                    // email borrower y

                    $data_email = $this->manually_model->get_email_borrower($loan_code);
                    
                    $emails_bor = array_map(function($value){
                        return $value->register_email;
                    }, $data_email);

                    var_dump(@$data_email[0]->register_email);
                    // foreach ($data_email as $email_entry) {
                        
                        $config = array();
                        $config['charset'] = 'iso-8859-1';
                        $config['useragent'] = 'Codeigniter';
                        $config['protocol']= 'smtp';
                        $config['mailtype']= 'html';
                        $config['smtp_host']= 'ssl://mail.heatcliffs31.com';//pengaturan smtp
                        $config['smtp_port']= 465;
                        $config['smtp_timeout']= 400;
                        $config['smtp_user']= 'sanders@heatcliffs31.com'; // isi dengan email kamu
                        $config['smtp_pass']= '1q2w3e4r5t'; // isi dengan password kamu
                        $config['crlf']="\r\n"; 
                        $config['newline']="\r\n"; 
                        $config['wordwrap'] = TRUE;
                                //memanggil library email dan set konfigurasi untuk pengiriman email
                        $this->load->library('email',$config);
                        $this->email->initialize($config);
                                //konfigurasi pengiriman
                        $this->email->from($config['smtp_user']);
                        $this->email->to(@$data_email[0]->register_email);
                        $this->email->subject("Notification Due Date");
                        $body = $this->load->view('frontend-fintech/email_due_date.php','',TRUE);
                        $this->email->message($body);
                        $this->email->send();

                    // // $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                    // // redirect(base_url().'Finance/F_register/check_activation');
                    // // die();  
                    // }
                    
                }

            }

        //}

    }

}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_lender extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('crud_model');
        $this->load->model('Website/artikel_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/slideshow_model');
        $this->load->model('Website/video_model');
        $this->load->model('Website/users_model');
        $this->load->model('Website/management_model');
        $this->load->model('Front_Fintech/personal_info_model');
        $this->load->model('Front_Fintech/auth_model');
        $this->load->model('Front_Fintech/auto_model');
        $this->load->model('Front_Fintech/indonesia_model');
        $this->load->model('Front_Fintech/bank_model');
        $this->load->model('Front_Fintech/register_model');
        $this->load->model('Front_Fintech/manually_model');
        $this->load->model('Front_Fintech/loan_model');
        $this->load->model('Front_Fintech/score_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('Parameter/parameter_all_model');
        $this->load->model('Parameter/param_model');
        $this->load->model('Front_Fintech/loan_model');
        $this->load->model('Front_Fintech/account_model');
        $this->load->model('Front_Fintech/report_model');
        $this->load->model('Front_Fintech/portofolio_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('Front_Fintech/connection_model');

        date_default_timezone_set("Asia/Jakarta");

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

            if (!isset($reg_code) && !isset($reg_password) && !isset($reg_access_status) && !isset($reg_activation_status) && !isset($reg_status)){
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'Finance/F_login/login');
                die();
            }

            if($check_access[0]->register_activation_status != "Activated"){
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_error', 'You do not have access to this page, Or your account not yet activated !');
                redirect(base_url().'Finance/F_login/login');
                die();
            }

            if($check_access[0]->register_access_status != "Activated"){
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'Finance/F_login/login');
                die();
            }

            if($check_access[0]->register_status != "Lender"){
                $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'Finance/F_login/login');
                die();
            }
    }

    public function index(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $data['get_code'] = $register_code;
        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['htgs_active'] = "active";  
        
        $data['data_province'] = $this->indonesia_model->get_province();
        $data['data_video'] = $this->video_model->get_video();
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'HTGS Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header_htgs');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/htgs' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }
    
    public function personal_info_lender()
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['personal_info_lender_active'] = "active";

        
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('lender');
        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_lender($register_code);

        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);

        $data['edit_url'] = site_url('Finance/F_lender/personal_update_lender');

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/personal_info_lender',$data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function personal_update_lender(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');
        
        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        
        $navigation['borrower_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('borrower');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['get_code'] = $register_code;
        $data['form_url'] = site_url('Finance/F_lender/personal_update_lender');
        $data['data_code'] = $this->personal_info_model->get_personal_info_lender($register_code);

        $prov = ((array)$data['data_code'][0]);
        $data['data_province'] = $this->indonesia_model->get_province_by_id($prov['bio_province']);
        $data['data_city'] = $this->indonesia_model->get_city_by_id($prov['bio_city']);
        $data['data_district'] = $this->indonesia_model->get_district_by_id($prov['bio_district']);
        $data['data_village'] = $this->indonesia_model->get_village_by_id($prov['bio_village']);
        $data['data_indonesia'] = $this->indonesia_model->get_province();


        $this->load->helper('file');
        
        $this->form_validation->set_rules("bio_fullname", "", "required");
        $this->form_validation->set_rules("bio_place_birth_date", "", "trim|required");
        $this->form_validation->set_rules("bio_birth_date", "", "required");
        $this->form_validation->set_rules("bio_gender", "", "trim|required");
        $this->form_validation->set_rules("bio_phone", " ", "trim|required");
        $this->form_validation->set_rules("bio_marriage_status", "", "trim|required");
        $this->form_validation->set_rules("bio_occupation", "", "trim|required");
        // $this->form_validation->set_rules("bio_occupation_others", "", "trim|required");
        $this->form_validation->set_rules("bio_address", "", "trim|required");
        $this->form_validation->set_rules("bio_post_code", "", "trim|required");
        $this->form_validation->set_rules("bio_last_education", "", "trim|required");
        $this->form_validation->set_rules("bio_cityzenship", "", "trim|required");
        // $this->form_validation->set_rules("bio_nik", "", "required");

        if ($this->form_validation->run() == true){

            $register_code  = $this->input->post('register_code');
            $bio_fullname = $this->input->post('bio_fullname');
            $bio_place_birth_date = $this->input->post('bio_place_birth_date');
            $bio_birth_date = $this->input->post('bio_birth_date');
            $bio_gender = $this->input->post('bio_gender');
            $bio_phone = $this->input->post('bio_phone');
            $bio_marriage_status = $this->input->post('bio_marriage_status');
            $bio_spouse_name = $this->input->post('bio_spouse_name');
            $bio_spouse_phone = $this->input->post('bio_spouse_phone');
            $bio_occupation = $this->input->post('bio_occupation');
            $bio_occupation_others = $this->input->post('bio_occupation_others');
            $bio_address = $this->input->post('bio_address');
            $bio_post_code = $this->input->post('bio_post_code');   
            $bio_last_education = $this->input->post('bio_last_education');
            $bio_cityzenship = $this->input->post('bio_cityzenship');

            if ($bio_cityzenship == 'WNI'){
                // $bio_nik = $this->input->post('bio_nik');  
                $bio_province = $this->input->post('bio_province_select');
                $bio_city = $this->input->post('bio_city_select');
                $bio_district = $this->input->post('bio_district_select');
                $bio_village = $this->input->post('bio_village_select');
                $bio_upload_nik = $this->input->post('bio_upload_nik'); 

                
            } else {
                // $bio_passport = $this->input->post('bio_passport');  
                $bio_province = $this->input->post('bio_province');
                $bio_city = $this->input->post('bio_city');
                $bio_upload_passport = $this->input->post('bio_upload_passport');   
            }

            if (!empty($bio_occupation_others) AND $bio_occupation == "Others"){
                $bio_occupation = $bio_occupation_others;
            }

            if ($bio_marriage_status == "Single"){
                $bio_spouse_name = "-";
                $bio_spouse_phone = "-";
            }  
            
            if ($bio_cityzenship == 'WNI'){
                if(!empty($_FILES['bio_upload_nik']['name'])){
                    $name_file = $bio_fullname."_".time();
                    $config['upload_path'] = './uploads/Fintech/ktp_lender';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size']     = '5120';
                    $config['file_name'] = $name_file;

                    $this->load->library('upload', $config);

                    if(!$this->upload->do_upload('bio_upload_nik')){
                        $this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
                        redirect(base_url().'Finance/F_lender/personal_update_lender/'.$register_code);
                        die();
                    } else {
                        $file_data = $this->upload->data();
                        $data_bio= $this->personal_info_model->get_bio_lender_by_id($register_code);
                        $file_path= './uploads/Fintech/ktp_lender/'.$data_bio[0]->bio_upload_nik;

                        @unlink($file_path);
                        $data_bio = array(
                                'register_code' => $register_code,
                                'bio_fullname' => $bio_fullname,
                                'bio_place_birth_date' => $bio_place_birth_date,
                                'bio_birth_date' => $bio_birth_date,
                                'bio_gender' => $bio_gender,
                                'bio_phone' => $bio_phone,
                                'bio_marriage_status' => $bio_marriage_status,
                                'bio_spouse_name' => $bio_spouse_name,
                                'bio_spouse_phone' => $bio_spouse_phone,
                                'bio_occupation' => $bio_occupation,
                                'bio_address' => $bio_address,
                                'bio_province' => $bio_province,
                                'bio_city' => $bio_city,
                                'bio_district' => $bio_district,
                                'bio_village' => $bio_village,
                                'bio_post_code' => $bio_post_code,
                                'bio_last_education' => $bio_last_education,
                                // 'bio_nik' => $bio_nik,
                                'bio_upload_nik' => $file_data['file_name']
                        );
                        $update_bio = $this->crud_model->update('tb_fintech_lender_bio', 'register_code', $register_code,  $data_bio);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_lender/personal_info_lender');

                        die();
                    }

                } else {
                    
                        $data_bio = array(
                                'register_code' => $register_code,
                                'bio_fullname' => $bio_fullname,
                                'bio_place_birth_date' => $bio_place_birth_date,
                                'bio_birth_date' => $bio_birth_date,
                                'bio_gender' => $bio_gender,
                                'bio_phone' => $bio_phone,
                                'bio_marriage_status' => $bio_marriage_status,
                                'bio_spouse_name' => $bio_spouse_name,
                                'bio_spouse_phone' => $bio_spouse_phone,
                                'bio_occupation' => $bio_occupation,
                                'bio_address' => $bio_address,
                                'bio_province' => $bio_province,
                                'bio_city' => $bio_city,
                                'bio_district' => $bio_district,
                                'bio_village' => $bio_village,
                                'bio_post_code' => $bio_post_code,
                                'bio_last_education' => $bio_last_education
                        );
                        $update_bio = $this->crud_model->update('tb_fintech_lender_bio', 'register_code', $register_code,  $data_bio);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_lender/personal_info_lender');

                        die();
                }

            } else {
                if(!empty($_FILES['bio_upload_passport']['name'])){
                    $name_file = $bio_fullname."_".time();
                    $config['upload_path'] = './uploads/Fintech/passport_lender';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size']     = '5120';
                    $config['file_name'] = $name_file;

                    $this->load->library('upload', $config);

                    if(!$this->upload->do_upload('bio_upload_passport')){
                        $this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
                        redirect(base_url().'Finance/F_lender/personal_update_lender/'.$register_code);
                        die();
                    } else {
                        $file_data = $this->upload->data();
                        $data_bio= $this->personal_info_model->get_bio_lender_by_id($register_code);
                        $file_path= './uploads/Fintech/passport_lender/'.$data_bio[0]->bio_upload_passport;

                        @unlink($file_path);
                        $data_bio = array(
                                'register_code' => $register_code,
                                'bio_fullname' => $bio_fullname,
                                'bio_place_birth_date' => $bio_place_birth_date,
                                'bio_birth_date' => $bio_birth_date,
                                'bio_gender' => $bio_gender,
                                'bio_phone' => $bio_phone,
                                'bio_marriage_status' => $bio_marriage_status,
                                'bio_spouse_name' => $bio_spouse_name,
                                'bio_spouse_phone' => $bio_spouse_phone,
                                'bio_occupation' => $bio_occupation,
                                'bio_address' => $bio_address,
                                'bio_province' => $bio_province,
                                'bio_city' => $bio_city,
                                'bio_post_code' => $bio_post_code,
                                'bio_last_education' => $bio_last_education,
                                // 'bio_passport' => $bio_passport,
                                'bio_upload_passport' => $file_data['file_name']
                        );
                        $update_bio = $this->crud_model->update('tb_fintech_lender_bio', 'register_code', $register_code,  $data_bio);
                        print_r($data_bio);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_lender/personal_info_lender');

                        die();
                    }

                } else {
                     $data_bio = array(
                                'register_code' => $register_code,
                                'bio_fullname' => $bio_fullname,
                                'bio_place_birth_date' => $bio_place_birth_date,
                                'bio_birth_date' => $bio_birth_date,
                                'bio_gender' => $bio_gender,
                                'bio_phone' => $bio_phone,
                                'bio_marriage_status' => $bio_marriage_status,
                                'bio_spouse_name' => $bio_spouse_name,
                                'bio_spouse_phone' => $bio_spouse_phone,
                                'bio_occupation' => $bio_occupation,
                                'bio_address' => $bio_address,
                                'bio_province' => $bio_province,
                                'bio_city' => $bio_city,
                                'bio_post_code' => $bio_post_code,
                                'bio_last_education' => $bio_last_education
                        );
                        $update_bio = $this->crud_model->update('tb_fintech_lender_bio', 'register_code', $register_code,  $data_bio);
                        print_r($data_bio);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_lender/personal_info_lender');

                        die();

                }
            }
        } 

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1',$navigation);
        $this->load->view('frontend-fintech/lender/personal_update_lender', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function data_bank_lender(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();

        $navigation['personal_info_lender_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['data_code'] = $this->bank_model->get_bank_lender($register_code);
        $data['edit_url'] = site_url('Finance/F_lender/bank_update_lender');

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/data_bank_lender' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function bank_update_lender(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');
        
        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        
        $navigation['borrower_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('borrower');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_lender($register_code);
        $data['form_url'] = site_url('Finance/F_lender/bank_update_lender');
        $data['data_code'] = $this->bank_model->get_bank_lender($register_code);

        $this->form_validation->set_rules("register_code", "", "required");
        $this->form_validation->set_rules("your_bank_name", "", "required");
        $this->form_validation->set_rules("bank_account", "", "required");
        $this->form_validation->set_rules("bank_name", "", "trim|required");
        $this->form_validation->set_rules("bank_branch", "", "trim|required");

        if($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');
            $your_bank_name = $this->input->post('your_bank_name');
            $bank_account = $this->input->post('bank_account');
            $bank_name = $this->input->post('bank_name');
            $bank_branch = $this->input->post('bank_branch');   

            $where = array('register_code' => $register_code);
            $data_check = $this->crud_model->get_data("tb_fintech_lender_bank", $where)->num_rows();

            if($data_check == 0){
                $data_bank = array(
                    'register_code' => $register_code,
                    'your_bank_name' => $your_bank_name,
                    'bank_account' => $bank_account,
                    'bank_name' => $bank_name,
                    'bank_branch' => $bank_branch
                            
                    );

                $insert_bank = $this->crud_model->insert('tb_fintech_lender_bank', $data_bank);
                $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                redirect(base_url().'Finance/F_lender/data_bank_lender');
                die();
            } else {
                $data_bank = array(
                    'bank_account' => $bank_account,
                    'your_bank_name' => $your_bank_name,
                    'bank_name' => $bank_name,
                    'bank_branch' => $bank_branch
                            
                    );

                $update_bank = $this->crud_model->update('tb_fintech_lender_bank', 'register_code', $register_code,  $data_bank);
                $this->session->set_flashdata('alert_success', 'Data successfully Updated.');
                redirect(base_url().'Finance/F_lender/data_bank_lender');
                die();
            }  

        }
        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1',$navigation);
        $this->load->view('frontend-fintech/lender/bank_update_lender', $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function change_password_lender(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);
        $register_code = $check_access[0]->register_code;

        $data['get_code'] = $register_code;
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $where = array('register_code' => $register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['personal_info_lender_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();
        $data['form_url'] = site_url('Finance/F_lender/change_password_lender');

        $data['data_code'] = $this->register_model->get_register_by_id($register_code);

        $this->form_validation->set_rules("register_code", "", "required");
        $this->form_validation->set_rules("old_register_password", "", "trim|required");
        $this->form_validation->set_rules("new_register_password", "", "trim|required");
        $this->form_validation->set_rules("new_register_re_password", "", "trim|required");
     
        if($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');
            $old_register_password = sha1($this->input->post('old_register_password'));
            $new_register_password = sha1($this->input->post('new_register_password'));
            $new_register_re_password = sha1($this->input->post('new_register_re_password'));

            $where = array('register_password' => $old_register_password ,'register_code' => $register_code) ;
            $data_check = $this->crud_model->get_data("tb_fintech_register", $where)->num_rows();

            if($data_check == 1){
                if($new_register_password == $new_register_re_password ) {

                    $data_register = array(
                        'register_password' => $new_register_password
                        );

                    $update_bank = $this->crud_model->update('tb_fintech_register', 'register_code', $register_code,  $data_register);
                    $this->session->unset_userdata("reg_code","reg_password","reg_access_status","reg_activation_status","reg_status");
                    $this->session->set_flashdata('alert_success', 'Password Has Been Changed, Please Login With New Password');
                    redirect(base_url().'Finance/F_login/login');
                    die();

                } else {
                    $this->session->set_flashdata('alert_error', 'Password Not Match .');
                    redirect(base_url().'Finance/F_lender/change_password_lender');
                }

            } else{
                $this->session->set_flashdata('alert_error', 'wrong old-password .');
                redirect(base_url().'Finance/F_lender/change_password_lender');
            } 

        }
        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/change_password_lender' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function withdrawal_lender(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code' => $register_code);
        $data_check = $this->crud_model->get_data("tb_fintech_lender_withdrawal", $where)->num_rows();

        $data['data_check'] = $data_check;
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['lender_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_lender($register_code);
        $data['data_code'] = $this->bank_model->get_bank_lender($register_code);
        $data['edit_url'] = site_url('Finance/F_lender/withdrawal_prosses');

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/withdrawal_lender' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function withdrawal_prosses(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['lender_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_lender($register_code);
        $data['data_code'] = $this->bank_model->get_bank_lender($register_code);
        $data['data_total'] = $this->report_model->get_total_amount($register_code);
        $data['data_loan'] = $this->report_model->get_cashflow($register_code);
        $data['form_url'] = site_url('Finance/F_lender/withdrawal_prosses');
        // $data['data_loan'] = $this->report_model->get_cashflow($register_code);
        // $data['data_total'] = $this->report_model->get_total_amount($register_code);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->form_validation->set_rules("withdrawal_amount", "", "trim|required");
        $this->form_validation->set_rules("withdrawal_reason", "", "trim|required");
        $this->form_validation->set_rules("your_bank_name", "", "trim|required");
        $this->form_validation->set_rules("bank_account", "", "trim|required");
        $this->form_validation->set_rules("bank_name", "", "trim|required");
        $this->form_validation->set_rules("bank_branch", "", "trim|required");
     

        if ($this->form_validation->run() == true){
            $withdrawal_amount  = $this->input->post('withdrawal_amount');
            $withdrawal_reason = $this->input->post('withdrawal_reason');
            $your_bank_name = $this->input->post('your_bank_name');
            $bank_account = $this->input->post('bank_account');
            $bank_name = $this->input->post('bank_name');
            $bank_branch = $this->input->post('bank_branch');

            $where = array('register_code' => $register_code) ;
            $data_check = $this->crud_model->get_data("tb_fintech_lender_fund", $where)->num_rows();
            $fund_data = $this->crud_model->get_data("tb_fintech_lender_fund", $where)->result();

            $date = date('Y-m-d H:i:s');
           
            $_POST['withdrawal_amount'] = $withdrawal_amount;
            $clean = preg_replace('/\D/','',$_POST['withdrawal_amount']);

            $data_setting = $this->crud_model->get_setting();
            $fee_pg = $data_setting[0]->fee_pg;
            $clean_amount = $clean - $fee_pg;

            if($clean < $fee_pg) {
                $this->session->set_flashdata('alert_error', 'Withdrawal Failed!!, your withdrawal amount must be more than Rp '.number_format($fee_pg,0,".",".").'');
                redirect(base_url().'Finance/F_lender/withdrawal_lender');
                die();
            }
            
            // var_dump($clean);
            // die();
            if($data_check == 1 AND $fund_data[0]->amount >= $clean){

                $data_withdraw = array(
                    'register_code' => $register_code,
                    'withdrawal_amount' => $clean,
                    'withdrawal_reason' => $withdrawal_reason,
                    'withdrawal_date' => $date,
                    'your_bank_name' => $your_bank_name,
                    'bank_account' => $bank_account,
                    'bank_name' => $bank_name,
                    'bank_branch' => $bank_branch,
                    'withdrawal_status' => 'Success'
                            
                    );
                
                $insert_withdraw = $this->crud_model->insert('tb_fintech_lender_withdrawal',$data_withdraw, $clean);

                 // GL OTOMATIS
                // Kode Jurnal
                $idMaxgl = $this->journal_model->journal_code();
                $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                $noUrutgl ++;
                $date_codegl = date('m/y');
                $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;
               

                // Penarikan Dana Investasi (Withdrawal) debit
                $data_journal1 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 42, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Penarikan Dana Investasi (Withdrawal)'.'-'.$register_code,
                            // 'journal_description_form' => 'Withdrawal ',
                            'journal_debit' => $clean,
                            'journal_kredit' => 0,
                            'cashflow_code_status' => '0',
                            'journal_status' => '0'
                            );

                $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                // Penarikan Dana Investasi (Withdrawal) credit
                $data_journal2 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 128, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Penarikan Dana Investasi (Withdrawal)'.'-'.$register_code,
                            // 'journal_description_form' => 'Escrow '.$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $clean_amount,
                            'cashflow_code_status' => 'ID',
                            'journal_status' => '0'

                            );
                           

                $insert_journal2 = $this->crud_model->insert('
                    tb_general_ledger_journal',$data_journal2);

                // Penarikan Dana Investasi (Withdrawal) credit
                $data_journal3 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 131, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Penarikan Dana Investasi (Withdrawal)'.'-'.$register_code,
                            // 'journal_description_form' => 'Biaya PG - '.$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $fee_pg,
                            'cashflow_code_status' => '0',
                            'journal_status' => '0'
                            );
                           

                $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                // Kode Jurnal 2
                $idMaxgl2 = $this->journal_model->journal_code();
                $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                $noUrutgl2 ++;
                $date_codegl2 = date('m/y');
                $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                // Pemindahan Dana PG debit
                $data_journal4 = array(
                            'journal_no' => $newIDgl2,
                            'id_param_coa_e' => 2, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Pemindahan Dana PG ke Rek Ops'.'-'.$register_code,
                            // 'journal_description_form' => 'Biaya PG - '.$register_code,
                            'journal_debit' => $fee_pg,
                            'journal_kredit' => 0,
                            'cashflow_code_status' => 'OTD',
                            'journal_status' => '0'
                            );

                $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);

                // Pemindahan Dana PG credit
                $data_journal5 = array(
                            'journal_no' => $newIDgl2,
                            'id_param_coa_e' => 128, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Pemindahan Dana PG ke Rek Ops'.'-'.$register_code,
                            // 'journal_description_form' => 'Biaya PG - ' .$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $fee_pg,
                            'cashflow_code_status' => 'OTC',
                            'journal_status' => '0'

                            );

                $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                $beginning = 0;
                $beginning = (int)@$data['data_total'][0]->total_amount;

                $ending = (int)$beginning - (int)$clean - (int)@$data['data_loan'][0]->invest_amount + (int)@$data['data_loan'][0]->payment_pokok - (int)@$data['data_loan'][0]->payment_tax + (int)@$data['data_loan'][0]->payment_interest;
                

                $data_cashflow = array(
                    'register_code' => $register_code,
                    'cashflow_date' => $date,
                    'beginning_amount' => $beginning,
                    'withdrawal_amount' => $clean,
                    'deposit_amount' => 0,
                    'invest_amount' => 0,
                    'payment_pokok' => 0,
                    'payment_tax' => 0,
                    'payment_interest' =>0,
                    'total_amount' => $ending,
                    'cashflow_status' => "Withdrawal"
                );

                $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_cashflow,$clean);

                $amount = $fund_data[0]->amount - $clean;

                $data_fund = array(
                    'amount' => $amount,
                );

                $update_fund = $this->crud_model->update('tb_fintech_lender_fund','register_code',$register_code,$data_fund);

                $this->session->set_flashdata('alert_success', 'Withdrawal Success.');
                redirect(base_url().'Finance/F_lender/withdrawal_lender');
                
            } else {

                $this->session->set_flashdata('alert_error', 'withdrawal Proses failed.');
                redirect(base_url().'Finance/F_lender/withdrawal_lender');

            }              
        }

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/withdrawal_lender_prosses' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function withdrawal_prosses_get_same_data(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $data['data_code'] = $this->bank_model->get_bank_lender($register_code);
        echo json_encode($data['data_code'][0]);  
    }

    public function delete_autopurchase()
    {
        $id_lender_automation = $this->uri->segment(4);
        if (!empty($id_lender_automation)){

                $this->crud_model->delete('tb_fintech_lender_automation','id_lender_automation',$id_lender_automation);
                $this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
                redirect(base_url().'Finance/F_lender/autopurchase');
                die();

        } else {
            $this->session->set_flashdata('alert_error', 'Data failed to Delete !');
            redirect(base_url().'Finance/F_lender/autopurchase');
            die();
        }
        
    }

    public function access_status_exchange()
    {

        $id_lender_automation = $this->input->post('id_lender_automation');

        $data_auto = $this->auto_model->get_auto_by_id($id_lender_automation);
        $automation_status = $data_auto[0]->automation_status;

        if ($automation_status == "Deactivated"){

            $data_exchange = array(
            'automation_status' => 'Activated'
            );

        } else {

            $data_exchange = array(
            'automation_status' => 'Deactivated'
            );

        }
                            
        $update_automation = $this->crud_model->update('tb_fintech_lender_automation','id_lender_automation',$id_lender_automation,$data_exchange);

    }

    public function social_point_lender(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['lender_active'] = "active";

        $data['get_code'] = $register_code;
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'home');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/social_point_lender' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function portofolio_lender(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['portofolio_active'] = "active";
        $data['lend_code'] = $register_code;
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $data['total_reserved'] = $this->account_model->get_total_reserved_sum($register_code);
        $data['total_invest'] = $this->account_model->get_total_invest_sum($register_code);
        $data['total_funding'] = $this->account_model->get_total_funding_sum($register_code);

        $data['data_loan'] = $this->account_model->get_data_loan($register_code,null);
        $data['data_loan_periode_sort'] = $this->account_model->get_data_loan_period_sort($register_code,null);
        // $data['data_loan_periode'] = $this->account_model->get_data_loan_period($register_code, $id_borrower_loan);


        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/portofolio_lender' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function portofolio($id_borrower_loan = null){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;
        

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['portofolio_active'] = "active";
        $data['lend_code'] = $register_code;
        $data['get_id_borrower_loan'] = $id_borrower_loan;
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $data['total_reserved'] = $this->account_model->get_total_reserved_sum($register_code);
        $data['total_invest'] = $this->account_model->get_total_invest_sum($register_code);
        $data['total_funding'] = $this->account_model->get_total_funding_sum($register_code);

        $data['data_loan'] = $this->account_model->get_data_loan($register_code,$id_borrower_loan);
        $data['data_loan_periode_sort'] = $this->account_model->get_data_loan_period_sort($register_code,$id_borrower_loan);
        $data['id_borrower_loan'] = $id_borrower_loan;
        // $data['data_loan_periode'] = $this->account_model->get_data_loan_period($register_code, $id_borrower_loan);


        // $footer['data_contact'] = $this->contact_model->get_contact();

        // $this->load->view('frontend-fintech/partial/header');
        // $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/portofolio' , $data);
        // $this->load->view('frontend-fintech/partial/footer' , $footer);
        // $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function browse(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['browse_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/browse' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function account(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['account_active'] = "active";

        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_lender($register_code);
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');

        $data['total_reserved'] = $this->account_model->get_total_reserved_sum($register_code);
        $data['total_invest'] = $this->account_model->get_total_invest_sum($register_code);
        $data['total_funding'] = $this->account_model->get_total_funding_sum($register_code);

        $data['data_loan'] = $this->account_model->get_data_loan($register_code);
        $data['data_term'] = $this->account_model->get_term_by_id_nreg_lender($register_code);
        $data['data_contacts'] = $this->contact_model->get_contact();
        $data['data_direk'] = $this->management_model->get_managementmenu_direk();
        $data['check_data'] = $this->crud_model->get_data("tb_fintech_register",$where)->result();
        $data['data_bio'] = $this->personal_info_model->get_personal_info_lender($register_code);
        
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/account' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function autopurchase(){
       $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);

        $id_lender_automation= $this->uri->segment(4);

        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['browse_active'] = "active";
        $navigation['autopurchase_active'] = "active_link";

        $data['get_code'] = $register_code;

        $footer['data_contact'] = $this->contact_model->get_contact();
        $data['auto'] = $this->auto_model->get_loan($register_code);
        $data['data_periode'] = $this->loan_model->get_periode();

        $data['data_auto'] = $this->auto_model->get_auto_by_id($id_lender_automation);

        $data['form_url'] = site_url('Finance/F_lender/autopurchase');
        $data['update_url'] = site_url('Finance/F_lender/update_autopurchase');
        $data['delete_url'] = site_url('Finance/F_lender/delete_autopurchase');

            $this->form_validation->set_rules("automation_name", "", "trim|required");
            $this->form_validation->set_rules("automation_amount", "", "required");
    
            if ($this->form_validation->run() == true){

                $register_code  = $this->input->post('register_code');
                $automation_name = $this->input->post('automation_name');
                $automation_amount = $this->input->post('automation_amount');
                $automation_loan_term = $this->input->post('automation_loan_term');
                $automation_rating = $this->input->post('automation_rating');
                $automation_type_loan = $this->input->post('automation_type_loan');

                $clean = preg_replace('/\D/','',$automation_amount);

                if(($clean%100000)!=0) {
                        $this->session->set_flashdata('alert_error', 'Minimum amount of investment multiples 100,000.');
                        redirect(base_url().'Finance/F_lender/autopurchase');
                        die();
                }
               
                if(!empty($automation_loan_term)){

                    $loan_term_array = array();
                    foreach ($automation_loan_term as $value) {
                      array_push($loan_term_array, $value);
                    }
                    $automation_loan_term = json_encode($loan_term_array, true);
                } else {
                    $automation_loan_term = '["3","6","12","24","36"]';

                }

                if(!empty($automation_rating)){

                    $rating_array = array();
                    foreach ($automation_rating as $value) {
                      array_push($rating_array, $value);
                    }
                    $automation_rating = json_encode($rating_array, true);
                } else {
                    $automation_rating = '["APlus","A","B","BPlus","C","CPlus","D","DPlus"]';

                }
                if(!empty($automation_type_loan)){

                    $type_loan_array = array();
                    foreach ($automation_type_loan as $value) {
                      array_push($type_loan_array, $value);
                    }
                    $automation_type_loan = json_encode($type_loan_array, true);
                } else {
                    $automation_type_loan = '["Personal_Loan","Fixed_Loan","Flexible_Loan"]';

                }

                        $data_auto = array(
                        'register_code' => $register_code,
                        'automation_name' => $automation_name,
                        'automation_amount' => $clean,
                        'automation_loan_term' => $automation_loan_term,
                        'automation_rating' => $automation_rating,
                        'automation_type_loan' => $automation_type_loan,
                        'automation_status' => 'Deactivated'

                        );

                        $insert_auto = $this->crud_model->insert('tb_fintech_lender_automation',$data_auto);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Finance/F_lender/autopurchase');
                        die();
                    
            }
        
        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation_browse' , $navigation);
        $this->load->view('frontend-fintech/lender/autopurchase' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function update_autopurchase(){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;


            $this->form_validation->set_rules("id_lender_automation", "", "trim|required");
            $this->form_validation->set_rules("automation_name", "", "trim|required");
            $this->form_validation->set_rules("automation_amount", "", "trim|required"); 

            if ($this->form_validation->run() == true){
                $automation_id = $this->input->post('id_lender_automation');
                $automation_name = $this->input->post('automation_name');
                $automation_amount = $this->input->post('automation_amount');
                $automation_loan_term = $this->input->post('automation_loan_term');
                $automation_rating = $this->input->post('automation_rating');
                $automation_type_loan = $this->input->post('automation_type_loan');

                $clean = preg_replace('/\D/','',$automation_amount);

                if(($clean%100000)!=0) {
                        $this->session->set_flashdata('alert_error', 'Minimum amount of investment multiples 100,000.');
                        redirect(base_url().'Finance/F_lender/autopurchase');
                        die();
                }
               
                if(!empty($automation_loan_term)){

                    $loan_term_array = array();
                    foreach ($automation_loan_term as $value) {
                      array_push($loan_term_array, $value);
                    }
                    $automation_loan_term = json_encode($loan_term_array, true);
                } else {
                    $automation_loan_term = '["3","6","12","24","36"]';

                }

                if(!empty($automation_rating)){

                    $rating_array = array();
                    foreach ($automation_rating as $value) {
                      array_push($rating_array, $value);
                    }
                    $automation_rating = json_encode($rating_array, true);
                } else {
                    $automation_rating = '["APlus","A","B","BPlus","C","CPlus","D","DPlus"]';

                }
                if(!empty($automation_type_loan)){

                    $type_loan_array = array();
                    foreach ($automation_type_loan as $value) {
                      array_push($type_loan_array, $value);
                    }
                    $automation_type_loan = json_encode($type_loan_array, true);
                } else {
                    $automation_type_loan = '["Personal_Loan","Fixed_Loan","Flexible_Loan"]';

                }

                        $data_auto = array(
                        'automation_name' => $automation_name,
                        'automation_amount' => $clean,
                        'automation_loan_term' => $automation_loan_term,
                        'automation_rating' => $automation_rating,
                        'automation_type_loan' => $automation_type_loan

                        );

                        $update_auto = $this->crud_model->update('tb_fintech_lender_automation','id_lender_automation',$automation_id,$data_auto);
                        $this->session->set_flashdata('alert_success', 'Data successfully Update.');
                        redirect(base_url().'Finance/F_lender/autopurchase');
                        die();
                    
            } else {
                $this->session->set_flashdata('alert_error', 'Data failed to update.');
                redirect(base_url().'Finance/F_lender/autopurchase');
                die();
            }

    }

    public function check_automation_update(){
        $id_lender_automation = $this->input->post('id_lender_automation');

        $where = array('id_lender_automation' => $id_lender_automation );

        $data_automation = $this->crud_model->get_data("tb_fintech_lender_automation",$where)->result();

        $automation_loan_term = json_decode($data_automation[0]->automation_loan_term);
        $automation_type_loan = json_decode($data_automation[0]->automation_type_loan);
        $automation_rating = json_decode($data_automation[0]->automation_rating);

        // var_dump($automation_loan_term);
        // var_dump($automation_type_loan);
        // var_dump($automation_rating);

        $result = array();

        foreach ($automation_loan_term as $value) {
            $result['id'.$value] = $value;
        }

        foreach ($automation_type_loan as $value2) {
            $result['id'.$value2] = $value2;
        }

        foreach ($automation_rating as $value3) {
            $result['id'.$value3] = $value3;
        }

        echo json_encode($result);
       
    }

    public function manually(){  
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);

        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['browse_active'] = "active";
        $navigation['manually_active'] = "active_link";

        $data['lend_code'] = $register_code;
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $data['form_url'] = site_url('Finance/F_lender/investment');

        
        $footer['data_contact'] = $this->contact_model->get_contact();
        $footer['Privacy'] = "orange";

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation_browse', $navigation);
        $this->load->view('frontend-fintech/lender/manually' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function investment(){  
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $data['data_total'] = $this->report_model->get_total_amount($register_code);
        $data['data_loan'] = $this->report_model->get_cashflow($register_code);

        $idMax = $this->loan_model->invest_code();
        $noUrut =(int) substr($idMax[0]->maxID,3,9);
        $noUrut ++;
        $newID="INV".sprintf("%08s",$noUrut);
        $date = date('Y-m-d H:i:s');

        $this->form_validation->set_rules("loan_code", "", "trim|required");
        $this->form_validation->set_rules("amount_invest", "", "trim|required");

        if($this->form_validation->run() == true){
            $id_borrower_loan = $this->input->post("loan_code");
            $amount_invest = $this->input->post("amount_invest");
            // $clean = preg_replace('/\D/','',$amount_invest);

            $lender_fund = $this->bank_model->get_fund_lender($register_code);

            $data_loan = $this->loan_model->get_loan_by_id($id_borrower_loan);

            $completion = $data_loan[0]->completion;
            $loan_amount = $data_loan[0]->loan_amount;
            $amount_left = $data_loan[0]->amount_left;
            $loan_status = $data_loan[0]->completion;
            $loan_payment = $data_loan[0]->completion;

            // var_dump($loan_amount);
            if($amount_invest > 0){
                if($loan_amount >= '1000000' AND $loan_amount < '10000000'){

                    // var_dump('10 sampe 1 jt');
                    if(($amount_invest%100000)!=0) {
                        $this->session->set_flashdata('alert_error', 'Minimum amount of investment multiples 100,000.');
                        redirect(base_url().'Finance/F_lender/manually');
                        die();
                    }
                } else if ($loan_amount >= '10000000'){

                    // var_dump('10 jt ke atas');
                    if(($amount_invest%1000000)!=0) {
                        $this->session->set_flashdata('alert_error', 'Minimum amount of investment multiples 1,000,000.');
                        redirect(base_url().'Finance/F_lender/manually');
                        die();
                    }
                }
            } else {
                $this->session->set_flashdata('alert_error', 'please input the correct investment nominal');
                redirect(base_url().'Finance/F_lender/manually');
                die();
            }

            if ($lender_fund[0]->amount < $amount_invest){
                $this->session->set_flashdata('alert_error', 'Transaction Failed, your balance / available funds is insufficient to make an investment.');
                redirect(base_url().'Finance/F_lender/manually');
                die();
            } else {
                $fund_amount = $lender_fund[0]->amount - $amount_invest;
            }

            $borrower_fund = $this->bank_model->get_fund_borrower($data_loan[0]->register_code);

            $borrower_reg_code = $data_loan[0]->register_code;

            $total_left = $amount_left - $amount_invest;
            
            if ($total_left > 0){
                $total_amount = $loan_amount - $total_left; 
                $total_completion = $completion + (($total_amount / $loan_amount) * 100);
            } else {
                $total_completion = 100;
            }

            if ($total_left < 0){
                $this->session->set_flashdata("alert_error", "Transaction Failed, The amount invested exceeds the borrowing limit. Limit Of Investment is Rp. ".number_format($amount_left).".");
                redirect(base_url().'Finance/F_lender/manually');
                die();

            } else {

                if ($total_left == 0){
                    // update loan 
                    $data_loan_update = array( 
                            'loan_payment' => "Fully Paid", 
                            'loan_status' => "Disbursed", 
                            'amount_left' => $total_left, 
                            'completion' => $total_completion, 
                            'loan_start_date' => date("Y-m-d"),
                    );

                    $update_loan = $this->crud_model->update('tb_fintech_borrower_loan','id_borrower_loan',$id_borrower_loan, $data_loan_update);

                    // proses pindah dana lender to borrower jika sudah terpenuhi
                    $data_commision_rate = $this->crud_model->get_setting();
                    $commision_lender = $loan_amount * ($data_commision_rate[0]->commision_lender/100);
                    $insurance_lender = $loan_amount * ($data_commision_rate[0]->insurance_rate/100);

                    $data_setting = $this->crud_model->get_setting();
                    $fee_pg = $data_setting[0]->fee_pg;

                    $GL_fund = $loan_amount - $commision_lender - $insurance_lender;
                    $fund_borrower_amount = $borrower_fund[0]->amount + ($loan_amount - $commision_lender - $insurance_lender);

                    $where = array('register_code' => $borrower_reg_code) ;
                    $check_fund = $this->crud_model->get_data("tb_fintech_borrower_fund", $where)->num_rows();

                    if($check_fund == 0){
                        $data_borrower_fund = array(
                        'register_code' => $borrower_reg_code,
                        'amount' => $fund_borrower_amount,
                        );

                        $insert_fund = $this->crud_model->insert('tb_fintech_borrower_fund',$data_borrower_fund);
                    } else {
                        $data_borrower_fund = array(
                        'amount' => $fund_borrower_amount,
                        );

                        $update_fund = $this->crud_model->update('tb_fintech_borrower_fund','register_code',$borrower_reg_code,$data_borrower_fund);
                    }

                    $periode = $data_loan[0]->loan_tenor;
                    $principal = $data_loan[0]->loan_principal;
                    $interest = $data_loan[0]->loan_interest;

                    for($i=0;$periode>$i;$i++){

                        $month = $i + 1;
                        $date = date("Y-m-d");    
                        $time = strtotime($date);
                        $final = date("Y-m-d", strtotime("+".$month." month", $time));

                        $data_payment_periode = array(
                            'id_borrower_loan' => $id_borrower_loan,
                            'payment_periode_date' => $final,
                            'payment_periode_principal' => $principal,
                            'payment_periode_interest' => $interest,
                            'payment_periode_pinalty' => 0,
                            'payment_periode_status_principal' => 'default',
                            'payment_periode_status_interest' => 'default',
                            'payment_periode_status_pinalty' => 'default',
                        );

                        $insert_payment = $this->crud_model->insert('tb_fintech_borrower_payment_periode', $data_payment_periode);
                    }

                    // GL OTOMATIS
                    // Kode Jurnal
                    $idMaxgl = $this->journal_model->journal_code();
                    $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                    $noUrutgl ++;
                    $date_codegl = date('m/y');
                    $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;
                   
                    // personal loan debit
                    $data_journal1 = array(
                                'journal_no' => $newIDgl,
                                'id_param_coa_e' => 6, 
                                'journal_entry' => date('Y-m-d H:i:s'),
                                'journal_date' => date('Y-m-d H:i:s'),
                                'journal_description' => 'Disbursement Pinjaman'.'-'.$borrower_reg_code.'-'.$id_borrower_loan,
                                // 'journal_description_form' => 'Pinjaman - '.$id_borrower_loan,
                                'journal_debit' => $loan_amount,
                                'journal_kredit' => 0,
                                'cashflow_code_status' => '0',
                                'journal_status' => '0'
                                );

                    $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                    // komisi credit
                    $data_journal2 = array(
                                'journal_no' => $newIDgl,
                                'id_param_coa_e' => 63, 
                                'journal_entry' => date('Y-m-d H:i:s'),
                                'journal_date' => date('Y-m-d H:i:s'),
                                'journal_description' => 'Disbursement Pinjaman'.'-'.$borrower_reg_code.'-'.$id_borrower_loan,
                                // 'journal_description_form' => 'Komisi Dari Peminjam - '.$id_borrower_loan,
                                'journal_debit' => 0,
                                'journal_kredit' => $commision_lender,
                                'cashflow_code_status' => '0',
                                'journal_status' => '0'
                                );

                    $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);

                    //Asuransi kredit
                    $data_journal3 = array(
                                'journal_no' => $newIDgl,
                                'id_param_coa_e' => 132, 
                                'journal_entry' => date('Y-m-d H:i:s'),
                                'journal_date' => date('Y-m-d H:i:s'),
                                'journal_description' => 'Disbursement Pinjaman'.'-'.$borrower_reg_code.'-'.$id_borrower_loan,
                                // 'journal_description_form' => 'Insurance Premium - '.$id_borrower_loan,
                                'journal_debit' => 0,
                                'journal_kredit' => $insurance_lender,
                                'cashflow_code_status' => '0',
                                'journal_status' => '0'
                                );

                    $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                    //loan to be disbursed kredit
                    $data_journal4 = array(
                                'journal_no' => $newIDgl,
                                'id_param_coa_e' => 130, 
                                'journal_entry' => date('Y-m-d H:i:s'),
                                'journal_date' => date('Y-m-d H:i:s'),
                                'journal_description' => 'Disbursement Pinjaman'.'-'.$borrower_reg_code.'-'.$id_borrower_loan,
                                // 'journal_description_form' => 'Loan Disbursed - '.$id_borrower_loan,
                                'journal_debit' => 0,
                                'journal_kredit' => $GL_fund,
                                'cashflow_code_status' => '0',
                                'journal_status' => '0'
                                );

                    $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);
                    // end disbursment

                    // Kode Jurnal 2
                    $idMaxgl2 = $this->journal_model->journal_code();
                    $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                    $noUrutgl2 ++;
                    $date_codegl2 = date('m/y');
                    $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                    // Commision debit
                    $data_journal5 = array(
                                'journal_no' => $newIDgl2,
                                'id_param_coa_e' => 2, 
                                'journal_entry' => date('Y-m-d H:i:s'),
                                'journal_date' => date('Y-m-d H:i:s'),
                                'journal_description' => 'Pemindahan Uang Komisi dari Peminjam'.'-'.$borrower_reg_code.'-'.$id_borrower_loan,
                                // 'journal_description_form' => 'Komisi Dari Peminjam - '.$id_borrower_loan,
                                'journal_debit' => $commision_lender,
                                'journal_kredit' => 0,
                                'cashflow_code_status' => 'OTD',
                                'journal_status' => '0'
                                );

                    $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                    // Commision credit
                    $data_journal6 = array(
                                'journal_no' => $newIDgl2,
                                'id_param_coa_e' => 128, 
                                'journal_entry' => date('Y-m-d H:i:s'),
                                'journal_date' => date('Y-m-d H:i:s'),
                                'journal_description' => 'Pemindahan Uang Komisi dari Peminjam'.'-'.$borrower_reg_code.'-'.$id_borrower_loan,
                                // 'journal_description_form' => 'Komisi Dari Peminjam - '.$id_borrower_loan,
                                'journal_debit' => 0,
                                'journal_kredit' => $commision_lender,
                                'cashflow_code_status' => 'OTC',
                                'journal_status' => '0'

                                );

                    $insert_journal6 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal6);
                    // end commission 




                    // Kode Jurnal 3
                    $idMaxgl3 = $this->journal_model->journal_code();
                    $noUrutgl3 = (int) substr($idMaxgl3[0]->maxID,0,4);
                    $noUrutgl3 ++;
                    $date_codegl3 = date('m/y');
                    $newIDgl3 = sprintf("%04s",$noUrutgl3).'/'.$date_codegl3;

                    // Asuransi dan PG debit
                    $data_journal7 = array(
                                'journal_no' => $newIDgl3,
                                'id_param_coa_e' => 2, 
                                'journal_entry' => date('Y-m-d H:i:s'),
                                'journal_date' => date('Y-m-d H:i:s'),
                                'journal_description' => 'Pemindahan Dana Premi Asuransi'.'-'.$borrower_reg_code.'-'.$id_borrower_loan,
                                // 'journal_description_form' => 'Asuransi - '.$id_borrower_loan,
                                'journal_debit' => $insurance_lender,
                                'journal_kredit' => 0,
                                'cashflow_code_status' => 'IP',
                                'journal_status' => '0'
                                );

                    $insert_journal7 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal7);

                    // Asuransi dan PG credit
                    $data_journal8 = array(
                                'journal_no' => $newIDgl3,
                                'id_param_coa_e' => 128, 
                                'journal_entry' => date('Y-m-d H:i:s'),
                                'journal_date' => date('Y-m-d H:i:s'),
                                'journal_description' => 'Pemindahan Dana Premi Asuransi'.'-'.$borrower_reg_code.'-'.$id_borrower_loan,
                                // 'journal_description_form' => 'Asuransi - '.$id_borrower_loan,
                                'journal_debit' => 0,
                                'journal_kredit' => $insurance_lender,
                                'cashflow_code_status' => 'INS',
                                'journal_status' => '0'
                                );

                    $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);


                } else {
                    // update loan 
                    $data_loan_update = array( 
                            'loan_payment' => "Not Yet Paid", 
                            'loan_status' => "On Proses", 
                            'amount_left' => $total_left,
                            'completion' => $total_completion, 
                    );

                    $update_loan = $this->crud_model->update('tb_fintech_borrower_loan','id_borrower_loan',$id_borrower_loan, $data_loan_update);       
                }
                // update lender fund
                $data_fund = array(
                        'amount' => $fund_amount,
                        );

                $update_fund = $this->crud_model->update('tb_fintech_lender_fund','register_code',$register_code,$data_fund);

                // investasi tb
                
                $data_invest = array(
                    'investment_code' => $newID,
                    'register_code' => $register_code,
                    'investmen_date' => date('Y-m-d H:i:s'),
                    'id_borrower_loan' => $id_borrower_loan,
                    'borrower_reg_code' => $borrower_reg_code,
                    'amount_invest' => $amount_invest,
                );

                $insert_invest = $this->crud_model->insert('tb_fintech_lender_investment', $data_invest);

                // $email_lender = $this->personal_info_model->get_email_lender($register_code);

                $beginning = 0;
                $beginning = (int)@$data['data_total'][0]->total_amount;

                $ending = (int)$beginning - (int)$amount_invest  + (int)@$data['data_loan'][0]->payment_pokok - (int)@$data['data_loan'][0]->payment_tax + (int)@$data['data_loan'][0]->payment_interest;
                

                $data_cashflow = array(
                        'register_code' => $register_code,
                        'cashflow_date' => date('Y-m-d H:i:s'),
                        'beginning_amount' => $beginning,
                        'withdrawal_amount' => 0,
                        'deposit_amount' => 0,
                        'invest_amount' => $amount_invest,
                        'payment_pokok' => 0,
                        'payment_tax' => 0,
                        'payment_interest' =>0,
                        'total_amount' => $ending,
                        'cashflow_status' => "Investment"
                );
                $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_cashflow);

                 // email
                $email_manager = $this->users_model->get_user_email();
                // $email_manager = array_merge($email_manager);
                $email_borrower = $this->personal_info_model->get_email_borrower($borrower_reg_code);

                $emails = array_map(function($value){
                    return $value->users_email;
                }, $email_manager);

                $emails_bor = array_map(function($value){
                    return $value->register_email;
                }, $email_borrower);

                $email_crowdfunding = array_merge($emails,$emails_bor);

                foreach ($email_crowdfunding as $email_entry) {
                   $config = array();
                    $config['charset'] = 'iso-8859-1';
                    $config['useragent'] = 'Codeigniter';
                    $config['protocol']= 'smtp';
                    $config['mailtype']= 'html';
                    $config['smtp_host']= 'ssl://mail.heatcliffs31.com';//pengaturan smtp
                    $config['smtp_port']= 465;
                    $config['smtp_timeout']= 400;
                    $config['smtp_user']= 'sanders@heatcliffs31.com'; // isi dengan email kamu
                    $config['smtp_pass']= '1q2w3e4r5t'; // isi dengan password kamu
                    $config['crlf']="\r\n"; 
                    $config['newline']="\r\n"; 
                    $config['wordwrap'] = TRUE;
                            //memanggil library email dan set konfigurasi untuk pengiriman email
                    $this->load->library('email',$config);
                    $this->email->initialize($config);
                    // $where_check = array('register_activation_code' => $random);

                            //konfigurasi pengiriman
                    $this->email->from($config['smtp_user']);
                    $this->email->to($email_crowdfunding);
                    $this->email->subject("Notification Fulfilled");
                    $body = $this->load->view('frontend-fintech/email_invest.php','',TRUE);
                    $this->email->message($body);
                    $this->email->send();

                    $this->session->set_flashdata('alert_success', 'Investment Success. ');
                    redirect(base_url().'Finance/F_lender/manually');
                    die();
                }
                

            }

        } else {
            echo "<script>history.back(1)</script>"; 
        }
   
    }

    public function deposit_transaction(){  
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['deposit_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_lender($register_code);
        $data['data_code'] = $this->bank_model->get_bank_lender($register_code);
        $data['form_url'] = site_url('Finance/F_lender/deposit_transaction');
        $data['data_contact'] = $this->contact_model->get_contact();
        $footer['data_contact'] = $this->contact_model->get_contact();
        $data['data_loan'] = $this->report_model->get_cashflow($register_code);
        $data['data_total'] = $this->report_model->get_total_amount($register_code);

        $this->form_validation->set_rules("register_code", "", "trim|required");
        $this->form_validation->set_rules("deposit_name", "", "trim|required");
        $this->form_validation->set_rules("deposit_bank_name", "", "trim|required");
        $this->form_validation->set_rules("deposit_branch", "", "trim|required");
        $this->form_validation->set_rules("deposit_account", "", "trim|required");
        $this->form_validation->set_rules("deposit_amount", "", "trim|required");

        if($this->form_validation->run() == true){
            $register_code  = $this->input->post('register_code');
            $deposit_name = $this->input->post('deposit_name');
            $deposit_bank_name = $this->input->post('deposit_bank_name');
            $deposit_branch = $this->input->post('deposit_branch');
            $deposit_account = $this->input->post('deposit_account');
            $deposit_amount = $this->input->post('deposit_amount');
            $deposit_virtual_account = "";
            $deposit_date = date('Y-m-d H:i:s');
            $date = date('Y-m-d');

            $where = array('register_code' => $register_code) ;
            $data_check = $this->crud_model->get_data("tb_fintech_register", $where)->num_rows();

            $_POST['deposit_amount'] = $deposit_amount;
            $clean = preg_replace('/\D/','',$_POST['deposit_amount']);

            if($clean < 1000000) {
                $this->session->set_flashdata('alert_error', 'Minimum investment must be 1,000,000. or more');
                redirect(base_url().'Finance/F_lender/deposit');
                die();
            }

            // deposit debit
            // ditambah biaya 1500
            $data_setting = $this->crud_model->get_setting();
            $fee_pg = $data_setting[0]->fee_pg;

            $clean_with_fee = $clean - $fee_pg;


            if($data_check == 1){

                $data_deposit = array(
                    'register_code' => $register_code,
                    'deposit_name' => $deposit_name,
                    'deposit_bank_name' => $deposit_bank_name,
                    'deposit_branch' => $deposit_branch,
                    'deposit_account' => $deposit_account,
                    'deposit_amount' => $clean_with_fee,
                    'deposit_virtual_account' => $deposit_virtual_account,
                    'deposit_date' => $deposit_date,
                    'deposit_status' => "Success"
                );
                $beginning = 0;
                $beginning = @$data['data_total'][0]->total_amount;

                $insert_deposit = $this->crud_model->insert('tb_fintech_lender_deposit', $data_deposit);


                $ending = $beginning + $clean_with_fee - @$data['data_loan'][0]->withdrawal_amount - @$data['data_loan'][0]->invest_amount + @$data['data_loan'][0]->payment_pokok - @$data['data_loan'][0]->payment_tax + @$data['data_loan'][0]->payment_interest;

                    
                    $data_deposit_cashflow = array(
                    'register_code' => $register_code,
                    'cashflow_date' => $deposit_date,
                    'beginning_amount' => $beginning,
                    'withdrawal_amount' => 0,
                    'deposit_amount' => $clean_with_fee,
                    'invest_amount' => 0,
                    'payment_pokok' => 0,
                    'payment_tax' => 0,
                    'payment_interest' =>0,
                    'total_amount' => $ending,
                    'cashflow_status' => "Deposit"
                );
               
                
                $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_deposit_cashflow);
                $where = array('register_code' => $register_code) ;
                $check_fund = $this->crud_model->get_data("tb_fintech_lender_fund", $where)->num_rows();

                if ($check_fund == 0){
                    
                    $data_fund = array(
                    'register_code' => $register_code,
                    'amount' => $clean_with_fee,
                    );

                    $insert_fund = $this->crud_model->insert('tb_fintech_lender_fund', $data_fund);
                } else {

                    $fund_data = $this->crud_model->get_data("tb_fintech_lender_fund", $where)->result();

                    $amount = $fund_data[0]->amount + $clean_with_fee;

                    $data_fund = array(
                    'amount' => $amount,
                    );

                    $update_fund = $this->crud_model->update('tb_fintech_lender_fund','register_code',$register_code,$data_fund);

                }

                // GL OTOMATIS
                // Kode Jurnal

                $idMaxgl = $this->journal_model->journal_code();
                $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                $noUrutgl ++;
                $date_codegl = date('m/y');
                $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;

                $data_journal1 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 128, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Penerimaan Dana Investor'.'-'.$register_code,
                            // 'journal_description_form' => 'Deposit - '.$register_code,
                            'journal_debit' => $clean,
                            'journal_kredit' => 0,
                            'cashflow_code_status' => 'ID',
                            'journal_status' => '0'
                            );

                $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                // deposit credit
                $data_journal2 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 42, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Penerimaan Dana Investor'.'-'.$register_code,
                            // 'journal_description_form' => 'Investor Fund - '.$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $clean_with_fee,
                            'cashflow_code_status' => '0',
                            'journal_status' => '0'
                            );

                $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);

                //fee PG
                $data_journal3 = array(
                            'journal_no' => $newIDgl,
                            'id_param_coa_e' => 131, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Penerimaan Dana Investor'.'-'.$register_code,
                            // 'journal_description_form' => 'Fee PG - '.$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $fee_pg,
                            'cashflow_code_status' => '0',
                            'journal_status' => '0'
                            );

                $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                //pemindahan biaya pg ke rek oprasional
                // Kode Jurnal
                $idMaxgl2 = $this->journal_model->journal_code();
                $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                $noUrutgl2 ++;
                $date_codegl2 = date('m/y');
                $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                //pemindahan biaya pg ke rek oprasional debit
                $data_journal4 = array(
                            'journal_no' => $newIDgl2,
                            'id_param_coa_e' => 2, 
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Pemindahan Biaya PG ke Rek Ops'.'-'.$register_code,
                            // 'journal_description_form' => 'Biaya PG - '.$register_code,
                            'journal_debit' => $fee_pg,
                            'journal_kredit' => 0,
                            'cashflow_code_status' => 'OTD',
                            'journal_status' => '0'
                            );

                $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);

                //pemindahan biaya pg ke rek oprasional credit
                $data_journal5 = array(
                            'journal_no' => $newIDgl2,
                            'id_param_coa_e' => 128,
                            'journal_entry' => date('Y-m-d H:i:s'),
                            'journal_date' => date('Y-m-d H:i:s'),
                            'journal_description' => 'Pemindahan Biaya PG ke Rek Ops'.'-'.$register_code,
                            // 'journal_description_form' => 'Biaya PG - '.$register_code,
                            'journal_debit' => 0,
                            'journal_kredit' => $fee_pg,
                            'cashflow_code_status' => 'OTC',
                            'journal_status' => '0'
                            );

                $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                $this->session->set_flashdata('alert_success', 'Transaction Success. ');
                redirect(base_url().'Finance/F_lender/deposit');
                die();

            } else {
                $this->session->set_flashdata('alert_error', 'Transaction failed.');
                redirect(base_url().'Finance/F_lender/deposit');
            }  

        }
        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1', $navigation);
        $this->load->view('frontend-fintech/lender/deposit_transaction' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function deposit(){  
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $data_check = $this->crud_model->get_data("tb_fintech_lender_deposit", $where)->num_rows();

        $data['data_check'] = $data_check;
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['deposit_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');

        $data['get_code'] = $register_code;
        $data['get_name'] = $this->personal_info_model->get_personal_info_lender($register_code);
        $data['data_code'] = $this->bank_model->get_bank_lender($register_code);
        $data['edit_url'] = site_url('Finance/F_lender/deposit_transaction');
        $data['data_contact'] = $this->contact_model->get_contact();
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1', $navigation);
        $this->load->view('frontend-fintech/lender/deposit' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function report(){  
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['report_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');

        $data['get_code'] = $register_code;

        $data['data_cashflow'] = $this->report_model->get_cashflow($register_code);
        $data['data_loan'] = $this->report_model->get_data_loan($register_code);

        // print_r($data['total_invest']);
        // die();

        $footer['data_contact'] = $this->contact_model->get_contact();
        $footer['Privacy'] = "orange";

        $this->load->view('frontend-fintech/partial/header');
        $this->load->view('frontend-fintech/partial/navigation1', $navigation);
        $this->load->view('frontend-fintech/lender/report' , $data);
        $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function dropdown_city_residence()
    {
      $id_indonesia_provinsi = $this->input->post('id_indonesia_provinsi');
      $data = $this->indonesia_model->get_city($id_indonesia_provinsi);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kota_kab>$value->nama</option>";
      }
    }

    public function dropdown_district()
    {
      $id_indonesia_kota_kab = $this->input->post('id_indonesia_kota_kab');

      $data = $this->indonesia_model->get_district($id_indonesia_kota_kab);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kec>$value->nama</option>";
      }
    }

    public function dropdown_village()
    {
      $id_indonesia_kec = $this->input->post('id_indonesia_kec');
      $data = $this->indonesia_model->get_village($id_indonesia_kec);
      foreach ($data as $value) {
          echo "<option value=$value->id_indonesia_kel_des>$value->nama</option>";
      }
    }

    public function cashflow(){  
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $data['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['report_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');

        $data['get_code'] = $register_code;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : null;
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : null;
        $time = strtotime($start_date);
        $start_date = date('Y-m-d H:i:s',$time);
        $time = strtotime($end_date. ' +23 hour +59 minutes +59 seconds');
        $end_date = date('Y-m-d H:i:s',$time);

        // var_dump($start_date);
        // die();
        $data['data_cashflow'] = $this->report_model->get_cashflow($register_code, $start_date, $end_date);
        $data['data_loan'] = $this->report_model->get_data_loan($register_code);

       
        $footer['data_contact'] = $this->contact_model->get_contact();
        $footer['Privacy'] = "orange";

        // $this->load->view('frontend-fintech/partial/header');
        // $this->load->view('frontend-fintech/partial/navigation1', $navigation);
        $this->load->view('frontend-fintech/lender/cashflow' , $data);
        // $this->load->view('frontend-fintech/partial/footer' , $footer);
        // $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function order_history(){  
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $data['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['report_active'] = "active";
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');

        $data['get_code'] = $register_code;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : null;
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : null;
        $time = strtotime($start_date);
        $start_date = date('Y-m-d H:i:s',$time);
        $time = strtotime($end_date. ' +23 hour +59 minutes +59 seconds');
        $end_date = date('Y-m-d H:i:s',$time);

        // var_dump($start_date);
        // die();
        $data['data_cashflow'] = $this->report_model->get_cashflow($register_code, $start_date, $end_date);
        $data['data_loan'] = $this->report_model->get_data_loan($register_code, $start_date, $end_date);

       
        $footer['data_contact'] = $this->contact_model->get_contact();
        $footer['Privacy'] = "orange";

        $this->load->view('frontend-fintech/partial/header');
        // $this->load->view('frontend-fintech/partial/navigation1', $navigation);
        $this->load->view('frontend-fintech/lender/order_history', $data);
        // $this->load->view('frontend-fintech/partial/footer' , $footer);
        $this->load->view('frontend-fintech/partial/sidebar');
    }

    public function fact_sheet($id_borrower_loan)
    {
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['borrower_fund'] = $this->bank_model->get_fund_borrower($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_borrower_bio',$where)->result();
        $navigation['account_active'] = "active";

        $data['data_bio_borrower'] = $this->manually_model->get_bio_borrower_loan($id_borrower_loan);
        $data['data_consumtive'] = $this->manually_model->get_personal_info_borrower_consumptive($id_borrower_loan);
        $prov_consumtive = ((array)@$data['data_consumtive'][0]);
        $data['data_province_consumtive'] = $this->indonesia_model->get_province_business_by_id(@$prov_consumtive['borrower_province_company']);
        $data['data_city_consumtive'] = $this->indonesia_model->get_city_business_by_id(@$prov_consumtive['borrower_city_company']);
        $data['data_district_consumtive'] = $this->indonesia_model->get_district_business_by_id(@$prov_consumtive['borrower_district_company']);
        $data['data_village_consumtive'] = $this->indonesia_model->get_village_business_by_id(@$prov_consumtive['borrower_village_company']);
        
        $data['get_code'] = $register_code;
        $data['data_manually'] = $this->manually_model->get_manually_id($id_borrower_loan,$register_code);
        $data['data_commercial'] = $this->manually_model->get_personal_info_borrower_commercial($id_borrower_loan);
        $industry_type = ((array)@$data['data_commercial'][0]);
        $data['data_industry_type'] = $this->param_model->get_industry_by_id(@$industry_type['borrower_industry_type']);
        $data['data_industry_cons'] = $this->param_model->get_industry();
        $prov_commercial = ((array)@$data['data_commercial'][0]);
        $data['data_province_commercial'] = $this->indonesia_model->get_province_business_by_id(@$prov_commercial['borrower_province_company']);
        $data['data_city_commercial'] = $this->indonesia_model->get_city_business_by_id(@$prov_commercial['borrower_city_company']);
        $data['data_district_commercial'] = $this->indonesia_model->get_district_business_by_id(@$prov_commercial['borrower_district_company']);
        $data['data_village_commercial'] = $this->indonesia_model->get_village_business_by_id(@$prov_commercial['borrower_village_company']);
        $data['data_business_field'] = $this->personal_info_model->get_business_field_borrower($register_code);
        $business_field = ((array)@$data['data_commercial'][0]);
        $data['data_business_field_name'] = $this->param_model->get_field_business_by_id(@$business_field['borrower_business_field']);
        $data['data_business_field_cons'] = $this->param_model->get_field_business();

        // $data['data_code'] = $this->personal_info_model->get_personal_info_borrower($register_code);
        // $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Borrower');
        $data['data_loan'] = $this->loan_model->get_loan_by_id($id_borrower_loan);
        // $data['data_disbursed'] = $this->loan_model->get_ongoing_list(null,null, $register_code)->result();
        // $data['avg_interest'] = $this->loan_model->get_avg_interest($register_code);

        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        // $this->load->view('frontend-fintech/partial/navigation2' , $navigation);
        $this->load->view('frontend-fintech/lender/fact-sheet' , $data);
        // $this->load->view('frontend-fintech/partial/footer' , $footer);
        // $this->load->view('frontend-fintech/partial/sidebar_borrower');
    }

    public function time_left()
    {
            $id_borrower_loan = $this->input->post('id_borrower_loan');
            $time_left = $this->input->post('time_left');

            $data_loan = array(
                    'time_left' => $time_left
            );

            $update_loan = $this->crud_model->update('tb_fintech_borrower_loan', 'id_borrower_loan', $id_borrower_loan,  $data_loan);
         
    }

    public function term_lender($register_code){
        $reg_code = $this->session->userdata('reg_code');
        $reg_password = $this->session->userdata('reg_password');
        $reg_access_status = $this->session->userdata('reg_access_status');
        $reg_activation_status = $this->session->userdata('reg_activation_status');
        $reg_status = $this->session->userdata('reg_status');

        $check_access = $this->auth_model->get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status);

        $register_code = $check_access[0]->register_code;

        $where = array('register_code'=>$register_code);
        $navigation['lender_fund'] = $this->bank_model->get_fund_lender($register_code);
        $navigation['bio_fullname'] = $this->crud_model->get_data('tb_fintech_lender_bio',$where)->result();
        $navigation['account_active'] = "active";

        $data['get_code'] = $register_code;
        $data['data_code'] = $this->personal_info_model->get_personal_info_lender($register_code);
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');

        $data['total_reserved'] = $this->account_model->get_total_reserved_sum($register_code);
        $data['total_invest'] = $this->account_model->get_total_invest_sum($register_code);
        $data['total_funding'] = $this->account_model->get_total_funding_sum($register_code);

        $data['data_loan'] = $this->account_model->get_data_loan($register_code);
        $data['data_term'] = $this->account_model->get_term_by_id_nreg_lender($register_code);
        $data['data_contacts'] = $this->contact_model->get_contact();
        $data['data_direk'] = $this->management_model->get_managementmenu_direk();
        $data['check_data'] = $this->crud_model->get_data("tb_fintech_register",$where)->result();
        $data['data_bio'] = $this->personal_info_model->get_personal_info_lender($register_code);
        
        $footer['data_contact'] = $this->contact_model->get_contact();

        $this->load->view('frontend-fintech/partial/header');
        // $this->load->view('frontend-fintech/partial/navigation1' , $navigation);
        $this->load->view('frontend-fintech/lender/term_lender' , $data);
        // $this->load->view('frontend-fintech/partial/footer' , $footer);
        // $this->load->view('frontend-fintech/partial/sidebar');
    }

}
?>

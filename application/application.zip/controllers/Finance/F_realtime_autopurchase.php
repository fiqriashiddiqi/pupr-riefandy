<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_realtime_autopurchase extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('Front_Fintech/auto_model');
        $this->load->model('Front_Fintech/payment_model');
        $this->load->model('Front_Fintech/loan_model');
        $this->load->model('Front_Fintech/personal_info_model');
        $this->load->model('Front_Fintech/bank_model');
        $this->load->model('Website/users_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('Front_Fintech/manually_model');
        $this->load->model('crud_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('Front_Fintech/report_model');

        date_default_timezone_set("Asia/Jakarta");

    }

    public function index()
    {

        $date_now = date("Y-m-d");

        $data_auto_purchase = $this->auto_model->get_auto_purchase();

        //while (1) {
                # code...

            foreach ($data_auto_purchase as $auto_entry) {
                
                $lender_code = $auto_entry->register_code;
                $id_lender_automation = $auto_entry->id_lender_automation;
                $automation_amount = $auto_entry->automation_amount;
                $automation_loan_term = json_decode($auto_entry->automation_loan_term , true);
                $automation_rating = json_decode($auto_entry->automation_rating , true);
                $automation_type_loan = json_decode($auto_entry->automation_type_loan , true);

                $data_lender_fund = $this->payment_model->get_realtime_lender_fund($lender_code);
                $avaible_fund_lender = $data_lender_fund[0]->amount;

                $data['data_total'] = $this->report_model->get_total_amount($lender_code);

                if ($avaible_fund_lender >= $automation_amount){
                    foreach ($automation_type_loan as $value_type) {

                        if ($value_type == "Personal_Loan"){$loan_type = "Personal Loan";}
                        else if ($value_type == "Fixed_Loan"){$loan_type = "Fixed Loan";}
                        else if ($value_type == "Flexible_Loan"){$loan_type = "Flexible Loan";}
                        else {$loan_type = "";}

                        if($loan_type != ""){ 

                            foreach ($automation_rating as $value_rating) {


                                if ($value_rating == "APlus"){$loan_rating = "A+";}
                                else if ($value_rating == "BPlus"){$loan_rating = "B+";}
                                else if ($value_rating == "CPlus"){$loan_rating = "C+";}
                                else if ($value_rating == "DPlus"){$loan_rating = "D+";}
                                else {$loan_rating = $value_rating;}

                                foreach ($automation_loan_term as $value_term) {

                                    @$data_loan_auto = $this->manually_model->get_autopurchase_set($loan_type,$automation_amount,$value_term,$loan_rating)->result();
                                    @$check_manually = $this->manually_model->check_manually_invest(@$data_loan_auto[0]->id_borrower_loan,$lender_code)->result();

                                    if (@$check_manually[0]->id_borrower_loan != @$data_loan_auto[0]->id_borrower_loan){
                                        
                                        $auto_amount_left = @$data_loan_auto[0]->amount_left - $automation_amount;

                                        if ($auto_amount_left >= 0){
                                            //echo " PINJAMAN DENGAN ATRIBUT &nbsp; ".$lender_code." &nbsp; ".$avaible_fund_lender."  = &nbsp;&nbsp;  LOAN TYPE = ".$loan_type.". RATING = ".$loan_rating.". PERIODE = ".$value_term.". Amount = ".$automation_amount.".<BR><BR>";

                                            $idMax = $this->loan_model->invest_code();
                                            $noUrut =(int) substr($idMax[0]->maxID,3,9);
                                            $noUrut ++;
                                            $newID="INV".sprintf("%08s",$noUrut);
                                            $date = date('Y-m-d H:i:s');

                                            $id_borrower_loan = @$data_loan_auto[0]->id_borrower_loan;
                                            $amount_invest = $automation_amount;

                                            $lender_fund = $this->bank_model->get_fund_lender($lender_code);
                                            $fund_amount = $lender_fund[0]->amount - $amount_invest;

                                            $data_loan = $this->loan_model->get_loan_by_id($id_borrower_loan);

                                            $borrower_fund = $this->bank_model->get_fund_borrower($data_loan[0]->register_code);

                                            $completion = $data_loan[0]->completion;
                                            $loan_amount = $data_loan[0]->loan_amount;
                                            $amount_left = $data_loan[0]->amount_left;
                                            $loan_status = $data_loan[0]->completion;
                                            $loan_payment = $data_loan[0]->completion;

                                            // if($amount_invest > 0){
                                            //     if($loan_amount >= '1000000' AND $loan_amount < '10000000'){
                                            //         // var_dump('10 sampe 1 jt');
                                            //         if(($amount_invest%100000)==0) {
                                            //             //codingan

                                                        
                                            //         } 
                                            //     } else if ($loan_amount >= '10000000'){
                                            //         // var_dump('10 jt ke atas');
                                            //         if(($amount_invest%1000000)==0) {
                                            //             //codingan

                                                        
                                            //         }
                                            //     }
                                            // } 


                                            $borrower_reg_code = $data_loan[0]->register_code;

                                            $total_left = $amount_left - $amount_invest;
                                            
                                            if ($total_left > 0){
                                                $total_amount = $loan_amount - $total_left; 
                                                $total_completion = $completion + (($total_amount / $loan_amount) * 100);
                                            } else {
                                                $total_completion = 100;
                                            }

                                            if ($total_left == 0){
                                                // update loan 
                                                $data_loan_update = array( 
                                                        'loan_payment' => "Fully Paid", 
                                                        'loan_status' => "Disbursed", 
                                                        'amount_left' => $total_left, 
                                                        'completion' => $total_completion, 
                                                        'loan_start_date' => date("Y-m-d"),
                                                );

                                                $update_loan = $this->crud_model->update('tb_fintech_borrower_loan','id_borrower_loan',$id_borrower_loan, $data_loan_update);

                                                // proses pindah dana lender to borrower jika sudah terpenuhi
                                                $data_commision_rate = $this->crud_model->get_setting();
                                                $commision_lender = $loan_amount * ($data_commision_rate[0]->commision_lender/100);
                                                $insurance_lender = $loan_amount * ($data_commision_rate[0]->insurance_rate/100);

                                                $data_setting = $this->crud_model->get_setting();
                                                $fee_pg = $data_setting[0]->fee_pg;

                                                $GL_fund = $loan_amount - $commision_lender - $insurance_lender;
                                                $fund_borrower_amount = $borrower_fund[0]->amount + ($loan_amount - $commision_lender - $insurance_lender);

                                                $where = array('register_code' => $borrower_reg_code) ;
                                                $check_fund = $this->crud_model->get_data("tb_fintech_borrower_fund", $where)->num_rows();

                                                if($check_fund == 0){
                                                    $data_borrower_fund = array(
                                                    'register_code' => $borrower_reg_code,
                                                    'amount' => $fund_borrower_amount,
                                                    );

                                                    $insert_fund = $this->crud_model->insert('tb_fintech_borrower_fund',$data_borrower_fund);
                                                } else {
                                                    $data_borrower_fund = array(
                                                    'amount' => $fund_borrower_amount,
                                                    );

                                                    $update_fund = $this->crud_model->update('tb_fintech_borrower_fund','register_code',$borrower_reg_code,$data_borrower_fund);
                                                }

                                                $periode = $data_loan[0]->loan_tenor;
                                                $principal = $data_loan[0]->loan_principal;
                                                $interest = $data_loan[0]->loan_interest;

                                                for($i=0;$periode>$i;$i++){

                                                $month = $i + 1;
                                                $date = date("Y-m-d");    
                                                $time = strtotime($date);
                                                $final = date("Y-m-d", strtotime("+".$month." month", $time));

                                                $data_payment_periode = array(
                                                    'id_borrower_loan' => $id_borrower_loan,
                                                    'payment_periode_date' => $final,
                                                    'payment_periode_principal' => $principal,
                                                    'payment_periode_interest' => $interest,
                                                    'payment_periode_pinalty' => 0,
                                                    'payment_periode_status_principal' => 'default',
                                                    'payment_periode_status_interest' => 'default',
                                                    'payment_periode_status_pinalty' => 'default',
                                                );

                                                $insert_payment = $this->crud_model->insert('tb_fintech_borrower_payment_periode', $data_payment_periode);
                                                }

                                                 // GL OTOMATIS
                                            // Kode Jurnal
                                            $idMaxgl = $this->journal_model->journal_code();
                                            $noUrutgl = (int) substr($idMaxgl[0]->maxID,0,4);
                                            $noUrutgl ++;
                                            $date_codegl = date('m/y');
                                            $newIDgl = sprintf("%04s",$noUrutgl).'/'.$date_codegl;

                                            $data_setting = $this->crud_model->get_setting();
                                            $fee_pg = $data_setting[0]->fee_pg;

                                            // personal loan debit
                                            $data_journal1 = array(
                                                        'journal_no' => $newIDgl,
                                                        'id_param_coa_e' => 6,
                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                        'journal_description' => 'Disbursement Pinjaman - Auto Invest'.'-'.$id_borrower_loan,
                                                        // 'journal_description_form' => 'Pinjaman - '.$id_borrower_loan,
                                                        'journal_debit' => $loan_amount,
                                                        'journal_kredit' => 0,
                                                        'cashflow_code_status' => '0',
                                                        'journal_status' => '0' 
                                                        );

                                            $insert_journal1 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal1);

                                            // komisi credit
                                            $data_journal2 = array(
                                                        'journal_no' => $newIDgl,
                                                        'id_param_coa_e' => 63,
                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                        'journal_description' => 'Disbursement Pinjaman - Auto Invest'.'-'.$id_borrower_loan,
                                                        // 'journal_description_form' => 'Komisi Dari Peminjam - '.$id_borrower_loan,
                                                        'journal_debit' => 0,
                                                        'journal_kredit' => $commision_lender,
                                                        'cashflow_code_status' => '0',
                                                        'journal_status' => '0'

                                                        );

                                            $insert_journal2 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal2);

                                            //Asuransi kredit
                                            $data_journal3 = array(
                                                        'journal_no' => $newIDgl,
                                                        'id_param_coa_e' => 132,
                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                        'journal_description' => 'Disbursement Pinjaman - Auto Invest'.'-'.$id_borrower_loan,
                                                        // 'journal_description_form' => 'Insurance Premium - '.$id_borrower_loan,
                                                        'journal_debit' => 0,
                                                        'journal_kredit' => $insurance_lender,
                                                        'cashflow_code_status' => '0',
                                                        'journal_status' => '0'

                                                        );

                                            $insert_journal3 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal3);

                                            //loan to be disbursed kredit
                                            $data_journal4 = array(
                                                        'journal_no' => $newIDgl,
                                                        'id_param_coa_e' => 130,
                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                        'journal_description' => 'Disbursement Pinjaman - Auto Invest'.'-'.$id_borrower_loan,
                                                        // 'journal_description_form' => 'Loan Disbursed - '.$id_borrower_loan,
                                                        'journal_debit' => 0,
                                                        'journal_kredit' => $GL_fund,
                                                        'cashflow_code_status' => '0',
                                                        'journal_status' => '0'

                                                        );

                                            $insert_journal4 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal4);


                                            // Kode Jurnal 2
                                            $idMaxgl2 = $this->journal_model->journal_code();
                                            $noUrutgl2 = (int) substr($idMaxgl2[0]->maxID,0,4);
                                            $noUrutgl2 ++;
                                            $date_codegl2 = date('m/y');
                                            $newIDgl2 = sprintf("%04s",$noUrutgl2).'/'.$date_codegl2;

                                            // Commision debit
                                            $data_journal5 = array(
                                                        'journal_no' => $newIDgl2,
                                                        'id_param_coa_e' => 2,
                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                        'journal_description' => 'Pemindahan Uang Komisi dari Peminjam - Auto Invest'.'-'.$id_borrower_loan,
                                                        // 'journal_description_form' => 'Komisi Dari Peminjam - '.$id_borrower_loan,
                                                        'journal_debit' => $commision_lender,
                                                        'journal_kredit' => 0,
                                                        'cashflow_code_status' => 'OTD',
                                                        'journal_status' => '0'
                                                        );

                                            $insert_journal5 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal5);

                                            // Commision credit
                                            $data_journal6 = array(
                                                        'journal_no' => $newIDgl2,
                                                        'id_param_coa_e' => 128,
                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                        'journal_description' => 'Pemindahan Uang Komisi dari Peminjam - Auto Invest'.'-'.$id_borrower_loan,
                                                        // 'journal_description_form' => 'Komisi Dari Peminjam - '.$id_borrower_loan,
                                                        'journal_debit' => 0,
                                                        'journal_kredit' => $commision_lender,
                                                        'cashflow_code_status' => 'OTC',
                                                        'journal_status' => '0'
                                                        );

                                            $insert_journal6 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal6);

                                            // Kode Jurnal 3
                                            $idMaxgl3 = $this->journal_model->journal_code();
                                            $noUrutgl3 = (int) substr($idMaxgl3[0]->maxID,0,4);
                                            $noUrutgl3 ++;
                                            $date_codegl3 = date('m/y');
                                            $newIDgl3 = sprintf("%04s",$noUrutgl3).'/'.$date_codegl3;

                                            $dana_A_PG = $insurance_lender;

                                            // Asuransi dan PG debit
                                            $data_journal7 = array(
                                                        'journal_no' => $newIDgl3,
                                                        'id_param_coa_e' => 2,
                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                        'journal_description' => 'Pemindahan Dana Premi Asuransi - Auto Invest'.'-'.$id_borrower_loan,
                                                        // 'journal_description_form' => 'Asuransi - '.$id_borrower_loan,
                                                        'journal_debit' => $dana_A_PG,
                                                        'journal_kredit' => 0,
                                                        'cashflow_code_status' => 'IP',
                                                        'journal_status' => '0'
                                                        );

                                            $insert_journal7 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal7);

                                            // Asuransi dan PG credit
                                            $data_journal8 = array(
                                                        'journal_no' => $newIDgl3,
                                                        'id_param_coa_e' => 128,
                                                        'journal_entry' => date('Y-m-d H:i:s'),
                                                        'journal_date' => date('Y-m-d H:i:s'),
                                                        'journal_description' => 'Pemindahan Dana Premi Asuransi - Auto Invest'.'-'.$id_borrower_loan,
                                                        // 'journal_description_form' => 'Asuransi - '.$id_borrower_loan,
                                                        'journal_debit' => 0,
                                                        'journal_kredit' => $dana_A_PG,
                                                        'cashflow_code_status' => 'INS',
                                                        'journal_status' => '0'
                                                        );

                                            $insert_journal8 = $this->crud_model->insert('tb_general_ledger_journal',$data_journal8);


                                            } else {
                                                // update loan 
                                                $data_loan_update = array( 
                                                        'loan_payment' => "Not Yet Paid", 
                                                        'loan_status' => "On Proses", 
                                                        'amount_left' => $total_left,
                                                        'completion' => $total_completion, 
                                                );

                                                $update_loan = $this->crud_model->update('tb_fintech_borrower_loan','id_borrower_loan',$id_borrower_loan, $data_loan_update);       
                                            }

                                            // update lender fund
                                            $data_fund = array(
                                                    'amount' => $fund_amount,
                                                    );

                                            $update_fund = $this->crud_model->update('tb_fintech_lender_fund','register_code',$lender_code,$data_fund);

                                            // investasi tb
                                            $data_invest = array(
                                                'investment_code' => $newID,
                                                'register_code' => $lender_code,
                                                'investmen_date' => date('Y-m-d'),
                                                'id_borrower_loan' => $id_borrower_loan,
                                                'borrower_reg_code' => $borrower_reg_code,
                                                'amount_invest' => $amount_invest,
                                            );

                                            $insert_invest = $this->crud_model->insert('tb_fintech_lender_investment', $data_invest);
                                            
                                            $beginning = 0;
                                            $beginning = (int)@$data['data_total'][0]->total_amount;

                                            $ending = (int)$beginning - (int)$amount_invest  + (int)@$data['data_loan'][0]->payment_pokok - (int)@$data['data_loan'][0]->payment_tax + (int)@$data['data_loan'][0]->payment_interest;
                                            

                                            $data_cashflow = array(
                                                    'register_code' => $lender_code,
                                                    'cashflow_date' => date('Y-m-d H:i:s'),
                                                    'beginning_amount' => $beginning,
                                                    'withdrawal_amount' => 0,
                                                    'deposit_amount' => 0,
                                                    'invest_amount' => $amount_invest,
                                                    'payment_pokok' => 0,
                                                    'payment_tax' => 0,
                                                    'payment_interest' =>0,
                                                    'total_amount' => $ending,
                                                    'cashflow_status' => "Investment"
                                            );
                                            $insert_deposit_cashflow = $this->crud_model->insert('tb_fintech_lender_cashflow',$data_cashflow);

                                            // email
                                            $email_manager = $this->users_model->get_user_email();
                                            // $email_manager = array_merge($email_manager);
                                            $email_borrower = $this->personal_info_model->get_email_borrower($borrower_reg_code);

                                            $emails = array_map(function($value){
                                                return $value->users_email;
                                            }, $email_manager);

                                            $emails_bor = array_map(function($value){
                                                return $value->register_email;
                                            }, $email_borrower);

                                            $email_crowdfunding = array_merge($emails,$emails_bor);
                                            
                                            foreach ($email_crowdfunding as $email_entry) {
                                            $config = array();
                                            $config['charset'] = 'iso-8859-1';
                                            $config['useragent'] = 'Codeigniter';
                                            $config['protocol']= 'smtp';
                                            $config['mailtype']= 'html';
                                            $config['smtp_host']= 'ssl://mail.heatcliffs31.com';//pengaturan smtp
                                            $config['smtp_port']= 465;
                                            $config['smtp_timeout']= 400;
                                            $config['smtp_user']= 'sanders@heatcliffs31.com'; // isi dengan email kamu
                                            $config['smtp_pass']= '1q2w3e4r5t'; // isi dengan password kamu
                                            $config['crlf']="\r\n"; 
                                            $config['newline']="\r\n"; 
                                            $config['wordwrap'] = TRUE;
                                                    //memanggil library email dan set konfigurasi untuk pengiriman email
                                            $this->load->library('email',$config);
                                            $this->email->initialize($config);
                                            // $where_check = array('register_activation_code' => $random);

                                                    //konfigurasi pengiriman
                                            $this->email->from($config['smtp_user']);
                                            $this->email->to($email_entry);
                                            $this->email->subject("Notification Fulfilled");
                                            $body = $this->load->view('frontend-fintech/email_invest.php','',TRUE);
                                            $this->email->message($body);
                                            $this->email->send();
                                        }

                                            // $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                                            // redirect(base_url().'Finance/F_register/check_activation');
                                            // die();

                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    $data_auto = array(
                        'automation_status' => "Deactivated",
                    );

                    $update_auto = $this->crud_model->update('tb_fintech_lender_automation','id_lender_automation',$id_lender_automation,$data_auto);
                }
            }

            echo" DONE <BR><BR><BR><BR>";
        //}

    }

}

?>

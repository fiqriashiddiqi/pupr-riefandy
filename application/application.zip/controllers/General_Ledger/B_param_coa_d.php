<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_param_coa_d extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '5');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['title'] = "Chart Of Account";
		$data['brd_title_main'] = "Chart Of Account";
		$data['brd_title_url'] = site_url('General_Ledger/B_param_coa_d');

		$data['create_url'] = site_url('General_Ledger/B_param_coa_d/create_coa_d');
		$data['delete_url'] = site_url('General_Ledger/B_param_coa_d/delete_coa_d');
		$data['info_url'] = site_url('General_Ledger/B_param_coa_d/update_coa_d');
		$data['update_url'] = site_url('General_Ledger/B_param_coa_d/update_coa_d');
		
		// $data['data_coa_d'] = $this->param_model->get_coa_d();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/parameter/coa/coa-d-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function create_coa_d()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Chart Of Account";
		$data['brd_title_main'] = "Chart Of Account";
		$data['brd_title_url'] = site_url('General_Ledger/B_param_coa_d');
		$data['brd_title_sub'] = "Add Chart Of Account";
		$data['brd_title_url_sub'] = site_url('General_Ledger/B_param_coa_d/create_coa_d');
		$data['back_url'] = site_url('General_Ledger/B_param_coa_d');

		$data['form_url'] = site_url('General_Ledger/B_param_coa_d/create_coa_d');

		$data['data_dropdown_c'] = $this->param_model->get_dropdown_coa_c();

		$this->form_validation->set_rules("id_param_coa_c", "Kode Coa", "trim|required");
		$this->form_validation->set_rules("coa_code_d", "code Coa", "trim|required");
		$this->form_validation->set_rules("coa_name_d", "Nama Coa", "trim|required");
	
		if ($this->form_validation->run() == true){
			$id_param_coa_c = $this->input->post('id_param_coa_c');
			$coa_code_d = $this->input->post('coa_code_d');
			$coa_name_d = $this->input->post('coa_name_d');

						$data_coa_d = array(
						'id_param_coa_c' => $id_param_coa_c,
						'coa_code_d' => $coa_code_d,
						'coa_name_d' => $coa_name_d
						);

						$insert_coa = $this->crud_model->insert('tb_param_coa_d',$data_coa_d);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'General_Ledger/B_param_coa_d/create_coa_d');
						die();
		
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/parameter/coa/coa-d-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function update_coa_d()
	{

		$id_param_coa_c = $this->uri->segment(4);
		$id_param_coa_d = $this->uri->segment(5);

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Update Chart Of Account";
		$data['brd_title_main'] = "Chart Of Account";
		$data['brd_title_url'] = site_url('General_Ledger/B_param_coa_d');
		$data['brd_title_sub'] = "Update Chart Of Account";
		$data['brd_title_url_sub'] = site_url('General_Ledger/B_param_coa_d/update_coa_d')."/".$id_param_coa_c."/".$id_param_coa_d;

		$data['form_url'] = site_url('General_Ledger/B_param_coa_d/update_coa_d');
		$data['back_url'] = site_url('General_Ledger/B_param_coa_d');


		$data['default_dropdown_coa_c'] = $this->param_model->get_dropdown_coa_c($id_param_coa_c);
		$data['dropdown_coa_c'] = $this->param_model->get_dropdown_coa_c();
		$data['data_coa_d'] = $this->param_model->get_coa_d($id_param_coa_d);


		$this->form_validation->set_rules("id_param_coa_c", "id COA", "trim|required");
		$this->form_validation->set_rules("id_param_coa_d", "id COA", "trim|required");
		$this->form_validation->set_rules("coa_code_d", "Code coa", "trim|required");
		$this->form_validation->set_rules("coa_name_d", "Nama coa", "trim|required");

	
		if ($this->form_validation->run() == true){
			$id_param_coa_c = $this->input->post('id_param_coa_c');
			$id_param_coa_d = $this->input->post('id_param_coa_d');
			$coa_code_d = $this->input->post('coa_code_d');
			$coa_name_d = $this->input->post('coa_name_d');
			
						$data_coa_d = array(
						'id_param_coa_c' => $id_param_coa_c,
						'id_param_coa_d' => $id_param_coa_d,
						'coa_code_d' => $coa_code_d,
						'coa_name_d' => $coa_name_d
						);

						$update_coa = $this->crud_model->update('tb_param_coa_d','id_param_coa_d',$id_param_coa_d,$data_coa_d);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'General_Ledger/B_param_coa_d/update_coa_d/'.$id_param_coa_c."/".$id_param_coa_d);
						die();

		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/parameter/coa/coa-d-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function delete_coa_d()
	{
		$id_param_coa_d = $this->uri->segment(4);
		$where =array('id_param_coa_d'=>$id_param_coa_d);

        $data_check = $this->param_model->get_data("tb_param_coa_e",$where)->num_rows();
		
		// if (!empty($id_param_coa_d)){

                if($data_check == 0){

					$this->crud_model->delete('tb_param_coa_d','id_param_coa_d',$id_param_coa_d);
					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'General_Ledger/B_param_coa_d');
					die();

                } else {

                    $this->session->set_flashdata('alert_error', 'Data failed to Delete, Becouse this data has been store for other data!');
                    redirect(base_url().'General_Ledger/B_param_coa_d');
                    die();
                }


		// } else {
		// 	$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
		// 	redirect(base_url().'General_Ledger/B_param_coa_d');
		// 	die();
		// }
	}

}

?>
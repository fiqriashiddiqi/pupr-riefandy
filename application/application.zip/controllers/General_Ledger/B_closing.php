<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_closing extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '5');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['title'] = "Closing";
		$data['brd_title_main'] = "Closing";
		$data['brd_title_url'] = site_url('General_Ledger/B_closing');

        $data['open_url'] = site_url('General_Ledger/B_closing/priview_journal_open');
        $data['close_url'] = site_url('General_Ledger/B_closing/priview_journal_close');

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/closing/closing-list', $data);
		$this->load->view('backend-web/partial/footer');

	}
    public function priview_journal_close()
    {
        $YEARS = $this->uri->segment(4);
        $MONTH = $this->uri->segment(5);

        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();
        $data['users_last_signin'] = $check_access[0]->users_last_signin;

        $data['title'] = "Priview Journal";
        $data['brd_title_main'] = "Closing";
        $data['brd_title_url'] = site_url('General_Ledger/B_closing');
        $data['brd_title_sub'] = "Priview Journal";
        $data['brd_title_url_sub'] = site_url("General_Ledger/B_closing/priview_journal_close/$YEARS/$MONTH");

        $data['close_url'] = site_url("General_Ledger/B_closing/closing_periode/$YEARS/$MONTH");
        $data['back_url'] = site_url('General_Ledger/B_closing');

        $data['info_url'] = site_url('General_Ledger//B_journal/update_journal');
        $data['info_url_temp'] = site_url('General_Ledger/B_journal_temp/update_journal_temp');

        $data['data_journal_closed'] = $this->journal_model->get_journal_group(null,null,$YEARS,$MONTH);
        $data['data_journal_closed_temp'] = $this->journal_model->get_journal_group_temp(null,null,$YEARS,$MONTH);

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-gl/closing/closing-form-close', $data);
        $this->load->view('backend-web/partial/footer');
    }

    public function priview_journal_open()
    {   

        $YEARS = $this->uri->segment(4);
        $MONTH = $this->uri->segment(5);

        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();
        $data['users_last_signin'] = $check_access[0]->users_last_signin;

        $data['title'] = "Priview Journal";
        $data['brd_title_main'] = "Closing";
        $data['brd_title_url'] = site_url('General_Ledger/B_closing');
        $data['brd_title_sub'] = "Priview Journal";
        $data['brd_title_url_sub'] = site_url("General_Ledger/B_closing/priview_journal_open/$YEARS/$MONTH");

        $data['open_url'] = site_url("General_Ledger/B_closing/open_periode/$YEARS/$MONTH");
        $data['back_url'] = site_url('General_Ledger/B_closing');

        $data['info_url'] = site_url('General_Ledger//B_journal/update_journal');
        //$data['info_url_temp'] = site_url('General_Ledger/B_journal_temp/update_journal_temp');

        $data['data_journal'] = $this->journal_model->get_journal_group(null,null,$YEARS,$MONTH);
        $data['data_journal_temp'] = $this->journal_model->get_journal_group_temp(null,null,$YEARS,$MONTH);

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-gl/closing/closing-form-open', $data);
        $this->load->view('backend-web/partial/footer');
    }

    public function closing_periode()
    {

        $YEARS = $this->uri->segment(4);
        $MONTHS = $this->uri->segment(5);

        $data_check_temp = $this->journal_model->get_journal_temp_closing($YEARS,$MONTHS)->num_rows();


        if($data_check_temp > 0){
            $this->session->set_flashdata('alert_error', 'TERDAPAT JURNAL YANG MASIH BELUM DI POSTING, TIDAK BISA CLOSING.');
            redirect(base_url().'General_Ledger/B_closing');
            die();
        } else {

            $data_check = $this->journal_model->get_journal_closing($YEARS,$MONTHS)->num_rows();

            if($data_check > 0){

                $data_check_before = $this->journal_model->get_journal_closing_before($YEARS,$MONTHS)->num_rows();


                if($data_check_before > 0){
                    $this->session->set_flashdata('alert_error', 'TERDAPAT PERIODE DI BULAN SEBELUMNYA YANG BELUM DI CLOSING.');
                    redirect(base_url().'General_Ledger/B_closing');
                    die();
                    

                } else {

                    $data_check_before_temp = $this->journal_model->get_journal_closing_before_temp($YEARS,$MONTHS)->num_rows();

                    if($data_check_before_temp == 0){

                        $update_journal = $this->journal_model->update_status_gl($MONTHS,$YEARS);

                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'General_Ledger/B_closing');
                        die();
                    } else {
                        $this->session->set_flashdata('alert_error', 'TERDAPAT JURNAL TEMPORARY DI PERIODE BULAN SEBELUMNYA YANG BELUM DI POSTING DAN CLOSING.');
                        redirect(base_url().'General_Ledger/B_closing');
                        die();
                    }

                }

            } else {
                $this->session->set_flashdata('alert_error', 'TIDAK TERDAPAT JURNAL DI PERIODE INI.');
                redirect(base_url().'General_Ledger/B_closing');
                die();

            }
        }       
    }

    public function open_periode()
    {

        $YEARS = $this->uri->segment(4);
        $MONTHS = $this->uri->segment(5);

        $update_journal = $this->journal_model->update_status_gl_open($MONTHS,$YEARS);

        $this->session->set_flashdata('alert_success', 'Data successfully Opened.');
        redirect(base_url().'General_Ledger/B_closing');
        die();
    }
}
?>
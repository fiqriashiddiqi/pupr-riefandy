<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_journal_temp extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '5');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['title'] = "Journal Temporary";
		$data['brd_title_main'] = "Journal Temporary";
		$data['brd_title_url'] = site_url('General_Ledger/B_journal_temp');

		$data['create_url'] = site_url('General_Ledger/B_journal_temp/create_journal_temp');
		$data['info_url'] = site_url('General_Ledger/B_journal_temp/update_journal_temp');

		$data['get_coa_a'] = $this->param_model->get_coa_a();
		$data['dropdown_coa_e'] = $this->param_model->get_dropdown_coa_e();
		$data['excel_url'] = site_url('Report/B_report/excel_journal_temp');
		// $data['data_journal'] = $this->journal_model->get_journal_temp_group();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/journal_temp/journal-temp-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	// public function create_journal_temp()
	// {
		
	// 	$users_username = $this->session->userdata('users_username');
	// 	$users_password = $this->session->userdata('users_password');

	// 	$check_access = $this->auth_model->get_access($users_username, $users_password);
 // 		$access_groups = $check_access[0]->id_backend_groups;
		
	// 	$header['users_name'] = $check_access[0]->users_name;
	// 	$header['groups_name'] = $check_access[0]->groups_name;
	// 	$navigation['users_name'] = $check_access[0]->users_name;
	// 	$navigation['groups_name'] = $check_access[0]->groups_name;
	// 	$navigation['access_groups'] = $access_groups;
	// 	$navigation['menus'] = $this->groups_model->groups_rules();

	// 	$navigation['users_active'] = 'active';

	// 	$data['title'] = "Add Journal";
	// 	$data['brd_title_main'] = "Journal";
	// 	$data['brd_title_url'] = site_url('General_Ledger/B_journal');
	// 	$data['brd_title_sub'] = "Add Journal";
	// 	$data['brd_title_url_sub'] = site_url('General_Ledger/B_journal/create_journal');
	// 	$data['back_url'] = site_url('General_Ledger/B_journal');

	// 	$data['form_url'] = site_url('General_Ledger/B_journal/create_journal');
	// 	$data['data_journal'] = $this->journal_model->get_journal();
	// 	//$data['dropdown_coa_e'] = $this->param_model->get_dropdown_coa_e();


	// 	$this->form_validation->set_rules("id_param_coa_e", "Id Coa e", "trim|required");
	// 	$this->form_validation->set_rules("journal_description", "Description", "trim|required");
	// 	$this->form_validation->set_rules("journal_debit", "debit", "trim");
	// 	$this->form_validation->set_rules("journal_kredit", "kredit", "trim");
	
	// 	if ($this->form_validation->run() == true){
	// 		$id_param_coa_e = $this->input->post('id_param_coa_e');
	// 		$journal_no = $this->input->post('journal_no');
	// 		$journal_description = $this->input->post('journal_description');
	// 		$journal_debit = $this->input->post('journal_debit');
	// 		$journal_kredit = $this->input->post('journal_kredit');
 //            $journal_date = $this->input->post('journal_date');
 //            $journal_entry = $this->input->post('journal_entry');

 //            // if($journal_status == "Credit"){
 //            //     $journal_debit = '0';
 //            //      $journal_kredit = '0';
 //            //     // $journal_kredit = $this->input->post('journal_kredit');
 //            // } else {
 //            // 	// $journal_debit = $this->input->post('journal_debit');
 //            //     $journal_debit = '0';
 //            //     $journal_kredit = '0';
 //            // }

	// 					$data_journal = array(
	// 					'id_param_coa_e' => $id_param_coa_e,
	// 					'journal_no' => $journal_no,
	// 					'journal_entry' => $journal_entry,
	// 					'journal_date' => $journal_date,
	// 					'journal_description' => $journal_description,
	// 					'journal_debit' => $journal_debit,
	// 					'journal_kredit' => $journal_kredit
	// 					);

	// 					$insert_journal = $this->crud_model->insert('tb_general_ledger_journal',$data_journal);
	// 					$this->session->set_flashdata('alert_success', 'Data successfully saved.');
	// 					redirect(base_url().'General_Ledger/B_journal/create_journal');
	// 					die();
		
	// 	}

	// 	$this->load->view('backend-web/partial/metadata');
	// 	$this->load->view('backend-web/partial/header', $header);
	// 	$this->load->view('backend-web/partial/navigation', $navigation);
	// 	$this->load->view('backend-gl/journal/journal-form', $data);
	// 	$this->load->view('backend-web/partial/footer');

	// }

	public function update_journal_temp()
	{
		// $id_param_coa_e = $this->uri->segment(4);
		$id_temp_journal = $this->uri->segment(4);

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Detail Journal Temporary";
		$data['brd_title_main'] = "Journal";
		$data['brd_title_url'] = site_url('General_Ledger/B_journal_temp');
		$data['brd_title_sub'] = "Detail Journal Temporary";
		$data['brd_title_url_sub'] = site_url('General_Ledger/B_journal_temp/update_journal_temp')."/".$id_temp_journal;
		$data['delete_url'] = site_url('General_Ledger/B_journal_temp/delete_journal_temp');

		$data['form_url'] = site_url('General_Ledger/B_journal_temp/update_journal_temp');
		$data['back_url'] = site_url('General_Ledger/B_journal_temp');

		//$data['default_dropdown_coa_e'] = $this->param_model->get_coa_e($id_param_coa_e);
		//$data['dropdown_coa_e'] = $this->param_model->get_coa_e();
		$journal = $this->journal_model->get_journal_temp_id_journal(@$id_temp_journal);
		$data['data_journal'] = $this->journal_model->get_journal_temp_detail(@$journal[0]->journal_no);

		$idMax = $this->journal_model->journal_code();
        $noUrut = (int) substr($idMax[0]->maxID,0,4);
        $noUrut ++;
        $date_code = date('m/y');
        $data['newID'] = sprintf("%04s",$noUrut).'/'.$date_code;

        $idMax2 = $this->journal_model->journal_temp_code();
        $noUrut2 = (int) substr($idMax2[0]->maxID,0,4);
        $noUrut2 ++;
        $date_code2 = date('m/y');
        $data['newID2'] = sprintf("%04s",$noUrut2).'/'.$date_code2."-TM";

		$this->form_validation->set_rules("journal_no", "Id ", "trim|required");
		$this->form_validation->set_rules("journal_description", "Description", "trim|required");

        if ($this->form_validation->run() == true){
        	$id_temp_journal = $this->input->post('id_temp_journal');
            $id_param_coa_e = $this->input->post('id_param_coa_e');
			$journal_no = $this->input->post('journal_no');
            $journal_entry = date('Y-m-d');
            $journal_date = $this->input->post('journal_date');
			$journal_debit = $this->input->post('journal_debit');
			$journal_kredit = $this->input->post('journal_kredit');
			$cashflow_code_status = $this->input->post('cashflow_code_status');
			$journal_description = $this->input->post('journal_description');
			// $journal_description_form = $this->input->post('journal_description_form');
			
			if($_POST['submit'] == 'Posting')
			{
				
				$this->crud_model->delete('tb_general_ledger_journal_temp','journal_no',$this->input->post('journal_del'));
		
                for($i=0;$i<count($this->input->post('id_param_coa_e'));$i++ ) {
            
            		$data_journal = array(
						'journal_no' => $this->input->post('journal_no'),
						'id_param_coa_e' => $this->input->post('id_param_coa_e')[$i],
						'journal_entry' => $journal_entry,
						'journal_date' => date('Y-m-d', strtotime($this->input->post('journal_date'))),
						'journal_description' => $this->input->post('journal_description'),
						// 'journal_description_form' => $this->input->post('journal_description_form')[$i],
						'journal_debit' => preg_replace('/\D/', '', $this->input->post('journal_debit')[$i]),
						'journal_kredit' => preg_replace('/\D/', '',  $this->input->post('journal_kredit')[$i]),
						'cashflow_code_status' => $this->input->post('cashflow_code_status')[$i]
						);

					$insert_journal = $this->crud_model->insert('tb_general_ledger_journal',$data_journal);
                }

                $this->session->set_flashdata('alert_success', 'Data successfully Update.');
				redirect(base_url().'General_Ledger/B_journal');
				die();


			}
			else if($_POST['submit'] == 'Temporary')
			{	

				$this->crud_model->delete('tb_general_ledger_journal_temp','journal_no',$this->input->post('journal_del'));
		
                for($i=0;$i<count($this->input->post('id_param_coa_e'));$i++ ) {
            
            		$data_journal = array(
						'journal_no' => $this->input->post('journal_no_temp'),
						'id_param_coa_e' => $this->input->post('id_param_coa_e')[$i],
						'journal_entry' => $journal_entry,
						'journal_date' => date('Y-m-d', strtotime($this->input->post('journal_date'))),
						'journal_description' => $this->input->post('journal_description'),
						// 'journal_description_form' => $this->input->post('journal_description_form')[$i],
						'journal_debit' => preg_replace('/\D/', '', $this->input->post('journal_debit')[$i]),
						'journal_kredit' => preg_replace('/\D/', '',  $this->input->post('journal_kredit')[$i]),
						'cashflow_code_status' => $this->input->post('cashflow_code_status')[$i]
						);

					$insert_journal = $this->crud_model->insert('tb_general_ledger_journal_temp',$data_journal);
                }

                $this->session->set_flashdata('alert_success', 'Data successfully Update.');
				redirect(base_url().'General_Ledger/B_journal_temp');
				die();

			}
				
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/journal_temp/journal-temp-form-update', $data);
		$this->load->view('backend-web/partial/footer');
		// echo "dada";

	}

	public function delete_journal_temp()
	{
		$id_param_coa_e = $this->uri->segment(4);
		$journal_no = $this->uri->segment(5);
		
		if (!empty($journal_no)){

                if($data_check == 1){

					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'General_Ledger/B_journal_temp');
					die();

                } else {

                    $this->session->set_flashdata('alert_error', 'Data failed to Delete, Because this data has been store for other data!');
                    redirect(base_url().'General_Ledger/B_journal_temp/update_journal_temp');
                    die();
                }


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'General_Ledger/B_journal_temp/update_journal_temp');
			die();
		}
	}

}
?>

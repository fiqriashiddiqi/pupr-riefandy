<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_param_coa_a extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '5');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['title'] = "Chart Of Account";
		$data['brd_title_main'] = "Chart Of Account";
		$data['brd_title_url'] = site_url('General_Ledger/B_param_coa_a');

		$data['create_url'] = site_url('General_Ledger/B_param_coa_a/create_coa_a');
		$data['delete_url'] = site_url('General_Ledger/B_param_coa_a/delete_coa_a');
		$data['info_url'] = site_url('General_Ledger/B_param_coa_a/update_coa_a');
		$data['update_url'] = site_url('General_Ledger/B_param_coa_a/update_coa_a');
		
		// $data['data_coa_a'] = $this->param_model->get_coa_a();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/parameter/coa/coa-a-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function create_coa_a()
	{
		
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Chart Of Account";
		$data['brd_title_main'] = "Chart Of Account";
		$data['brd_title_url'] = site_url('General_Ledger/B_param_coa_a');
		$data['brd_title_sub'] = "Add Chart Of Account";
		$data['brd_title_url_sub'] = site_url('General_Ledger/B_param_coa_a/create_coa_a');
		$data['back_url'] = site_url('General_Ledger/B_param_coa_a');

		$data['form_url'] = site_url('General_Ledger/B_param_coa_a/create_coa_a');
		$data['data_coa_a'] = $this->param_model->get_coa_a();

		$this->form_validation->set_rules("coa_code_a", "Kode Coa", "trim|required");
		$this->form_validation->set_rules("coa_name_a", "Nama Coa", "trim|required");
	
		if ($this->form_validation->run() == true){
			$coa_code_a = $this->input->post('coa_code_a');
			$coa_name_a = $this->input->post('coa_name_a');

						$data_coa_a = array(
						'coa_code_a' => $coa_code_a,
						'coa_code_a' => $coa_code_a,
						'coa_name_a' => $coa_name_a,
						);

						$insert_coa = $this->crud_model->insert('tb_param_coa_a',$data_coa_a);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'General_Ledger/B_param_coa_a/create_coa_a');
						die();
		
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/parameter/coa/coa-a-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function update_coa_a()
	{

		$id_param_coa_a = $this->uri->segment(4);
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Update Chart Of Account";
		$data['brd_title_main'] = "Chart Of Account";
		$data['brd_title_url'] = site_url('General_Ledger/B_param_coa_a');
		$data['brd_title_sub'] = "Update Chart Of Account";
		$data['brd_title_url_sub'] = site_url('General_Ledger/B_param_coa_a/update_coa_a')."/".$id_param_coa_a;

		$data['form_url'] = site_url('General_Ledger/B_param_coa_a/update_coa_a');
		$data['back_url'] = site_url('General_Ledger/B_param_coa_a');

		$data['data_coa_a'] = $this->param_model->get_coa_a($id_param_coa_a);

		$this->form_validation->set_rules("id_param_coa_a", "id COA", "trim|required");
		$this->form_validation->set_rules("coa_code_a", "Nama coa", "trim|required");
		$this->form_validation->set_rules("coa_name_a", "Nama coa", "trim|required");
	
		if ($this->form_validation->run() == true){

			$id_param_coa_a = $this->input->post('id_param_coa_a');
			$coa_code_a = $this->input->post('coa_code_a');
			$coa_name_a = $this->input->post('coa_name_a');
			
						$data_coa_a = array(

						'id_param_coa_a' => $id_param_coa_a,
						'coa_code_a' => $coa_code_a,
						'coa_name_a' => $coa_name_a,
						);

						$update_coa = $this->crud_model->update('tb_param_coa_a','id_param_coa_a',$id_param_coa_a,$data_coa_a);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'General_Ledger/B_param_coa_a/update_coa_a/'.$id_param_coa_a);
						die();

		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/parameter/coa/coa-a-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function delete_coa_a()
	{
		$id_param_coa_a = $this->uri->segment(4);

        $data_check = $this->param_model->get_data("tb_param_coa_b")->num_rows();
		
		if (!empty($id_param_coa_a)){

                if($data_check == 0){

					$this->crud_model->delete('tb_param_coa_a','id_param_coa_a',$id_param_coa_a);
					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'General_Ledger/B_param_coa_a');
					die();

                } else {

                    $this->session->set_flashdata('alert_error', 'Data failed to Delete, Becouse this data has been store for other data!');
                    redirect(base_url().'General_Ledger/B_param_coa_a');
                    die();
                }


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'General_Ledger/B_param_coa_a');
			die();
		}
	}

}

?>
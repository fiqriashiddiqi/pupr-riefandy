<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_journal extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('Parameter/param_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '5');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Journal";
		$data['brd_title_main'] = "Journal";
		$data['brd_title_url'] = site_url('General_Ledger/B_journal');

		$data['create_url'] = site_url('General_Ledger/B_journal/create_journal');
		$data['info_url'] = site_url('General_Ledger/B_journal/update_journal');
		$data['excel_url'] = site_url('Report/B_report/excel_journal');

		$data['get_coa_a'] = $this->param_model->get_coa_a();
		$data['dropdown_coa_e'] = $this->param_model->get_dropdown_coa_e();
		// $data['data_journal'] = $this->journal_model->get_journal_group(@$start_date,@$end_date);
		

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/journal/journal-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function create_journal()
	{
		
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Journal";
		$data['brd_title_main'] = "Journal";
		$data['brd_title_url'] = site_url('General_Ledger/B_journal');
		$data['brd_title_sub'] = "Add Journal";
		$data['brd_title_url_sub'] = site_url('General_Ledger/B_journal/create_journal');
		$data['back_url'] = site_url('General_Ledger/B_journal/create_journal_temp');

		$data['form_url'] = site_url('General_Ledger/B_journal/create_journal');
		$data['data_journal'] = $this->journal_model->get_journal();

        $idMax = $this->journal_model->journal_code();
        $noUrut = (int) substr($idMax[0]->maxID,0,4);
        $noUrut ++;
        $date_code = date('m/y');
        $data['newID'] = sprintf("%04s",$noUrut).'/'.$date_code;

        $idMax2 = $this->journal_model->journal_temp_code();
        $noUrut2 = (int) substr($idMax2[0]->maxID,0,4);
        $noUrut2 ++;
        $date_code2 = date('m/y');
        $newID2 = sprintf("%04s",$noUrut2).'/'.$date_code2."-TM";


		$this->form_validation->set_rules("journal_no", "Description", "trim|required");
        $this->form_validation->set_rules("journal_date", "Description", "trim|required");
        $this->form_validation->set_rules("journal_description", "Description", "trim|required");
	
	
		if ($this->form_validation->run() == true){
			$id_param_coa_e = $this->input->post('id_param_coa_e');
			$journal_no = $this->input->post('journal_no');
			$journal_description = $this->input->post('journal_description');
			$journal_description_form = $this->input->post('journal_description_form');
			$journal_debit = $this->input->post('journal_debit');
			$journal_kredit = $this->input->post('journal_kredit');
			$cashflow_code_status = $this->input->post('cashflow_code_status');
            $journal_date = $this->input->post('journal_date');
            $journal_entry = date("Y-m-d");


            if($_POST['submit'] == 'Posting'){
                if ($id_param_coa_e == 0) {
                	$this->session->set_flashdata('alert_error', 'Data is empty.');
          			redirect(base_url().'General_Ledger/B_journal/create_journal');
           			die();
                	}
                for($i=0;$i<count($this->input->post('id_param_coa_e'));$i++ ) {
            
            		$data_journal = array(
						'journal_no' => $this->input->post('journal_no'),
						'id_param_coa_e' => $this->input->post('id_param_coa_e')[$i],
						'journal_entry' => $journal_entry,
						'journal_date' => date('Y-m-d', strtotime($this->input->post('journal_date'))),
						'journal_description' => $this->input->post('journal_description'),
						// 'journal_description_form' => $this->input->post('journal_description_form')[$i],
						'journal_debit' => preg_replace('/\D/', '', $this->input->post('journal_debit')[$i]),
						'journal_kredit' => preg_replace('/\D/', '',  $this->input->post('journal_kredit')[$i]),
						'cashflow_code_status' => $this->input->post('cashflow_code_status')[$i]

						);

					$insert_journal = $this->crud_model->insert('tb_general_ledger_journal',$data_journal);
					$this->session->set_flashdata('alert_success', 'Data successfully saved.');
                
                }


			} else if($_POST['submit'] == 'Temporary') {
				if ($id_param_coa_e == 0) {
                		$this->session->set_flashdata('alert_error', 'Data is empty.');
          				redirect(base_url().'General_Ledger/B_journal/create_journal');
           				die();
                	}
			    
                	for($i=0;$i<count($this->input->post('id_param_coa_e'));$i++ ) {
            
            		$data_journal = array(
						'journal_no' => $newID2,
						'id_param_coa_e' => $this->input->post('id_param_coa_e')[$i],
						'journal_entry' => $journal_entry,
						'journal_date' => date('Y-m-d', strtotime($this->input->post('journal_date'))),
						'journal_description' => $this->input->post('journal_description'),
						'journal_debit' => preg_replace('/\D/', '', $this->input->post('journal_debit')[$i]),
						// 'journal_description_form' => $this->input->post('journal_description_form')[$i],
						'journal_kredit' => preg_replace('/\D/', '',  $this->input->post('journal_kredit')[$i]),
						'cashflow_code_status' => $this->input->post('cashflow_code_status')[$i]
						);

						$insert_journal = $this->crud_model->insert('tb_general_ledger_journal_temp',$data_journal);			
                
                }
			}
		    $this->session->set_flashdata('alert_success', 'Data successfully saved.');
            redirect(base_url().'General_Ledger/B_journal/create_journal');
            die();
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/journal/journal-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function update_journal()
	{

		$id_journal = $this->uri->segment(4);

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Detail Journal";
		$data['brd_title_main'] = "Journal";
		$data['brd_title_url'] = site_url('General_Ledger/B_journal');
		$data['brd_title_sub'] = "Detail Journal";
		$data['brd_title_url_sub'] = site_url('General_Ledger/B_journal/update_journal')."/".$id_journal;
		$data['back_url'] = site_url('General_Ledger/B_journal');

        $journal = $this->journal_model->get_journal_id_journal($id_journal);

		$data['data_journal'] = $this->journal_model->get_journal_detail($journal[0]->journal_no);

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-gl/journal/journal-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function delete_journal()
	{
		$id_journal = $this->uri->segment(4);
		
		if (!empty($id_journal)){

                if($data_check == 0){

					$this->crud_model->delete('tb_general_ledger_journal','id_journal',$id_journal);
					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'General_Ledger/B_journal');
					die();

                } else {

                    $this->session->set_flashdata('alert_error', 'Data failed to Delete, Becouse this data has been store for other data!');
                    redirect(base_url().'General_Ledger/B_journal');
                    die();
                }


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'General_Ledger/B_journal');
			die();
		}
	}

}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_history_invest extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('Front_Fintech/personal_info_model');
    	$this->load->model('Front_Fintech/account_model');
    	$this->load->model('Website/groups_model');
    	$this->load->model('Front_Fintech/payment_model');
        $this->load->model('General_Ledger/journal_model');
        
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '7');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }
	public function index()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();


		$data['title'] = "History Investment";
		$data['brd_title_url'] = site_url('Manager/B_history_invest');
		$data['brd_title_main'] = "Investment List";
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['get_invest'] = $this->account_model->get_investment(null,null)->result();

		$data['info_url'] = site_url('Manager/B_history_invest/detail_invest');

		// $data['create_url'] = site_url('Fintech_Site/b_faq/create_faq');
		// $data['delete_url'] = site_url('Fintech_Site/b_faq/delete_faq');
		// $data['update_url'] = site_url('Fintech_Site/b_faq/update_faq');

        // $data['get_name'] = $this->personal_info_model->get_personal_info_lender($register_code);

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-manager/invest/invest_list', $data);
		$this->load->view('backend-web/partial/footer');
	}

	public function detail_invest()
	{

		$investment_code = $this->uri->segment(4);

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();


		$data['title'] = "History Investment";
		$data['brd_title_url'] = site_url('Manager/B_history_invest');
		$data['brd_title_main'] = "Investment List";
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['get_invest'] = $this->account_model->get_investment(null,null)->result();
		$data['get_invest_payment'] = $this->payment_model->get_invest_payment($investment_code,null,null)->result();

		// $data['create_url'] = site_url('Fintech_Site/b_faq/create_faq');
		// $data['delete_url'] = site_url('Fintech_Site/b_faq/delete_faq');
		// $data['update_url'] = site_url('Fintech_Site/b_faq/update_faq');

        // $data['get_name'] = $this->personal_info_model->get_personal_info_lender($register_code);

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-manager/invest/invest_detail', $data);
		$this->load->view('backend-web/partial/footer');
	}

	public function access_status_exchange()
	{

		$register_code = $this->input->post('register_code');
		$data_register = $this->register_model->get_register_by_id($register_code);
		$register_access_status = $data_register[0]->register_access_status;

		if ($register_access_status == "Deactivated"){

			$data_exchange = array(
			'register_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'register_access_status' => 'Deactivated'
			);

		}
							
		$update_register = $this->crud_model->update('tb_fintech_register','register_code',$register_code,$data_exchange);

	}


    public function change_order()
    {

        $register_code = $this->input->post('register_code');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'faq_orders' => $value_order
        );
                            
        $update_faq = $this->crud_model->update('tb_fintech_register','register_code',$register_code,$data_order);

    }


}
?>
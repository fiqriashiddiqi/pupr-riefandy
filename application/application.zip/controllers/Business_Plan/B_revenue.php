<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_revenue extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
        $this->load->model('Business_Plan/business_model');
        $this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '6');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }

	public function index()
	{

        $id_asumption = $this->uri->segment(4);
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

        $get_target= $this->business_model->get_target();
        $id_asumption = $get_target[0]->id_asumption;

        $data['title'] = "Revenue";
        $data['brd_title_main'] = "Revenue";
        $data['brd_title_url'] = site_url('Business_Plan/B_revenue')."/".$id_asumption;
        $data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_revenue');

        $where = array('id_asumption' => $id_asumption);
        $data['data_revenue'] = $this->crud_model->get_data('tb_business_plan_asumption', $where)->result();
        $data['get_wages'] = $this->business_model->get_wages(array(3,4), true, 'id_wages');
        $data['get_wages_gx'] = $this->business_model->get_wages(array(1,2,5,6,7,8,9,10,11), true, 'id_wages');
        $data['get_target'] = $get_target;
        $data['get_cost'] = $this->business_model->get_cost();

        $this->form_validation->set_rules("asumption_commission_investor", "Description", "trim|required");
        $this->form_validation->set_rules("asumption_commission_borrower", "Description", "trim|required");
        
    
        if ($this->form_validation->run() == true){
            
            $asumption_commission_investor = $this->input->post('asumption_commission_investor');
            $asumption_commission_borrower = $this->input->post('asumption_commission_borrower');
          

                 $data_target = array(
                        'id_asumption' => $id_asumption,
                        'asumption_commission_investor' => $asumption_commission_investor,
                        'asumption_commission_borrower' => $asumption_commission_borrower
                       
                        );

                        
                    $where = array('id_asumption' => $id_asumption);
                    $data_check = $this->crud_model->get_data("tb_business_plan_asumption", $where)->num_rows();

                    // var_dump($data_check);
                    //  die();
            
                 if ($data_check == 0) {
                    $insert_target = $this->crud_model->insert('tb_business_plan_asumption',$data_target);
                        $this->session->set_flashdata('alert_success', 'Data Successfully Posting.');
                 }else{
                        $update_target = $this->crud_model->update('tb_business_plan_asumption','id_asumption',$id_asumption,$data_target);
                        $this->session->set_flashdata('alert_success', 'Data Successfully Posting.');
                 }
                        
                redirect(base_url().'Business_Plan/B_revenue/');
                die();

                        // $update_target = $this->crud_model->update('tb_business_plan_asumption','id_target',$id_target,$data_target);

                }

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-bp/revenue/revenue-list', $data);
		$this->load->view('backend-web/partial/footer');

	}
}

?>
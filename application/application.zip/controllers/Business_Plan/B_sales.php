<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_sales extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
        $this->load->model('Business_Plan/business_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
        $this->load->model('General_Ledger/journal_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '6');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }

	public function index()
	{

        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();
        
        $get_target= $this->business_model->get_target();
        $id_asumption =  $get_target[0]->id_asumption;

		$data['title'] = "Sales";
        $data['brd_title_main'] = "Sales";
		$data['brd_title_url'] = site_url('Business_Plan/B_sales')."/".$id_asumption;
		$data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_sales');

        $data['get_sales'] = $this->business_model->get_target();

        $this->form_validation->set_rules("asumption_interest_percent", "Description", "trim|required");
    
        if ($this->form_validation->run() == true){
            
            $asumption_interest_percent = $this->input->post('asumption_interest_percent');

                    $data_target = array(
                        'asumption_interest_percent' => $asumption_interest_percent,
                       
                        );

                    $update_target = $this->crud_model->update('tb_business_plan_asumption','id_asumption',$id_asumption,$data_target);
                    $this->session->set_flashdata('alert_success', 'Data Successfully Update.');
                    redirect(base_url().'Business_Plan/B_sales/');
                    die();

        }

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-bp/sales/sales-list', $data);
		$this->load->view('backend-web/partial/footer');

	}
}

?>
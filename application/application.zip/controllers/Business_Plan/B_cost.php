<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_cost extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
        $this->load->model('Business_Plan/business_model');
        $this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '6');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }

	public function wages()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Wages";
        $data['brd_title_main'] = "Wages";
		$data['brd_title_url'] = site_url('Business_Plan/B_cost/wages');
		$data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_cost/wages');
        $data['create_url'] = site_url('Business_Plan/B_cost/wages_create');
        
        $get_target= $this->business_model->get_target();
        $id_asumption =  $get_target[0]->id_asumption;

        $data['get_target'] = $this->business_model->get_target();
        $data['get_wages'] = $this->business_model->get_wages();

        $this->form_validation->set_rules("asumption_bonus", "Description", "trim|required");
        
        if ($this->form_validation->run() == true){
            
            $asumption_bonus = $this->input->post('asumption_bonus');

                $data_target = array(
                    'asumption_bonus' => $asumption_bonus
                );

                $update_target = $this->crud_model->update('tb_business_plan_asumption','id_asumption',$id_asumption,$data_target);
                $this->session->set_flashdata('alert_success', 'Data Successfully Update.');        
                redirect(base_url().'Business_Plan/B_cost/wages');
                die();

        }

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-bp/wages/wages-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

    public function wages_create()
    {
        $this->form_validation->set_rules("wages_name", "Description", "trim|required");
        $this->form_validation->set_rules("wages_people", "Description", "trim|required");
        $this->form_validation->set_rules("wages_pay_check", "Description", "trim|required");
        $this->form_validation->set_rules("wages_bonus_status", "Description", "trim|required");
        
        if ($this->form_validation->run() == true){
            $wages_name = $this->input->post('wages_name');
            $wages_people = $this->input->post('wages_people');
            $wages_pay_check = $this->input->post('wages_pay_check');
            $wages_bonus_status = $this->input->post('wages_bonus_status');

                $data_wages = array(
                    'wages_name' => $wages_name,
                    'wages_people' => $wages_people,
                    'wages_pay_check' => $wages_pay_check,
                    'wages_bonus_status' => $wages_bonus_status      
                );

                $insert_wages = $this->crud_model->insert('tb_business_plan_wages',$data_wages);
                $this->session->set_flashdata('alert_success', 'Data Successfully Saved.');        
                redirect(base_url().'Business_Plan/B_cost/wages');
                die();

        } else {
                redirect(base_url().'Business_Plan/B_cost/wages');
                die();

        }

    }

    public function account()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $data['title'] = "Advertising & Promotion";
        $data['brd_title_main'] = "Advertising & Promotion";
        $data['brd_title_url'] = site_url('Business_Plan/B_cost/account');
        $data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_cost/account');
        
        $get_cost= $this->business_model->get_cost();
        $id_cost =  $get_cost[0]->id_cost;
        $data['get_cost'] = $this->business_model->get_cost();
        $data['get_target'] = $this->business_model->get_target();

        $this->form_validation->set_rules("cost_ap", "Description", "trim|required");
        
        if ($this->form_validation->run() == true){
            
            $cost_ap = $this->input->post('cost_ap');

                $data_target = array(
                    'cost_ap' => $cost_ap
                );

                $update_target = $this->crud_model->update('tb_business_plan_cost','id_cost',$id_cost,$data_target);
                $this->session->set_flashdata('alert_success', 'Data Successfully Update.');        
                redirect(base_url().'Business_Plan/B_cost/account');
                die();

        }

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-bp/advertising/advertising-list', $data);
        $this->load->view('backend-web/partial/footer');

    }

    public function amortization()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $data['title'] = "Aamortization";
        $data['brd_title_main'] = "Aamortization";
        $data['brd_title_url'] = site_url('Business_Plan/B_cost/amortization');
        $data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_cost/amortization');
        
        $get_cost= $this->business_model->get_cost();
        $id_cost =  $get_cost[0]->id_cost;
        $data['get_cost'] = $this->business_model->get_cost();

        $this->form_validation->set_rules("cost_amortization_system", "Description", "trim|required");
        $this->form_validation->set_rules("cost_amortization_period", "Description", "trim|required");
        
        if ($this->form_validation->run() == true){
            
            $cost_amortization_system = $this->input->post('cost_amortization_system');
            $cost_amortization_period = $this->input->post('cost_amortization_period');

                $data_target = array(
                    'cost_amortization_system' => $cost_amortization_system,
                    'cost_amortization_period' => $cost_amortization_period
                );

                $update_target = $this->crud_model->update('tb_business_plan_cost','id_cost',$id_cost,$data_target);
                $this->session->set_flashdata('alert_success', 'Data Successfully Update.');        
                redirect(base_url().'Business_Plan/B_cost/amortization');
                die();

        }

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-bp/amortization/amortization-list', $data);
        $this->load->view('backend-web/partial/footer');

    }

    public function system()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $data['title'] = "System & Maintenance";
        $data['brd_title_main'] = "System & Maintenance";
        $data['brd_title_url'] = site_url('Business_Plan/B_cost/system');
        $data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_cost/system');
        
        $get_cost= $this->business_model->get_cost();
        $id_cost =  $get_cost[0]->id_cost;

        $data['get_cost'] = $this->business_model->get_cost();

        $this->form_validation->set_rules("cost_system_cloud", "Description", "trim|required");
        $this->form_validation->set_rules("cost_system_firewall", "Description", "trim|required");
        $this->form_validation->set_rules("cost_system_maintenance", "Description", "trim|required");
        // var_dump($get_cost);
        // die();
        
        if ($this->form_validation->run() == true){
            
            $cost_system_cloud = $this->input->post('cost_system_cloud');
            $cost_system_firewall = $this->input->post('cost_system_firewall');
            $cost_system_maintenance = $this->input->post('cost_system_maintenance');

                $data_target = array(
                    'cost_system_cloud' => $cost_system_cloud,
                    'cost_system_firewall' => $cost_system_firewall,
                    'cost_system_maintenance' => $cost_system_maintenance
                );

                $update_target = $this->crud_model->update('tb_business_plan_cost','id_cost',$id_cost,$data_target);
                $this->session->set_flashdata('alert_success', 'Data Successfully Update.');        
                redirect(base_url().'Business_Plan/B_cost/system');
                die();

        }

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-bp/system/system-list', $data);
        $this->load->view('backend-web/partial/footer');

    }

    public function office_rent()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $data['title'] = "Office Rent";
        $data['brd_title_main'] = "Office Rent";
        $data['brd_title_url'] = site_url('Business_Plan/B_cost/office_rent');
        $data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_cost/office_rent');
        
        $get_target= $this->business_model->get_target();
        $id_asumption =  $get_target[0]->id_asumption;

        $data['get_target'] = $this->business_model->get_target();

        $get_cost= $this->business_model->get_cost();
        $id_cost =  $get_cost[0]->id_cost;

        $data['get_cost'] = $this->business_model->get_cost();

        $this->form_validation->set_rules("cost_office_rent", "Description", "trim|required");
        
        if ($this->form_validation->run() == true){
            
            $cost_office_rent = $this->input->post('cost_office_rent');

                $data_target = array(
                    'cost_office_rent' => $cost_office_rent
                );

                $update_target = $this->crud_model->update('tb_business_plan_cost','id_cost',$id_cost,$data_target);
                $this->session->set_flashdata('alert_success', 'Data Successfully Update.');        
                redirect(base_url().'Business_Plan/B_cost/office_rent');
                die();

        }

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-bp/office_rent/office-rent-list', $data);
        $this->load->view('backend-web/partial/footer');

    }

    public function depreciation()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $data['title'] = "Depreciation";
        $data['brd_title_main'] = "Depreciation";
        $data['brd_title_url'] = site_url('Business_Plan/B_cost/depreciation');
        $data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_cost/depreciation');

        $get_cost= $this->business_model->get_cost();
        $id_cost =  $get_cost[0]->id_cost;

        $data['get_cost'] = $this->business_model->get_cost();

        $this->form_validation->set_rules("cost_depreciation_assets", "Description", "trim|required");
        $this->form_validation->set_rules("cost_depreciation_period", "Description", "trim|required");
        
        if ($this->form_validation->run() == true){
            
            $cost_depreciation_assets = $this->input->post('cost_depreciation_assets');
            $cost_depreciation_period = $this->input->post('cost_depreciation_period');

                $data_target = array(
                    'cost_depreciation_assets' => $cost_depreciation_assets,
                    'cost_depreciation_period' => $cost_depreciation_period
                );

                $update_target = $this->crud_model->update('tb_business_plan_cost','id_cost',$id_cost,$data_target);
                $this->session->set_flashdata('alert_success', 'Data Successfully Update.');        
                redirect(base_url().'Business_Plan/B_cost/depreciation');
                die();

        }

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-bp/depreciation/deperciation-list', $data);
        $this->load->view('backend-web/partial/footer');

    }

    public function other_selling()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $data['title'] = "Other Selling";
        $data['brd_title_main'] = "Other Selling";
        $data['brd_title_url'] = site_url('Business_Plan/B_cost/other_selling');
        $data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_cost/other_selling');
        
        $get_cost= $this->business_model->get_cost();
        $id_cost =  $get_cost[0]->id_cost;

        $data['get_cost'] = $this->business_model->get_cost();
        $data['get_target'] = $this->business_model->get_target();

        $this->form_validation->set_rules("cost_other_selling", "Description", "trim|required");
        
        if ($this->form_validation->run() == true){
            
            $cost_other_selling = $this->input->post('cost_other_selling');

                $data_target = array(
                    'cost_other_selling' => $cost_other_selling
                );

                $update_target = $this->crud_model->update('tb_business_plan_cost','id_cost',$id_cost,$data_target);
                $this->session->set_flashdata('alert_success', 'Data Successfully Update.');        
                redirect(base_url().'Business_Plan/B_cost/other_selling');
                die();

        }

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-bp/other-selling/other-selling-list', $data);
        $this->load->view('backend-web/partial/footer');

    }

    public function other()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $data['title'] = "Other";
        $data['brd_title_main'] = "Other";
        $data['brd_title_url'] = site_url('Business_Plan/B_cost/other');
        $data['users_last_signin'] = $check_access[0]->users_last_signin;
        $data['form_url'] = site_url('Business_Plan/B_cost/other');
        
         $get_cost= $this->business_model->get_cost();
        $id_cost =  $get_cost[0]->id_cost;

        $data['get_cost'] = $this->business_model->get_cost();
        $data['get_target'] = $this->business_model->get_target();

        $this->form_validation->set_rules("cost_other", "Description", "trim|required");
        
        if ($this->form_validation->run() == true){
            
            $cost_other = $this->input->post('cost_other');

                $data_target = array(
                    'cost_other' => $cost_other
                );

                $update_target = $this->crud_model->update('tb_business_plan_cost','id_cost',$id_cost,$data_target);
                $this->session->set_flashdata('alert_success', 'Data Successfully Update.');        
                redirect(base_url().'Business_Plan/B_cost/other');
                die();

        }

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-bp/other/other-list', $data);
        $this->load->view('backend-web/partial/footer');

    }
}

?>
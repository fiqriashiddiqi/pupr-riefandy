<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_report extends CI_Controller {

	function __construct()
    {
        parent::__construct();
        $this->load->model('Parameter/param_model');
        $this->load->model('General_Ledger/journal_model');
        date_default_timezone_set("Asia/Jakarta");
    }

	public function excel_industry()
	{		
        $id_param_industry = isset($_REQUEST['id_param_industry']) ? $_REQUEST['id_param_industry'] : NULL;

        $data['data_industry'] = $this->param_model->get_industry_list_report($id_param_industry);
		$this->load->view('report/excel_industry', $data);
	}

    public function excel_entity()
    {       
        $id_param_entity = isset($_REQUEST['id_param_entity']) ? $_REQUEST['id_param_entity'] : NULL;

        $data['data_entity'] = $this->param_model->get_entity_list_report($id_param_entity);
        $this->load->view('report/excel_entity', $data);
    }

    public function excel_journal()
    {       
        $id_journal = isset($_REQUEST['id_journal']) ? $_REQUEST['id_journal'] : NULL;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');

        $data['data_journal'] = $this->journal_model->get_journal_list_report(null,$start_date,$end_date);
        $this->load->view('report/excel_journal', $data);
    }

    public function excel_journal_temp()
    {       
        $id_journal = isset($_REQUEST['id_journal']) ? $_REQUEST['id_journal'] : NULL;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');

        $data['data_journal'] = $this->journal_model->get_journal_temp_list_report(null,$start_date,$end_date);
        $this->load->view('report/excel_journal_temp', $data);
    }

    public function excel_journal_listing()
    {       
        $id_journal = isset($_REQUEST['id_journal']) ? $_REQUEST['id_journal'] : NULL;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');

        $data['data_journal'] = $this->journal_model->get_journal_list_report(null,$start_date,$end_date);
        $this->load->view('report/excel_journal_listing', $data);
    }

    public function excel_general()
    {       
        $journal_no = isset($_REQUEST['journal_no']) ? $_REQUEST['journal_no'] : NULL;

        $data['data_journal'] = $this->journal_model->get_general_list_report($journal_no);
        $this->load->view('report/excel_general', $data);
    }
     public function excel_general_ledger()
    {       
        $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : NULL;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');

        $data['data_journal'] = $this->journal_model->get_ledger_list_report(null,$id_param_coa_e,$start_date,$end_date);
        $this->load->view('report/excel_general_ledger', $data);
    }
    public function excel_balance()
    {       
         $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : NULL;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');

        // $data['data_journal'] = $this->journal_model->get_general_list_report($journal_no);
        $this->load->view('report/excel_balance', $data);
    }

    public function excel_trial()
    {       
         $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : NULL;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');

        // $data['data_journal'] = $this->journal_model->get_general_list_report($journal_no);
        $this->load->view('report/excel_trial', $data);
    }
    public function excel_profit()
    {       
        $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : NULL;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');

        // $data['data_journal'] = $this->journal_model->get_general_list_report($journal_no);
        $this->load->view('report/excel_profit', $data);
    }

     public function excel_cashflow()
    {       
        $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : NULL;
        $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
        $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');

        // $data['data_journal'] = $this->journal_model->get_general_list_report($journal_no);
        $this->load->view('report/excel_cashflow', $data);
    }


}
?>
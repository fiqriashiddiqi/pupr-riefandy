<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_faq extends CI_Controller {

	function __construct()
    {
        parent::__construct();
        $this->load->model('Website/slideshow_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/faq_model');
        $this->load->model('General_Ledger/journal_model');

        date_default_timezone_set("Asia/Jakarta");
    }

	public function index()
	{
        $navigation['faq_active'] = "active";

        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Faq');

        $footer['data_contact'] = $this->contact_model->get_contact();
        $sidebar['data_contact'] = $this->contact_model->get_contact();
		$this->load->view('frontend-web/partial/header');
		$this->load->view('frontend-web/partial/navigation' , $navigation);
		$this->load->view('frontend-web/faq' , $data);
		$this->load->view('frontend-web/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar', $sidebar);

	}
}
?>
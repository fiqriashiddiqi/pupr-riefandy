<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_home extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
        $this->load->model('Website/artikel_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/feedback_model');
        $this->load->model('Website/slideshow_model');
        $this->load->model('General_Ledger/journal_model');
        $this->load->model('Website/video_model');
        $this->load->model('Website/about_model');
        date_default_timezone_set("Asia/Jakarta");
    }

	public function index()
	{
        $data['data_video'] = $this->video_model->get_video();
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Home');
        $data['data_artikel'] = $this->artikel_model->get_artikel_by_limit(3,0);
        $data['data_feedback'] = $this->feedback_model->get_feedback_by_limit(3,0);
        $data['data_aboutmenu'] = $this->about_model->get_aboutmenu_front(2,0);

        $navigation['data_aboutmenu'] = $this->about_model->get_aboutmenu_front(2,0);
        $footer['data_contact'] = $this->contact_model->get_contact();
        $sidebar['data_contact'] = $this->contact_model->get_contact();

		$this->load->view('frontend-web/partial/header');
		$this->load->view('frontend-web/partial/navigation');
		$this->load->view('frontend-web/home' , $data);
		$this->load->view('frontend-web/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar', $sidebar);

	}
}
?>
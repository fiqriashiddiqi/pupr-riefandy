<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_about extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/about_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

		$groups = array(
			'1',
			'3');

			if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
			}

			if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
			}

			if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
			}

    }

	public function index()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "About Us";
		$data['brd_title_main'] = "About Us";
		$data['brd_title_url'] = site_url('Website/B_about');

		$data['form_url'] = site_url('Website/B_about');
		$data['create_url'] = site_url('Website/B_about/create_aboutmenu');
		$data['delete_url'] = site_url('Website/B_about/delete_aboutmenu');
		$data['info_url'] = site_url('Website/B_about/detail_aboutmenu');
		$data['access_status_url'] = site_url('Website/B_about');

		$data_about = $this->about_model->get_about();
		$data["data_about"] = $this->about_model->get_about();
		// $data["data_aboutmenu"] = $this->about_model->get_aboutmenu($data_about[0]->id_website_about);

		if ($this->input->post()){

			$this->form_validation->set_rules("id_website_about", "Id About", "trim|required");
			$this->form_validation->set_rules("about_description", "Description", "trim|required");

			if ($this->form_validation->run() == true){
				$id_website_about = $this->input->post('id_website_about');
				$about_description = $this->input->post('about_description');
				$date = date('Y-m-d H:i:s');

					$data_about_entry = array(
							'about_description' => $about_description,
							'about_postdate' => $date,
						
							);

							$update_about = $this->crud_model->update('tb_website_about','id_website_about',$id_website_about,$data_about_entry);

							$this->session->set_flashdata('alert_success', 'Description successfully changed.');
							redirect(base_url().'Website/B_about');
							die();

			} else {
							$this->session->set_flashdata('alert_error', 'Description failed to change !');
							redirect(base_url().'Website/B_about');
							die();
			}

		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/about/about-list', $data);
		$this->load->view('backend-web/partial/footer');
	}
	
	public function access_status_exchange()
	{

		$id_website_about_menu = $this->input->post('id_website_about_menu');

		$data_about_menu = $this->about_model->get_aboutmenu_by_id($id_website_about_menu);
		$about_menu_access_status = $data_about_menu[0]->about_menu_access_status;

		if ($about_menu_access_status == "Deactivated"){

			$data_exchange = array(
			'about_menu_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'about_menu_access_status' => 'Deactivated'
			);

		}
							
		$update_about = $this->crud_model->update('tb_website_about_menu','id_website_about_menu',$id_website_about_menu,$data_exchange);

	}

	public function create_aboutmenu()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;

		$this->load->helper('file');
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "About Us";
		$data['brd_title_main'] = "About Us";
		$data['brd_title_url'] = site_url('Website/B_about');
		$data['brd_title_sub'] = "Add About Us Menu";
		$data['brd_title_url_sub'] = site_url('Website/B_about/create_aboutmenu');

		$data['form_url'] = site_url('Website/B_about/create_aboutmenu');
		$data['back_url'] = site_url('Website/B_about');

		$data_about = $this->about_model->get_about();


		if ($this->input->post()){

			$this->form_validation->set_rules("about_menu_name", "About Us Menu", "trim|required");
			$this->form_validation->set_rules("about_menu_description", "About Us Description", "required");
			$this->form_validation->set_rules("about_menu_access_status", "Posting Status", "trim|required");
			$this->form_validation->set_rules("about_menu_media_status", "About Us Menu", "trim|required");

			if ($this->form_validation->run() == true){
				$id_website_about = $data_about[0]->id_website_about;
				$id_menu_about_menu = $this->input->post('id_website_about_menu');
				$about_menu_name = $this->input->post('about_menu_name');
				$about_menu_description = $this->input->post('about_menu_description');
				$about_menu_access_status = $this->input->post('about_menu_access_status');
				$about_menu_media_status = $this->input->post('about_menu_media_status');
				$link_picture = $this->input->post('link_picture');
				$link_video = $this->input->post('link_video');

				if(empty($link_video)){
					$link_video = '-';
				}

				if(!empty($_FILES['link_picture']['name'])){

					$name_file = $about_menu_name."_".time();
					$config['upload_path'] = './uploads/Website/about_menu';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['max_size']     = '5120';
					$config['file_name'] = $name_file;

					$this->load->library('upload', $config);

					if(!$this->upload->do_upload('link_picture')){

						$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_about/create_aboutmenu');
						die();

					} else {

						$file_data = $this->upload->data();

						$data_aboutmenu = array(
						'id_website_about' => $id_website_about,
						'about_menu_name' => $about_menu_name,
						'about_menu_description' => $about_menu_description,
						'about_menu_access_status' => $about_menu_access_status,
						'about_menu_media_status' => $about_menu_media_status,
						'about_menu_video_url' => $link_video,
						'about_menu_picture_url' => $file_data['file_name']
						);
						

						$insert_aboutmenu = $this->crud_model->insert('tb_website_about_menu',$data_aboutmenu);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_about/create_aboutmenu');
						die();

					}

				} else {

						$data_aboutmenu = array(
						'id_website_about' => $id_website_about,
						'about_menu_name' => $about_menu_name,
						'about_menu_description' => $about_menu_description,
						'about_menu_access_status' => $about_menu_access_status,
						'about_menu_media_status' => $about_menu_media_status,
						'about_menu_video_url' => $link_video,
						'about_menu_picture_url' => '-'
						);
						

						$insert_aboutmenu = $this->crud_model->insert('tb_website_about_menu',$data_aboutmenu);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_about/create_aboutmenu');
						die();

				}

			} else {
						$this->session->set_flashdata('alert_error', 'Data failed to save !');
						redirect(base_url().'Website/B_about/create_aboutmenu');
						die();
			}

		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/about/about-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function detail_aboutmenu()
	{
		
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$this->load->helper('file');
		$id_website_about_menu = $this->uri->segment(4);

		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Detail About Us Menu";
		$data['brd_title_main'] = "About Us";
		$data['brd_title_url'] = site_url('Website/B_about');
		$data['brd_title_sub'] = "Detail About Us Menu";
		$data['brd_title_url_sub'] = site_url('Website/B_about/detail_aboutmenu').'/'.$id_website_about_menu;

		$data['form_url'] = site_url('Website/B_about/detail_aboutmenu');
		$data['back_url'] = site_url('Website/B_about');

		$data_about = $this->about_model->get_about();
		$data['data_aboutmenu'] = $this->about_model->get_aboutmenu_by_id($id_website_about_menu);

		if ($this->input->post()){

			$this->form_validation->set_rules("id_website_about_menu", "Id About Us Menu", "trim|required");
			$this->form_validation->set_rules("about_menu_name", "About Us Menu", "trim|required");
			$this->form_validation->set_rules("about_menu_description", "About Us Description", "required");
			$this->form_validation->set_rules("about_menu_access_status", "Posting Status", "trim|required");
			$this->form_validation->set_rules("about_menu_media_status", "About Us Menu", "trim|required");

			if ($this->form_validation->run() == true){
				$id_website_about = $data_about[0]->id_website_about;
				$id_website_about_menu = $this->input->post('id_website_about_menu');
				$about_menu_name = $this->input->post('about_menu_name');
				$about_menu_description = $this->input->post('about_menu_description');
				$about_menu_access_status = $this->input->post('about_menu_access_status');
				$about_menu_media_status = $this->input->post('about_menu_media_status');
				$link_picture = $this->input->post('link_picture');
				$link_video = $this->input->post('link_video');

				if(empty($link_video)){
					$link_video = '-';
				}

				if(!empty($_FILES['link_picture']['name'])){

					$name_file = $about_menu_name."_".time();
					$config['upload_path'] = './uploads/Website/about_menu';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['max_size']     = '5120';
					$config['file_name'] = $name_file;
					$config['overwrite'] = FALSE;
					$config['detect_mime'] = TRUE;
					$config['mod_mime_fix'] = TRUE;

					$this->load->library('upload', $config);

					if(!$this->upload->do_upload('link_picture')){

						$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_about/detail_aboutmenu/'.$id_website_about_menu);
						die();

					} else {

						$file_data = $this->upload->data();

						$data_aboutmenu= $this->about_model->get_aboutmenu_by_id($id_website_about_menu);
						$file_path= './uploads/Website/about_menu/'.$data_aboutmenu[0]->about_menu_picture_url;

						@unlink($file_path);

						$data_aboutmenu = array(
						'id_website_about' => $id_website_about,
						'about_menu_name' => $about_menu_name,
						'about_menu_description' => $about_menu_description,
						'about_menu_access_status' => $about_menu_access_status,
						'about_menu_media_status' => $about_menu_media_status,
						'about_menu_video_url' => $link_video,
						'about_menu_picture_url' => $file_data['file_name']
						);
						

						$update_aboutmenu = $this->crud_model->update('tb_website_about_menu','id_website_about_menu',$id_website_about_menu,$data_aboutmenu);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_about/detail_aboutmenu/'.$id_website_about_menu);
						die();

					}

				} else {

						$data_aboutmenu = array(
						'id_website_about' => $id_website_about,
						'about_menu_name' => $about_menu_name,
						'about_menu_description' => $about_menu_description,
						'about_menu_access_status' => $about_menu_access_status,
						'about_menu_media_status' => $about_menu_media_status,
						'about_menu_video_url' => $link_video
						);
						

						$update_aboutmenu = $this->crud_model->update('tb_website_about_menu','id_website_about_menu',$id_website_about_menu,$data_aboutmenu);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_about/detail_aboutmenu/'.$id_website_about_menu);
						die();

				}

			} else {
						$this->session->set_flashdata('alert_error', 'Data failed to save !');
						redirect(base_url().'Website/B_about/detail_aboutmenu/'.$id_website_about_menu);
						die();
			}
		}


		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/about/about-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

    public function change_order()
    {

        $id_website_about_menu = $this->input->post('id_website_about_menu');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'about_menu_orders' => $value_order
        );
                            
        $update_about_menu = $this->crud_model->update('tb_website_about_menu','id_website_about_menu',$id_website_about_menu,$data_order);

    }

	public function delete_aboutmenu()
	{	

		$this->load->helper('file');
		$id_website_about_menu = $this->uri->segment(4);

		$data_aboutmenu= $this->about_model->get_aboutmenu_by_id($id_website_about_menu);
		$file_path= './uploads/Website/about_menu/'.$data_aboutmenu[0]->about_menu_picture_url;
		
		if (!empty($id_website_about_menu)){

				@unlink($file_path);
				$this->crud_model->delete('tb_website_about_menu','id_website_about_menu',$id_website_about_menu);

				$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
				redirect(base_url().'Website/B_about');
				die();


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Website/B_about');
			die();
		}
	}

}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_feedback extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/feedback_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '3');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
             

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
             

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
             
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

    }
	public function index()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Feedback";
		$data['brd_title_url'] = site_url('Website/B_feedback');
		$data['brd_title_main'] = "Feedback";
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['create_url'] = site_url('Website/B_feedback/create_feedback');
		$data['delete_url'] = site_url('Website/B_feedback/delete_feedback');
		$data['update_url'] = site_url('Website/B_feedback/update_feedback');

        // $data['data_feedback'] = $this->feedback_model->get_feedback();
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/feedback/feedback_list', $data);
		$this->load->view('backend-web/partial/footer');
	}

	public function access_status_exchange()
	{

		$id_website_feedback = $this->input->post('id_website_feedback');

		$data_feedback = $this->feedback_model->get_feedback_by_id($id_website_feedback);
		$feedback_access_status = $data_feedback[0]->feedback_access_status;

		if ($feedback_access_status == "Deactivated"){

			$data_exchange = array(
			'feedback_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'feedback_access_status' => 'Deactivated'
			);

		}
							
		$update_feedback = $this->crud_model->update('tb_website_feedback','id_website_feedback',$id_website_feedback,$data_exchange);

	}

	public function create_feedback()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$this->load->helper('file');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Add Feedback";
		$data['brd_title_main'] = "Feedback";
		$data['brd_title_url'] = site_url('Website/B_feedback');
		$data['brd_title_sub'] = "Add feedback";
		$data['brd_title_url_sub'] = site_url('Website/B_feedback/create_feedback');

		$data['form_url'] = site_url('Website/B_feedback/create_feedback');
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);
		$data['back_url'] = site_url('Website/B_feedback');
		$data_feedback = $this->feedback_model->get_feedback();


		$this->form_validation->set_rules("feedback_name", "Customer Name", "trim|required");
		$this->form_validation->set_rules("feedback_description", "Description Custromer", "trim|required");
		$this->form_validation->set_rules("feedback_access_status", "Status Access", "trim|required");
		$this->form_validation->set_rules("feedback_postdate", "Post Date", "required");

		if(empty($_FILES['link_picture']['name'])){
			$this->form_validation->set_rules("link_picture", "Link Picture", "trim|required");
		}

		if ($this->form_validation->run() == true){
			$feedback_name = $this->input->post('feedback_name');
			$feedback_description = $this->input->post('feedback_description');
			$feedback_picture_url = $this->input->post('feedback_picture_url');
			$feedback_access_status = $this->input->post('feedback_access_status');
			$link_picture = $this->input->post('link_picture');
			$feedback_postdate = $this->input->post('feedback_postdate');

			$name_file = $feedback_name."_".time();
			$config['upload_path'] = './uploads/Website/feedback';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['file_name'] = $name_file;

			$this->load->library('upload', $config);

			if(!$this->upload->do_upload('link_picture')){

				$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
				redirect(base_url().'Website/B_feedback/create_feedback');
				die();

			} else {

				$file_data = $this->upload->data();

				$data_feedback = array(
				'feedback_name' => $feedback_name,
				'feedback_description' => $feedback_description,
				'feedback_picture_url' => $file_data['file_name'],
				'feedback_postdate' => $feedback_postdate,
				'feedback_access_status' => $feedback_access_status,
				
				);
				

				$insert_feedback = $this->crud_model->insert('tb_website_feedback',$data_feedback);
				
					$this->session->set_flashdata('alert_success', 'Data successfully saved.');
					redirect(base_url().'Website/B_feedback/create_feedback');
					die();

			}
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/feedback/feedback_form', $data);
		$this->load->view('backend-web/partial/footer');
	}
	
	public function update_feedback()
    {
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');
		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
	
		$id_website_feedback = $this->uri->segment(4);

		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Update Feedback";
		$data['brd_title_main'] = "Feedback";
		$data['brd_title_url'] = site_url('Website/B_feedback');
		$data['brd_title_sub'] = "Update feedback";
		$data['brd_title_url_sub'] = site_url('Website/B_feedback/update_feedback')."/".$id_website_feedback;

		$data['form_url'] = site_url('Website/B_feedback/update_feedback');
		$data['back_url'] = site_url('Website/B_feedback');

		$data['profile_true'] = "backdoor";

		$where_feedbackname = array('id_website_feedback' => $id_website_feedback);
		$data['data_feedback'] = $this->crud_model->get_data('tb_website_feedback', $where_feedbackname)->result();

		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		$this->form_validation->set_rules("id_website_feedback", "id_feedback", "trim|required");
		$this->form_validation->set_rules("feedback_name", "Deskripsi Feedback", "trim|required");
		$this->form_validation->set_rules("feedback_description", "Deskripsi Feedback", "trim|required");
		$this->form_validation->set_rules("feedback_postdate", "Postdate", "required");
		$this->form_validation->set_rules("feedback_access_status", "Status Akses", "trim|required");


		if ($this->form_validation->run() == true){
			$id_website_feedback = $this->input->post('id_website_feedback');
			$feedback_name = $this->input->post('feedback_name');
			$feedback_description = $this->input->post('feedback_description');
			$link_picture = $this->input->post('link_picture');
			$feedback_postdate = $this->input->post('feedback_postdate');
			$feedback_access_status = $this->input->post('feedback_access_status');
			

					if(!empty($_FILES['link_picture']['name'])){

				
					$name_file = $feedback_name."_".time();
					$config['upload_path'] = './uploads/Website/feedback';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['file_name'] = $name_file;

					$this->load->library('upload', $config);

						if(!$this->upload->do_upload('link_picture')){

						$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_feedback/update_feedback/'.$id_website_feedback);
						die();

						} else {

						$file_data = $this->upload->data();

						$data_feedback= $this->feedback_model->get_feedback_by_id($id_website_feedback);
						$file_path= './uploads/Website/feedback/'.$data_feedback[0]->feedback_picture_url;

						@unlink($file_path);


						$data_feedback = array(
						'id_website_feedback' => $id_website_feedback,
						'feedback_name' => $feedback_name,
						'feedback_description' => $feedback_description,
						'feedback_picture_url' => $file_data['file_name'],
						'feedback_postdate' => $feedback_postdate,
						'feedback_access_status' => $feedback_access_status
						);

						$update_feedback = $this->crud_model->update('tb_website_feedback','id_website_feedback',$id_website_feedback,$data_feedback);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_feedback/update_feedback/'.$id_website_feedback);
						die();

						}
					}else{

						$data_feedback = array(
						'id_website_feedback' => $id_website_feedback,
						'feedback_name' => $feedback_name,
						'feedback_description' => $feedback_description,
						'feedback_postdate' => $feedback_postdate,
						'feedback_access_status' => $feedback_access_status,
						);
						$update_feedback = $this->crud_model->update('tb_website_feedback','id_website_feedback',$id_website_feedback,$data_feedback);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_feedback/update_feedback/'.$id_website_feedback);
						die();

					}
				}
	
						$this->load->view('backend-web/partial/metadata');
						$this->load->view('backend-web/partial/header', $header);
						$this->load->view('backend-web/partial/navigation', $navigation);
						$this->load->view('backend-web/feedback/feedback_form_update', $data);
						$this->load->view('backend-web/partial/footer');
	}


	 public function change_order()
    {

        $id_website_feedback = $this->input->post('id_website_feedback');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'feedback_orders' => $value_order
        );
                            
        $update_feedback = $this->crud_model->update('tb_website_feedback','id_website_feedback',$id_website_feedback,$data_order);

    }

	public function delete_feedback()	
	{

		$id_website_feedback = $this->uri->segment(4);

		$data_feedback= $this->feedback_model->get_feedback_by_id($id_website_feedback);
		$file_path= './uploads/Website/feedback/'.$data_feedback[0]->feedback_picture_url;
		
		if (!empty($id_website_feedback)){

				@unlink($file_path);
				$this->crud_model->delete('tb_website_feedback','id_website_feedback',$id_website_feedback);
				$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
				redirect(base_url().'Website/B_feedback');
				die();


		} else {
		$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Website/B_feedback');
			die();
		
		}
	}
}
?>
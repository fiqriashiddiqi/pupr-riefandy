<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_management extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	$this->load->model('Website/management_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '3');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users__name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Management";
		$data['brd_title_main'] = "Management";
		$data['brd_title_url'] = site_url('Website/B_management');

		$data['form_url'] = site_url('Website/B_management');
		$data['create_url'] = site_url('Website/B_management/create_managementmenu');
		$data['delete_url'] = site_url('Website/B_management/delete_managementmenu');
		$data['info_url'] = site_url('Website/B_management/detail_managementmenu');
		$data['access_status_url'] = site_url('Website/B_management');

		$data_management = $this->management_model->get_management();
		$data["data_management"] = $this->management_model->get_management();
		// $data["data_managementmenu"] = $this->management_model->get_managementmenu($data_management[0]->id_website_management);


		if ($this->input->post('management_description')){

			$this->form_validation->set_rules("id_website_management", "Id Management", "trim|required");
			$this->form_validation->set_rules("management_description", "Description", "trim|required");

			if ($this->form_validation->run() == true){
				$id_website_management = $this->input->post('id_website_management');
				$management_description = $this->input->post('management_description');
				
				$date = date('Y-m-d H:i:s');

					$data_management_entry = array(
							'management_description' => $management_description,
							'management_postdate' => $date,
							
							);

							$update_management = $this->crud_model->update('tb_website_management','id_website_management',$id_website_management,$data_management_entry);
							$this->session->set_flashdata('alert_success', 'Description successfully changed.');
							redirect(base_url().'Website/B_management');
							die();
			} 

		}


		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/management/management_list', $data);
		$this->load->view('backend-web/partial/footer');

	}
	
	public function access_status_exchange()
	{

		$id_website_management_menu = $this->input->post('id_website_management_menu');

		$data_managementmenu = $this->management_model->get_managementmenu_by_id($id_website_management_menu);
		$management_menu_access_status = $data_managementmenu[0]->management_menu_access_status;

		if ($management_menu_access_status == "Deactivated"){

			$data_exchange = array(
			'management_menu_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'management_menu_access_status' => 'Deactivated'
			);

		}
							
		$update_management = $this->crud_model->update('tb_website_management_menu','id_website_management_menu',$id_website_management_menu,$data_exchange);

	}

	public function create_managementmenu()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$this->load->helper('file');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Add Management  Menu";
		$data['brd_title_main'] = "Management ";
		$data['brd_title_url'] = site_url('Website/B_management');
		$data['brd_title_sub'] = "Add Management  Menu";
		$data['brd_title_url_sub'] = site_url('Website/B_management/create_managementmenu');
		$data['back_url'] = site_url('Website/B_management');

		$data['form_url'] = site_url('Website/B_management/create_managementmenu');

		$data_management = $this->management_model->get_management();


			$this->form_validation->set_rules("management_menu_name", "Management Name", "trim|required");
			$this->form_validation->set_rules("management_menu_position", "Management Position", "required");
			$this->form_validation->set_rules("management_menu_person", "Management Person", "required");
			$this->form_validation->set_rules("management_menu_description", "Management Description", "required");
			$this->form_validation->set_rules("management_menu_access_status", "Posting Status", "trim|required");
			if (empty($_FILES['link_picture']['name']))
			{
    			$this->form_validation->set_rules('link_picture', 'Link Picture', 'required');
			}
		

			if ($this->form_validation->run() == true){
				$id_website_management = $data_management[0]->id_website_management;
				$management_menu_name = $this->input->post('management_menu_name');
				$management_menu_description = $this->input->post('management_menu_description');
				$management_menu_position = $this->input->post('management_menu_position');
				$management_menu_person = $this->input->post('management_menu_person');
				$management_menu_access_status = $this->input->post('management_menu_access_status');
				$link_picture = $this->input->post('link_picture');

					$name_file = $management_menu_name."_".time();
					$config['upload_path'] = './uploads/Website/management_menu';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['file_name'] = $name_file;

					$this->load->library('upload', $config);

					if(!$this->upload->do_upload('link_picture')){

						$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_management/create_managementmenu');
						die();


					} else {

						$file_data = $this->upload->data();

						$data_management = array(
						'id_website_management' => $id_website_management,
						'management_menu_name' => $management_menu_name,
						'management_menu_description' => $management_menu_description,
						'management_menu_position' => $management_menu_position,
						'management_menu_person' => $management_menu_person,
						'management_menu_access_status' => $management_menu_access_status,
						'management_menu_picture_url' => $file_data['file_name']
						);
						

						$insert_managementmenu = $this->crud_model->insert('tb_website_management_menu',$data_management);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_management/create_managementmenu');
						die();

					}

			}


		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/management/management_form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function detail_managementmenu()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$this->load->helper('file');

		$id_website_management_menu = $this->uri->segment(4);

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Detail management Menu";
		$data['brd_title_main'] = "management ";
		$data['brd_title_url'] = site_url('Website/B_management');
		$data['brd_title_sub'] = "Detail management  Menu";
		$data['brd_title_url_sub'] = site_url('Website/B_management/detail_managementmenu');

		$data['form_url'] = site_url('Website/B_management/detail_managementmenu');
		$data['back_url'] = site_url('Website/B_management');

		$data_management = $this->management_model->get_management();
		$data['data_managementmenu'] = $this->management_model->get_managementmenu_by_id($id_website_management_menu);


			$this->form_validation->set_rules("id_website_management_menu", "Id Management Menu ", "trim|required");
			$this->form_validation->set_rules("management_menu_name", "Management Menu", "trim|required");
			$this->form_validation->set_rules("management_menu_description", "Management Description", "required");
			$this->form_validation->set_rules("management_menu_access_status", "Posting Status", "trim|required");
			

			if ($this->form_validation->run() == true){


				$id_website_management = $data_management[0]->id_website_management;
				$id_website_management_menu = $this->input->post('id_website_management_menu');
				$management_menu_name = $this->input->post('management_menu_name');
				$management_menu_description = $this->input->post('management_menu_description');
				$management_menu_position = $this->input->post('management_menu_position');
				$management_menu_person = $this->input->post('management_menu_person');
				$management_menu_access_status = $this->input->post('management_menu_access_status');
				$link_picture = $this->input->post('link_picture');

				if(!empty($_FILES['link_picture']['name'])){

					

					$name_file = $management_menu_name."_".time();
					$config['upload_path'] = './uploads/Website/management_menu';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['file_name'] = $name_file;

					$this->load->library('upload', $config);

					if(!$this->upload->do_upload('link_picture')){

					$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_management/detail_managementmenu'.$id_website_management_menu);
						die();

					} else {

						$file_data = $this->upload->data();
						$data_managementmenu= $this->management_model->get_managementmenu_by_id($id_website_management_menu);
						$file_path= './uploads/Website/management_menu/'.$data_managementmenu[0]->management_menu_picture_url;

						@unlink($file_path);

						$data_managementmenu = array(
						'id_website_management' => $id_website_management,
						'management_menu_name' => $management_menu_name,
						'management_menu_description' => $management_menu_description,
						'management_menu_position' => $management_menu_position,
						'management_menu_person' => $management_menu_person,
						'management_menu_access_status' => $management_menu_access_status,
						'management_menu_picture_url' => $file_data['file_name']
						);
						

						$update_managementmenu = $this->crud_model->update('tb_website_management_menu','id_website_management_menu',$id_website_management_menu,$data_managementmenu);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_management/detail_managementmenu/'.$id_website_management_menu);
						die();

					}
				} else {

						$data_managementmenu = array(
						'id_website_management' => $id_website_management,
						'management_menu_name' => $management_menu_name,
						'management_menu_description' => $management_menu_description,
						'management_menu_position' => $management_menu_position,
						'management_menu_person' => $management_menu_person,
						'management_menu_access_status' => $management_menu_access_status
						);
						

						$update_managementmenu = $this->crud_model->update('tb_website_management_menu','id_website_management_menu',$id_website_management_menu,$data_managementmenu);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_management/detail_managementmenu/'.$id_website_management_menu);
						die();
				}
			
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/management/management_form_update', $data);
		$this->load->view('backend-web/partial/footer');

	}

     public function change_order()
    {

        $id_website_management_menu = $this->input->post('id_website_management_menu');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'management_menu_orders' => $value_order
        );
                            
        $update_management_menu = $this->crud_model->update('tb_website_management_menu','id_website_management_menu',$id_website_management_menu,$data_order);

    }

	
	public function delete_managementmenu()
	{

		$this->load->helper('file');
		$id_website_management_menu = $this->uri->segment(4);

		$data_managementmenu= $this->management_model->get_managementmenu_by_id($id_website_management_menu);
		$file_path= './uploads/Website/management_menu/'.$data_managementmenu[0]->management_menu_picture_url;
		
		if (!empty($id_website_management_menu)){

				@unlink($file_path);
				$this->crud_model->delete('tb_website_management_menu','id_website_management_menu',$id_website_management_menu);
				$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
				redirect(base_url().'Website/B_management');
				die();

		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Website/B_management');
			die();
		}
	}
	
}
?>
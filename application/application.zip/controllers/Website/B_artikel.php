<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_artikel extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/artikel_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '3');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Article & Pages";
		$data['brd_title_url'] = site_url('Website/B_artikel');
		$data['brd_title_main'] = "Article";
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['info_url'] = site_url('Website/B_artikel/detail_artikel');
		$data['create_url'] = site_url('Website/B_artikel/create_artikel');
		$data['delete_url'] = site_url('Website/B_artikel/delete_artikel');
		$data['update_url'] = site_url('Website/B_artikel/update_artikel');

		// $data['data_artikel'] = $this->artikel_model->get_data("tb_website_blog")->result();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/artikel/artikel-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function access_status_exchange()
	{

		$id_website_blog = $this->input->post('id_website_blog');

		$data_artikel = $this->artikel_model->get_artikel_by_id($id_website_blog);
		$blog_access_status = $data_artikel[0]->blog_access_status;

		if ($blog_access_status == "Deactivated"){

			$data_exchange = array(
			'blog_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'blog_access_status' => 'Deactivated'
			);

		}
							
		$update_artikel = $this->crud_model->update('tb_website_blog','id_website_blog',$id_website_blog,$data_exchange);

	}

	public function create_artikel()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$this->load->helper('file');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Add Article";
		$data['brd_title_main'] = "Article & Pages List";
		$data['brd_title_url'] = site_url('Website/B_artikel');
		$data['brd_title_sub'] = "Add Article";
		$data['brd_title_url_sub'] = site_url('Website/B_artikel/create_artikel');
		$data['back_url'] = site_url('Website/B_artikel');

		$data['form_url'] = site_url('Website/B_artikel/create_artikel');

			$this->form_validation->set_rules("blog_name", "About Us Menu", "trim|required");
			$this->form_validation->set_rules("blog_description", "About Us Description", "required");
			$this->form_validation->set_rules("blog_access_status", "Posting Status", "trim|required");
			$this->form_validation->set_rules("blog_media_status", "About Us Menu", "trim|required");

			if ($this->form_validation->run() == true){
				$blog_name = $this->input->post('blog_name');
				$blog_description = $this->input->post('blog_description');
				$blog_access_status = $this->input->post('blog_access_status');
				$blog_media_status = $this->input->post('blog_media_status');
				$link_picture = $this->input->post('link_picture');
				$link_video = $this->input->post('link_video');

				$date = date('Y-m-d H:i:s');	

				if(!empty($_FILES['link_picture']['name'])){

					$name_file = $blog_name."_".time();
					$config['upload_path'] = './uploads/Website/artikel';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['file_name'] = $name_file;

					$this->load->library('upload', $config);

					if(!$this->upload->do_upload('link_picture')){

						$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_artikel/create_artikel');
						die();

					} else {

						$file_data = $this->upload->data();

						$data_blog = array(
						'blog_name' => $blog_name,
						'blog_description' => $blog_description,
						'blog_access_status' => $blog_access_status,
						'blog_media_status' => $blog_media_status,
						'blog_display_status' => "Blog",
						'blog_video_url' => $link_video,
						'blog_postdate' => $date,
						'blog_picture_url' => $file_data['file_name']
						);
						

						$insert_blog = $this->crud_model->insert('tb_website_blog',$data_blog);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_artikel/create_artikel');
						die();

					}

				} else {

						$data_blog = array(
						'blog_name' => $blog_name,
						'blog_description' => $blog_description,
						'blog_access_status' => $blog_access_status,
						'blog_media_status' => $blog_media_status,
						'blog_display_status' => "Blog",
						'blog_video_url' => $link_video,
						'blog_postdate' => $date,
						'blog_picture_url' => '-'
						);
						

						$insert_blog = $this->crud_model->insert('tb_website_blog',$data_blog);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_artikel/create_artikel');
						die();

				}

			}


		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/artikel/artikel-form', $data);
		$this->load->view('backend-web/partial/footer');
	}

	public function detail_artikel()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');
		
		$id_website_blog= $this->uri->segment(4);
		$this->load->helper('file');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Detail Article";
		$data['brd_title_main'] = "Article & Pages List";
		$data['brd_title_url'] = site_url('Website/B_artikel');
		$data['brd_title_sub'] = "Detail Artikel";
		$data['brd_title_url_sub'] = site_url('Website/B_artikel/detail_artikel');

		$data['form_url'] = site_url('Website/B_artikel/detail_artikel');
		$data['delete_url'] = site_url('Website/B_artikel/delete_artikel');
		$data['back_url'] = site_url('Website/B_artikel');
	    
		$data['data_blog'] = $this->artikel_model->get_artikel_by_id($id_website_blog);


			$this->form_validation->set_rules("id_website_blog", "Id blog", "trim|required");
			$this->form_validation->set_rules("blog_name", "Artikel Menu", "trim|required");
			$this->form_validation->set_rules("blog_description", "Article Content", "required");
			$this->form_validation->set_rules("blog_access_status", "Posting Status", "trim|required");
			$this->form_validation->set_rules("blog_media_status", "About Us Menu", "trim|required");

			if ($this->form_validation->run() == true){
				$id_website_blog = $this->input->post('id_website_blog');
				$blog_name = $this->input->post('blog_name');
				$blog_description = $this->input->post('blog_description');
				$blog_access_status = $this->input->post('blog_access_status');
				$blog_media_status = $this->input->post('blog_media_status');
				$link_picture = $this->input->post('link_picture');
				$link_video = $this->input->post('link_video');

				$date = date('Y-m-d H:i:s');

				if(empty($link_video)){
					$link_video = '-';
				}

				if(!empty($_FILES['link_picture']['name'])){

					$name_file = $blog_name."_".time();
					$config['upload_path'] = './uploads/Website/artikel';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['max_size']     = '5120';
					$config['file_name'] = $name_file;

					$this->load->library('upload', $config);

					if(!$this->upload->do_upload('link_picture')){
						$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_artikel/detail_artikel/'.$id_website_blog);
						die();

					} else {

						$file_data = $this->upload->data();
						$data_blog= $this->artikel_model->get_artikel_by_id($id_website_blog);
						$file_path= './uploads/Website/artikel/'.$data_blog[0]->blog_picture_url;

						@unlink($file_path);

						$data_blog = array(
						'blog_name' => $blog_name,
						'blog_description' => $blog_description,
						'blog_access_status' => $blog_access_status,
						'blog_media_status' => $blog_media_status,
						'blog_video_url' => $link_video,
						'blog_postdate' => $date,
						'blog_picture_url' => $file_data['file_name']
						);
						

						$update_blog = $this->crud_model->update('tb_website_blog','id_website_blog',$id_website_blog,$data_blog);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_artikel/detail_artikel/'.$id_website_blog);
						die();
					}

				} else {

						$data_blog = array(
						'blog_name' => $blog_name,
						'blog_description' => $blog_description,
						'blog_access_status' => $blog_access_status,
						'blog_media_status' => $blog_media_status,
						'blog_postdate' => $date,
						'blog_video_url' => $link_video
						);
						

						$update_blog = $this->crud_model->update('tb_website_blog','id_website_blog',$id_website_blog,$data_blog);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_artikel/detail_artikel/'.$id_website_blog);
						die();

				}

			}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/artikel/artikel-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}
	
	 public function change_order()
    {

        $id_website_blog = $this->input->post('id_website_blog');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'blog_orders' => $value_order
        );
                            
        $update_blog = $this->crud_model->update('tb_website_blog','id_website_blog',$id_website_blog, $data_order);

    }

	public function delete_artikel()
	{
		
		$id_blog = $this->uri->segment(4);

		$data_blog= $this->artikel_model->get_artikel_by_id($id_blog);
		$file_path= './uploads/Website/artikel/'.$data_blog[0]->blog_picture_url;
					
		if (!empty($id_blog)){

			if($data_blog[0]->blog_display_status == "Blog"){

				@unlink($file_path);
				$this->crud_model->delete('tb_website_blog','id_website_blog',$id_blog);
				$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
				redirect(base_url().'Website/B_artikel');
				die();

			} else {

				$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
				redirect(base_url().'Website/B_artikel');
				die();

			}

		} else {

			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Website/B_artikel');
			die();
		
		
		}
	}
}
?>
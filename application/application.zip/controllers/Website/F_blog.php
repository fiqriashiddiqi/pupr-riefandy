<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_blog extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
    	$this->load->model('Website/artikel_model');
    	$this->load->model('Website/contact_model');
        $this->load->model('Website/about_model');
        $this->load->model('General_Ledger/journal_model');

    	date_default_timezone_set("Asia/Jakarta");
    }

	public function index()
	{

        $id_artikel = isset($_REQUEST['blog']) ? $_REQUEST['blog'] : NULL;

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status_id('Blog', $id_artikel);
        $data['data_aboutmenu'] = $this->about_model->get_aboutmenu_front(2,0);
        
        $footer['data_contact'] = $this->contact_model->get_contact();
        $sidebar['data_contact'] = $this->contact_model->get_contact();

		$this->load->view('frontend-web/partial/header');
		$this->load->view('frontend-web/partial/navigation');
		$this->load->view('frontend-web/blog' , $data);
        $this->load->view('frontend-web/partial/sidebar' , $sidebar);
		$this->load->view('frontend-web/partial/footer' , $footer);

	}
}
?>
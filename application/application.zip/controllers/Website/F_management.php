<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_management extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
        $this->load->model('Website/about_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/management_model');
        $this->load->model('Website/slideshow_model');
        $this->load->model('General_Ledger/journal_model');

        date_default_timezone_set("Asia/Jakarta");
    }

	public function index()
	{
        $navigation['managemen_li_active'] = 'class="active_li"';
        $navigation['managemen_a_active'] = "active_link";
        $navigation['about_active'] = "active";
        $navigation['data_aboutmenu'] = $this->about_model->get_aboutmenu_front(2,0);
        
        $data['data_aboutmenu'] = $this->about_model->get_aboutmenu_front(2,0);
        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Management');
        $data['data_management'] = $this->management_model->get_management();
        $data['data_managementmenu'] = $this->management_model->get_managementmenu_all();

        $footer['data_contact'] = $this->contact_model->get_contact();
        $sidebar['data_contact'] = $this->contact_model->get_contact();

		$this->load->view('frontend-web/partial/header');
		$this->load->view('frontend-web/partial/navigation_about' , $navigation);
		$this->load->view('frontend-web/management' , $data);
		$this->load->view('frontend-web/partial/footer', $footer);
        $this->load->view('frontend-web/partial/sidebar', $sidebar);
	}
}
?>
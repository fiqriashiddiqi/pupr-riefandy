<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_lender extends CI_Controller {

	function __construct()
    {
        parent::__construct();
        $this->load->model('Website/artikel_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/slideshow_model');
        $this->load->model('General_Ledger/journal_model');

        date_default_timezone_set("Asia/Jakarta");
    }

	public function index()
	{
        $navigation['lender_active'] = "active";

        $data['data_artikel'] = $this->artikel_model->get_artikel_by_display_status('Investor');
        $footer['data_contact'] = $this->contact_model->get_contact();
        $sidebar['data_contact'] = $this->contact_model->get_contact();

		$this->load->view('frontend-web/partial/header');
		$this->load->view('frontend-web/partial/navigation' , $navigation);
		$this->load->view('frontend-web/lender' , $data);
		$this->load->view('frontend-web/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar', $sidebar);

	}
    
}
?>
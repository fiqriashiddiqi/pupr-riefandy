<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class F_about extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
        $this->load->model('Website/about_model');
        $this->load->model('Website/contact_model');
        $this->load->model('Website/slideshow_model');
        $this->load->model('General_Ledger/journal_model');

        date_default_timezone_set("Asia/Jakarta");
    }

	public function index()
	{
        $navigation['managemen_li_active'] = 'class="deactive_li href"';
        $navigation['managemen_a_active'] = "deactive_link";
        $navigation['about_active'] = "active";
        $navigation['data_aboutmenu'] = $this->about_model->get_aboutmenu_front(2,0);

        $data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'About');
        $data['data_slideshow_product'] = $this->slideshow_model->get_slideshow_by_limit(3,0,'Product & Service','Vission Mission');
        $data['data_aboutmenu'] = $this->about_model->get_aboutmenu_front(2,0);
        $data['data_about'] = $this->about_model->get_about();

        $footer['data_contact'] = $this->contact_model->get_contact();
        $sidebar['data_contact'] = $this->contact_model->get_contact();

		$this->load->view('frontend-web/partial/header');
		$this->load->view('frontend-web/partial/navigation_about' , $navigation);
		$this->load->view('frontend-web/about' , $data);
		$this->load->view('frontend-web/partial/footer' , $footer);
        $this->load->view('frontend-web/partial/sidebar' , $sidebar);

	}
}
?>
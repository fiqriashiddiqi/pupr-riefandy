<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_groups extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users__name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['groups_active'] = "active";

		$data['title'] = "Groups Management";
		$data['brd_title_main'] = "Groups Management";
		$data['brd_title_url'] = site_url('Website/B_groups');

		$data['create_url'] = site_url('Website/B_groups/create_groups');
		$data['delete_url'] = site_url('Website/B_groups/delete_groups');
		$data['info_url'] = site_url('Website/B_groups/update_groups');

		$data['data_groups'] = $this->groups_model->get_groups();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/root/groups-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function create_groups()
	{
		
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Add Groups";
		$data['brd_title_main'] = "Groups Management";
		$data['brd_title_url'] = site_url('Website/B_groups');
		$data['brd_title_sub'] = "Add Groups";
		$data['brd_title_url_sub'] = site_url('Website/B_groups/create_groups');
		$data['back_url'] = site_url('Website/B_groups');

		$data['form_url'] = site_url('Website/B_groups/create_groups');

		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		$this->form_validation->set_rules("groups_name", "Nama Groups", "trim|required");
	
		if ($this->form_validation->run() == true){
			$groups_name = $this->input->post('groups_name');
			$where_groups_name = array('groups_name' => $groups_name);
			$check_groups_name = $this->crud_model->get_data('tb_backend_groups',$where_groups_name)->num_rows();

		

				if ($check_grops_name == 0){
						$data_groups = array(
						'groups_name' => $groups_name,
						);

						$insert_groups = $this->crud_model->insert('tb_backend_groups',$data_groups);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_groups/create_groups');
						die();
					
				} else {
					$this->session->set_flashdata('alert_error', 'Data failed to save !');
						redirect(base_url().'Website/B_groups/create_groups');
						die();

				}
		
		}

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/root/groups-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function update_groups()
	{

		$id_backend_groups = $this->uri->segment(4);


		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['users_active'] = 'active';

		$data['title'] = "Update Groups";
		$data['brd_title_main'] = "Groups Management";
		$data['brd_title_url'] = site_url('Website/B_groups');
		$data['brd_title_sub'] = "Update Groups";
		$data['brd_title_url_sub'] = site_url('Website/B_groups/update_groups')."/".$id_backend_groups;

		$data['form_url'] = site_url('Website/B_groups/update_groups');
		$data['back_url'] = site_url('Website/B_groups');

		$data['profile_true'] = "backdoor";

		$where_groups = array('id_backend_groups' => $id_backend_groups);

		$data['data_groups'] = $this->crud_model->get_data('tb_backend_groups', $where_groups)->result();

		$this->form_validation->set_rules("id_backend_groups", "id_backend_users", "trim|required");
		$this->form_validation->set_rules("groups_name", "Nama Pengguna", "trim|required");
	
		if ($this->form_validation->run() == true){

			$id_backend_groups = $this->input->post('id_backend_groups');
			$groups_name = $this->input->post('groups_name');
			
						$data_groups = array(

						'id_backend_groups' => $id_backend_groups,
						'groups_name' => $groups_name
						);

						$update_groups = $this->crud_model->update('tb_backend_groups','id_backend_groups',$id_backend_groups,$data_groups);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_groups/update_groups/'.$id_backend_groups);
						die();

		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/root/groups-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function delete_groups()
	{
		$id_backend_groups = $this->uri->segment(4);
		
		if (!empty($id_backend_groups)){

					$this->crud_model->delete('tb_backend_groups','id_backend_groups',$id_backend_groups);
					$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
					redirect(base_url().'Website/B_groups');
					die();


		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Website/B_groups');
			die();
		}
	}

}
?>
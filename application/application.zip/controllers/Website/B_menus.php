<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_menus extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
        $this->load->model('Website/users_model');
    	$this->load->model('Website/menus_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users__name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['menus_active'] = "active";

		$data['title'] = "Menus Management";
		$data['brd_title_main'] = "Menus Management";
		$data['brd_title_url'] = site_url('Website/B_menus');

		$data['create_url'] = site_url('Website/B_menus/create_menus');
		$data['delete_url'] = site_url('Website/B_menus/delete_menus');
		$data['info_url'] = site_url('Website/B_menus/detail_menus');

		// $data['data_menus'] = $this->groups_model->get_menus();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/root/menus-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function access_status_exchange()
	{

		$id_backend_menus = $this->input->post('id_backend_menus');

		$data_menus = $this->menus_model->get_menus_by_id($id_backend_menus);
		$menus_access_status = $data_menus[0]->menus_access_status;

		if ($menus_access_status == "Deactivated"){

			$data_exchange = array(
			'menus_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'menus_access_status' => 'Deactivated'
			);

		}
							
		$update_menus = $this->crud_model->update('tb_backend_menus','id_backend_menus',$id_backend_menus,$data_exchange);

	}

	public function create_menus()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = " Management Menu";
		$data['brd_title_main'] = " Management Menu";
		$data['brd_title_url'] = site_url('Website/B_menus');
		$data['brd_title_sub'] = "Add Management Menu";
		$data['brd_title_url_sub'] = site_url('Website/B_menus/create_menus');

		$data['form_url'] = site_url('Website/B_menus/create_menus');
		$data['back_url'] = site_url('Website/B_menus');
		
		$data['get_groups'] = $this->groups_model->get_groups($access_groups);

		if ($this->input->post()){

			$this->form_validation->set_rules("menus_name", "Menagement Menu", "trim|required");
			$this->form_validation->set_rules("menus_controller", "Controller Name", "trim|required");
			$this->form_validation->set_rules("menus_access_status", "Posting Status", "trim|required");
			$this->form_validation->set_rules("menus_submenus_status", "Submenus Status", "trim|required");	

			if ($this->form_validation->run() == true){

				$menus_name = $this->input->post('menus_name');
				$menus_controller = $this->input->post('menus_controller');
				$menus_favicon = $this->input->post('menus_favicon');
				$menus_access_status = $this->input->post('menus_access_status');
				$access_groups = $this->input->post('access_groups');
				$menus_submenus_status = $this->input->post('menus_submenus_status');


				if(!empty($access_groups)){

					$access_array = array();
					foreach ($access_groups as $value) {
					  array_push($access_array, $value);
					}
					$menus_groups_rules = json_encode($access_array, true);
				} else {
                    $menus_groups_rules = '["0"]';

                }

						$data_menus = array(
						'menus_name' => $menus_name,
						'menus_controller' => $menus_controller,
						'menus_favicon' => $menus_favicon,
						'menus_groups_rules' => $menus_groups_rules,
						'menus_submenus_status' => $menus_submenus_status,
						'menus_access_status' => $menus_access_status

						);

						$insert_menus = $this->crud_model->insert('tb_backend_menus',$data_menus);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_menus/create_menus');
						die();
					
			}
		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/root/menus-form', $data);
		$this->load->view('backend-web/partial/footer');
	}

	
	public function detail_menus()
	{
		
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;

		$id_backend_menus = $this->uri->segment(4);
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Detail Management Menu";
		$data['brd_title_main'] = "Management Menu";
		$data['brd_title_url'] = site_url('Website/B_menus');
		$data['brd_title_sub'] = "Detail Management Menu";
		$data['brd_title_url_sub'] = site_url('Website/B_menus/detail_menus').'/'.$id_backend_menus;

		$data['form_url'] = site_url('Website/B_menus/detail_menus');
		$data['back_url'] = site_url('Website/B_menus');

		$data['data_menus'] = $this->menus_model->get_menus_by_id($id_backend_menus);
		$data['get_groups'] = $this->groups_model->get_groups($access_groups);

		if ($this->input->post()){

			$this->form_validation->set_rules("id_backend_menus", "Id Management Menu", "trim|required");
			$this->form_validation->set_rules("menus_name", "Menus Name", "trim|required");
			$this->form_validation->set_rules("menus_controller", "Controller Name", "required");
			$this->form_validation->set_rules("menus_submenus_status", "Submenus Rules", "trim|required");
			$this->form_validation->set_rules("menus_access_status", "Access Status", "trim|required");

			if ($this->form_validation->run() == true){

				$id_backend_menus = $this->input->post('id_backend_menus');
				$menus_name = $this->input->post('menus_name');
				$menus_controller = $this->input->post('menus_controller');
				$menus_favicon = $this->input->post('menus_favicon');
				$menus_access_status = $this->input->post('menus_access_status');
				$access_groups = $this->input->post('access_groups');
				$menus_submenus_status = $this->input->post('menus_submenus_status');

				if(!empty($access_groups)){

					$access_array = array();
					foreach ($access_groups as $value) {
					  array_push($access_array, $value);
					}
					$menus_groups_rules = json_encode($access_array, true);
				} else {
                    $menus_groups_rules = '["0"]';

                }

					$data_menus = array(

						'id_backend_menus' => $id_backend_menus,
						'menus_name' => $menus_name,
						'menus_controller' => $menus_controller,
						'menus_favicon' => $menus_favicon,
						'menus_groups_rules' => $menus_groups_rules,
						'menus_submenus_status' => $menus_submenus_status,
						'menus_access_status' => $menus_access_status

						);

						$update_menus = $this->crud_model->update('tb_backend_menus','id_backend_menus',$id_backend_menus,$data_menus);
						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_menus/detail_menus/'.$id_backend_menus);
						die();
			}
		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/root/menus-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

    public function change_order()
    {

        $id_backend_menus = $this->input->post('id_backend_menus');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'menus_orders' => $value_order
        );
                            
        $update_menus = $this->crud_model->update('tb_backend_menus','id_backend_menus',$id_backend_menus,$data_order);

    }

	public function delete_menus()
	{
		$id_backend_menus = $this->uri->segment(4);
		
		if (!empty($id_backend_menus)){
				$this->crud_model->delete('tb_backend_menus','id_backend_menus',$id_backend_menus);
				$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
				redirect(base_url().'Website/B_menus');
				die();

		} else {
			$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
			redirect(base_url().'Website/B_menus');
			die();
		}
	}

}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_submenus extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
        $this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
        $this->load->model('Website/menus_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users__name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$navigation['submenus_active'] = "active";

		$data['title'] = "Submenus Management";
		$data['brd_title_main'] = "Submenus Management";
		$data['brd_title_url'] = site_url('Website/B_submenus');

		$data['info_url'] = site_url('Website/B_submenus/detail_submenus');

		$data['data_submenus'] = $this->groups_model->get_menus_by_submenus_status();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/root/submenus-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

    public function access_status_exchange()
    {

        $id_backend_submenus = $this->input->post('id_backend_submenus');

        $data_menus = $this->menus_model->get_submenus_by_id($id_backend_submenus);
        $submenus_access_status = $data_menus[0]->submenus_access_status;

        if ($submenus_access_status == "Deactivated"){

            $data_exchange = array(
            'submenus_access_status' => 'Activated'
            );

        } else {

            $data_exchange = array(
            'submenus_access_status' => 'Deactivated'
            );

        }
                            
        $update_menus = $this->crud_model->update('tb_backend_submenus','id_backend_submenus',$id_backend_submenus,$data_exchange);

    }

    public function detail_submenus()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $id_backend_menus = $this->uri->segment(4);

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users__name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $navigation['submenus_active'] = "active";

        $data['title'] = "Detail Submenus";
        $data['brd_title_main'] = "Submenus Management";
        $data['brd_title_url'] = site_url('Website/B_submenus');
        $data['brd_title_sub'] = "Detail Submenus";
        $data['brd_title_url_sub'] = site_url('Website/B_submenus/detail_submenus/'.$id_backend_menus);

        $data['create_url'] = site_url('Website/B_submenus/create_submenus/'.$id_backend_menus);
        $data['update_url'] = site_url('Website/B_submenus/update_submenus');
        $data['delete_url'] = site_url('Website/B_submenus/delete_submenus');

        $data['data_submenus'] = $this->groups_model->get_submenus_all($id_backend_menus);

        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-web/root/submenus-detail', $data);
        $this->load->view('backend-web/partial/footer');

    }

    public function create_submenus()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $id_backend_menus = $this->uri->segment(4);

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $navigation['submenus_active'] = "active";

        $data['title'] = "Add Submenus";
        $data['brd_title_main'] = "Submenus Management";
        $data['brd_title_url'] = site_url('Website/B_submenus');
        $data['brd_title_sub'] = "Detail Submenus";
        $data['brd_title_url_sub'] = site_url('Website/B_submenus/detail_submenus/'.$id_backend_menus);
        $data['brd_title_sub2'] = "Add Submenus";
        $data['brd_title_url_sub2'] = site_url('Website/B_submenus/create_submenus/'.$id_backend_menus);

        $data['form_url'] = site_url('Website/B_submenus/create_submenus/'.$id_backend_menus);
        $data['back_url'] = site_url('Website/B_submenus/detail_submenus/'.$id_backend_menus);
        
        $data['data_menus'] = $this->menus_model->get_menus_by_id($id_backend_menus);
        $data['get_groups'] = $this->groups_model->get_groups($access_groups);

        if ($this->input->post()){
            $this->form_validation->set_rules("id_backend_menus", "Menagement Menu", "trim|required");
            $this->form_validation->set_rules("submenus_name", "Menagement Menu", "trim|required");
            $this->form_validation->set_rules("submenus_controller", "Controller Name", "trim|required");
            $this->form_validation->set_rules("submenus_access_status", "Posting Status", "trim|required");

            if ($this->form_validation->run() == true){
                $id_backend_menus = $this->input->post('id_backend_menus');
                $submenus_name = $this->input->post('submenus_name');
                $submenus_controller = $this->input->post('submenus_controller');
                $submenus_access_status = $this->input->post('submenus_access_status');
                $access_groups = $this->input->post('access_groups');

                if(!empty($access_groups)){

                    $access_array = array();
                    foreach ($access_groups as $value) {
                      array_push($access_array, $value);
                    }
                    $submenus_groups_rules = json_encode($access_array, true);
                } else {
                    $submenus_groups_rules = '["0"]';

                }

                        $data_submenus = array(
                        'id_backend_menus' => $id_backend_menus,
                        'submenus_name' => $submenus_name,
                        'submenus_controller' => $submenus_controller,
                        'submenus_groups_rules' => $submenus_groups_rules,
                        'submenus_access_status' => $submenus_access_status

                        );

                        $insert_submenus = $this->crud_model->insert('tb_backend_submenus',$data_submenus);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Website/B_submenus/create_submenus/'.$id_backend_menus);
                        die();
                    
            }
        }
        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-web/root/submenus-form', $data);
        $this->load->view('backend-web/partial/footer');
    }


    public function update_submenus()
    {
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');

        $id_backend_menus = $this->uri->segment(4);
        $id_backend_submenus = $this->uri->segment(5);

        $check_access = $this->auth_model->get_access($users_username, $users_password);
        $access_groups = $check_access[0]->id_backend_groups;
        
        $header['users_name'] = $check_access[0]->users_name;
        $header['groups_name'] = $check_access[0]->groups_name;
        $navigation['users_name'] = $check_access[0]->users_name;
        $navigation['groups_name'] = $check_access[0]->groups_name;
        $navigation['access_groups'] = $access_groups;
        $navigation['menus'] = $this->groups_model->groups_rules();

        $navigation['submenus_active'] = "active";

        $data['title'] = "Update Submenus";
        $data['brd_title_main'] = "Submenus Management";
        $data['brd_title_url'] = site_url('Website/B_submenus');
        $data['brd_title_sub'] = "Detail Submenus";
        $data['brd_title_url_sub'] = site_url('Website/B_submenus/detail_submenus/'.$id_backend_menus);
        $data['brd_title_sub2'] = "Update Submenus";
        $data['brd_title_url_sub2'] = site_url('Website/B_submenus/update_submenus/'.$id_backend_menus.'/'.$id_backend_submenus);

        $data['form_url'] = site_url('Website/B_submenus/update_submenus/'.$id_backend_menus.'/'.$id_backend_submenus);
        $data['back_url'] = site_url('Website/B_submenus/detail_submenus/'.$id_backend_menus);
        
        $data['data_submenus'] = $this->menus_model->get_submenus_by_id($id_backend_submenus);
        $data['get_groups'] = $this->groups_model->get_groups($access_groups);

        if ($this->input->post()){
            $this->form_validation->set_rules("id_backend_submenus", "Menagement Menu", "trim|required");
            $this->form_validation->set_rules("id_backend_menus", "Menagement Menu", "trim|required");
            $this->form_validation->set_rules("submenus_name", "Menagement Menu", "trim|required");
            $this->form_validation->set_rules("submenus_controller", "Controller Name", "trim|required");
            $this->form_validation->set_rules("submenus_access_status", "Posting Status", "trim|required");

            if ($this->form_validation->run() == true){
                $id_backend_submenus = $this->input->post('id_backend_submenus');
                $id_backend_menus = $this->input->post('id_backend_menus');
                $submenus_name = $this->input->post('submenus_name');
                $submenus_controller = $this->input->post('submenus_controller');
                $submenus_access_status = $this->input->post('submenus_access_status');
                $access_groups = $this->input->post('access_groups');

                if(!empty($access_groups)){

                    $access_array = array();
                    foreach ($access_groups as $value) {
                      array_push($access_array, $value);
                    }
                    $submenus_groups_rules = json_encode($access_array, true);

                } else {
                    $submenus_groups_rules = '["0"]';

                }

                        $data_submenus = array(
                        'submenus_name' => $submenus_name,
                        'submenus_controller' => $submenus_controller,
                        'submenus_groups_rules' => $submenus_groups_rules,
                        'submenus_access_status' => $submenus_access_status

                        );

                        $update_submenus = $this->crud_model->update('tb_backend_submenus','id_backend_submenus',$id_backend_submenus,$data_submenus);
                        $this->session->set_flashdata('alert_success', 'Data successfully saved.');
                        redirect(base_url().'Website/B_submenus/update_submenus/'.$id_backend_menus.'/'.$id_backend_submenus);
                        die();
                    
            }
        }
        $this->load->view('backend-web/partial/metadata');
        $this->load->view('backend-web/partial/header', $header);
        $this->load->view('backend-web/partial/navigation', $navigation);
        $this->load->view('backend-web/root/submenus-form-update', $data);
        $this->load->view('backend-web/partial/footer');
    }

    public function change_order()
    {

        $id_backend_submenus = $this->input->post('id_backend_submenus');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'submenus_orders' => $value_order
        );
                            
        $update_menus = $this->crud_model->update('tb_backend_submenus','id_backend_submenus',$id_backend_submenus,$data_order);

    }

    public function delete_submenus()
    {
        $id_backend_menus = $this->uri->segment(4);
        $id_backend_submenus = $this->uri->segment(5);
        
        if (!empty($id_backend_menus) AND !empty($id_backend_submenus)){
                $this->crud_model->delete('tb_backend_submenus','id_backend_submenus',$id_backend_submenus);
                $this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
                redirect(base_url().'Website/B_submenus/detail_submenus/'.$id_backend_menus);
                die();

        } else {
            $this->session->set_flashdata('alert_error', 'Data failed to Delete !');
            redirect(base_url().'Website/B_submenus/detail_submenus/'.$id_backend_menus);
            die();
        }
    }
}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_slideshow extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/slideshow_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '3');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
              

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
              

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
              
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }

	public function index()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Slideshow & Picture List";
		$data['brd_title_url'] = site_url('Website/B_slideshow');
		$data['brd_title_main'] = "Slideshow & Picture List";
		$data['users_last_signin'] = $check_access[0]->users_last_signin;

		$data['info_url'] = site_url('Website/B_slideshow/detail_slideshow');
		$data['create_url'] = site_url('Website/B_slideshow/create_slideshow');
		$data['delete_url'] = site_url('Website/B_slideshow/delete_slideshow');
		$data['update_url'] = site_url('Website/B_slideshow/update_slideshow');

		// $data['data_slideshow'] = $this->slideshow_model->get_data("tb_website_slideshow")->result();

		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/slideshow/slideshow-list', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function access_status_exchange()
	{

		$id_website_slideshow = $this->input->post('id_website_slideshow');

		$data_slideshow = $this->slideshow_model->get_slideshow_by_id($id_website_slideshow);
		$slideshow_access_status = $data_slideshow[0]->slideshow_access_status;

		if ($slideshow_access_status == "Deactivated"){

			$data_exchange = array(
			'slideshow_access_status' => 'Activated'
			);

		} else {

			$data_exchange = array(
			'slideshow_access_status' => 'Deactivated'
			);

		}
							
		$update_slideshow = $this->crud_model->update('tb_website_slideshow','id_website_slideshow',$id_website_slideshow,$data_exchange);

	}

	public function create_slideshow()
	{

    	$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$this->load->helper('file');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Add Slideshow & Picture";
		$data['brd_title_main'] = "Slideshow & Picture";
		$data['brd_title_url'] = site_url('Website/B_slideshow');
		$data['brd_title_sub'] = "Add Slideshow & Picture";
		$data['brd_title_url_sub'] = site_url('Website/B_slideshow/create_slideshow');

		$data['form_url'] = site_url('Website/B_slideshow/create_slideshow');
		$data['back_url'] = site_url('Website/B_slideshow');

		$this->form_validation->set_rules("slideshow_name", "picture ", "required");
		$this->form_validation->set_rules("slideshow_description", "Description picture", "required");
		$this->form_validation->set_rules("slideshow_access_status", "Posting Status", "trim|required");

		if(empty($_FILES['link_picture']['name'])){
			$this->form_validation->set_rules("link_picture", "Link Picture", "trim|required");
		}

			if ($this->form_validation->run() == true){

				
				$slideshow_name = $this->input->post('slideshow_name');
				$slideshow_description = $this->input->post('slideshow_description');
				$slideshow_display_menus = $this->input->post('slideshow_display_menus');
				$slideshow_access_status = $this->input->post('slideshow_access_status');
				$link_picture = $this->input->post('link_picture');

				$date = date('Y-m-d H:i:s');

				if(!empty($_FILES['link_picture']['name'])){

				$name_file = $slideshow_name."_".time();
				$config['upload_path'] = './uploads/Website/slideshow';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$config['file_name'] = $name_file;

					$this->load->library('upload', $config);

					
					if(!$this->upload->do_upload('link_picture')){

					$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_slideshow/create_slideshow');
						die();

					} else {

						$file_data = $this->upload->data();

						$data_slideshow = array(
						'slideshow_name' => $slideshow_name,
						'slideshow_description' => $slideshow_description,
						'slideshow_display_menus' => $slideshow_display_menus,
						'slideshow_access_status' => $slideshow_access_status,
						'slideshow_postdate' => $date,
						'slideshow_url' => $file_data['file_name']
						);
						

						$insert_slideshow = $this->crud_model->insert('tb_website_slideshow',$data_slideshow);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_slideshow/create_slideshow');
						die();

					} 

				}
			}


		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/slideshow/slideshow-form', $data);
		$this->load->view('backend-web/partial/footer');

	}

	public function detail_slideshow()
	{
		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');
		
		$id_website_slideshow= $this->uri->segment(4);
		$this->load->helper('file');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Detail Slideshow & Picture List";
		$data['brd_title_main'] = "Slideshow & Picture List";
		$data['brd_title_url'] = site_url('Website/B_slideshow');
		$data['brd_title_sub'] = "Detail Slideshow & Picture List";
		$data['brd_title_url_sub'] = site_url('Website/B_slideshow/detail_slideshow');

		$data['form_url'] = site_url('Website/B_slideshow/detail_slideshow');
		$data['delete_url'] = site_url('Website/B_slideshow/delete_slideshow');
		$data['back_url'] = site_url('Website/B_slideshow');
	    
		$data['data_slideshow'] = $this->slideshow_model->get_slideshow_by_id($id_website_slideshow);


			$this->form_validation->set_rules("id_website_slideshow", "Id picture", "trim|required");
			$this->form_validation->set_rules("slideshow_name", "picture Title", "required");
			$this->form_validation->set_rules("slideshow_description", "Description picture", "required");
			$this->form_validation->set_rules("slideshow_access_status", "Posting Status", "trim|required");
			
			if ($this->form_validation->run() == true){
				$id_website_slideshow = $this->input->post('id_website_slideshow');
				$slideshow_name = $this->input->post('slideshow_name');
				$slideshow_description = $this->input->post('slideshow_description');
				$slideshow_display_menus = $this->input->post('slideshow_display_menus');
				$slideshow_access_status = $this->input->post('slideshow_access_status');
				$link_picture = $this->input->post('link_picture');

				$date = date('Y-m-d H:i:s');

				if(!empty($_FILES['link_picture']['name'])){


				$name_file = $slideshow_name."_".time();
				$config['upload_path'] = './uploads/Website/slideshow';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$config['file_name'] = $name_file;

					$this->load->library('upload', $config);

					
					if(!$this->upload->do_upload('link_picture')){

						$this->session->set_flashdata('alert_error', 'uploaded file failed, file is too big or wrong file format !');
						redirect(base_url().'Website/B_slideshow/detail_slideshow/'.$id_website_slideshow);
						die();

					} else {

						$file_data = $this->upload->data();
						$data_slideshow= $this->slideshow_model->get_slideshow_by_id($id_website_slideshow);
						$file_path= './uploads/Website/slideshow/'.$data_slideshow[0]->slideshow_url;

						@unlink($file_path);

						$data_slideshow = array(
						'slideshow_name' => $slideshow_name,
						'slideshow_description' => $slideshow_description,
						'slideshow_display_menus' => $slideshow_display_menus,
						'slideshow_access_status' => $slideshow_access_status,
						'slideshow_postdate' => $date,
						'slideshow_url' => $file_data['file_name']
						);
						$update_slideshow = $this->crud_model->update('tb_website_slideshow','id_website_slideshow',$id_website_slideshow,$data_slideshow);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_slideshow/detail_slideshow/'.$id_website_slideshow);
						die();

					} 

				} else {


						$data_slideshow = array(
						'slideshow_name' => $slideshow_name,
						'slideshow_description' => $slideshow_description,
						'slideshow_display_menus' => $slideshow_display_menus,
						'slideshow_postdate' => $date,
						'slideshow_access_status' => $slideshow_access_status
						);
						

						$update_slideshow = $this->crud_model->update('tb_website_slideshow','id_website_slideshow',$id_website_slideshow,$data_slideshow);

						$this->session->set_flashdata('alert_success', 'Data successfully saved.');
						redirect(base_url().'Website/B_slideshow/detail_slideshow/'.$id_website_slideshow);
						die();	

					} 
				

			}


		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/slideshow/slideshow-form-update', $data);
		$this->load->view('backend-web/partial/footer');

	}

	 public function change_order()
    {

        $id_website_slideshow = $this->input->post('id_website_slideshow');
        $value_order = $this->input->post('value_order');

        $data_order = array(
            'slideshow_orders' => $value_order
        );
                            
        $update_slideshow = $this->crud_model->update('tb_website_slideshow','id_website_slideshow',$id_website_slideshow,$data_order);

    }

	public function delete_slideshow()
	{
		$id_website_slideshow = $this->uri->segment(4);

		$data_slideshow= $this->slideshow_model->get_slideshow_by_id($id_website_slideshow);
		$file_path= './uploads/Website/slideshow/'.$data_slideshow[0]->slideshow_url;

		if (!empty($id_website_slideshow)){

				@unlink($file_path);
				$this->crud_model->delete('tb_website_slideshow','id_website_slideshow',$id_website_slideshow);
				$this->session->set_flashdata('alert_success', 'Data successfully Deleted.');
				redirect(base_url().'Website/B_slideshow');
				die();


		} else {
				$this->session->set_flashdata('alert_error', 'Data failed to Delete !');
				redirect(base_url().'Website/B_slideshow');
				die();
		}
	}
}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_contactus extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
    	$this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/contact_model');
    	$this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
    	$users_password = $this->session->userdata('users_password');
		$users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1',
            '3');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
               
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }


    }

	public function index()
	{

		$users_username = $this->session->userdata('users_username');
		$users_password = $this->session->userdata('users_password');

		$check_access = $this->auth_model->get_access($users_username, $users_password);
 		$access_groups = $check_access[0]->id_backend_groups;
		
		$header['users_name'] = $check_access[0]->users_name;
		$header['groups_name'] = $check_access[0]->groups_name;
		$navigation['users_name'] = $check_access[0]->users_name;
		$navigation['groups_name'] = $check_access[0]->groups_name;
		$navigation['access_groups'] = $access_groups;
		$navigation['menus'] = $this->groups_model->groups_rules();

		$data['title'] = "Contact Us";
		$data['brd_title_main'] = "Contact Us";
		$data['brd_title_url'] = site_url('Website/B_contactus');

		$data['form_url'] = site_url('Website/B_contactus');
		$data['data_contact'] = $this->contact_model->get_contact();
		$data['data_groups'] = $this->groups_model->get_groups($access_groups);

		$this->form_validation->set_rules("id_website_contact_us", "id contact us", "trim|required");
		$this->form_validation->set_rules("contact_us_description", "Deskripsi contact", "trim|required");
		$this->form_validation->set_rules("contact_us_headquarter", "Alamat", "trim|required");
		$this->form_validation->set_rules("contact_us_phone", "No Handphone", "trim|required");
		$this->form_validation->set_rules("contact_us_fax", "No Fax", "trim|required");
		$this->form_validation->set_rules("contact_us_email", "Alamat Email", "trim|required");
		$this->form_validation->set_rules("contact_us_livechat", "Live Chat", "trim|required");
		$this->form_validation->set_rules("contact_us_facebook", "Facebook", "trim|required");
		$this->form_validation->set_rules("contact_us_twitter", "Twitter", "trim|required");
		$this->form_validation->set_rules("contact_us_instagram", "Intagram", "trim|required");
		$this->form_validation->set_rules("contact_us_google_plus", "Intagram", "trim|required");
		$this->form_validation->set_rules("contact_us_linkedin", "Intagram", "trim|required");
		$this->form_validation->set_rules("contact_us_whatsapp", "Intagram", "trim|required");
		$this->form_validation->set_rules("contact_us_address", "Intagram", "trim|required");

		if ($this->form_validation->run() == true){
			$id_website_contact_us = $this->input->post('id_website_contact_us');
			$contact_us_description = $this->input->post('contact_us_description');
			$contact_us_headquarter = $this->input->post('contact_us_headquarter');
			$contact_us_phone = $this->input->post('contact_us_phone');
			$contact_us_fax = $this->input->post('contact_us_fax');
			$contact_us_email = $this->input->post('contact_us_email');
			$contact_us_livechat = $this->input->post('contact_us_livechat');
			$contact_us_facebook = $this->input->post('contact_us_facebook');
			$contact_us_twitter = $this->input->post('contact_us_twitter');
			$contact_us_instagram = $this->input->post('contact_us_instagram');
			$contact_us_google_plus = $this->input->post('contact_us_google_plus');
			$contact_us_linkedin = $this->input->post('contact_us_linkedin');
			$contact_us_whatsapp = $this->input->post('contact_us_whatsapp');
			$contact_us_address = $this->input->post('contact_us_address');

						$data_contact = array(
						'id_website_contact_us' => $id_website_contact_us,
						'contact_us_description' => $contact_us_description,
						'contact_us_headquarter' => $contact_us_headquarter,
						'contact_us_phone' => $contact_us_phone,
						'contact_us_fax' => $contact_us_fax,
						'contact_us_email' => $contact_us_email,
						'contact_us_livechat' => $contact_us_livechat,
						'contact_us_facebook' => $contact_us_facebook,
						'contact_us_twitter' => $contact_us_twitter,
						'contact_us_instagram' => $contact_us_instagram,
						'contact_us_google_plus' => $contact_us_google_plus,
						'contact_us_linkedin' => $contact_us_linkedin,
						'contact_us_whatsapp' => $contact_us_whatsapp,
						'contact_us_address' => $contact_us_address

						);

						$update_contact = $this->crud_model->update('tb_website_contact_us','id_website_contact_us',$id_website_contact_us,$data_contact);
							$this->session->set_flashdata('alert_success', 'Description successfully changed.');
							redirect(base_url().'Website/B_contactus');
							die();


		}
		$this->load->view('backend-web/partial/metadata');
		$this->load->view('backend-web/partial/header', $header);
		$this->load->view('backend-web/partial/navigation', $navigation);
		$this->load->view('backend-web/contactus/contact_form_detail', $data);
		$this->load->view('backend-web/partial/footer');
	}

	
}
?>
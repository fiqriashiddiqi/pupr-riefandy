<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_report extends CI_Controller {

	function __construct()
  	{
    	parent::__construct();
   	 	$this->load->library('form_validation');
    	$this->load->model('auth_model');
    	$this->load->model('crud_model');
        $this->load->model('General_Ledger/journal_model');
    	$this->load->model('Website/users_model');
    	$this->load->model('Website/menus_model');
        $this->load->model('Website/groups_model');
    	date_default_timezone_set("Asia/Jakarta");

    	$users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');
        $users_access_status = $this->session->userdata('users_access_status');

		$check_access = $this->auth_model->get_access($users_username, $users_password);

        $groups = array(
            '1');

            if (!isset($users_username) && !isset($users_password) && !isset($users_access_status)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You have not logged in or you have left the page for too long. !');
                redirect(base_url().'auth');
                die();
            }

            if(!in_array($check_access[0]->id_backend_groups, $groups)){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                

                $this->session->set_flashdata('alert_error', 'You do not have access to this page !');
                redirect(base_url().'auth');
                die();
            }

            if($check_access[0]->users_access_status != "Activated"){
                $this->session->unset_userdata("users_username","users_password", "users_access_status");
                
                
                $this->session->set_flashdata('alert_error', 'Your account is already Disabled !');
                redirect(base_url().'auth');
                die();
            }

  	}

    //  	public function excel_users()
	// {
	// 	$username = $this->session->userdata('username');
	// 	$password = $this->session->userdata('password');

	// 	$check_access = $this->auth_model->get_access($username, $password);
    // 		$access_groups = $check_access[0]->id_groups;

	// 	$id_groups = isset($_REQUEST['id_groups']) ? $_REQUEST['id_groups'] : NULL;
	// 	$access_status = isset($_REQUEST['access_status']) ? $_REQUEST['access_status'] : NULL;

	// 	$data['data_users'] = $this->users_model->get_users($access_groups, $id_groups, $access_status);

	// 	$this->load->view('back-end/report/excel_users', $data);

	// }

}
?>
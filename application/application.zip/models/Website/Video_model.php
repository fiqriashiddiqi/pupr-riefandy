<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Video_model extends CI_Model {

	public function get_data($table)
	{	
		return $this->db->get($table);
    
	}

  public function get_video()
    {   
        $this->db->select("twv.*")
          ->from("tb_website_videos twv");

    return $this->db->get()->result();
    }

    // public function get_artikel_by_ds($display_status)
    // {   
    //     $this->db->select("ta.*")
    //       ->from("tb_blog ta");

    // return $this->db->where("ta.display_status != 'Lender'");
    // return $this->db->where("ta.display_status != 'Borowwer'");
    // }

  public function get_video_by_id($id_website_videos)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_videos tam");

        $this->db->where("tam.id_website_videos", $id_website_videos);

        // $this->db->where("tam.display_status != 'Lender'");
        // $this->db->where("tam.display_status != 'Borowwer'");



    return $this->db->get()->result();
    }

  public function get_data_all($id_videos = null)
  { 
    $this->db->select("tn.*")
      ->from("tb_website_videos tn");

    if (!empty($id_website_videos  )){
      $this->db->where("tn.id_website_videos ", $id_website_videos );
    }

    $this->db->order_by("tn.videos_postdate", "DESC");

    return $this->db->get()->result();

  }

 
	
}
?>
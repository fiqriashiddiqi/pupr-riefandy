<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Slideshow_model extends CI_Model {

	public function get_data($table)
	{	
		return $this->db->get($table);
    
	}

  public function get_slideshow()
   {   
        $this->db->select("ta.*")
          ->from("tb_website_slideshow ta");

    return $this->db->get()->result();
    }
    
      public function get_slideshow_list($limit = null, $position = null)
    {   
        $this->db->select("twa.*")
          ->from("tb_website_slideshow twa");

           if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

    return $this->db->get();
    }


  public function get_slideshow_by_id($id_website_slideshow)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_slideshow tam");

        $this->db->where("tam.id_website_slideshow", $id_website_slideshow);


    return $this->db->get()->result();
    }

  public function get_data_all($id_website_slideshow = null)
  { 
    $this->db->select("tn.*")
      ->from("tb_website_slideshow tn");

    if (!empty($id_website_slideshow  )){
      $this->db->where("tn.id_website_slideshow ", $id_website_slideshow );
    }

    $this->db->order_by("tn.slideshow_postdate", "DESC");

    return $this->db->get()->result();

  }

  public function get_slideshow_by_limit($limit,$start,$slideshow_display_menus)
  {   
    $this->db->select("ta.*")
          ->from("tb_website_slideshow ta");
    $this->db->where("ta.slideshow_display_menus", $slideshow_display_menus);
    $this->db->where("ta.slideshow_access_status = 'Activated'");
    $this->db->order_by("ta.slideshow_orders  ", "ASC");
    $this->db->limit($limit, $start);
    return $this->db->get()->result();

  }

	
}
?>
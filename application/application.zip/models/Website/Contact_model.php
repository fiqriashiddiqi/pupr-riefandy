<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact_model extends CI_Model {

	public function get_contact($contact_us_access_status = null)
    {   
        $this->db->select("tc.*")
          ->from("tb_website_contact_us tc");
     

        if (!empty($contact_us_access_status)){
          $this->db->where("tc.contact_us_access_status", $contact_us_access_status);
        }

        $this->db->order_by("tc.id_website_contact_us", "ASC");

        return $this->db->get()->result();

    }

  public function get_contact_by_id($id_website_contact_us)
    {   
        $this->db->select("tam.*")
          ->from("tb_webite_contact_us tam");

        $this->db->where("tam.id_website_contact_us", $id_website_contact_us);

      return $this->db->get()->result();
    }

  
}
?>
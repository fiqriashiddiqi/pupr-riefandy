<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Management_model extends CI_Model {

    public function get_management()
    {   
        $this->db->select("ta.*")
          ->from("tb_website_management ta");

    return $this->db->get()->result();
    }

    public function get_managementmenu($id_website_management)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_management_menu tam")
          ->join("tb_website_management ta","ta.id_website_management = tam.id_website_management");

        $this->db->where("ta.id_website_management", $id_website_management);
        $this->db->order_by("tam.id_website_management_menu", "ASC");

    return $this->db->get()->result();
    }
      public function get_managementmenu_list($limit = null, $position = null)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_management_menu tam")
          ->join("tb_website_management ta","ta.id_website_management = tam.id_website_management");

        if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("tam.id_website_management_menu", "ASC");

    return $this->db->get();
    }


    public function get_managementmenu_by_name($management_menu_name)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_management_menu tam");

        $this->db->where("tam.management_menu_name", $management_menu_name);
        $this->db->where("tam.management_menu_access_status = 'Activated'");
        $this->db->order_by("tam.management_menu_orders", "ASC");

    return $this->db->get()->result();
    }

    public function get_managementmenu_direk()
    {   
        $this->db->select("tam.*")
          ->from("tb_website_management_menu tam");

        $this->db->where("tam.management_menu_name", "Board Of Director");
        

    return $this->db->get()->result();
    }

    public function get_managementmenu_all()
    {   
        $this->db->select("tam.*")
          ->from("tb_website_management_menu tam")
          ->join("tb_website_management ta","ta.id_website_management = tam.id_website_management");

        $this->db->group_by("tam.management_menu_name");
        $this->db->order_by("tam.management_menu_orders", "ASC");

    return $this->db->get()->result();
    }

    public function get_managementmenu_by_id($id_website_management_menu)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_management_menu tam");

        $this->db->where("tam.id_website_management_menu", $id_website_management_menu);

    return $this->db->get()->result();
    }

}
?>
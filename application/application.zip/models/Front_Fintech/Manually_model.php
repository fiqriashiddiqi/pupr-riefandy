<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manually_model extends CI_Model {

    public function get_personal_info_borrower_commercial($id_borrower_loan)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_detail_commercial twb");
          $this->db->join('tb_fintech_borrower_loan ta', 'twb.register_code = ta.register_code');
         // $this->db->join('tb_fintech_lender_investment tc', 'ta.id_borrower_loan = tc.id_borrower_loan');
          
          $this->db->where("ta.id_borrower_loan",$id_borrower_loan);
          // $this->db->where("twb.register_code",$register_code);
        
        return $this->db->get()->result();

    }

    public function get_personal_info_borrower_consumptive($id_borrower_loan)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_detail_consumtive twb");
          $this->db->join('tb_fintech_borrower_loan ta', 'twb.register_code = ta.register_code');
         // $this->db->join('tb_fintech_lender_investment tc', 'ta.id_borrower_loan = tc.id_borrower_loan');
          
          $this->db->where("ta.id_borrower_loan",$id_borrower_loan);
          // $this->db->where("twb.register_code",$register_code);
        
        return $this->db->get()->result();

    }

    public function get_bio_borrower_loan($id_borrower_loan)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_bio twb");
          $this->db->join('tb_fintech_borrower_loan ta', 'twb.register_code = ta.register_code');
         // $this->db->join('tb_fintech_lender_investment tc', 'ta.id_borrower_loan = tc.id_borrower_loan');
          
          $this->db->where("ta.id_borrower_loan",$id_borrower_loan);
          // $this->db->where("twb.register_code",$register_code);
        
        return $this->db->get()->result();

    }

    public function get_data_borrower($id_borrower_loan)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");

          $this->db->join('tb_fintech_borrower_payment_periode ta', 'twb.id_borrower_loan = ta.id_borrower_loan');
         // $this->db->join('tb_fintech_lender_investment tc', 'ta.id_borrower_loan = tc.id_borrower_loan');
          
          $this->db->where("ta.id_borrower_loan",$id_borrower_loan);
          // $this->db->where("twb.register_code",$register_code);
        
        return $this->db->get()->result();

    }

    public function get_email_borrower($id_borrower_loan)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_register twb");

          $this->db->join('tb_fintech_borrower_loan ta', 'twb.register_code = ta.register_code');
          $this->db->join('tb_fintech_borrower_payment_periode tc', 'ta.id_borrower_loan = tc.id_borrower_loan');
          
          $this->db->where("ta.id_borrower_loan",$id_borrower_loan);
          //$this->db->where("twb.register_code",$register_code);
        
        return $this->db->get()->result();

    }


    public function get_autopurchase_set($loan_type, $loan_amount, $loan_tenor, $loan_rating)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        
        $this->db->where("twb.loan_type = '".$loan_type."'");
        $this->db->where("twb.amount_left >= '".$loan_amount."'");
        $this->db->where("twb.loan_tenor = '".$loan_tenor."'");
        $this->db->where("twb.loan_rating = '".$loan_rating."'");

        $this->db->where("twb.loan_status != 'Disbursed'");
        $this->db->where("twb.loan_status != 'Closed'");
        $this->db->where("twb.loan_status != 'Done'");
        $this->db->order_by("twb.id_borrower_loan", "ASC");

        return $this->db->get();

    }

	public function get_manually($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        
        //$this->db->where("twb.loan_status != 'Disbursed'");
        $this->db->where("twb.loan_status != 'Closed'");
        $this->db->where("twb.loan_status != 'Done'");
        
        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }  
          
        // $this->db->order_by("twb.id_borrower_loan", "ASC");
        $this->db->order_by("twb.amount_left", "DESC");
        $this->db->order_by("twb.time_left", "DESC");
        

        return $this->db->get();

    }

    public function get_manually_dis($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        
        $this->db->where("twb.loan_status != 'Closed'");
        $this->db->where("twb.loan_status != 'Crowdfunding'");
        $this->db->where("twb.loan_status != 'Done'");
        
        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }  
          
        $this->db->order_by("twb.id_borrower_loan", "ASC");

        return $this->db->get();

    }

    public function get_consumtive($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        
        //$this->db->where("twb.loan_status != 'Disbursed'");
        $this->db->where("twb.loan_status != 'Closed'");
        $this->db->where("twb.loan_status != 'Done'");
        $this->db->where("twb.loan_type = 'Personal Loan'");

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_borrower_loan", "ASC");

        return $this->db->get();

    }

    public function get_commercial_invoice($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        
        //$this->db->where("twb.loan_status != 'Disbursed'");
        $this->db->where("twb.loan_status != 'Closed'");
        $this->db->where("twb.loan_status != 'Done'");
        $this->db->where("twb.loan_type = 'Invoice Financing'");

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }
      
        $this->db->order_by("twb.id_borrower_loan", "ASC");

        return $this->db->get();

    }
     public function get_commercial_principal($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        
        //$this->db->where("twb.loan_status != 'Disbursed'");
        $this->db->where("twb.loan_status != 'Closed'");
        $this->db->where("twb.loan_status != 'Done'");
        $this->db->where("twb.loan_type = 'Fixed Loan'");

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }
      
        $this->db->order_by("twb.id_borrower_loan", "ASC");

        return $this->db->get();

    }
    
    public function get_commercial_revolver($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        
        //$this->db->where("twb.loan_status != 'Disbursed'");
        $this->db->where("twb.loan_status != 'Closed'");
        $this->db->where("twb.loan_status != 'Done'");
        $this->db->where("twb.loan_type = 'Flexible Loan'");

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_borrower_loan", "ASC");

        return $this->db->get();

    }

    public function get_score_list($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_param_score twb");
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_score", "ASC");

        return $this->db->get();

    }

    public function get_score_by_id($id_score)
    {   
        $this->db->select("tf.*")
          ->from("tb_param_score tf");

        $this->db->where("tf.id_score", $id_score);

      return $this->db->get()->result();
    }

    public function check_manually_invest($id_borrower_loan,$register_code)
    {   
        $this->db->select("tbg.id_borrower_loan, tbg.amount_invest")
          ->from("tb_fintech_lender_investment tbg");

        $this->db->where("tbg.id_borrower_loan", $id_borrower_loan);
        $this->db->where("tbg.register_code", $register_code);
        return $this->db->get();

    }

    public function get_manually_id($id_borrower_loan,$register_code)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        
          
          $this->db->where("twb.id_borrower_loan",$id_borrower_loan);
          $this->db->where("twb.register_code",$register_code);
        
        return $this->db->get();

    }

    public function get_principal_sum($register_code)
    {   
        $this->db->select("sum(tc.loan_principal) as total_principal")
          ->from("tb_fintech_borrower_loan tc");

        $this->db->where("tc.loan_status","Disbursed");
        $this->db->where("tc.register_code", $register_code);

    return $this->db->get()->result();
    }

    public function get_interest_sum($register_code)
    {   
        $this->db->select("sum(tc.loan_interest) as total_interest")
          ->from("tb_fintech_borrower_loan tc");

        $this->db->where("tc.loan_status","Disbursed");
        $this->db->where("tc.register_code", $register_code);

    return $this->db->get()->result();
    }

    
  
}
?>
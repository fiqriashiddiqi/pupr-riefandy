<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Faq_model extends CI_Model {

	public function get_faq($access_status = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_faq twb");
     

        if (!empty($faq_access_status)){
          $this->db->where("twb.faq_access_status", $faq_access_status);
        }

        $this->db->order_by("twb.id_fintech_faq", "ASC");

        return $this->db->get()->result();

    }
    public function get_faq_list($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_faq twb");
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_fintech_faq", "ASC");

        return $this->db->get();

    }

  public function get_faq_by_id($id_fintech_faq)
    {   
        $this->db->select("tf.*")
          ->from("tb_fintech_faq tf");

        $this->db->where("tf.id_fintech_faq", $id_fintech_faq);

      return $this->db->get()->result();
    }

  public function get_dropdown_faq_category()
    {   
        $this->db->select("tf.*")
          ->from("tb_fintech_faq tf");

        $this->db->group_by("tf.category_faq");
        $this->db->order_by("tf.id_fintech_faq", "ASC");

      return $this->db->get()->result();
    }
   
    public function get_faq_by_category($category_faq = null)
    {   
        $this->db->select("tf.*")
          ->from("tb_fintech_faq tf");

        if (!empty($category_faq)){
          $this->db->where("tf. category_faq", $category_faq);
        }


        $this->db->order_by("tf.id_fintech_faq", "ASC");

      return $this->db->get()->result();
    }
  
}
?>
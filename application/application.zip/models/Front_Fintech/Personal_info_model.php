<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Personal_info_model extends CI_Model {

    public function get_personal()
    {   
        $this->db->select("ta.*")
          ->from("tb_fintech_borrower_bio ta");

    return $this->db->get()->result();
    }

    public function get_personal_info_borrower($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_borrower_bio tam");

        $this->db->where("tam.register_code", $register_code);

    return $this->db->get()->result();
    }

    public function get_personal_info_borrower_period($id_borrower_loan)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_borrower_bio tam");
        $this->db->join('tb_fintech_borrower_payment tp','tam.register_code = tp.register_code');
        $this->db->where("tp.id_borrower_loan", $id_borrower_loan);

    return $this->db->get()->result();
    }

    public function get_personal_info_lender_inv($investment_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_bio tam");

        $this->db->join('tb_fintech_lender_investment tl','tam.register_code = tl.register_code');

        $this->db->where("tl.investment_code", $investment_code);

    return $this->db->get()->result();
    }



    public function get_personal_info_lender($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_bio tam");

        $this->db->where("tam.register_code ", $register_code);

    return $this->db->get()->result();
    }

    public function get_bio_lender_by_id($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_bio tam");

        $this->db->where("tam.register_code", $register_code);


    return $this->db->get()->result();
    }

    public function get_bio_borrower_by_id($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_bio tam");

        $this->db->where("tam.register_code", $register_code);


    return $this->db->get()->result();
    }

    public function get_email_borrower($register_code)
    {   
        $this->db->select("tam.register_email")
          ->from("tb_fintech_register tam");

        $this->db->where("tam.register_code", $register_code);


    return $this->db->get()->result();
    }

    public function get_email_lender($register_code)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_register twb");

          // $this->db->join('tb_fintech_borrower_loan ta', 'twb.register_code = ta.register_code');
          // $this->db->join('tb_fintech_borrower_payment_periode tc', 'ta.id_borrower_loan = tc.id_borrower_loan');
          
          $this->db->where("twb.register_code",$register_code);
          //$this->db->where("twb.register_code",$register_code);
        
        return $this->db->get()->result();

    }

    public function get_consumtive_borrower($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_borrower_detail_consumtive tam");

        $this->db->where("tam.register_code", $register_code);

    return $this->db->get()->result();
    }   

    public function get_commercial_borrower($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_borrower_detail_commercial tam");

        $this->db->where("tam.register_code", $register_code);
        

    return $this->db->get()->result();
    }

    public function get_commercial_by_id($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_borrower_detail_commercial tam");

        $this->db->where("tam.register_code", $register_code);


    return $this->db->get()->result();
    }

    public function get_file_commercial($register_code, $file_upload_name=null)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_file_commercial tam");

        $this->db->where("tam.register_code", $register_code);

        if (!empty($file_upload_name)){
            $this->db->where("tam.file_upload_name", $file_upload_name);
        }

       return $this->db->get()->result();
    }

    public function get_file_consumtive($register_code, $file_upload_name=null)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_file_consumtive tam");

        $this->db->where("tam.register_code", $register_code);

        if (!empty($file_upload_name)){
            $this->db->where("tam.file_upload_name", $file_upload_name);
        }

       return $this->db->get()->result();
    }

    public function check_status()
    {   
        $this->db->select("tam.*")
          ->from("tb_param_industry tam");

        $this->db->where("tam.bio_marriage_status = 'Activated'");
        return $this->db->get()->result();
    }

    public function get_industry_borrower()
    {   
        $this->db->select("tam.*")
          ->from("tb_param_industry tam");

        $this->db->where("tam.industry_access_status = 'Activated'");
        return $this->db->get()->result();
    }
    public function get_entity_borrower()
    {   
        $this->db->select("tam.*")
        ->from("tb_param_type_entity tam");

     $this->db->where("tam.entity_access_status = 'Activated'");


        return $this->db->get()->result();
    }

    public function get_business_entity_borrower()
    {   
        $this->db->select("tam.*")
        ->from("tb_param_entity_business tam");

        $this->db->where("tam.entity_access_status = 'Activated'");

        return $this->db->get()->result();
    }
    public function get_entity_borrower_by_id($id)
    {   
        $this->db->select("tam.*")
        ->from("tb_param_type_entity tam");

        $this->db->where("tam.id_param_entity", $id);

        return $this->db->get()->result();
    }

    public function get_business_entity_borrower_by_id($id)
    {   
        $this->db->select("tam.*")
        ->from("tb_param_entity_business tam");

        $this->db->where("tam.id_param_entity_business", $id);

        return $this->db->get()->result();
    }
    public function get_business_field_borrower()
    {   
        $this->db->select("tam.*")
        ->from("tb_param_business_field tam");
        
        $this->db->where("tam.business_field_access_status = 'Activated'");

        return $this->db->get()->result();
    }
}
?>
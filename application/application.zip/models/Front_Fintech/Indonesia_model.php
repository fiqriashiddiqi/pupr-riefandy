<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Indonesia_model extends CI_Model {



    public function get_province() 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_provinsi tip");

        $this->db->order_by("tip.nama", "ASC");
        return $this->db->get()->result();
    }

  	public function get_city($id_indonesia_provinsi)
    {   
        $this->db->select("tikk.*")
          ->from("tb_indonesia_kota_kab tikk");

        $this->db->where("tikk.id_indonesia_provinsi", $id_indonesia_provinsi);  
        $this->db->order_by("tikk.nama", "ASC");
        return $this->db->get()->result();
    }

    public function get_district($id_indonesia_kota_kab)
    {   
        $this->db->select("tik.*")
          ->from("tb_indonesia_kec tik");

        $this->db->where("tik.id_indonesia_kota_kab", $id_indonesia_kota_kab);  
        $this->db->order_by("tik.nama", "ASC");
        return $this->db->get()->result();
    }

    public function get_village($id_indonesia_kec)
    {   
        $this->db->select("tikd.*")
          ->from("tb_indonesia_kel_des tikd");

        $this->db->where("tikd.id_indonesia_kec", $id_indonesia_kec);  
        $this->db->order_by("tikd.nama", "ASC");
        return $this->db->get()->result();
    }
    
    public function get_province_by_id($id_indonesia_provinsi = null , $name_province = null) 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_provinsi tip");
        
        if(!empty($id_indonesia_provinsi)){
        $this->db->where("tip.id_indonesia_provinsi", $id_indonesia_provinsi);
        }
        if(!empty($name_province)){
        $this->db->where("tip.nama", $name_province);
        }

        return $this->db->get()->result();
    }

    public function get_city_by_id($id_indonesia_kota_kab = null , $name_city = null) 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_kota_kab tip");

        if(!empty($id_indonesia_kota_kab)){
        $this->db->where("tip.id_indonesia_kota_kab", $id_indonesia_kota_kab);
        }
        if(!empty($name_city)){
        $this->db->where("tip.nama", $name_city);
        }
        return $this->db->get()->result();
    }

    public function get_district_by_id($id_indonesia_kec = null , $name_district = null) 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_kec tip");

        if(!empty($id_indonesia_kec)){
        $this->db->where("tip.id_indonesia_kec", $id_indonesia_kec);
        }
        if(!empty($name_district)){
        $this->db->where("tip.nama", $name_district);
        }
        return $this->db->get()->result();
    }

    public function get_village_by_id($id_indonesia_kel_des = null , $name_village = null) 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_kel_des tip");

        if(!empty($id_indonesia_kel_des)){
        $this->db->where("tip.id_indonesia_kel_des", $id_indonesia_kel_des);
        }
        if(!empty($name_village)){
        $this->db->where("tip.nama", $name_village);
        }    
        return $this->db->get()->result();
    }

    public function get_province_business_by_id($id_indonesia_provinsi, $name_province = null) 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_provinsi tip");
        

        $this->db->where("tip.id_indonesia_provinsi", $id_indonesia_provinsi);

        if(!empty($name_province)){
        $this->db->where("tip.nama", $name_province);
        }

        return $this->db->get()->result();
    }

    public function get_city_business_by_id($id_indonesia_kota_kab, $name_city = null) 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_kota_kab tip");

        
        $this->db->where("tip.id_indonesia_kota_kab", $id_indonesia_kota_kab);
        
        if(!empty($name_city)){
        $this->db->where("tip.nama", $name_city);
        }
        return $this->db->get()->result();
    }

    public function get_district_business_by_id($id_indonesia_kec, $name_district = null) 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_kec tip");

        
        $this->db->where("tip.id_indonesia_kec", $id_indonesia_kec);
        
        if(!empty($name_district)){
        $this->db->where("tip.nama", $name_district);
        }
        return $this->db->get()->result();
    }

    public function get_village_business_by_id($id_indonesia_kel_des, $name_village = null) 
    {   
        $this->db->select("tip.*")
          ->from("tb_indonesia_kel_des tip");

        
        $this->db->where("tip.id_indonesia_kel_des", $id_indonesia_kel_des);
        
        if(!empty($name_village)){
        $this->db->where("tip.nama", $name_village);
        }    
        return $this->db->get()->result();
    }

}

?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Register_model extends CI_Model {



    public function register_code($reg_ID) 
    {   
        return $this->db->query("SELECT max(register_code) as maxID 
        FROM tb_fintech_register WHERE register_code LIKE '".$reg_ID."%'")->result();
    }

    public function term_code($reg_ID) 
    {   
        return $this->db->query("SELECT max(term_id) as maxID 
        FROM tb_fintech_term_lender WHERE register_code LIKE 'SA-%'")->result();
    }

    public function term_code_borrower($reg_ID) 
    {   
        return $this->db->query("SELECT max(term_id) as maxID 
        FROM tb_fintech_term_borrower WHERE register_code LIKE 'SA-%'")->result();
    }

    public function reference_code() 
    {   
        return $this->db->query("SELECT max(reference_code) 
        FROM tb_fintech_register WHERE reference_code LIKE 'REF-%'")->result();
    }

  	public function get_register_by_id($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_register tam");

        $this->db->where("tam.register_code", $register_code);


    return $this->db->get()->result();
    }

     public function get_nik_borrower($cek_ktp_nik)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_cek_ktp tc");

        $this->db->where("tc.cek_ktp_nik", $cek_ktp_nik);
     
        return $this->db->get()->result();

    }

    public function get_lender_list($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_register twb");

        $register_status='Lender';
        $this->db->where("twb.register_status", $register_status);
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.register_code", "ASC");

        return $this->db->get();

    }

    public function get_lender_bio()
    {   
        $this->db->select("tl.*")
          ->from("tb_fintech_lender_bio tl");
        $this->db->join('tb_fintech_register ta', 'tl.register_code = ta.register_code');

        // $this->db->where("tl.register_code", $register_code);

        return $this->db->get()->result();

    }

    public function get_borrower_list($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_register twb");

        $register_status='Borrower';
        $this->db->where("twb.register_status", $register_status);
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.register_code", "ASC");

        return $this->db->get();

    }
  
}

?>
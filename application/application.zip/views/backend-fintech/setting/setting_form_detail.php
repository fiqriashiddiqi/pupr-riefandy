<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
        <div class="box" id="">
            <div class="box-header with-border">
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
              <div class="form-group">
                <div class="box-body">
              
              <div class="form-group">
                  <input type="hidden" value="<?php echo $data_contact[0]->id_setting; ?>" name="id_setting" required="true">
                  <label for="setting_pagination">Set Limit Pagination</label>
                  <input type="number" class="form-control" id="setting_pagination" name="setting_pagination" value="<?php echo $data_contact[0]->setting_pagination; ?>" placeholder="Set Pagination" required="true">
              </div>
              <div class="form-group">
                  <label for="setting_pagination">Set Format Registration Code</label>
                  <input type="text" class="form-control" name="reg_ID" value="<?php echo $data_contact[0]->reg_ID; ?>" placeholder="Set Format Registration Code" required="true">
              </div>
              <div class="form-group">
                  <label for="setting_pagination">Set Point Reference</label>
                  <input type="number" class="form-control" name="point_reference" value="<?php echo $data_contact[0]->point_reference; ?>" placeholder="Set Point Reference" required="true">
              </div>
              <div class="form-group">
                  <label for="setting_pagination">Set Point Investment</label>
                  <input type="number" class="form-control" id="setting_pagination" name="point_invest" value="<?php echo $data_contact[0]->point_invest; ?>" placeholder="Set Point Investment" required="true">
              </div>
              <div class="form-group">
                  <label for="setting_pagination">Set Point Exchange</label>
                  <input type="number" class="form-control" id="setting_pagination" name="point_exchange" value="<?php echo $data_contact[0]->point_exchange; ?>" placeholder="Set Point Exchange" required="true">
              </div>
              <div class="form-group">
                  <label for="setting_pagination">Set Commision Borrower</label>
                  <input type="number" class="form-control" id="setting_pagination" name="commision_borrower" value="<?php echo $data_contact[0]->commision_borrower; ?>" placeholder="Set Commision Borrower" required="true">
              </div>
              <div class="form-group">
                  <label for="setting_pagination">Set Commision Lender</label>
                  <input type="number" class="form-control" id="setting_pagination" name="commision_lender" value="<?php echo $data_contact[0]->commision_lender; ?>" placeholder="Set Commision Lender" required="true">
              </div>
              <div class="form-group">
                  <label for="setting_pagination">Set Penalty</label>
                  <input type="number" class="form-control" id="setting_pagination" name="penalty" value="<?php echo $data_contact[0]->penalty; ?>" placeholder="Set Penalty" required="true">
              </div>
              <div class="form-group">
                  <label for="setting_pagination">Set Fee Payment Gateway</label>
                  <input type="text" class="form-control dengan-rupiah" id="setting_pagination" name="fee_pg" value="Rp. <?php echo number_format($data_contact[0]->fee_pg,0,".","."); ?>" placeholder="Set Fee Payment Gateway" required="true">
              </div>
              
              </div>
              <!-- /.box-body -->
              <div class="box-footer text-right">
                <button type="submit" class="btn btn-success btn-sm btnbig"><i class="fa fa-fa-save"></i>Save / Update</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>


        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->

<script src="<?php echo base_url() ?>assets/Sanders/js/jquery-1.4.js"></script>
<script type="text/javascript">
   $(function() {
        $('.dengan-rupiah').on('keyup', function(e){
            var dengan_rupiah = formatRupiah(this.value, 'Rp. ');
            $('.dengan-rupiah').val(dengan_rupiah);
        });
    });

   function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split   = number_string.split(','),
            sisa    = split[0].length % 3,
            rupiah  = split[0].substr(0, sisa),
            ribuan  = split[0].substr(sisa).match(/\d{3}/gi);
            

        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
</script>



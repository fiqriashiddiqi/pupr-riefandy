<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>

        <div class="box" id="">  
            <div class="box-header with-border">
              
            </div>
            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                  <label for="entity_business_name">Business Entity Name</label>
                  <input type="text" class="form-control" name="entity_business_name" maxlength="100" placeholder="Entity Name" required="true">
                  <span style="color: #dd4b39; font-size: 12px">*max 100 character.</span>
              </div>
              <div class="form-group">
                  <label for="entity_business_score">Business Entity Score </label>
                  <input type="number" class="form-control"  name="entity_business_score" min="0.00" max="9999.99" step="1" placeholder="Entity Score" required="true">
                  <span style="color: #dd4b39; font-size: 12px">*data max min 0.00 max 9999.99</span>
              </div>
              <div class="form-group">
                <label>Posting Status</label>
                <select class="form-control select2" name="entity_access_status" style="width: 100%;" required="true">
                  <option value="">- Choose Status -</option>
                  <option value="Activated">Active</option>
                  <option value="Deactivated">Deactive</option>
                </select>
              </div>
              <div class="box-footer text-right">
                 <a href="<?php echo $back_url; ?>" id="info" class="btn btn-warning btn-sm btnwdt">Back</a>
                <button type="submit" class="btn btn-success btnbig">Save</button>
              </div>
            
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>

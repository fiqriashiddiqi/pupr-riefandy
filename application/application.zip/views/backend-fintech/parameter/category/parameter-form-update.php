<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>

         <div class="box">  
            <div class="box-header with-border">
            <div class="col-md-12 col-sm-12">  
            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
            <h4><strong>Category Edit & Option</strong></h4>
            <button type="submit" class="btn btn-success btn-sm btnbig2" style="float: right;">Save / Update</button>
            <p style="font-size: 10px;">&nbsp;</p>
            
               <div  class="form-group" ">
                  <label>Category Parameter</label>
                  <select class="form-control select2"  name="id_category" style="width: 100%;">
                   <option value="<?php echo $default_category[0]->id_category;?>"><?php echo $default_category[0]->category_name;?></option>
                  

                  <?php
                        foreach ($dropdown_category as $category_entry) {
                  ?>
                        <option value="<?php echo $category_entry->id_category; ?>"><?php echo $category_entry->category_name; ?></option>

                  <?php
                        }
                  ?>

                </select>
                  <span style="color: #dd4b39;">.</span>
              </div>
                <div class="form-group">
                  <label>Parameter Name</label>
                   <input type="hidden" name="id_parameter" value="<?php echo $data_parameter[0]->id_parameter; ?>">
                  <input type="text" class="form-control" name="parameter_name" maxlength="50" placeholder="Parameter Name" required="true" value="<?php echo $data_parameter[0]->parameter_name; ?>">
                  <span style="color: #dd4b39; font-size: 12px">*max 50 character.</span> 
              </div>

              <div class="form-group">
                <?php 
                if ($data_parameter[0]->parameter_access_status == 'Activated'){
                    $activated = "selected"; 
                    $deactivated = "";
                } else {
                    $activated = "";
                    $deactivated = "selected";
                }
                ?>
                <label>Posting Status</label>
                <select class="form-control select2" name="parameter_access_status" style="width: 100%;" required="true">
                  <option value="">- Choose Status -</option>
                  <option value="Activated"<?php echo @$activated ?>>Active</option>
                  <option value="Deactivated"<?php echo @$deactivated ?>>Deactive</option>
                </select>
              </div>

            </form>
            </div>
          </div>
        </div>

        <div class="box">
            <div class="box-header with-border">
              <div class="row">
              <div class="col-lg-6 col-xs-12">
              <h4><strong>Paramater Option</strong></h4>
              </div>
              <div class="col-lg-6 col-xs-12 text-right">
                <a href="<?php echo $create_url; ?>" class="btn-primary btn-sm btn btnbig2">Add Option</a>
              </div>
              </div>
            </div>
          
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12">
              <div class="col-xs-12 col-lg-12" style="overflow-y: auto;">
              <table id="" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Paramater Option Name</th>
                    <th>Paramater Option Math</th>
                    <th>Paramater Option Score</th>
                    <th style="width: 80px;  text-align: center;">Action</th>               
                    
                </tr>
                </thead>
                <tbody>
                <?php
                  $no = 0;
                  foreach ($data_parameter_option as $parameter_option_entry){
                  $no++;

                
                ?>
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $parameter_option_entry->option_name; ?></td>  
                  <td><?php echo $parameter_option_entry->option_math; ?></td>   
                  <td><?php echo $parameter_option_entry->option_score; ?></td>       
                  <td class="text-center">
                      
                      <a href="#" id="delete" onclick="delete_data(<?php echo $parameter_option_entry->id_parameter; ?>, <?php echo $parameter_option_entry->id_parameter_option; ?>)" class="btn-danger btn-sm btn btnwdt" >Delete</a>

                  </td>
                </tr>
                <?php } 
                ?>

                </tbody>
              </table>
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>

          
        </div>
      </div>
    </section>
  </div>
<script type="text/javascript">
    function delete_data(id_parameter,id_parameter_option)
    {
        bootbox.confirm({
        title: "Deleting Data?",
        message: "Do you want to delete this data?",
        buttons: {
            cancel: {
                label: '<i class="fa fa-times"></i> Cancel',
                className: 'btn-default'
            },
            confirm: {
                label: '<i class="fa fa-check"></i> Delete',
                className: 'btn-danger'
            }
        },
        callback: function (result) {
            if (result == true){
                window.location = "<?php echo $delete_url; ?>/" + id_parameter + "/" + id_parameter_option;
            } else {
                event.preventDefault();
            }
        }
        });
    }
</script>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">

                 <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
        <div class="box" id="">
            <div class="box-header with-border">
          
              
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
                 <div class="form-group">
                   <input type="hidden" value="<?php echo $data_faq[0]->id_fintech_faq; ?>" name="id_fintech_faq" required="true">
               
                  <label>Faq Category</label>
                  <select class="form-control select2"  name="category_faq"  style="width: 100%;   ">
                    <?php
                        if ($data_faq[0]->category_faq == "Internet Banking"){
                            $internet = "selected";
                        } else if($data_faq[0]->category_faq == "ATM"){
                            $atm = "selected";
                        } else if($data_faq[0]->category_faq == "Bank Teller"){
                            $teller = "selected";
                        } else if($data_faq[0]->category_faq == "Mobile Banking"){
                            $mobile = "selected";
                        } else if($data_faq[0]->category_faq == "Other"){
                            $other = "selected";
                        } else {
                            $default = "selected";
                        }
                    ?>
                        <option value="" <?php echo @$default; ?>>- Choose Access Status -</option>
                        <option value="Internet Banking" <?php echo @$internet; ?>>Internet Banking</option>
                        <option value="ATM" <?php echo @$atm; ?>>ATM</option>
                        <option value="Bank Teller" <?php echo @$teller; ?>>Bank Teller</option>
                        <option value="Mobile Banking" <?php echo @$mobile; ?>>Mobile Banking</option>
                        <option value="Other" <?php echo @$other; ?>>Other</option>
                   </select>
                  <span style="color: #dd4b39;">.</span>
             
              </div>
   
              <div class="form-group">
                  <label >Question</label>
                   <textarea class="form-control" name="question_faq" required="true" maxlength="300" placeholder="Place Some Question" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"> <?php echo $data_faq[0]->question_faq; ?></textarea>
                   <span style="color: #dd4b39; font-size: 12px">*max 300 character.</span>
                  
              </div>
              <div class="form-group">
                  <label for="answer_faq">Answer</label>
                   <textarea class="texteditor form-control" name="answer_faq" required="true" maxlength="300" placeholder="Place Some answer" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $data_faq[0]->answer_faq; ?></textarea>
                   <span style="color: #dd4b39; font-size: 12px">*max 300 character.</span>
              </div>
           
              <?php if ($profile_true != 'profile'){ ?>
              <div class="form-group">
                <?php 
                if ($data_faq[0]->faq_access_status == 'Activated'){
                    $activated = "selected"; 
                    $deactivated = "";
                } else {
                    $activated = "";
                    $deactivated = "selected";
                }
                ?>
                <label>Posting Status</label>
                <select class="form-control select2" name="faq_access_status" style="width: 100%;" <?php echo $data_faq[0]->faq_access_status; ?> required="true">
                  <option value="">- Choose Status -</option>
                  <option value="Activated"<?php echo @$activated ?>>Active</option>
                  <option value="Deactivated"<?php echo @$deactivated ?>>Deactive</option>
                </select>
              </div>
              <?php } ?>
              <!-- /.box-body -->
              <div class="box-footer text-right">
                <a href="<?php echo $back_url; ?>" id="info" class="btn btn-warning btn-sm btnwdt">Back</a>
                <button type="submit" class="btn btn-success btn-sm btnbig"><i class="fa fa-fa-save"></i> Save / Update</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->


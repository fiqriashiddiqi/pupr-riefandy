<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } 
          ?>
          <div class="box">
            <h3 style="text-align: left; margin-left: 2%;">Data Investor <?php echo @$data_code[0]->bio_fullname; ?></h3>
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12" >
              <div class="col-xs-12 col-lg-12" style="overflow-y: auto;">
              <table id="" class="table table-bordered table-striped">
                <thead>
            
                </thead>
                <tbody>
                
                <div class="col-md-6 col-sm-12 col-xs-12" id="left3"> 
                    <br>
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" value="<?php echo @$data_code[0]->bio_fullname; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Birth Place</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_place_birth_date; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Birthdate</label>
                        <input type="date" value="<?php echo $data_code[0]->bio_birth_date; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Gender</label>
                        <select class="form-control" style="width: 100%;" disabled>
                            <?php   if ($data_code[0]->bio_gender == 'Male') {
                                                $Male  = 'selected';
                                            } else if ($data_code[0]->bio_gender == 'Female') {
                                                $Female = 'selected';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?> >- Choose Statement -</option>
                              <option value="Male" <?php echo @$Male;?> >Male</option>
                              <option value="Female" <?php echo @$Female;?> >Female</option>          
                           </select>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_phone; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" style="width: 100%;" disabled>
                                    <?php   
                                        if ($data_code[0]->bio_marriage_status == 'Married') {
                                                $Married  = 'selected';
                                            } else if ($data_code[0]->bio_marriage_status == 'Single') {
                                                $Single = 'selected';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                              <option value="Married" <?php echo @$Married;?>>Married</option>
                              <option value="Single" <?php echo @$Single;?>>Single</option>  
                           
                           </select>
                    </div>
                    <?php
                    if ($data_code[0]->bio_marriage_status == 'Married'){
                    ?>
                    <div class="form-group">
                        <label>Spouse Name</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_spouse_name; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Spouse Phone</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_spouse_phone; ?>" class="form-control" readonly>
                    </div>
                    <?php
                    }
                    ?>
                    <div class="form-group">
                        <label>Last Education</label>
                        <select class="form-control" style="width: 100%;" disabled>
                                    <?php   
                                        if ($data_code[0]->bio_last_education == 'SMP') {
                                                $SMP  = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'SMA') {
                                                $SMA = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'D3') {
                                                $D3 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S1') {
                                                $S1 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S2') {
                                                $S2 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S3') {
                                                $S3 = 'selected';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                              <option value="SMP"<?php echo @$SMP;?>>SMP</option>
                              <option value="SMA"<?php echo @$SMA;?>>SMA</option>
                              <option value="D3" <?php echo @$D3;?>>D3</option>
                              <option value="S1" <?php echo @$S1;?>>S1</option>
                              <option value="S2" <?php echo @$S2;?>>S2</option>
                              <option value="S3" <?php echo @$S3;?>>S3</option>
                                           
                             </select>
                    </div>
                    <div class="form-group">
                        <label>Occupation</label>
                        <select class="form-control" disabled>
                                    <?php   
                                        if ($data_code[0]->bio_occupation == 'Wiraswasta') {
                                                $Wiraswasta  = 'selected';
                                            } else if ($data_code[0]->bio_occupation == 'Karyawan Swasta') {
                                                $Karyawan  = 'selected';
                                                $display = "none";
                                            } else if ($data_code[0]->bio_occupation == 'Pegawai Negeri Sipil') {
                                                $PNS = 'selected';
                                                $display = "none";
                                            } else if ($data_code[0]->bio_occupation == 'TNI/POLRI') {
                                                $TNI_POLRI = 'selected';
                                                $display = "none";
                                            }else if ($data_code[0]->bio_occupation == 'Pensiunan') {
                                                $Pensiunan = 'selected';
                                                $display = "none";
                                            }else if ($data_code[0]->bio_occupation == '') {
                                                $default  = 'selected';
                                                $display = "none";
                                            }else {
                                                $Others = 'selected';
                                                $display = "block";
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?>>- Choose Occupation -</option>
                              <option value="Wiraswasta" <?php echo @$Wiraswasta;?>>Wiraswasta</option>
                              <option value="Karyawan Swasta"<?php echo @$Karyawan;?> >Karyawan Swasta</option>
                              <option value="Pegawai Negeri Sipil"<?php echo @$PNS;?> >Pegawai Negeri Sipil</option>
                              <option value="TNI/POLRI" <?php echo @$TNI_POLRI;?>>TNI/POLRI</option>
                              <option value="Pensiunan" <?php echo @$Pensiunan;?>>Pensiunan</option>
                              <option value="Others" <?php echo @$Others;?>>Others</option>
                          </select>
                        
                    </div>
                    <div class="form-group">
                        <input class="form-control select2" name="bio_occupation_others" value="<?php echo $data_code[0]->bio_occupation; ?>" placeholder="Write your Statement" type="text" id="dummyText" style="display: <?php echo @$display ?>;" disabled>
                    </div>
                    <div class="form-group">
                        <label>Reference Code</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_reference_code; ?>" class="form-control" readonly>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <br>
                    <div class="form-group">
                        <label>Citizenship</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_cityzenship; ?>" class="form-control" readonly>
                    </div>

                    <?php 
                    if($data_code[0]->bio_cityzenship == "WNI"){
                    ?>
                    <div class="form-group">
                        <label>KTP / NIK</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_nik; ?>" class="form-control" readonly>
                        <br>
                     
                         <img id="ktp_lender" src="<?php echo base_url();?>uploads/Fintech/ktp_lender/<?php echo @$data_code[0]->bio_upload_nik;?>" style="width: 100%; height: 150px; border: 1px solid;">
                      
                    </div>
                    <div class="form-group hidden">
                        <label>Country / State</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_country; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Province</label>
                        <input type="text" value="<?php echo $data_province[0]->nama; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" value="<?php echo $data_city[0]->nama; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>District</label>
                        <input type="text" value="<?php echo $data_district[0]->nama; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Village</label>
                        <input type="text" value="<?php echo $data_village[0]->nama; ?>" class="form-control" readonly>
                    </div>
                    <?php 
                    } else {
                    ?>
                    <div class="form-group">
                        <label>Passport Number</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_passport; ?>" class="form-control" readonly>
                        <br>
                        <?php 
                            if($data_code[0]->bio_upload_passport == "-"){
                                $passport_lender = "noimage.jpg";
                            } else {
                                $passport_lender = $data_code[0]->bio_upload_passport;
                            }
                        ?>
                        <img src="<?php echo base_url();?>uploads/Fintech/passport_lender/<?php echo $passport_lender; ?>" style="width: 100%; height: 150px; border: 1px solid;">

                    </div>
                    <div class="form-group">
                        <label>Country / State</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_country; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Province</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_province; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_city; ?>" class="form-control" readonly>
                    </div>
                    <?php 
                    }
                    ?>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <textarea rows="3" value="" class="form-control" readonly><?php echo $data_code[0]->bio_address; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Post Code</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_post_code; ?>" class="form-control" readonly>
                    </div>
             
                </tbody>
              </table>
              <div class="box">
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12" >
              <div class="col-xs-12 col-lg-12" style="overflow-y: auto;">
              <table id="" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Investment Code</th>
                  <th>Name</th>
                  <th>Date</th>
                  <th>Payment Amount</th>
                  <th>Fee</th>
                  <th>Status</th>
                  <!-- <th width="180" style="text-align: center;">Action</th> -->
                </tr>
                </thead>
                <tbody>
                <?php
                $this->load->model("crud_model");
                $data_setting = $this->crud_model->get_setting();
                $limit   = $data_setting[0]->setting_pagination;
                $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

                
                if(empty($page)){
                    $position  = 0;
                    $page = 1;
                } else {
                    $position = ($page-1) * $limit;
                }

                // $this->load->model('Front_Fintech/account_model');
                // $get_invest = $this->account_model->get_investment($limit,$position)->result();

                $no = $position+1;
                   foreach ($get_invest_payment as $invest_entry){
                    $register_code = $get_invest[0]->register_code;
                    $data_bio = $this->personal_info_model->get_personal_info_lender_inv($invest_entry->investment_code);
                
                ?>   
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $invest_entry->investment_code; ?></td>
                  <td><?php echo $data_bio[0]->bio_fullname; ?></td>
                  <td><?php echo date('d/m/Y', strtotime ($invest_entry->payment_date)); ?></td>
                  <td>Rp. <?php echo number_format($invest_entry->payment_amount,0,".","."); ?></td>
                  <td>Rp. <?php echo number_format($invest_entry->payment_fee,0,".","."); ?></td>
                  <td><?php echo $invest_entry->payment_status; ?></td>

                  <!-- <td class="text-center"><a href="<?php echo $info_url; ?>/<?php echo $payment_entry->id_borrower_payment; ?>" id="info" class="btn btn-info btn-sm btnwdt">Detail</a></td> -->
                </tr>
                <?php
                    $no++;
                 } 
                ?>
                </tbody>
              </table>
               <?php
                $data_rows = $this->payment_model->get_invest_payment()->num_rows();
                $all_page  = ceil($data_rows/$limit);
                ?>
                <center>
                <ul class="pagination">
                    <li>
                        <?php
                            if($page > 1){
                                $prev = $page-1;
                                echo "<a href='".base_url()."Manager/b_history_payment?page=$prev'>Previous</a>";
                            }
                        ?>
                    </li>
                    <li>
                        <?php
                            for($i=1;$i<=$all_page;$i++)
                                if ($i != $page){
                                    echo "<a href='".base_url()."Manager/b_history_payment?page=$i'>$i</a>";
                                }
                        ?>
                        </li>
                        <li>
                        <?php
                            if($page < $all_page){
                                $next=$page+1;
                                echo "<a href='".base_url()."Manager/b_history_payment?page=$next'>Next</a>";
                            }
                        ?>
                    </li>
                </ul>
                </center>
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
             
                <center>
               
                </center>
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->


<?php 
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data-Pengguna.xls");
?>
<html>
<body>
<center>
                            <h3>Data Pengguna</h3>
          
                            <table width="1000" border="1">
                                <thead>
                                    <tr style="background-color: lightblue;">
                                        <th style="text-align: center;">No</th>
                                        <th style="text-align: center;">Nama Pengguna</th>
                                        <th style="text-align: center;">E-mail</th>
                                        <th style="text-align: center;">No Handphone</th>
                                        <th style="text-align: center;">Hak Akses</th>
                                        <th style="text-align: center;">Status Akses</th>
                                        <th style="text-align: center;">Terakhir Login</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                      $no = 0;
                                      foreach ($data_users as $users_entry){
                                      $no++;
                  
                                    ?>
                                    <tr>
                                        <td><?php echo $no; ?></td>
                                        <td><?php echo $users_entry->name_users; ?></td>
                                        <td><?php echo $users_entry->email_users; ?></td>
                                        <td><?php echo $users_entry->phones_users; ?></td>
                                        <td><?php echo $users_entry->name_groups; ?></td>
                                        <td class="text-center">
                                        <?php 
                                          if($users_entry->status_access == '1'){
                                          echo "Aktif";
                                          } else {
                                          echo "Tidak Aktif";
                                          }
                                        ?>
                                        </td>
                                        <td class="text-center"><?php echo date('H:i:s - d/m/Y', strtotime($users_entry->last_signout)); ?></td>
                                    </tr>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
</center>
</body>
</html>
<?php 
    echo"<script>alert('Mendownload Data Pengguna.')</script>";
    echo "<script>history.back(1)</script>";
?>
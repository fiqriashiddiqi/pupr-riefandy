<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
                 <div class="col-lg-12 col-xs-12 ">
               
              </div>
              </div>
            </div>
          
            
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12" >
              <div class="col-xs-12 col-lg-12" style="overflow-y: auto;">
              <table id="" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Menus Name</th>
                  <th>Controller</th>
                  <th>Favicon</th>
                  <th>Sub Menus</th>
                  <th width="100" style="text-align: center;">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                  date_default_timezone_set("Asia/Jakarta");
                
                  $no = 0;
                  foreach ($data_submenus as $submenus_entry){
                  $no++;
                  
                ?>
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $submenus_entry->menus_name; ?></td>
                  <td><?php echo $submenus_entry->menus_controller; ?></td>
                  <td><?php echo $submenus_entry->menus_favicon; ?></td>
                  <td class="text-center"><?php echo $submenus_entry->menus_submenus_status; ?></td>
                  <td class="text-center">

                    <a href="<?php echo $info_url; ?>/<?php echo $submenus_entry->id_backend_menus; ?>" id="info" class="btn btn-info btn-sm btnwdt">Detail</a>

                  </td>
                </tr>
                <?php } ?>
                </tbody>
              </table>
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>



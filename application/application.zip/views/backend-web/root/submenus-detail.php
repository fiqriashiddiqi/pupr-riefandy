<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"><?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
                 <div class="col-lg-12 col-xs-12 ">
                
              </div>
              <div class="col-lg-6 col-xs-12">
              </div>
              <div class="col-lg-6 col-xs-12 text-right">
              <a href="<?php echo $create_url; ?>" class="btn-primary btn-sm btn btnbig2">Add Submenus</a>
              </div>
              </div>
            </div>
          
            
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12" >
              <div class="col-xs-12 col-lg-12" style="overflow-y: auto;">
              <table id="table-test" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Submenus Name</th>
                  <th>Function</th>
                  <th width="30" style="text-align: center;">Order</th>
                  <th width="180" style="text-align: center;">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                  date_default_timezone_set("Asia/Jakarta");
                
                  $no = 0;
                  foreach ($data_submenus as $submenus_entry){
                  $no++;
                  
                ?>
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $submenus_entry->submenus_name; ?></td>
                  <td><?php echo $submenus_entry->submenus_controller; ?></td>
                  <td class="text-center">
                    <input type="number" class="text-center" onchange="change_order(<?php echo $submenus_entry->id_backend_submenus; ?> , this.value)" value="<?php echo $submenus_entry->submenus_orders; ?>" maxlength="4" size="1" min="1" step="1" max="9999" style="border: none; background: transparent;"></td>
                  <td class="text-center">

                    <?php                     
                    if ($submenus_entry->submenus_access_status == "Activated"){
                    ?>

                      <input type="checkbox" name="submenus_access_status" onchange="loaddata(<?php echo $submenus_entry->id_backend_submenus; ?>)" checked data-toggle="toggle" value="">
                    
  
                    <?php
                    } else {
                    ?>

                      <input type="checkbox" name="submenus_access_status" onchange="loaddata(<?php echo $submenus_entry->id_backend_submenus; ?>)" data-toggle="toggle" value="">

                    <?php
                    }
                    ?>

                    <a href="<?php echo $update_url; ?>/<?php echo $submenus_entry->id_backend_menus; ?>/<?php echo $submenus_entry->id_backend_submenus; ?>" id="info" class="btn btn-info btn-sm btnwdt">Detail</a>

                    <a href="#" id="delete" onclick="delete_data(<?php echo $submenus_entry->id_backend_menus; ?>,<?php echo $submenus_entry->id_backend_submenus; ?>)" class="btn-danger btn-sm btn btnwdt" >Delete</a>

                  </td>
                </tr>
                <?php } ?>
                </tbody>
              </table>
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>

<script type="text/javascript">
  function loaddata(id_backend_submenus)
  {
    var id_backend_submenus = id_backend_submenus;

    $.ajax({
          type: 'POST',
          url: "<?php echo base_url(); ?>Website/B_submenus/access_status_exchange",
          data: {
            id_backend_submenus : id_backend_submenus
          },

          success: function() {
             //alert('DONE' + id_aboutmenu);
     
          }
    });

    event.preventDefault();

  }
  </script>


<script type="text/javascript">
    function delete_data(id_backend_menus,id_backend_submenus)
    {
        bootbox.confirm({
        title: "Deleting Data?",
        message: "Do you want to delete this data?",
        buttons: {
            cancel: {
                label: '<i class="fa fa-times"></i> Cancel',
                className: 'btn-default'
            },
            confirm: {
                label: '<i class="fa fa-check"></i> Delete',
                className: 'btn-danger'
            }
        },
        callback: function (result) {
            if (result == true){
                window.location = "<?php echo $delete_url; ?>/" + id_backend_menus + "/" + id_backend_submenus;
            } else {
                event.preventDefault();
            }
        }
        });
    }
</script>

<script type="text/javascript">
  function change_order(id_backend_submenus, value_order)
  {
    var id_backend_submenus = id_backend_submenus;
    var value_order = value_order;

    $.ajax({
          type: 'POST',
          url: "<?php echo base_url(); ?>Website/B_submenus/change_order",
          data: {
            id_backend_submenus : id_backend_submenus,
            value_order : value_order
          },

          success: function() {
             // alert('Success To Change Order');
     
          }
    });
    event.preventDefault();
  }
  </script>

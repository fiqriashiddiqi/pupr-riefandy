<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
           <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
            
        <div class="box" id="">
            <div class="box-header with-border">
            
                
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
              <div class="form-group">
                  <label for="videos_name">Home Title Video</label>
                  <input type="hidden" name="id_website_videos" value="<?php echo $data_video[0]->id_website_videos; ?>">
                  <input type="text" class="form-control" id="videos_name" name="videos_name" maxlength="50" placeholder="Video title" required="true" value="<?php echo $data_video[0]->videos_name; ?>">
                  <!-- <span style="color: #dd4b39;">* Isi Deskripsi Data Perumahan.</span> -->
                  <span style="color: #dd4b39; font-size: 12px">*max 50 character.</span>
              </div>


              <div class="form-group">
                  <label>Home Header Video</label>
                  <input type="text" class="form-control" name="link_video" required="required" placeholder="Youtube Url Video" value="<?php echo $data_video[0]->videos_url; ?>">
                  <span style="color: #dd4b39;">* put your ID video from youtube video. (ex: izGwDsrQ1eQ)</span>
                  <!-- <span style="color: #dd4b39;">* Isi Deskripsi Data Perumahan.</span> -->
              </div>

              <div class="form-group">
                  <label>Last Video  <!-- <?php echo $data_aboutmenu[0]->aboutmenu_video_url;?> --></label>
                  <br>
                  <?php if($data_video[0]->videos_url == "-"){ ?>
                  <img src="<?php echo base_url()?>/uploads/video/novideo.jpg" height="250" width="50%">
                  <?php } else { ?>
                  <iframe width="50%" height="315" src="https://www.youtube.com/embed/<?php echo $data_video[0]->videos_url;?>?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
                  <?php } ?>
                  
              </div>

              <div class="form-group">
                  <label for="videos_desciption">Description</label>
                   <p>(Max Character: 250) </p>
                
                  <textarea class="form-control" name="videos_description" id="videos_description" maxlength="250" required="true" placeholder="Place some text here" style="width: 100%; height: 100px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $data_video[0]->videos_description; ?></textarea>
                  <!-- <span style="color: #dd4b39;">* Isi Deskripsi Data Perumahan.</span> -->
                    <span id="hitung"></span> Character Remaining.
              </div>

              <!-- <div class="form-group">
                <label>Posting Status</label>
                <select class="form-control select2" name="access_status" style="width: 100%;" required="true">
                  <option value="">- Choose Status -</option>
                  <option value="Aktif">Active</option>
                  <option value="Tidak Aktif">Deactive</option>
                </select>
                <span style="color: #dd4b39;">* pilih status akses pengguna, jika pilih tidak aktif maka pengguna tidak bisa masuk kedalam aplikasi.</span>
              </div>
 -->              <!-- /.box-body -->
              <div class="box-footer text-right">
                <button type="submit" class="btn btn-success btn-sm btnbig">Save / Update</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
<script src="<?php echo base_url() ?>assets/Sanders/js/jquery-1.4.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$('#videos_description').keyup(function() {
var len = this.value.length;
if (len >= 250) {
this.value = this.value.substring(0, 250);
}
$('#hitung').text(250 - len);
});
});
</script>
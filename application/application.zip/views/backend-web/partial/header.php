<?php date_default_timezone_set("Asia/Jakarta"); ?>
  <header class="main-header">
    <a href="#" class="logo">
      <span class="logo-mini"><?php echo $this->config->item('backend_mini_title') ?></span>
      <span class="logo-lg" style="font-size: 15px;"><?php echo $this->config->item('backend_full_title') ?></span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li>
            <a href="#" id="zoomapps"><i class="fa fa-expand"></i></a>
          </li>
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo base_url();?>uploads/base-img/avatar5.png" class="user-image" alt="User Image">
              <span class="hidden-xs">Profile</span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
                <img src="<?php echo base_url();?>uploads/base-img/avatar5.png" class="img-circle" alt="User Image">

                <p>
                  <?php echo $users_name; ?>
                  <small><?php echo $groups_name; ?></small>
                </p>
              </li>
              <li class="user-footer">
                <?php
                $this->load->model('auth_model');

                $users_username = $this->session->userdata('users_username');
                $users_password = $this->session->userdata('users_password');

                $check_access = $this->auth_model->get_access($users_username, $users_password);
                ?>
                <div class="row text-center">
                  <a href="<?php echo site_url('Website/B_users/profile') ?>/<?php echo $check_access[0]->id_backend_users; ?>/profile" class="btn btn-default btn-flat"><i class="fa fa-book"></i> Profile</a>
                  <a href="<?php echo site_url('Auth/signout') ?>" class="btn btn-default btn-flat"><i class="fa fa-book"></i> Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
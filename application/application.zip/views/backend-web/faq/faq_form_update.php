<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">

                 <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
        <div class="box" id="">
            <div class="box-header with-border">
          
              
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
                 <div class="form-group">
                   <input type="hidden" value="<?php echo $data_faq[0]->id_website_faq; ?>" name="id_website_faq" required="true">
                <label class="radio_custom">New Category 
                  <input type="radio" name="faq_check" value="new" onchange="load_faq('New')" checked="checked">
                  <span class="mark_custom"></span>
                </label>
                &nbsp;&nbsp;&nbsp;
                <label class="radio_custom">Previous Category
                  <input type="radio" name="faq_check" value="old" onchange="load_faq('Old')">
                  <span class="mark_custom"></span>
                </label>
              </div>

               <div id="check_new" class="form-group">
                  <label>Faq New Category</label>
                  <input type="text" class="form-control" id="faq_category_new" name="faq_category_new" placeholder="Category"  maxlength="100" required="true" >
                   <span style="color: #dd4b39; font-size: 12px">*max 50 character.</span>

              </div>

              <div id="check_old" class="form-group" style="display: none;">
                  <label>Faq Previous Category</label>
                  <select class="form-control select2" id="faq_category_old" name="faq_category_old" style="width: 100%;">
                  <option value="">- Choose Category -</option>

                  <?php
                        foreach ($get_dropdown_faq_category as $category_entry) {
                  ?>
                        <option value="<?php echo $category_entry->faq_category; ?>"><?php echo $category_entry->faq_category; ?></option>
                  <?php
                        }
                  ?>

                </select>
              </div>
              <div class="form-group">

                <label class="radio_custom">New Subcategory 
                    <input type="hidden" value="<?php echo $data_faq[0]->id_website_faq; ?>" name="id_website_faq" required="true">
                  <input type="radio" name="sub_check" maxlength="50" value="new" onchange="load_sub('New')" checked="checked">
                  <span class="mark_custom"></span>
                     
                </label>
                &nbsp;&nbsp;&nbsp;
                <label class="radio_custom">Previous Subcategory
                  <input type="radio" name="sub_check" maxlength="50" value="old" onchange="load_sub('Old')">
                  <span class="mark_custom"></span>
                   
                </label>
              </div>

              <div id="sub_new" class="form-group">
                  <label>Faq New Subcategory</label>
                  <input type="text" class="form-control" maxlength="50" id="faq_subcategory_new" name="faq_subcategory_new" placeholder="Category"  maxlength="100" required="true">
                     <span style="color: #dd4b39; font-size: 12px">*max 50 character.</span>
              </div>

              <div id="sub_old" class="form-group" style="display: none;">
                  <label>Faq Previous Subcategory</label>
                  <select class="form-control select2" maxlength="50" id="faq_subcategory_old" name="faq_subcategory_old" style="width: 100%;">
                  <option value="">- Choose Subcategory -</option>

                  <?php
                        foreach ($get_dropdown_faq_subcategory as $subcategory_entry) {
                  ?>
                        <option value="<?php echo $subcategory_entry->faq_subcategory; ?>"> <?php echo $subcategory_entry->faq_subcategory; ?></option>
                  <?php
                        }
                  ?>

                </select>
                
              </div> 
              <div class="form-group">
                  <label for="faq_question">Question</label>
                   <textarea class="form-control" name="faq_question" required="true" maxlength="300" placeholder="Place Some Question" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $data_faq[0]->faq_question; ?></textarea>
                   <span style="color: #dd4b39; font-size: 12px">*max 300 character.</span>
                  
              </div>
              <div class="form-group">
                  <label for="faq_answer">Answer</label>
                   <textarea class="form-control" name="faq_answer" required="true" maxlength="300" placeholder="Place Some answer" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $data_faq[0]->faq_answer; ?></textarea>
                   <span style="color: #dd4b39; font-size: 12px">*max 300 character.</span>
              </div>
               <div class="form-group">
                <label for="faq_postdate">Postdate</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                   <input type="text" name="faq_postdate" class="form-control pull-right datetimepicker" value="<?php echo $data_faq[0]->faq_postdate; ?>" placeholder="Postdate" id="faq_postdate"  required="true" >
                </div>
              </div>
              <?php if ($profile_true != 'profile'){ ?>
              <div class="form-group">
                <?php 
                if ($data_faq[0]->faq_access_status == 'Activated'){
                    $activated = "selected"; 
                    $deactivated = "";
                } else {
                    $activated = "";
                    $deactivated = "selected";
                }
                ?>
                <label>Posting Status</label>
                <select class="form-control select2" name="faq_access_status" style="width: 100%;" required="true">
                  <option value="">- Choose Status -</option>
                  <option value="Activated"<?php echo @$activated ?>>Active</option>
                  <option value="Deactivated"<?php echo @$deactivated ?>>Deactive</option>
                </select>
              </div>
              <?php } ?>
              <!-- /.box-body -->
              <div class="box-footer text-right">
                <a href="<?php echo $back_url; ?>" id="info" class="btn btn-warning btn-sm btnwdt">Back</a>
                <button type="submit" class="btn btn-success btn-sm btnbig"><i class="fa fa-fa-save"></i> Save / Update</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->

<script type="text/javascript">
  
function load_faq(media)
{
    var media = media;

    //alert('test');

    if (media == 'New') {
        $("#check_new").show();
        $("#check_old").hide();
        $("#faq_category_new").attr('required',true);
        $("#faq_category_old").attr('required',false);
    }
    else if (media == 'Old') {
        $("#check_old").show();
        $("#check_new").hide();
        $("#faq_category_old").attr('required',true);
        $("#faq_category_new").attr('required',false);
    }
}

</script>

<script type="text/javascript">
  
function load_sub(medi)
{
    var medi = medi;

    //alert('test');

    if (medi == 'New') {
        $("#sub_new").show();
        $("#sub_old").hide();
        $("#faq_subcategory_new").attr('required',true);
        $("#faq_subcategory_old").attr('required',false);
    }
    else if (medi == 'Old') {
        $("#sub_old").show();
        $("#sub_new").hide();
        $("#faq_subcategory_old").attr('required',true);
        $("#faq_subcategory_new").attr('required',false);
    }
}

</script>
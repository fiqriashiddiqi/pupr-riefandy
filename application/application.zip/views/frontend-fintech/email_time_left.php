<html>
	<head>
	  <meta charset="utf-8" />
	  <title>Email Time Left Loan</title>
	  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	</head>
	<body>
		<table style="width: 624px;border:1px solid">
			<tbody>
				<tr style="height: 38px; background-color: black;">
					<td style="width: 628px; height: 38px;color:white;text-align:center;">Notification Time Left Loan</td>
				</tr>
				<tr style="text-align:center;">
					<td style="width: 628px; height: 260px;"><img src="http://sanders.heatcliffs31.com/uploads/base-img/img_home/logoSanders.png" width="60%" style="margin-right: 50px;"></td>
				</tr>
				<tr style="height: 50px;">
					
					<td style="width: 628px; height: 50px;color:black;text-align:center;">Loan belum terpenuhi, sisa waktu crowdfunding 6 jam lagi.</td>
				</tr>
				<tr style="height: 50px;">
					<td style="width: 628px; height: 50px;color:white;text-align:center;"></td>
				</tr>
			</tbody>
		</table>
	</body>
</html>
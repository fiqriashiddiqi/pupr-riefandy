<?php date_default_timezone_set("Asia/Jakarta"); ?>
<div class="showcase" style="background-image:url('<?php echo base_url(); ?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
        <div class="container" style="padding-top: 10px;">

            <div class="row">
                <div class="hero loading">
                    
                    <ul class="bxslider">
                        <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                                # code...
                        ?>
                        <li>
                            <img src="<?php echo base_url(); ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%"/>
                            <div>
                                <br><br>
                                <h3><?php echo $slideshow_entry->slideshow_name;?></h3>
                                <p><small style="font-size:18px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

        </div>
</div>
<section class="container home" >
		
	<div class="row" style="margin-bottom: 15px;">
        <div class="container div-feedback">
            <div class="row">
				<?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check"></i>
                    <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban"></i>
                    <?php echo $this->session->flashdata('alert_error'); ?></p>
                    </div>
                <?php } ?>
			
				<div class="col-md-12 col-sm-12 col-xs-12" style="background-color: white; margin-top: 2%; margin-bottom: 20px">
					<div class="col-md-3 col-sm-12 col-xs-12" >
						<div class=" form-group" ">
							<a style="color: <?php echo @$style_href;?>" href="<?php echo site_url();?>Finance/F_login/login"><h1>Login</h1></a>
						</div>
					<div class=" form-group" ">
						<a style="color: orange;" href="<?php echo site_url();?>Finance/F_register/register  "><h1>Register</h1></a>
					</div>
					</div>
					<div class="col-md-9 col-sm-12 col-xs-12" id="left2" style="background-color: white; margin-top: 0%; margin-bottom: 2%;"">

							<p align="right">Registration form </p>
							<HR style="display: block; border-width: 2px; border-color: gray;">
						<div class="row" style="text-align: center;width: 65%;margin-left: 15%" >
							<br>
									<h3 style="color: #6d6d6d">Please check your email and clicking the link that we send to your email</h3> 
						</div>
								
					</div>				
				</div>
			</div>
		</div>
	</div>
</section>

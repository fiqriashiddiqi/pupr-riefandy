<?php date_default_timezone_set("Asia/Jakarta"); ?>
<div class="showcase" style="background-image:url('<?php echo base_url(); ?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
        <div class="container" style="padding-top: 10px;">

            <div class="row">
                <div class="hero loading">
                    
                    <ul class="bxslider">
                        <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                                # code...
                        ?>
                        <li>
                            <img src="<?php echo base_url(); ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%"/>
                            <div>
                                <br><br>
                                <h3><?php echo $slideshow_entry->slideshow_name;?></h3>
                                <p><small style="font-size:18px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

        </div>
</div>

<section class="container home">
    <div class="row" style="margin-bottom: 15px;">
        <div class="container div-feedback">
            <div class="row">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding: 0;padding-right: 35px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding: 0;padding-right: 35px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>

				<div class="col-md-3 col-sm-12 col-xs-12" >
					<div class=" form-group">
						<a style="color: <?php echo @$style_login;?>;" href="<?php echo site_url();?>Finance/F_login/login"><h1>Login</h1></a>
					</div>
					<div class=" form-group">
						<a style="color: <?php echo @$style_register;?>" href="<?php echo site_url();?>Finance/F_register/register"><h1>Register</h1></a>
					</div>
				</div>
				<div class="col-md-9 col-sm-12 col-xs-12">
					<br>
                    <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
					<div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 1%; margin-bottom: 4%;">
						<div class="form-group" >
							<label> User ID/Email</label> 							
							<input type="text" placeholder=" User ID/Email " name="reg_code" class="form-control" required="required">
						</div>
						<div class="form-group">
							<label> Password</label>
							<input type="Password" placeholder=" Password " name="reg_password" class="form-control" required="required">
						</div>
						<div class="from-grup" style="text-align: center;" >
							<button type="submit" class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: orange; width: 100%;font-size: 17px;height: 30px">Login</button>
						</div>	
					</div>
                    </form>
					<div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 1%; border-color: gray;">
							<H4> Forget Password?</H4>
						<div class=" form-group" ">
							<a style="color: #06bbf1;" href="<?php echo $forgot_url; ?>"><h4><u>Click here</u></h4></a>
							<p> A temporary will be sent to your registerd email. </p>
							<p> Please change to your new password afterwards </p>
						</div>
					</div>
				</div>
			</div>
		</div>		
	</div>
</section>
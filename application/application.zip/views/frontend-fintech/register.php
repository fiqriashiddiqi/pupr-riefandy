<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
/* The container */
.label_radio {
    display: inline;
    position: relative;
    padding-left: 35px;
    padding-right: 10px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default radio button */
.label_radio input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

/* Create a custom radio button */
.radio_style {
    position: absolute;
    top: 0;
    left: 0;
    height: 25px;
    width: 25px;
    background-color: #c1c1c1;
    border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.label_radio:hover input ~ .radio_style {
    background-color: #bbb;
}

/* When the radio button is checked, add a blue background */
.label_radio input:checked ~ .radio_style {
    background-color: #fac516;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.radio_style:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the indicator (dot/circle) when checked */
.label_radio input:checked ~ .radio_style:after {
    display: block;
}

/* Style the indicator (dot/circle) */
.label_radio .radio_style:after {
    top: 9px;
    left: 9px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: white;
}
</style>
<style>
.success_pass {
    color: green;
}

.error_pass {
    color: red;
}


.background-step {
    background-color: orange;
}
.stepwizard-step p {
    margin-top: 10px;
}

.stepwizard-row {
    display: table-row;
}

.stepwizard {
    display: table;
    width: 100%;
    position: relative;
}

.stepwizard-step button[disabled] {
    opacity: 1 !important;
    filter: alpha(opacity=100) !important;
}

.stepwizard-row:before {
    top: 14px;
    bottom: 0;
    position: absolute;
    content:" ";
    width: 100%;
    height: 1px;
    background-color: #ccc;
    z-order: 0;

}

.stepwizard-step {
    display: table-cell;
    text-align: center;
    position: relative;
}

.btn-circle {
  width: 64px;
  height: 34px;
  text-align: center;
  padding: 3px 0;
  font-size: 12px;
  line-height: 26px;
  border-radius: 8px;
}
.btn_modal_ok {
    height: 27px;
    width: 65px;
}
.btn_modal_cancel {
    height: 27px;
    width: 70px;
}
.check_custom {
      position: relative;
      padding-left: 35px;
      margin-bottom: 12px;
      margin-right: 10px;
      cursor: pointer;
      font-size: 15px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  /* Hide the browser's default checkbox */
  .check_custom input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
  }

  /* Create a custom checkbox */
  .check_mark {
      position: absolute;
      top: 0;
      left: 0;
      height: 25px;
      width: 25px;
      background-color: #eee;
  }

  /* On mouse-over, add a grey background color */
  .check_custom:hover input ~ .check_mark {
      background-color: #ccc;
  }

  /* When the checkbox is checked, add a blue background */
  .check_custom input:checked ~ .check_mark {
      background-color: #ffd100;
  }

  /* Create the check_mark/indicator (hidden when not checked) */
  .check_mark:after {
      content: "";
      position: absolute;
      display: none;
      border-radius: 10%;
  }

  /* Show the check_mark when checked */
  .check_custom input:checked ~ .check_mark:after {
      display: block;
  }

  /* Style the check_mark/indicator */
  .check_custom .check_mark:after {
      left: 10px;
      top: 7px;
      width: 7px;
      height: 10px;
      border: solid white;
      border-width: 0 3px 3px 0;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
  }
</style>

<div class="showcase" style="background-image:url('<?php echo base_url(); ?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
        <div class="container" style="padding-top: 10px;">

            <div class="row">
                <div class="hero loading">
                    
                    <ul class="bxslider">
                        <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                                # code...
                        ?>
                        <li>
                            <img src="<?php echo base_url(); ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%"/>
                            <div>
                                <br><br>
                                <h3><?php echo $slideshow_entry->slideshow_name;?></h3>
                                <p><small style="font-size:18px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                       </li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

        </div>
</div>


<section class="container home">

    <div class="row" style="margin-bottom: 15px;">
       
        <div class="container div-feedback">
            <div class="row">
             <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
            <?php } ?>

            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="form-group" ">
                    <a style="color: <?php echo @$style_href;?>" href="
                    <?php echo site_url();?>Finance/F_login/login">
                    <h1>Login</h1>
                    </a>
                </div>
                <div class="form-group" ">
                    <a style="color: <?php echo @$style_register;?>;" href="
                    <?php echo site_url();?>Finance/F_register/register">
                    <h1>Register</h1>
                    </a>
                </div>
            </div>
            <div class="col-md-9 col-sm-12 col-xs-12" id="left2" style="margin-top: 2%">
                <p align="right">Registration form</p>
                <form action="<?php echo $form_url; ?>" name="register_form" onsubmit="return validate_form()" method="post" enctype="multipart/form-data" id="myForm">
                    <div class="stepwizard">
                        <div class="stepwizard-row setup-panel">
                            <div class="stepwizard-step">
                                <a href="#step-1" type="button" class="btn btn-warning btn-circle">Step 1</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">Step 2</a>
                            </div>
                        </div>
                    </div>
                    <br>
                    <HR style="display: block; border-width: 2px; border-color: gray;">
                    <br>

                    <div class="col-md-3 col-sm-12 col-xs-12">
                    </div>

                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <form role="form">
                            <div class="row setup-content" id="step-1">
                                <div class="col-xs-12">
                                    <div class="col-md-12">
                                        <br>
                                        <br>
                                        <?php   
                                            if ($this->session->flashdata('cache_status') == "Borrower" ) {
                                                $cache_borrower = 'checked';
                                            } else {
                                                $cache_lender = 'checked';
                                            }
                                        ?>
                                        <div class="form-group" style="text-align: center; margin-bottom: 40px">
                                            <div class="col-md-6 col-sm-6 col-xs-6">
                                                <label class="label_radio">Investor
                                            <input type="radio" <?php echo @$cache_lender; ?> value="Lender" name="register_status">
                                            <span class="radio_style"></span>
                                       </label>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-6">
                                                <label class="label_radio">Borrower
                                            <input type="radio" <?php echo @$cache_borrower; ?> value="Borrower" name="register_status">
                                            <span class="radio_style"></span>
                                       </label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <br>
                                            <?php   if ($this->session->flashdata('cache_email')) {
                                                $cache_email = $this->session->flashdata('cache_email');
                                            } else {
                                                $cache_email = "";
                                            }
                                            ?>
                                            <label class="control-label">Email</label>
                                            <input type="hidden" name="reference_code" id="reference_code" >
                                            <input type="email" placeholder="Email" oninput="validate_test()" value="<?php echo @$cache_email; ?>"  name="register_email" class="form-control" id="cek_email" required>
                                            <p id="hasil_cari_email" ></p>
                                        </div>
                                        <!-- <div class="form-group">
                                            <?php   if ($this->session->flashdata('cache_username')) {
                                                $cache_username = $this->session->flashdata('cache_username');
                                            } else {
                                                $cache_username = "";
                                            }
                                            ?>
                                            <label class="control-label">Username</label>
                                            <input type="text" minlength="8" placeholder="Username" value="<?php echo @$cache_username; ?>" name="register_username" class="form-control" required="required">
                                            <p style="color: #dd4b39;">* min 8 character </p>
                                        </div> -->

                                        <div class="form-group">
                                            <label class="control-label">Password</label>
                                            <input type="Password" id="error_pass" minlength="8" placeholder="Password" name="register_password" class="form-control" oninput="check_password()" required="required">
                                            <p style="color: black;">* Password must contain alpha numericals, min 8 character</p>
                                            <p id="error_password"></p>
                                        </div>
                                        <div class="form-group" id="error_group">
                                            <label class="control-label">Re-enter Password</label>
                                            <input type="Password" id="error_pass_valid" minlength="8" placeholder="Re-enter Password" name="register_re_password" class="form-control" oninput="check_password()" required="required">
                                            <p id="error_html"></p>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">How you know about sander ?</label>
                                            <select class="form-control select2" name="register_how_know_sanders" id="hks" onchange="check_hks()" required="required">
                                                <?php   if ($this->session->flashdata('cache_hks') == 'Friend') {
                                                            $hks_friend  = 'selected';
                                                        } else if ($this->session->flashdata('cache_hks') == 'Facebook') {
                                                            $hks_facebook = 'selected';
                                                        } else if ($this->session->flashdata('cache_hks') == 'Website') {
                                                            $hks_website = 'selected';
                                                        } else {
                                                            $hks_default  = 'selected';
                                                        }
                                                ?>
                                                <option value="" <?php echo @$hks_default; ?>>- Choose Statement -</option>
                                                <option value="Friend" <?php echo @$hks_friend; ?>>Friend</option>
                                                <option value="Facebook" <?php echo @$hks_facebook; ?>>Facebook</option>
                                                <option value="Website" <?php echo @$hks_website; ?>>Website</option>
                                                <option value="Others">Others</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input class="form-control" name="regiter_how_know_sanders_other" placeholder="Write your Statement" type="text" id="regiter_how_know_sanders_other" style="display: none;" />
                                        </div>
                                        <div class="form-group">
                                            <button id="next_button" class="btn btn-warning nextBtn btn-lg btn-block" type="button" style="">Next</button>
                                            <p id="alert_next" style="color: #dd4b39;" style="display: none;"></p>
                                            <br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>

                    <div class="col-md-3 col-sm-12 col-xs-12">
                    </div>

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row setup-content" id="step-2">

                            <div id="regisrer_lender" class="col-xs-12 col-md-12 col-sm-12">
                                <h3>Personal Information Investor</h3>
                                <br>
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>Full Name</label>
                                        <input id="lender_name" required="required" type="text" placeholder="Name" name="lender_bio_fullname" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Birth Place</label>
                                        <input type="text" id="lender_birth_place" placeholder="Birth Place" name="lender_bio_place_birth_date" class="form-control" >
                                    </div>
                                    <div class="form-group">
                                        <label>Birthdate</label>
                                        <div class="input-group">
                                          <div class="input-group-addon">
                                            <i class="fa fa-calendar" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;text-rendering: auto; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;padding: 0; width: 11px;margin: 0;"></i>
                                          </div>
                                           <input type="text" name="lender_bio_birth_date" class="form-control pull-right datepicker" value="" placeholder="Birthdate" id="lender_birthdate"  required="required" >

                                        </div>
                                        <span id="alert-age" style="color: #dd4b39; font-size: 12px">*you have to be more then 17 years old to register.</span>
                                    </div>
                                    <div class="form-group">
                                        <label>Gender</label>
                                        <select id="lender_gender" required="required" class="form-control select2" name="lender_bio_gender" style="width: 100%;">
                                        <option value="">- Choose Statement -</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input id="lender_phone" required="required" type="number" placeholder=" Phone" name="lender_bio_phone" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select id="lender_status" required="required" class="form-control select2" name="lender_bio_marriage_status" onchange="check_status_marriage_lender();" style="width: 100%;">
                                        <option value="">- Choose Statement -</option>
                                        <option value="Married">Married</option>
                                        <option value="Single">Single</option> 
                                    </select>
                                    </div>
                                    <div class="form-group" id="spouse_name_lender" style="display: none;">
                                        <label>Spouse Name</label>
                                        <input id="lender_spouse_name" type="text" placeholder="Spouse Name" name="lender_bio_spouse_name" class="form-control">
                                    </div>
                                    <div class="form-group" id="spouse_phone_lender" style="display: none;">
                                        <label>Spouse Phone</label>
                                        <input id="lender_spouse_phone" type="number" placeholder="Spouse Phone" name="lender_bio_spouse_phone" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Occupation</label>
                                        <select id="lender_occupation" required="required" class="form-control select2" name="lender_bio_occupation" onchange="check_occupation_lender();">
                                        <option value="">- Choose Occupation -</option>
                                        <option value="Wiraswasta">Wiraswasta</option>
                                        <option value="Karyawan Swasta">Karyawan Swasta</option>
                                        <option value="Pegawai Negeri Sipil">Pegawai Negeri Sipil</option>
                                        <option value="TNI/POLRI">TNI/POLRI</option>
                                        <option value="Pensiunan">Pensiunan</option>
                                        <option value="Others">Others</option>
                                    </select>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control select2" name="lender_bio_occupation_others" placeholder="Write your Statement" type="text" id="lender_bio_occupation_others" visible="false" style="display: none;" />
                                    </div>
                                    <div class="form-group">
                                        <label>Last Education</label>
                                        <select id="lender_last_education" required="required" class="form-control select2" name="lender_bio_last_education" style="width: 100%;">
                                            <option value="">- Choose Statement -</option>
                                            <option value="SMP">SMP</option>
                                            <option value="SMA">SMA</option>
                                            <option value="D3">D3</option>
                                            <option value="S1">S1</option>
                                            <option value="S2">S2</option>
                                            <option value="S3">S3</option>                            
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Reference Code</label>
                                        <input type="text" placeholder="Reference Code" name="lender_bio_reference_code" id="lender_ref_code" class="form-control">
                                        <p id="hasil_cari_ref"></p>

                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    
                                    <div class="form-group">
                                        <label>Cityzenship</label>
                                        <select class="form-control select2" required="required" name="lender_bio_cityzenship" id="lender_cityzenship" onchange="check_cityzenship_lender();" style="width: 100% ; ">
                                        <option value="">- Choose Statement -</option>
                                        <option value="WNI">WNI</option>
                                        <option value="WNA">WNA</option>                
                                    </select>
                                    </div>
                                    <div class="form-group" id="lender_dummy1" style="display: none;">
                                        <label>Country</label>
                                        <input id="lender_country" type="text" placeholder="Country/State" name="lender_bio_country" class="form-control">
                                    </div>
                                    <div class="form-group" id="lender_dummy2" style="display: none;">
                                        <label>Province/State</label>
                                        <input id="lender_province" type="text" placeholder="Province" name="lender_bio_province" class="form-control">
                                    </div>
                                    <div class="form-group" id="lender_dummy3" style="display: none;">
                                        <label>City / Regency</label>
                                        <input id="lender_city" type="text" placeholder="City" name="lender_bio_city" class="form-control">
                                    </div>
                                    <div class="form-group" id="lender_dummy4" style="display: none;">
                                        <label>District</label>
                                        <input id="lender_district" type="text" placeholder="District" name="lender_bio_district" class="form-control">
                                    </div>
                                    <div class="form-group" id="lender_dummy5" style="display: none;">
                                        <label>Village</label>
                                        <input id="lender_village" type="text" placeholder="Village" name="lender_bio_village" class="form-control">
                                    </div>
                                    <div class="form-group" id="lender_dummy1_select" style="display: none;">
                                        <label>Province</label>
                                        <select id="lender_province_select" type="text" name="lender_bio_province_select" class="form-control select2">
                                            <option value="">- Choose Province -</option>
                                            <?php 
                                                foreach ($data_province as $province_entry) {
                                                    echo "<option value='".$province_entry->id_indonesia_provinsi."'>".$province_entry->nama."</option>";
                                                }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group" id="lender_dummy2_select" style="display: none;">
                                        <label>City / Regency</label>
                                        <select id="lender_city_select" type="text" name="lender_bio_city_select" class="form-control select2">
                                            <option value="">- Choose City / Regency -</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="lender_dummy3_select" style="display: none;">
                                        <label>District</label>
                                        <select id="lender_district_select" type="text" name="lender_bio_district_select" class="form-control select2">
                                            <option value="">- Choose District -</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="lender_dummy4_select" style="display: none;">
                                        <label>Village</label>
                                        <select id="lender_village_select" type="text" name="lender_bio_village_select" class="form-control select2">
                                            <option value="">- Choose Village -</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="lender_dummy6" style="display: none;">
                                        <label>Address</label>
                                        <textarea id="lender_address" placeholder="Enter Address Here.." rows="3" name="lender_bio_address" class="form-control"></textarea>
                                    </div>
                                    <div class="form-group" id="lender_dummy7" style="display: none;">
                                        <label>Zip Code</label>
                                        <input id="lender_post_code" type="number" placeholder="Zip Code" name="lender_bio_post_code" class="form-control">
                                    </div>
                                    <div class="form-group" id="lender_dummy" style="display: none;">
                                        <label>KTP / NIK KTP</label>
                                        <input type="Number" placeholder="KTP" id="lender_nik" name="lender_bio_nik" class="form-control">
                                          <p id="hasil_cari_nik_lender" ></p>
                                          <p id="error_nik"></p>
                                        <br>
                                        <img id="ktp_lender" src="<?php echo base_url();?>uploads/Website/slideshow/noimage.jpg" style="width: 100%; height: 150px;"></img>
                                        <br>
                                        <canvas id="edited" class="img img-responsive" style="display: none;"></canvas>
                                        <br>
                                        <label>Upload KTP</label>
                                        <input type="hidden" value="8cadb11f56" name="sc_key" id="sc_key">
                                        <input type="file" placeholder="Upload your id KTP" onchange="preview_ktp_lender()" id="lender_id_picture" name="lender_link_picture" class="form-control">

                                        <span style="color: #dd4b39; font-size: 12px">*file size picture max 5mb</span>
                                        <span style="color: #dd4b39; font-size: 12px">& file type picture jpg/png/jpeg .</span>
                                        <!-- <button type="submit" id="btn_simpan" value="simpan" class="btn btn-success">Cek KTP</button> -->
                                        
                                    </div>
                                    <div class="form-group" id="lender_dummy_1" style="display: none;">
                                        <label>Passport Number</label>
                                        <input type="Number" placeholder="Passport" id="lender_passport" name="lender_bio_passport" class="form-control">
                                        
                                        <br>
                                        <img id="passport_lender" src="<?php echo base_url();?>uploads/Website/slideshow/noimage.jpg" style="width: 100%; height: 150px;"></img>
                                        <br>
                                        
                                        <label>Upload Passport</label>
                                        <input type="file" placeholder="Upload your Passport" onchange="preview_passport_lender()" id="lender_id_passport" name="lender_bio_upload_passport" class="form-control">
                                        <span style="color: #dd4b39; font-size: 12px">*file size picture max 5mb</span>
                                        <span style="color: #dd4b39; font-size: 12px">& file type picture jpg/png/jpeg .</span>
                                    </div>
                                    <!-- <form action="#" onsubmit="if(document.getElementById('agree_lender').checked) { return true; } else { alert('Please indicate that you have read and agree to the Terms and Conditions and Privacy Policy'); return false; }"> -->
                                            
                                         
                                    <div class="form-group">
                                        <!-- <input type="checkbox" name="checkbox" value="yes" id="agree_lender" required="required" /><a href="#myModal" data-toggle="modal" data-target="#myModal"> I have read and agree to the Terms and Conditions and Privacy Policy</a> -->

                                        <label class="check_custom" style="font-weight: normal;font-size: 11px;"><a href="#myModal" data-toggle="modal" data-target="#myModal"> I have read and agree to the Terms and Conditions and Privacy Policy</a>
                                          <input type="checkbox" onClick="checkboxValueLender(1); return false;" name="checkbox" value="Yes" id="myCheck_lender" data-toggle="modal" data-target="#myModal"/>
                                          <span class="check_mark"></span>
                                        </label>
                                            <span id="alert-check" style="color: #dd4b39; font-size: 12px"></span>
                                            
                                        <br>
                                        <button id="finish_lender" class="finish_button btn btn-warning btn-lg btn-block submit-btn-investor" onClick="if(!this.form.checkbox.checked){document.getElementById('alert-check').innerHTML = '*Please check this checkbox.'; return false;}" type="submit" >Finish!</button>
                                        <br>
                                    </div>
                                    <!-- </form> -->
                                </div>
                            </div>

                            <div id="regisrer_borrower" class="col-xs-12 col-md-12 col-sm-12" style="display: none;">
                                <h3>Personal Information Borrower</h3>
                                <br>
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>Full Name</label>
                                        <input type="text" id="borrower_name" placeholder="Name" name="borrower_bio_fullname" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Birth Place</label>
                                        <input type="text" id="borrower_birth_place" placeholder="Birth Place" name="borrower_bio_place_birth_date" class="form-control" >
                                    </div>
                                    <div class="form-group">
                                        <label for="feedback_postdate">Birthdate</label>
                                        <div class="input-group">
                                          <div class="input-group-addon">
                                            <i class="fa fa-calendar" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;text-rendering: auto; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;padding: 0; width: 11px;margin: 0;"></i>
                                          </div>
                                           <input type="text" name="borrower_bio_birth_date" class="form-control pull-right datepicker" value="" placeholder="Birthdate" id="borrower_birthdate">
                                        </div>
                                        <span id="alert-age-bor" style="color: #dd4b39; font-size: 12px">*you have to be more then 17 years old and should not be more than 65 years old to register.</span>
                                    </div>
                                    <div class="form-group">
                                        <label>Gender</label>
                                        <select class="form-control select2" id="borrower_gender" name="borrower_bio_gender" style="width: 100%;">
                                        <option value="">- Choose Statement -</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>         
                                    </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="number" placeholder=" Phone" id="borrower_phone" name="borrower_bio_phone" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select class="form-control select2" id="borrower_status" name="borrower_bio_marriage_status" onchange="check_status_marriage_borrower();" style="width: 100%;">
                                        <option value="">- Choose Statement -</option>
                                        <option value="Married">Married</option>
                                        <option value="Single">Single</option> 
                                    </select>
                                    </div>
                                    <div class="form-group" id="spouse_name_borrower" style="display: none;">
                                        <label>Spouse Name</label>
                                        <input type="text" placeholder="Spouse Name" id="borrower_spouse_name" name="borrower_bio_spouse_name" class="form-control">
                                    </div>
                                    <div class="form-group" id="spouse_phone_borrower" style="display: none;"> 
                                        <label>Spouse Phone</label>
                                        <input type="number" placeholder="Spouse Phone" id="borrower_spouse_phone" name="borrower_bio_spouse_phone" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label>Occupation</label>
                                        <select class="form-control select2" name="borrower_bio_occupation" id="borrower_occupation" onchange="check_occupation_borrower()">
                                        <option value="">- Choose Occupation -</option>
                                        <option value="Wiraswasta">Wiraswasta</option>
                                        <option value="Karyawan Swasta">Karyawan Swasta</option>
                                        <option value="Pegawai Negeri Sipil">Pegawai Negeri Sipil</option>
                                        <option value="TNI/POLRI">TNI/POLRI</option>
                                        <option value="Pensiunan">Pensiunan</option>
                                        <option value="Others">Others</option>
                                    </select>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control select2" name="borrower_bio_occupation_others" placeholder="Write your Statement" type="text" id="borrower_bio_occupation_others" visible="false" style="display: none;" />
                                    </div>
                                    <div class="form-group">
                                        <label>Mothers Name</label>
                                        <input type="text" placeholder="Mothers Name" id="borrower_mother_name" name="borrower_bio_mother_name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Last Education</label>
                                        <select class="form-control select2" id="borrower_last_education" name="borrower_bio_last_education" style="width: 100%;">
                                        <option value="">- Choose Statement -</option>
                                        <option value="SMP">SMP</option>
                                        <option value="SMA">SMA</option>
                                        <option value="D3">D3</option>
                                        <option value="S1">S1</option>
                                        <option value="S2">S2</option>
                                        <option value="S3">S3</option>            
                                    </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Reference Code</label>
                                        <input type="text" placeholder="Reference Code" id="borrower_ref_code" name="borrower_bio_reference_code" class="form-control">
                                        <p id="hasil_cari_ref_bor"></p>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>Citizenship</label>
                                        <select class="form-control select2" name="borrower_bio_cityzenship" id="borrower_cityzenship" onchange="check_cityzenship_borrower();" style="width: 100% ; ">
                                        <option value="">- Choose Statement -</option>
                                        <option value="WNI">WNI</option>
                                        <option value="WNA">WNA</option>                
                                    </select>
                                    </div>

                                    <div class="form-group" id="borrower_dummy1" style="display: none;">
                                        <label>Country</label>
                                        <input id="borrower_country" type="text" placeholder="Country/State" name="borrower_bio_country" class="form-control">
                                    </div>


                                    <div class="form-group" id="borrower_dummy2" style="display: none;">
                                        <label>Province/State</label>
                                        <input id="borrower_province" type="text" placeholder="Province" name="borrower_bio_province" class="form-control">
                                    </div>
                                    <div class="form-group" id="borrower_dummy3" style="display: none;">
                                        <label>City/Regency</label>
                                        <input id="borrower_city" type="text" placeholder="City" name="borrower_bio_city" class="form-control">
                                    </div>
                                    <div class="form-group" id="borrower_dummy4" style="display: none;">
                                        <label>District</label>
                                        <input id="borrower_district" type="text" placeholder="District" name="borrower_bio_district" class="form-control">
                                    </div>
                                    <div class="form-group" id="borrower_dummy5" style="display: none;">
                                        <label>Village</label>
                                        <input id="borrower_village" type="text" placeholder="City" name="borrower_bio_village" class="form-control">
                                    </div>

                                    <div class="form-group" id="borrower_dummy1_select" style="display: none;">
                                        <label>Province</label>
                                        <select id="borrower_province_select" type="text" name="borrower_bio_province_select" class="form-control select2">
                                            <option value="">- Choose Province -</option>
                                            <?php 
                                                foreach ($data_province as $province_entry) {
                                                    echo "<option value='".$province_entry->id_indonesia_provinsi."'>".$province_entry->nama."</option>";
                                                }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group" id="borrower_dummy2_select" style="display: none;">
                                        <label>City / Regency</label>
                                        <select id="borrower_city_select" type="text" name="borrower_bio_city_select" class="form-control select2">
                                            <option value="">- Choose City / Regency -</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="borrower_dummy3_select" style="display: none;">
                                        <label>District</label>
                                        <select id="borrower_district_select" type="text" name="borrower_bio_district_select" class="form-control select2">
                                            <option value="">- Choose District -</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="borrower_dummy4_select" style="display: none;">
                                        <label>Village</label>
                                        <select id="borrower_village_select" type="text" name="borrower_bio_village_select" class="form-control select2">
                                            <option value="">- Choose Village -</option>
                                        </select>
                                    </div>

                                    <div class="form-group" id="borrower_dummy6" style="display: none;">
                                        <label>Address</label>
                                        <textarea id="borrower_address" placeholder="Enter Address Here.." rows="3" name="borrower_bio_address" class="form-control"></textarea>
                                    </div>
                                    <div class="form-group" id="borrower_dummy7" style="display: none;">
                                        <label>Zip Code</label>
                                        <input id="borrower_post_code" type="Number" placeholder="Zip Code" name="borrower_bio_post_code" class="form-control">
                                    </div>
                                    <div class="form-group" id="borrower_dummy" style="display: none;">

                                        <label>KTP / NIK KTP</label>
                                             <input type="Number" placeholder="KTP" name="borrower_bio_nik" id="borrower_nik" class="form-control" >
                                          <p id="hasil_cari_nik" ></p>
                                          <p id="error_nik_borrower"></p>
                                        <br>
                                        <img id="ktp_borrower" src="<?php echo base_url();?>uploads/Website/slideshow/noimage.jpg" style="width: 100%; height: 150px;"></img>
                                        <br>
                                        <canvas id="edited_borrower" class="img img-responsive" style="display: none;"></canvas>
                                        <br>
                                        
                                        <label>Upload KTP</label>
                                        <input type="hidden" value="8cadb11f56" name="sc_key" id="sc_key_bor">
                                        <input type="file" placeholder="Upload your id KTP" onchange="preview_ktp_borrower()" id="borrower_id_picture" name="borrower_link_picture" class="form-control">
                                        <span style="color: #dd4b39; font-size: 12px">*file size picture max 5mb</span>
                                        <span style="color: #dd4b39; font-size: 12px">& file type picture jpg/png/jpeg .</span>
                                    </div>

                                    <div class="form-group" id="borrower_dummy_1" style="display: none;">
                                        <label>Passport Number</label>
                                        <input type="Number" placeholder="Passport" name="borrower_bio_passport" id="borrower_passport" class="form-control">
                                        
                                        <br>
                                        <img id="passport_borrower" src="<?php echo base_url();?>uploads/Website/slideshow/noimage.jpg" style="width: 100%; height: 150px;"></img>
                                        <br>
                                        
                                        <label>Upload Passport</label>
                                        <input type="file" placeholder="Upload your Passport" onchange="preview_passport_borrower()" name="borrower_bio_upload_passport" id="borrower_id_passport" class="form-control">
                                        <span style="color: #dd4b39; font-size: 12px">*file size picture max 5mb</span>
                                        <span style="color: #dd4b39; font-size: 12px">& file type picture jpg/png/jpeg .</span>
                                    </div>
                                    <!-- <form action="#" onsubmit="
                                        if(document.getElementById('agree').checked) { 
                                            return true; 
                                        } else {
                                         alert('Please indicate that you have read and agree to the Terms and Conditions and Privacy Policy'); 
                                         return false; 
                                     }"> -->
                                        <div class="form-group">
                                                  
                                            <label class="check_custom" style="font-weight: normal;font-size: 11px;"><a href="#myModal" data-toggle="modal" data-target="#myModal"> I have read and agree to the Terms and Conditions and Privacy Policy</a>
                                              <input type="checkbox" name="checkbox_borrower" onClick="checkboxValueBorrower(1); return false;" value="Yes" id="myCheck_borrower" data-toggle="modal" data-target="#myModal_TB"/>
                                              <span class="check_mark"></span>
                                            </label>
                                            <span id="alert-check-bor" style="color: #dd4b39; font-size: 12px">*you must check this checkbox.</span>
                                            <br>
                                            <button id="finish_borrower" class="finish_button btn btn-warning btn-lg btn-block submit-btn-borower" type="submit" onClick="if(!this.form.checkbox_borrower.checked){ document.getElementById('alert-check-bor').innerHTML = '*Please check this checkbox.'; return false;}">Finish!</button>  
                                        </div>
                                    <!-- </form> -->
                                </div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <!-- <h4 class="modal-title" style="text-align: right;">PT One Stop</h4> -->
              <div class="container">
              <div class="row">
                <div class="col-md-3 col-sm-4 col-xs-12">
                
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                  <ul class="nav nav-pills">
                    <a class="navbar-brand" href="#">
                      <img alt="Brand" class="img-responsive img-logo" src="<?php echo base_url();?>uploads/base-img/logoSanders.png">
                    </a>

                  </ul>
                  
                  </div>
                </div>

                    <div class="col-md-9 col-sm-8 col-xs-12">
                      
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <div class="clearfix"> </div>
                                      
                        </div><!-- /.navbar-collapse -->
                    </div>

                  </div> <!-- .row -->
                  </div><!-- /.container-fluid -->
                  <br>
               <h2 style="text-align: center;">TERMS AND CONDITIONS</h2>
          </div>
        
          <div class="col-md-12 col-sm-12 col-xs-12" style="overflow-y: auto;overflow-x: hidden;height: 400px">
              <br>
              
                      <strong>01. Introduction</strong>
                
              <p align="justify">These Website Standard Terms and Conditions written on this webpage shall manage your use of this website. These Terms will be applied fully and affect to your use of this Website. By using this Website, you agreed to accept all terms and conditions written in here. You must not use this Website if you disagree with any of these Website Standard Terms and Conditions.</p>
              <p>Minors or people below 18 years old are not allowed to use this Website.</p>
              
                  
                      <strong>02. Intellectual Property Rights</strong>
                  
              
              <p align="justify">Other than the content you own, under these Terms, SatuStopSolusi and/or its licensors own all the intellectual property rights and materials contained in this Website.</p>
              <p align="justify">You are granted limited license only for purposes of viewing the material contained on this Website.</p>
              
                      <strong>03. Restrictions</strong>
                  
              <p>You are specifically restricted from all of the following</p>
              <ul>
                  <li>publishing any Website material in any other media;</li>
                  <li>selling, sublicensing and/or otherwise commercializing any Website material;</li>
                  <li>publicly performing and/or showing any Website material;</li>
                  <li>using this Website in any way that is or may be damaging to this Website;</li>
                  <li>using this Website in any way that impacts user access to this Website;</li>
                  <li>using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity;</li>
                  <li>engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to this Website;</li>
                  <li>using this Website to engage in any advertising or marketing.</li>
              </ul>
              <p align="justify">Certain areas of this Website are restricted from being access by you and SatuStopSolusi may further restrict access by you to any areas of this Website, at any time, in absolute discretion. Any user ID and password you may have for this Website are confidential and you must maintain confidentiality as well.</p>
              
                      <strong>04. Your Content</strong>
                 
              <p align="justify">In these Website Standard Terms and Conditions, “Your Content” shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant SatuStopSolusi a non-exclusive, worldwide irrevocable, sub licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media.</p>
              <p align="justify">Your Content must be your own and must not be invading any third-party’s rights. SatuStopSolusi reserves the right to remove any of Your Content from this Website at any time without notice.</p>
              
                      <strong>05. No warranties</strong>
                  
              <p align="justify">This Website is provided “as is,” with all faults, and SatuStopSolusi express no representations or warranties, of any kind related to this Website or the materials contained on this Website. Also, nothing contained on this Website shall be interpreted as advising you.</p>
             
                      <strong>06. Limitation of liability</strong>
                  
              <p align="justify">In no event shall SatuStopSolusi, nor any of its officers, directors and employees, shall be held liable for anything arising out of or in any way connected with your use of this Website whether such liability is under contract. &nbsp;SatuStopSolusi, including its officers, directors and employees shall not be held liable for any indirect, consequential or special liability arising out of or in any way related to your use of this Website.</p>
             
                      <strong>07. Indemnification</strong>
                  
              <p align="justify">You hereby indemnify to the fullest extent SatuStopSolusi from and against any and/or all liabilities, costs, demands, causes of action, damages and expenses arising in any way related to your breach of any of the provisions of these Terms.</p>
              
                      <strong>08. Severability</strong>
                 
              <p align="justify">If any provision of these Terms is found to be invalid under any applicable law, such provisions shall be deleted without affecting the remaining provisions herein.</p>
              
                      <strong>09. Variation of Terms</strong>
                  
              <p align="justify">SatuStopSolusi is permitted to revise these Terms at any time as it sees fit, and by using this Website you are expected to review these Terms on a regular basis.</p>
              
                      <strong>10. Assignment</strong>
                  
              <p align="justify">The SatuStopSolusi is allowed to assign, transfer, and subcontract its rights and/or obligations under these Terms without any notification. However, you are not allowed to assign, transfer, or subcontract any of your rights and/or obligations under these Terms.</p>
              
                      <strong>11. Entire Agreement</strong>
                  
              <p align="justify">These Terms constitute the entire agreement between SatuStopSolusi and you in relation to your use of this Website, and supersede all prior agreements and understandings.</p>
              
                      <strong>12. Governing Law &amp; Jurisdiction</strong>
                  
              <p align="justify">These Terms will be governed by and interpreted in accordance with the laws of the State of Indonesia, and you submit to the non-exclusive jurisdiction of the state and federal courts located in Indonesia for the resolution of any disputes.</p>
              
          </div>
        
      
        <div class="modal-footer">
          <label class="check_custom" style="font-weight: normal;font-size: 11px;float: left;line-height: 22px;"> I have read and agree to the Terms and Conditions and Privacy Policy
                    <input type="checkbox" id="myCheckModal" />
                    <span class="check_mark"></span>
                  </label>
                  
          <button type="button" class="btn btn-default" onClick="check();" data-dismiss="modal" style="width: 60px;margin-top: 2%;">Close</button>
        </div>
      </div>

    </div>
</div>

<div id="myModal_TB" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <!-- <h4 class="modal-title" style="text-align: right;">PT One Stop</h4> -->
              <div class="container">
              <div class="row">
                <div class="col-md-3 col-sm-4 col-xs-12">
                
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                  <ul class="nav nav-pills">
                    <a class="navbar-brand" href="#">
                      <img alt="Brand" class="img-responsive img-logo" src="<?php echo base_url();?>uploads/base-img/logoSanders.png">
                    </a>

                  </ul>
                  
                  </div>
                </div>

                    <div class="col-md-9 col-sm-8 col-xs-12">
                      
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <div class="clearfix"> </div>
                                      
                        </div><!-- /.navbar-collapse -->
                    </div>

                  </div> <!-- .row -->
                  </div><!-- /.container-fluid -->
                  <br>
               <h2 style="text-align: center;">TERMS AND CONDITIONS</h2>
          </div>
        
          <div class="col-md-12 col-sm-12 col-xs-12" style="overflow-y: auto;overflow-x: hidden;height: 400px">
              <br>
              <ol>
                  <li>
                      <strong>Introduction</strong>
                  </li>
              </ol>
              <p>These Website Standard Terms and Conditions written on this webpage shall manage your use of this website. These Terms will be applied fully and affect to your use of this Website. By using this Website, you agreed to accept all terms and conditions written in here. You must not use this Website if you disagree with any of these Website Standard Terms and Conditions.</p>
              <p>Minors or people below 18 years old are not allowed to use this Website.</p>
              <ol start="2">
                  <li>
                      <strong>Intellectual Property Rights</strong>
                  </li>
              </ol>
              <p>Other than the content you own, under these Terms, SatuStopSolusi and/or its licensors own all the intellectual property rights and materials contained in this Website.</p>
              <p>You are granted limited license only for purposes of viewing the material contained on this Website.</p>
              <ol start="3">
                  <li>
                      <strong>Restrictions</strong>
                  </li>
              </ol>
              <p>You are specifically restricted from all of the following</p>
              <ul>
                  <li>publishing any Website material in any other media;</li>
                  <li>selling, sublicensing and/or otherwise commercializing any Website material;</li>
                  <li>publicly performing and/or showing any Website material;</li>
                  <li>using this Website in any way that is or may be damaging to this Website;</li>
                  <li>using this Website in any way that impacts user access to this Website;</li>
                  <li>using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity;</li>
                  <li>engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to this Website;</li>
                  <li>using this Website to engage in any advertising or marketing.</li>
              </ul>
              <p>Certain areas of this Website are restricted from being access by you and SatuStopSolusi may further restrict access by you to any areas of this Website, at any time, in absolute discretion. Any user ID and password you may have for this Website are confidential and you must maintain confidentiality as well.</p>
              <ol start="4">
                  <li>
                      <strong>Your Content</strong>
                  </li>
              </ol>
              <p>In these Website Standard Terms and Conditions, “Your Content” shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant SatuStopSolusi a non-exclusive, worldwide irrevocable, sub licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media.</p>
              <p>Your Content must be your own and must not be invading any third-party’s rights. SatuStopSolusi reserves the right to remove any of Your Content from this Website at any time without notice.</p>
              <ol start="5">
                  <li>
                      <strong>No warranties</strong>
                  </li>
              </ol>
              <p>This Website is provided “as is,” with all faults, and SatuStopSolusi express no representations or warranties, of any kind related to this Website or the materials contained on this Website. Also, nothing contained on this Website shall be interpreted as advising you.</p>
              <ol start="6">
                  <li>
                      <strong>Limitation of liability</strong>
                  </li>
              </ol>
              <p>In no event shall SatuStopSolusi, nor any of its officers, directors and employees, shall be held liable for anything arising out of or in any way connected with your use of this Website whether such liability is under contract. &nbsp;SatuStopSolusi, including its officers, directors and employees shall not be held liable for any indirect, consequential or special liability arising out of or in any way related to your use of this Website.</p>
              <ol start="7">
                  <li>
                      <strong>Indemnification</strong>
                  </li>
              </ol>
              <p>You hereby indemnify to the fullest extent SatuStopSolusi from and against any and/or all liabilities, costs, demands, causes of action, damages and expenses arising in any way related to your breach of any of the provisions of these Terms.</p>
              <ol start="8">
                  <li>
                      <strong>Severability</strong>
                  </li>
              </ol>
              <p>If any provision of these Terms is found to be invalid under any applicable law, such provisions shall be deleted without affecting the remaining provisions herein.</p>
              <ol start="9">
                  <li>
                      <strong>Variation of Terms</strong>
                  </li>
              </ol>
              <p>SatuStopSolusi is permitted to revise these Terms at any time as it sees fit, and by using this Website you are expected to review these Terms on a regular basis.</p>
              <ol start="10">
                  <li>
                      <strong>Assignment</strong>
                  </li>
              </ol>
              <p>The SatuStopSolusi is allowed to assign, transfer, and subcontract its rights and/or obligations under these Terms without any notification. However, you are not allowed to assign, transfer, or subcontract any of your rights and/or obligations under these Terms.</p>
              <ol start="11">
                  <li>
                      <strong>Entire Agreement</strong>
                  </li>
              </ol>
              <p>These Terms constitute the entire agreement between SatuStopSolusi and you in relation to your use of this Website, and supersede all prior agreements and understandings.</p>
              <ol start="12">
                  <li>
                      <strong>Governing Law &amp; Jurisdiction</strong>
                  </li>
              </ol>
              <p>These Terms will be governed by and interpreted in accordance with the laws of the State of Indonesia, and you submit to the non-exclusive jurisdiction of the state and federal courts located in Indonesia for the resolution of any disputes.</p>
              
          </div>
        
      
        <div class="modal-footer">
          <label class="check_custom" style="font-weight: normal;font-size: 11px;float: left;line-height: 22px;"> I have read and agree to the Terms and Conditions and Privacy Policy
            <input type="checkbox" id="myCheckModal_Bor" />
            <span class="check_mark"></span>
          </label>
                  
          <button type="button" class="btn btn-default" onClick="check_term();" data-dismiss="modal" style="width: 60px;margin-top: 2%;">Close</button>
        </div>
      </div>

    </div>
</div>

<div id="myModal_lender" class="modal fade" role="dialog" >
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Notice !!</h4>
          </div>
          <div class="modal-body">
            <?php 
                $data_setting = $this->crud_model->get_setting();
                $comm_borrower   = $data_setting[0]->commision_borrower;
                $fee_pg = $data_setting[0]->fee_pg;
                $insurance = $data_setting[0]->insurance_rate;
            ?>
            <p style="text-align: justify;">Any deposit of investment funds and withdrawal transactions will incur a transaction fee Rp <?php echo number_format($fee_pg,0,".",".");?> Acceptance of installments will be deducted from the commission <?php echo $comm_borrower;?>% </p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width: 65px">Close</button>
          </div>
        </div>

      </div>
  </div>
<div id="myModal_borrower" class="modal fade" role="dialog" >
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Notice !!</h4>
          </div>
          <div class="modal-body">
            <?php 
                $data_setting = $this->crud_model->get_setting();
                $comm_borrower   = $data_setting[0]->commision_borrower;
                $fee_pg = $data_setting[0]->fee_pg;
                $insurance = $data_setting[0]->insurance_rate;
            ?>
            <p style="text-align: justify;">Credit disbursement will be deducted from the commission fee <?php echo $comm_borrower;?>%, credit life insurance premium <?php echo $insurance;?>% and then transaction fee Rp <?php echo number_format($fee_pg,0,".",".");?>. Installment payments are subject to a transaction fee. </p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width: 65px">Close</button>
          </div>
        </div>

      </div>
    </div>

<script type="text/javascript">
  /* Submit Process */


  var lender_NIK = "";
  var borrower_NIk = "";
  var hasil_baca_NIK = "";
  var birthdate = "";
  var str = "";
  var email ="";
  var error_pass = "";
  var error_pass_valid =""; 

  var pass_next;
  var email_next;
  var letter_number;
  var nik_finish_lender;
  var nik_finish_borrower;

  function check() {
      document.getElementById("myCheck_lender").checked = document.getElementById("myCheckModal").checked;
      console.log(document.getElementById("myCheckModal").checked);

      str = $("#lender_cityzenship").val();

      if (str == "WNI"){
        birthdate = $("#lender_birthdate").val();
        lender_NIK = $("#lender_nik").val();
        validate_finish(birthdate,lender_NIK,hasil_baca_NIK);
      }else if (str == "WNA"){
        birthdate = $("#lender_birthdate").val();
        validate_finish_wna(birthdate);
      } 
  }

  function check_term() {
      document.getElementById("myCheck_borrower").checked = document.getElementById("myCheckModal_Bor").checked;
      console.log(document.getElementById("myCheckModal_Bor").checked);
      
      str = $("#borrower_cityzenship").val();

      if (str == "WNI"){
        birthdate = $("#borrower_birthdate").val();
        borrower_NIK = $("#borrower_nik").val();
        validate_finish_borrower(birthdate,borrower_NIK,hasil_baca_NIK);
      }else if (str == "WNA"){
        birthdate = $("#borrower_birthdate").val();
        validate_finish_borrower_wna(birthdate);
      }
  }

  $("#lender_birthdate").change(function(){
    
    str = $("#lender_cityzenship").val();

    if (str == "WNI"){
      birthdate = $("#lender_birthdate").val();
      lender_NIK = $("#lender_nik").val();
      validate_finish(birthdate,lender_NIK,hasil_baca_NIK);
    } else if (str == "WNA"){
      birthdate = $("#lender_birthdate").val();
      validate_finish_wna(birthdate);
    } else {
      birthdate = $("#lender_birthdate").val();
      validate_finish_wna(birthdate);
    }
  });

  $("#lender_ref_code").keyup(function(){
    
    str = $("#lender_cityzenship").val();

    if (str == "WNI"){
      birthdate = $("#lender_birthdate").val();
      lender_NIK = $("#lender_nik").val();
      validate_finish(birthdate,lender_NIK,hasil_baca_NIK);
    } else if (str == "WNA"){
      birthdate = $("#lender_birthdate").val();
      validate_finish_wna(birthdate);
    } else {
      birthdate = $("#lender_birthdate").val();
      validate_finish_wna(birthdate);
    }
    
  });

  $("#borrower_birthdate").change(function(){

    str = $("#borrower_cityzenship").val();

      if (str == "WNI"){
        birthdate = $("#borrower_birthdate").val();
        borrower_NIK = $("#borrower_nik").val();
        validate_finish_borrower(birthdate,borrower_NIK,hasil_baca_NIK);
      } else if (str == "WNA"){
        birthdate = $("#borrower_birthdate").val();
        validate_finish_borrower_wna(birthdate);
      } else {
      birthdate = $("#borrower_birthdate").val();
      validate_finish_borrower_wna(birthdate);
      }
  
  });

  $("#borrower_ref_code").keyup(function(){
    str = $("#borrower_cityzenship").val();

      if (str == "WNI"){
        birthdate = $("#borrower_birthdate").val();
        borrower_NIK = $("#borrower_nik").val();
        validate_finish_borrower(birthdate,borrower_NIK,hasil_baca_NIK);
      } else if (str == "WNA"){
        birthdate = $("#borrower_birthdate").val();
        validate_finish_borrower_wna(birthdate);
      } else {
      birthdate = $("#borrower_birthdate").val();
      validate_finish_borrower_wna(birthdate);
      }
  });

  $("#lender_nik").keyup(function(){
    console.log("niklah");
    birthdate = $("#lender_birthdate").val();
    lender_NIK = $("#lender_nik").val();
    validate_finish(birthdate,lender_NIK,hasil_baca_NIK);
  });

  $("#borrower_nik").keyup(function(){
    console.log("niklah");
    birthdate = $("#borrower_birthdate").val();
    borrower_NIK = $("#borrower_nik").val();
    validate_finish_borrower(birthdate,borrower_NIK,hasil_baca_NIK);
  });

  $("#cek_email").keyup(function(){
    console.log("email");
    email = $("#cek_email").val();
    error_pass = $("#error_pass").val();
    error_pass_valid = $("#error_pass_valid").val();
    // validate_next(email,error_pass,error_pass_valid);
  });

  $("#error_pass").keyup(function(){
    console.log("password");
    email = $("#cek_email").val();
    error_pass = $("#error_pass").val();
    error_pass_valid = $("#error_pass_valid").val();
    // validate_next(email,error_pass,error_pass_valid);
  });

  $("#error_pass_valid").keyup(function(){
    console.log("password");
    email = $("#cek_email").val();
    error_pass = $("#error_pass").val();
    error_pass_valid = $("#error_pass_valid").val();
    // validate_next(email,error_pass,error_pass_valid);
  });




  // function check_age_lender(){
  //   birthdate = $("#lender_birthdate").val();
  //   validate_finish(birthdate);
  // }

  function checking(inp_NIK, ocr_NIK){
    console.log("asup");
    $("#error_nik").removeClass('success_pass');
    $("#error_nik").addClass('error_pass');

    $("#error_nik_borrower").removeClass('success_pass');
    $("#error_nik_borrower").addClass('error_pass');

    document.getElementById('error_nik').innerHTML = 'Your NIK didnt match, please re-type your NIK or re-upload KTP.';
    document.getElementById('error_nik_borrower').innerHTML = 'Your NIK didnt match, please re-type your NIK or re-upload KTP.';

    if(inp_NIK != undefined && ocr_NIK != undefined && inp_NIK != "" && ocr_NIK != ""){
      if(inp_NIK == ocr_NIK){
        // $('.finish_button').removeClass('btn-default');
        // $('.finish_button').addClass('btn-warning');
        // $(".finish_button").prop('disabled', false);

        $("#error_nik").addClass('success_pass');
        $("#error_nik").removeClass('error_pass');

        $("#error_nik_borrower").addClass('success_pass');
        $("#error_nik_borrower").removeClass('error_pass');

        document.getElementById('error_nik').innerHTML = 'Your NIK match.';
        document.getElementById('error_nik_borrower').innerHTML = 'Your NIK match.';
        console.log("NIK Sesuai");
        console.log(inp_NIK);
        console.log(ocr_NIK);
        return true;
      }
    }else{
      console.log("parameter checking belum terpenuhi");
      $("#error_nik").removeClass('success_pass');
    $("#error_nik").addClass('error_pass');

    $("#error_nik_borrower").removeClass('success_pass');
    $("#error_nik_borrower").addClass('error_pass');

    document.getElementById('error_nik').innerHTML = '';
    document.getElementById('error_nik_borrower').innerHTML = '';
    }
    return false;
  }

  function changeLenderNikVal(){
    lender_NIK = $("#lender_nik").val();
    checking(lender_NIK,hasil_baca_NIK);
  }

  function changeBorrowerNikVal(){
    borrower_NIK = $("#borrower_nik").val();
    checking(borrower_NIK,hasil_baca_NIK);
  }


 $("#lender_id_picture").change(function() {
        upload_lender();
      });

      function upload_lender(){
        var file_data = $("#lender_id_picture").prop("files")[0];  
        var NIK = $("#lender_nik").val(); 
        var form_data = new FormData();                  
        form_data.append("lender_id_picture", file_data) ;            
        form_data.append("NIK", NIK);   
        $.ajax({
          url: "<?php echo site_url('/api/do_upload/'); ?>",
          dataType: 'json',
          cache: false,
          contentType: false,
          processData: false,
          data: form_data,                         
          type: 'POST',
          success: function(response) {
            $('.finish_button').addClass('btn-default');
            $('.finish_button').removeClass('btn-warning');
            $(".finish_button").prop('disabled', true);
            console.log("Proses upload berhasil!");
            console.log("Response dari server : ");
            console.log(response);
            if(response.message_severity === "success"){
              document.querySelector('#edited').removeAttribute('data-caman-id');
              $("#ktp_lender").attr("src","<?php echo base_url('image_dir/"+ response.nama_lampiran +"')?>");
              Caman("#edited", "<?php echo base_url('image_dir/"+ response.nama_lampiran +"')?>", 
                function () {
                  console.log("Melaksanakan proses editing . . . "); 
                  this.brightness(15);
                  this.render(function(){
                      do_save_edit_lender(response.nama_lampiran,this.toBase64());
                  });
                }
              );
            }
          },
          error: function(response){
            console.log(response);
            alert("Proses upload gagal!");
          }
        });

      }

      function do_ocr_lender(image_name){
        console.log('do ocr lender');
        console.log("Proses pemindaian text OCR Tesseract . . . "); 
        $.ajax({
            url: "<?php echo site_url('/api/do_ocr/'); ?>/" + image_name,
            type: 'GET',
            success: function(response) {
              $('.finish_button').addClass('btn-default');
              $('.finish_button').removeClass('btn-warning');
              $(".finish_button").prop('disabled', true);
              console.log("Penyimpanan pemindaian berhasil!");
              console.log("Response dari server : ");
              console.log(response);
              var raw_text = response.message;
              var raw_splited = raw_text.split("\r\n");
              for(var i=0;i<raw_splited.length;i++){
                if(raw_splited[i].indexOf("NIK") >= 0){
                  var split_nik = raw_splited[i].split(" ");
                  var text_nik = $("#lender_nik").val(); 
                  lender_NIK = split_nik[split_nik.length - 1];
                  hasil_baca_NIK = lender_NIK;
                  validate_finish(birthdate,text_nik,lender_NIK);
                  // if(split_nik[split_nik.length - 1] == text_nik){
                  //   $('#hasil_cari_nik').css('color', 'green');
                  //   $('.finish_button').addClass('btn-warning');
                  //   $('.finish_button').removeClass('btn-default');
                  //   $(".finish_button").prop('disabled', false);
                  //   // alert("NIK pada KTP dan INPUT sesuai");
                  //   console.log("NIK pada KTP dan INPUT sesuai");
                  // }else{
                  //   $('#hasil_cari_nik').css('color', 'green');
                  //   $('.finish_button').addClass('btn-warning');
                  //   $('.finish_button').removeClass('btn-default');
                  //   $(".finish_button").prop('disabled', true);
                  //   alert("NIK pada KTP dan INPUT tidak sesuai");
                  //   console.log("NIK pada KTP dan INPUT tidak sesuai");
                  // }
                }else{
                  console.log("Tidak ditemukan key NIK pada hasil baca OCR");
                }
              }
            },
            error: function(response){
              console.log("Penyimpanan pemindaian gagal!");
            },
            cache: false,
            contentType: false,
            processData: false
        });
      }

      function do_save_edit_lender(ktp_lender_name,base64){
        var dataimage = {
          "original_name" : ktp_lender_name,
          "image" : base64
        }
        console.log("Menyimpan hasil editing . . . "); 
        $.ajax({
            url: "<?php echo site_url('/api/do_save_edit/'); ?>/",
            type : "POST",
            data : dataimage,
            dataType : "json",
            success: function(response) {
              console.log("Penyimpanan hasil editing berhasil!");
              console.log("Response dari server : ");
              console.log(response);
              console.log("Nama file hasil editing : " + response.image_name);
              if(response.message_severity === "success"){
                do_ocr_lender(response.image_name);
              }
            },
            error: function(response){
              console.log("Penyimpanan hasil editing gagal!"); 
            }
        });
      }
</script>

<!--borrowwer ok-->
<script type="text/javascript">
 $("#borrower_id_picture").change(function() {
        upload();
      });

      function upload(){
        var files_data = $("#borrower_id_picture").prop("files")[0];  
        var NIK = $("#borrower_nik").val(); 
        var form_data_bor = new FormData();                  
        form_data_bor.append("borrower_id_picture", files_data) ;            
        form_data_bor.append("NIK", NIK);   
        $.ajax({
          url: "<?php echo site_url('/Api/do_upload_borrower/'); ?>",
          dataType: 'json',
          cache: false,
          contentType: false,
          processData: false,
          data: form_data_bor,                         
          type: 'POST',
          success: function(response) {
            $('.finish_button').addClass('btn-default');
            $('.finish_button').removeClass('btn-warning');
            $(".finish_button").prop('disabled', true);
            console.log("Proses upload berhasil!");
            console.log("Response dari server : ");
            console.log(response);
            if(response.message_severity === "success"){
              document.querySelector('#edited_borrower').removeAttribute('data-caman-id');
              $("#ktp_borrower").attr("src","<?php echo base_url('image_dir/"+ response.nama_lampiran +"')?>");
              Caman("#edited_borrower", "<?php echo base_url('image_dir/"+ response.nama_lampiran +"')?>", 
                function () {
                  console.log("Melaksanakan proses editing . . . "); 
                  this.brightness(15);
                  this.render(function(){
                      do_save_edit(response.nama_lampiran,this.toBase64());
                  });
                }
              );
            }
          },
          error: function(response){
            console.log(response);
            alert("Proses upload gagal!");
          }
        });

      }

      function do_ocr(image_name){
        console.log("Proses pemindaian text OCR Tesseract . . . "); 
        $.ajax({
            url: "<?php echo site_url('/Api/do_ocr/'); ?>/" + image_name,
            type: 'GET',
            success: function(response) {
              $('.finish_button').addClass('btn-default');
              $('.finish_button').removeClass('btn-warning');
              $(".finish_button").prop('disabled', true);
              console.log("Penyimpanan pemindaian berhasil!");
              console.log("Response dari server : ");
              console.log(response);
              var raw_text = response.message;
              var raw_splited = raw_text.split("\r\n");
              for(var i=0;i<raw_splited.length;i++){
                if(raw_splited[i].indexOf("NIK") >= 0){
                  var split_nik = raw_splited[i].split(" ");
                  var text_nik = $("#borrower_nik").val(); 
                  borrower_NIK = split_nik[split_nik.length - 1];
                  hasil_baca_NIK = borrower_NIK;
                  validate_finish_borrower(birthdate,text_nik,borrower_NIK); 
                  // if(split_nik[split_nik.length - 1] == text_nik){
                  //   $('#hasil_cari_nik').css('color', 'green');
                  //   $('.finish_button').addClass('btn-warning');
                  //   $('.finish_button').removeClass('btn-default');
                  //   $(".finish_button").prop('disabled', false);
                  //   // alert("NIK pada KTP dan INPUT sesuai");
                  //   console.log("NIK pada KTP dan INPUT sesuai");
                  // }else{
                  //   // $('#hasil_cari_nik').css('color', 'green');
                  //   $('.finish_button').addClass('btn-warning');
                  //   $('.finish_button').removeClass('btn-default');
                  //   $(".finish_button").prop('disabled', true);
                  //   alert("NIK pada KTP dan INPUT tidak sesuai");
                  //   console.log("NIK pada KTP dan INPUT tidak sesuai");
                  // }
                  }else{
                  console.log("Tidak ditemukan key NIK pada hasil baca OCR");
                }
              }
            },
            error: function(response){
              console.log("Penyimpanan pemindaian gagal!");
            },
            cache: false,
            contentType: false,
            processData: false
        });
      }

      function do_save_edit(ktp_borrower_name,base64){
        var dataimage = {
          "original_name" : ktp_borrower_name,
          "image" : base64
        }
        console.log("Menyimpan hasil editing . . . "); 
        $.ajax({
            url: "<?php echo site_url('/Api/do_save_edit/'); ?>/",
            type : "POST",
            data : dataimage,
            dataType : "json",
            success: function(response) {
              console.log("Penyimpanan hasil editing berhasil!");
              console.log("Response dari server : ");
              console.log(response);
              console.log("Nama file hasil editing : " + response.image_name);
              if(response.message_severity === "success"){
                do_ocr(response.image_name);
              }
            },
            error: function(response){
              console.log("Penyimpanan hasil editing gagal!"); 
            }
        });
      }
</script>

<script type="text/javascript">
    function validate_next(pass, email){

        // console.log(pass, email);
        if(pass==true && email==true){
            document.getElementById('next_button').disabled = false;
            $('#next_button').removeClass('btn-default');
            $('#next_button').addClass('btn-warning');
            document.getElementById('alert_next').style.display = 'block';
        }else{
            document.getElementById('next_button').disabled = true;
            $('#next_button').removeClass('btn-warning');
            $('#next_button').addClass('btn-default');
             document.getElementById('alert_next').style.display = 'none';
            
        }


      // check_password(function(isValid){
             
      //   if (validate_test(email) && isValid){
      //   }else{
      //   }
      // });
    }
    function validate_test(email) {
      var email = $("#cek_email").val();
     $.ajax({
            url: <?php echo "'". site_url("Finance/F_register/cek_email")."'";?>,
            type: 'POST',
            dataType: 'json',
            data: $('#cek_email').serialize(),
            timeout: 180000,
            beforeSend: function() {
                $('#next_button').addClass('btn-default');
                $('#next_button').removeClass('btn-warning');
                $("#next_button").prop('disabled', true);
            },
            success: function(data) {
                // console.log(data);
                $("#hasil_cari_email").html(data.message);
                if(data.is_success==true){                    
                    $('#hasil_cari_email').css('color', 'green');

                    email_next = true;
                    validate_next(pass_next,email_next);

                    // document.getElementById('next_button').disabled = false;
                    // $('#next_button').removeClass('btn-default');
                    // $('#next_button').addClass('btn-warning');
                    // document.getElementById('alert_next').style.display = 'block';
                    
                }else{
                    $('#hasil_cari_email').css('color', 'red');

                    email_next = false;
                    validate_next(pass_next,email_next);
                    // document.getElementById('next_button').disabled = true;
                    // $('#next_button').removeClass('btn-warning');
                    // $('#next_button').addClass('btn-default');
                    //  document.getElementById('alert_next').style.display = 'none';
                }
            
            },
            error: function(x, t, m) {

            }
        });

     
    }

    function check_password(error_pass,error_pass_valid) {
     var error_pass = $("#error_pass").val();
     var error_pass_valid = $("#error_pass_valid").val();
     var str = document.getElementById('error_pass').value;
     
     letter_number = false;
        
     if (error_pass == error_pass_valid) {
         $("#error_group").removeClass("has-error");
         $("#error_html").addClass('success_pass');
         $("#error_html").removeClass('error_pass');
         document.getElementById('error_html').innerHTML = 'your password match.';
         

     } else {
         $("#error_group").addClass("has-error");
         $("#error_html").addClass('error_pass');
         $("#error_html").removeClass('success_pass');
         document.getElementById('error_html').innerHTML = 'your password does not match !!';
         
     }

     if (error_pass.length < 8) {
        $("#error_password").show();
            $("#error_password").addClass('error_pass');
            document.getElementById('error_password').innerHTML = 'your password too short.';
            
            
     } else if (error_pass.length > 50) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password too long.';
        
        
     } else if (error_pass.search(/\d/) == -1) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password no number content.';
        
     } else if (error_pass.search(/[a-zA-Z]/) == -1) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password no letter content.';
        
     } else {
     $("#error_password").hide();
     letter_number = true;
    
     }
     if(error_pass == error_pass_valid&&letter_number==true){
        pass_next = true;
     }else{
        pass_next = false;
     }
     validate_next(pass_next,email_next);
  }

</script>

<script type="text/javascript">

  $("#reference_code").window.onload(function(){

        
        $.ajax({
            url: <?php echo "'". site_url("Finance/F_register/cek_ref_code")."'";?>,
            type: 'POST',
            dataType: 'json',
            data: $('#reference_code').serialize(),
            timeout: 180000,
            beforeSend: function() {
                
            },
            success: function(data) {
                // console.log(data);
                
                // if(data.ref_code != $newref){                    
                //     $('#hasil_cari_nik').css('color', 'green');
                //     $('.finish_button').addClass('btn-warning');
                //     $('.finish_button').removeClass('btn-default');
                //     $(".finish_button").prop('disabled', false);
                // }else{
                //     $('#hasil_cari_nik').css('color', 'red');
                //     $('.finish_button').addClass('btn-default');
                //     $('.finish_button').removeClass('btn-warning');
                //     $(".finish_button").prop('disabled', true);

                // }
            
            },
            error: function(x, t, m) {

            }
        });
    });
</script>

<script type="text/javascript">
function validate_finish(birthdate,inp_NIK, ocr_NIK){
  validate(function(isValid){
    // console.log(inp_NIK);
    // console.log(ocr_NIK);
    var ocrValid = checking(inp_NIK, ocr_NIK);
    var isChecked = $('#myCheck_lender').get(0).checked;
    if (validate_birthdate(birthdate) && isValid && isChecked && ocrValid){
        $('.finish_button').addClass('btn-warning');
        $('.finish_button').removeClass('btn-default');
        $(".finish_button").prop('disabled', false);
    }else{
        $('.finish_button').addClass('btn-default');
        $('.finish_button').removeClass('btn-warning');
        $(".finish_button").prop('disabled', true);
    }
  });
 }

function validate_finish_wna(birthdate){
  validate(function(isValid){
    
    var isChecked = $('#myCheck_lender').get(0).checked;
    if (validate_birthdate(birthdate) && isValid && isChecked){
        $('.finish_button').addClass('btn-warning');
        $('.finish_button').removeClass('btn-default');
        $(".finish_button").prop('disabled', false);
    }else{
        $('.finish_button').addClass('btn-default');
        $('.finish_button').removeClass('btn-warning');
        $(".finish_button").prop('disabled', true);
    }
  });
 }

  function validate (callback){
    $.ajax({
          url: <?php echo "'". site_url("Finance/F_register/validation_ref_code_lender")."'";?>,
          type: 'POST',
          dataType: 'json',
          data: $('#lender_ref_code').serialize(), 
          timeout: 180000,

          beforeSend: function() {

    
              $('.finish_button').addClass('btn-default');
              $('.finish_button').removeClass('btn-warning');
              $(".finish_button").prop('disabled', true);
          },
          success: function(data) {
              console.log(data);
              $("#hasil_cari_ref").html(data.message);
              if(data.is_success==true){                    
                  $('#hasil_cari_ref').css('color', 'green');
                  // $('.finish_button').addClass('btn-warning');
                  // $('.finish_button').removeClass('btn-default');
                  // $(".finish_button").prop('disabled', false);
                  callback(true);
              }else{
                  $('#hasil_cari_ref').css('color', 'red');
                  // $('.finish_button').addClass('btn-default');
                  // $('.finish_button').removeClass('btn-warning');
                  // $(".finish_button").prop('disabled', true);
                  callback(false);
              }
          },
          error: function(x, t, m) {
            callback(false);
          }
      });
    callback(true);

  }



</script>

<script type="text/javascript">
  function validate_finish_borrower(birthdate,inp_NIK, ocr_NIK){
  validate_borrower(function(isValid){
    console.log(isValid);
    var ocrValid = checking(inp_NIK, ocr_NIK);
    var isChecked = $('#myCheck_borrower').get(0).checked;
    if (validate_birthdate_borrower(birthdate) && isValid && isChecked && ocrValid){
        $('#finish_borrower').addClass('btn-warning');
        $('#finish_borrower').removeClass('btn-default');
        $("#finish_borrower").prop('disabled', false);
    }else{
        $('#finish_borrower').addClass('btn-default');
        $('#finish_borrower').removeClass('btn-warning');
        $("#finish_borrower").prop('disabled', true);
    }
  });
 }

 function validate_finish_borrower_wna(birthdate){
  validate_borrower(function(isValid){
    
    var isChecked = $('#myCheck_borrower').get(0).checked;
    if (validate_birthdate_borrower(birthdate) && isValid && isChecked){
        $('#finish_borrower').addClass('btn-warning');
        $('#finish_borrower').removeClass('btn-default');
        $("#finish_borrower").prop('disabled', false);
    }else{
        $('#finish_borrower').addClass('btn-default');
        $('#finish_borrower').removeClass('btn-warning');
        $("#finish_borrower").prop('disabled', true);
    }
  });
 }

  function validate_borrower (callback){
    $.ajax({
          url: <?php echo "'". site_url("Finance/F_register/validation_ref_code_borrower")."'";?>,
          type: 'POST',
          dataType: 'json',
          data: $('#borrower_ref_code').serialize(),
          timeout: 180000,
          beforeSend: function() {
              $('#finish_borrower').addClass('btn-default');
              $('#finish_borrower').removeClass('btn-warning');
              $("#finish_borrower").prop('disabled', true);
          },
          success: function(data) {
              // console.log(data);
              $("#hasil_cari_ref_bor").html(data.message);
              if(data.is_success==true){                    
                  $('#hasil_cari_ref_bor').css('color', 'green');
                  // $('.finish_button').addClass('btn-warning');
                  // $('.finish_button').removeClass('btn-default');
                  // $(".finish_button").prop('disabled', false);
                  callback(true);
              }else{
                  $('#hasil_cari_ref_bor').css('color', 'red');
                  // $('.finish_button').addClass('btn-default');
                  // $('.finish_button').removeClass('btn-warning');
                  // $(".finish_button").prop('disabled', true);
                  callback(false);
              }
          
          },
          error: function(x, t, m) {
            callback(false);
          }
      });
    callback(true);
  }
</script>

<script type="text/javascript">

    $("#lender_ref_code").on('input', function(){
      str = $("#lender_cityzenship").val();
      if (str == "WNI"){
        validate_finish();
      }else if (str == "WNA"){
        validate_finish_wna();
      }
        
        // $.ajax({
        //     url: <?php //echo "'". site_url("Finance/F_register/validation_ref_code_lender")."'";?>,
        //     type: 'POST',
        //     dataType: 'json',
        //     data: $('#lender_ref_code').serialize(),
        //     timeout: 180000,
        //     beforeSend: function() {
        //         $('.finish_button').addClass('btn-default');
        //         $('.finish_button').removeClass('btn-warning');
        //         $(".finish_button").prop('disabled', true);
        //     },
        //     success: function(data) {
        //         // console.log(data);
        //         $("#hasil_cari_ref").html(data.message);
        //         if(data.is_success==true){                    
        //             $('#hasil_cari_ref').css('color', 'green');
        //             $('.finish_button').addClass('btn-warning');
        //             $('.finish_button').removeClass('btn-default');
        //             $(".finish_button").prop('disabled', false);
        //         }else{
        //             $('#hasil_cari_ref').css('color', 'red');
        //             $('.finish_button').addClass('btn-default');
        //             $('.finish_button').removeClass('btn-warning');
        //             $(".finish_button").prop('disabled', true);

        //         }
            
        //     },
        //     error: function(x, t, m) {

        //     }
        // });
    });
</script>

<script type="text/javascript">

    $("#borrower_ref_code").on('input', function(){
      str = $("#borrower_cityzenship").val();
      if (str == "WNI"){
        validate_finish_borrower();
      }else if (str == "WNA"){
        validate_finish_borrower_wna();
      }
      
        
        // $.ajax({
        //     url: <?php //echo "'". site_url("Finance/F_register/validation_ref_code_borrower")."'";?>,
        //     type: 'POST',
        //     dataType: 'json',
        //     data: $('#borrower_ref_code').serialize(),
        //     timeout: 180000,
        //     beforeSend: function() {
        //         $('.finish_button').addClass('btn-default');
        //         $('.finish_button').removeClass('btn-warning');
        //         $(".finish_button").prop('disabled', true);
        //     },
        //     success: function(data) {
        //         // console.log(data);
        //         $("#hasil_cari_ref").html(data.message);
        //         if(data.is_success==true){                    
        //             $('#hasil_cari_ref').css('color', 'green');
        //             $('.finish_button').addClass('btn-warning');
        //             $('.finish_button').removeClass('btn-default');
        //             $(".finish_button").prop('disabled', false);
        //         }else{
        //             $('#hasil_cari_ref').css('color', 'red');
        //             $('.finish_button').addClass('btn-default');
        //             $('.finish_button').removeClass('btn-warning');
        //             $(".finish_button").prop('disabled', true);

        //         }
            
        //     },
        //     error: function(x, t, m) {

        //     }
        // });
    });
</script>

<script type="text/javascript">
  $("#myModal").on("hidden.bs.modal", function () {
    check();
});
</script>
<script type="text/javascript">
  $("#myModal_TB").on("hidden.bs.modal", function () {
    check_term();
});
</script>

<script type="text/javascript">

    $("#borrower_nik").on('input', function(){
        
        $.ajax({
            url: <?php echo "'". site_url("Finance/F_register/cek_nik")."'";?>,
            type: 'POST',
            dataType: 'json',
            data: $('#borrower_nik').serialize(),
            timeout: 180000,
            beforeSend: function() {
                $('.finish_button').addClass('btn-default');
                $('.finish_button').removeClass('btn-warning');
                $(".finish_button").prop('disabled', true);
            },
            success: function(data) {
                // console.log(data);
                $("#hasil_cari_nik").html(data.message);
                if(data.is_success==true){                    
                    $('#hasil_cari_nik').css('color', 'red');
                    $('.finish_button').addClass('btn-default');
                    $('.finish_button').removeClass('btn-warning');
                    $(".finish_button").prop('disabled', true);
                }else{
                    $('#hasil_cari_nik').css('color', 'green');
                    
                    $('.finish_button').addClass('btn-warning');
                    $('.finish_button').removeClass('btn-default');
                    $(".finish_button").prop('disabled', false);

                }
            
            },
            error: function(x, t, m) {

            }
        });
    });
</script>

<script type="text/javascript">

    $("#lender_nik").on('input', function(){

        
        $.ajax({
            url: <?php echo "'". site_url("Finance/F_register/cek_nik_lender")."'";?>,
            type: 'POST',
            dataType: 'json',
            data: $('#lender_nik').serialize(),
            timeout: 180000,
            beforeSend: function() {
                $('.finish_button').addClass('btn-default');
                $('.finish_button').removeClass('btn-warning');
                $(".finish_button").prop('disabled', true);
            },
            success: function(data) {
                // console.log(data);
                $("#hasil_cari_nik_lender").html(data.message);
                if(data.is_success==true){                    
                    $('#hasil_cari_nik_lender').css('color', 'red');
                    nik_finish_lender = false;
                    validate_finish(birthdate,text_nik,lender_NIK);
                    // $('.finish_button').addClass('btn-default');
                    // $('.finish_button').removeClass('btn-warning');
                    // $(".finish_button").prop('disabled', true);
                }else{
                    $('#hasil_cari_nik_lender').css('color', 'green');
                    nik_finish_lender = true;
                    validate_finish(birthdate,text_nik,lender_NIK);
                    // $('.finish_button').addClass('btn-warning');
                    // $('.finish_button').removeClass('btn-default');
                    // $(".finish_button").prop('disabled', false);

                }
            
            },
            error: function(x, t, m) {

            }
        });
    });
</script>


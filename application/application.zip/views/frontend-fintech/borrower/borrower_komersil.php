<?php date_default_timezone_set("Asia/Jakarta"); ?>
   <style>

  /* The check_custom */
  .check_custom {
      position: relative;
      padding-left: 35px;
      margin-bottom: 12px;
      margin-right: 10px;
      cursor: pointer;
      font-size: 15px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  /* Hide the browser's default checkbox */
  .check_custom input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
  }

  /* Create a custom checkbox */
  .check_mark {
      position: absolute;
      top: 0;
      left: 0;
      height: 25px;
      width: 25px;
      background-color: #eee;
  }

  /* On mouse-over, add a grey background color */
  .check_custom:hover input ~ .check_mark {
      background-color: #ccc;
  }

  /* When the checkbox is checked, add a blue background */
  .check_custom input:checked ~ .check_mark {
      background-color: #ffd100;
  }

  /* Create the check_mark/indicator (hidden when not checked) */
  .check_mark:after {
      content: "";
      position: absolute;
      display: none;
      border-radius: 10%;
  }

  /* Show the check_mark when checked */
  .check_custom input:checked ~ .check_mark:after {
      display: block;
  }

  /* Style the check_mark/indicator */
  .check_custom .check_mark:after {
      left: 10px;
      top: 7px;
      width: 7px;
      height: 10px;
      border: solid white;
      border-width: 0 3px 3px 0;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
  }

   /*wizard*/
      .background-step {
          background-color: orange;
      }
      .stepwizard-step p {
          margin-top: 10px;
      }

      .stepwizard-row {
          display: table-row;
      }

      .stepwizard {
          display: table;
          width: 100%;
          position: relative;
      }

      .stepwizard-step button[disabled] {
          opacity: 1 !important;
          filter: alpha(opacity=100) !important;
      }

      .stepwizard-row:before {
          top: 14px;
          bottom: 0;
          position: absolute;
          content:" ";
          width: 100%;
          height: 1px;
          background-color: #ccc;
          z-order: 0;

      }

      .stepwizard-step {
          display: table-cell;
          text-align: center;
          position: relative;
      }

      .btn-circle {
        width: 64px;
        height: 34px;
        text-align: center;
        padding: 3px 0;
        font-size: 12px;
        line-height: 26px;
        border-radius: 8px;
      }
      .btn_modal_ok {
          height: 27px;
          width: 65px;
      }
      .btn_modal_cancel {
          height: 27px;
          width: 70px;
      }
  </style>
<style>
    .tool_tip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }
    
    .tool_tip .tool_tiptext {
        visibility: hidden;
        width: 180px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 0px;
        padding: 5px 0;
    
        /* Position the tool_tip */
        position: absolute;
        z-index: 1;
    }
    
    .tool_tip:hover .tool_tiptext {
        visibility: visible;
    }
</style>
				
<section class="container home" >
	<div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
		 <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
       <?php } ?>
		<div class="container div-feedback" >
		<div class="row" style="background-color: white; margin-top: 2%; margin-bottom: 2%;">
			<div class="col-md-12 col-sm-12 col-xs-12" >
         <div class=" form-group" align="center">
            <label><h2>Commercial Loan Detail</h2></label>
          </div>
				    <div class="stepwizard">
                        <div class="stepwizard-row">
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_komersil" class="btn btn-warning btn-circle">Step 1</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_file_komersil" class="btn btn-default btn-circle">Step 2</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/new_loan_commercial" class="btn btn-default btn-circle">Step 3</a>
                            </div>
                        </div>
                    </div>
				<br>
				
				
				<div class="col-md-6 col-sm-12 col-xs-12" >
					<br>
					<br>
					<div class=" form-group" >
						<label>Personal's/ Entity Name</label>
						<input type="text" class="form-control" placeholder="" name="bio_fullname" value="<?php echo $data_code[0]->bio_fullname; ?>"  disabled="true">
					</div>
					<div class=" form-group" >
						<label>Place/Date of Birth</label>
						<input type="text" class="form-control" placeholder="Place" name="birth_place" value="<?php echo $data_code[0]->bio_place_birth_date; ?>" disabled="true" >
					</div>
					<div class="form-group">
						<input type="text" class="form-control" placeholder="" name="" value="<?php echo $data_code[0]->bio_birth_date; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
						<label>Gender</label>
						<input type="text" class="form-control" placeholder="" name="bio_gender" value="<?php echo $data_code[0]->bio_gender; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
					<div class=" form-group" >
						<label> Province</label>
						<input type="text" class="form-control" placeholder="" name="city" value="<?php echo @$data_province[0]->nama; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
						<label> City</label>
						<input type="text" class="form-control" placeholder="" name="city" value="<?php echo @$data_city[0]->nama; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
						<label> District</label>
						<input type="text" placeholder=" " class=" form-control" value="<?php echo @$data_district[0]->nama; ?>" disabled="true">
					</div>
					<div class=" form-group" >
						<label> Village </label>
						<input type="text" placeholder=" " class=" form-control" value="<?php echo @$data_village[0]->nama; ?>" disabled="true" >
					</div>
					<label>Address</label>
						<textarea placeholder="" rows="3" name="bio_address"  class="form-control" disabled=""><?php echo $data_code[0]->bio_address; ?></textarea>
					</div>
					<div class=" form-group" >
						<label> Post Code</label>
						<input type="Number" class="form-control" placeholder="" name="bio_post_code" value="<?php echo $data_code[0]->bio_post_code; ?>" required="true" disabled>
					</div>
				<!-- 	<div class=" form-group" >
						<label>Home Phone Number</label>
						<input type="text" placeholder="" class=" form-control">
					</div> -->
					<div class=" form-group" >
						<label> Phone Number </label>
						<input type="Number" class="form-control" placeholder="" name="bio_phone" value="<?php echo $data_code[0]->bio_phone; ?>" required="true" disabled="true">
					</div>
					<!-- <div class=" form-group">
						<label>Marital Status </label>
						<input type="text" class="form-control" placeholder="" name="bio_marriage_status" value="<?php echo $data_code[0]->bio_marriage_status; ?>" required="true" disabled="true">
					</div> -->
					<div class="form-group">
                        <label>Marital Status</label>
                        <select id="borrower_status" required="required" class="form-control select2" name="bio_marriage_status" onchange="check_status_marriage_commercial();" style="width: 100%;" disabled="true">
                                    <?php   
                                        if ($data_code[0]->bio_marriage_status == 'Married') {
                                                $Married  = 'selected';
                                                $display = 'block';
                                            } else if ($data_code[0]->bio_marriage_status == 'Single') {
                                                $Single = 'selected';
                                                $display = 'none';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                              <option value="Married" <?php echo @$Married;?>>Married</option>
                              <option value="Single" <?php echo @$Single;?>>Single</option>  
                           
                        </select>
                    </div>
					<div class=" form-group" id="spouse_name_borrower" style="display: <?php echo @$display;?>;">
						<label>Name of Spouse (Husband/Wife) </label>
						<input type="text" class="form-control" placeholder="" name="bio_spouse_name" value="<?php echo $data_code[0]->bio_spouse_name; ?>" required="true" disabled>
					</div>
					<div class=" form-group" id="spouse_phone_borrower" style="display: <?php echo @$display;?>;">
			            <label>Phone Number Spouse (Husband/Wife) </label>
			            <input type="number" class="form-control" name="bio_spouse_phone" value="<?php echo @$data_code[0]->bio_spouse_phone; ?>" required="true" disabled >
			         </div>
					<div class=" form-group" id="spouse_ktp_borrower" style="display: <?php echo @$display;?>;">
						<label>Number ID Card(KTP) Spouse </label>
						<input type="Number" placeholder="" class=" form-control" value="<?php echo @$data_commercial[0]->borrower_ktp_spouse; ?>" disabled="true">
					
						<br>
						 <?php
						if (@$data_commercial[0]->borrower_ktp_spouse_picture == 0) {
						?> 	
						<img id="ktp_spouse" src="<?php echo base_url();?>uploads/Fintech/ktp_spouse_borrower/noimage.jpg " style="width: 100%; height: 150px; border: 1px solid;">
						<?php 	
						}else{
					   ?>
						<img id="ktp_spouse" src="<?php echo base_url();?>uploads/Fintech/ktp_spouse_borrower/<?php echo @$data_commercial[0]->borrower_ktp_spouse_picture; ?>" style="width: 100%; height: 150px; border: 1px solid;">
						<?php  
						}
						?>
						<br>
						<label>Upload KTP</label>
						
                        <input type="file" placeholder="Upload Spouse KTP" onchange="preview_ktp_spouse()" id="borrower_ktp_spouse" name="borrower_link_picture" class="form-control" disabled>
                        <span style="color: #dd4b39; font-size: 12px">*file size picture max 5mb</span>
                        <span style="color: #dd4b39; font-size: 12px">& file type picture jpg/png/jpeg .</span>
                    </div>	
                    <div class=" form-group">
                        <label>Collectibility BI </label>
                        <!-- <input type="text" class="form-control" name="borrower_collectibility_bi" value="<?php echo @$data_commercial[0]->borrower_collectibility_bi; ?>" disabled> -->
                        <select class="form-control select2" name="borrower_collectibility_bi" value="<?php echo @$data_commercial[0]->borrower_collectibility_bi; ?>" style="width: 100%;" disabled>
                             <?php   
                                    if ($data_commercial[0]->borrower_collectibility_bi =='1') {
                                      $Lancar  = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='2') {
                                      $Watch   = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='3') {
                                      $DPK   = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='4') {
                                      $Kurang   = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='5') {
                                      $Ragu   = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='6') {
                                      $Macet   = 'selected';
                                    } else {
                                      $default  = 'selected';
                                    }
                                   ?>
                                  <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                                  <option value="1"<?php echo @$Lancar;?>>Lancar</option>
                                  <option value="2"<?php echo @$Watch;?>>Watchlist</option>
                                  <option value="3"<?php echo @$DPK;?>>DPK</option>
                                  <option value="4"<?php echo @$Kurang;?>>Kurang Lancar</option>
                                  <option value="5"<?php echo @$Ragu;?>>Diragukan</option>
                                  <option value="6"<?php echo @$Macet;?>>Macet</option>
                               </select>
                    </div>
				</div>
					<br>
					<br>		
				<div class="col-md-6 col-sm-12 col-xs-12" >
          <div class=" form-group">
              <label>Monthly Income </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
              <input type="text" class="form-control" name="borrower_montly_income" value="Rp. <?php echo @number_format($data_commercial[0]->borrower_montly_income,0,".","."); ?>" disabled>
          </div>
          <div class=" form-group">
              <label>Operating Costs </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
              <input type="text" class="form-control" name="borrower_operating_costs" value="Rp. <?php echo @number_format($data_commercial[0]->borrower_operating_costs,0,".","."); ?>" disabled>
          </div>
          <div class=" form-group">
              <label>Additional Costs </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
              <input type="text" class="form-control" name="borrower_additional_costs" value="Rp. <?php echo @number_format($data_commercial[0]->borrower_additional_costs,0,".","."); ?>" disabled>
          </div>
					<div class=" form-group" >
						<label>Name of Business Entity</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
						<input type="text" placeholder="" value="<?php echo @$data_commercial[0]->borrower_business_name; ?>" class="form-control"   disabled="true">
					</div>
					<div  class=" form-group">
						<label>Form of Business Entity</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
						<input type="text" placeholder="" value="<?php echo @$data_business_entity_form[0]->entity_business_name; ?>" class="form-control"   disabled="true">
					        
					</div>
					<div  class=" form-group">
						<label> Industry Type</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
						<input type="text" placeholder="" value="<?php echo @$data_industry_type[0]->industry_name; ?>" class="form-control"   disabled="true">	
          		     </div>
          		     <div  class=" form-group">
						<label> Business Field</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
					    <input type="text" placeholder="" value="<?php echo @$data_business_field_name[0]->business_field_name; ?>" class="form-control"   disabled="true">
          		     </div>		 
					<div class=" form-group">
						<label>Long Entrepreneurship</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
						<input type="text" placeholder="" value="<?php echo @$data_commercial[0]->borrower_long_entrepreneurship; ?>" class=" form-control"  disabled="true">
					</div>
					<div  class=" form-group">
						<label>Province</label>
						<input type="text" placeholder="" value="<?php echo @$data_province_commercial[0]->nama; ?>" class=" form-control"  disabled="true">
					</div>
					<div  class=" form-group">
						<label>City</label>
						<input type="text" placeholder="" value="<?php echo @$data_city_commercial[0]->nama; ?>" class=" form-control"  disabled="true">
					</div>
					<div  class=" form-group">
						<label> District</label>
						<input type="text" placeholder="" value="<?php echo @$data_district_commercial[0]->nama; ?>" class=" form-control"  disabled="true" >
					</div>
					<div  class=" form-group">
						<label> Village </label>
						<input type="text" placeholder="" value="<?php echo @$data_village_commercial[0]->nama; ?>" class=" form-control"  disabled="true" >
					</div>					
					<div class=" form-group">
						<label> Business Address</label>
						<label>Street </label>
						<textarea rows="3" placeholder="" class=" form-control" disabled="true"><?php echo @$data_commercial[0]->borrower_address_company; ?></textarea>
					</div>
					<div class=" form-group">
						<label> Post Code </label>
						<input type="Number" placeholder="" value="<?php echo @$data_commercial[0]->borrower_post_code_company; ?>" class=" form-control"  disabled="true">
					</div>
					<div class=" form-group">
						<label>Office Phone Number</label>
						<input type="Number" placeholder="" value="<?php echo @$data_commercial[0]->borrower_office_number; ?>" class=" form-control" disabled="true" >
					</div>
					
					<div class="row" style="text-align: right; margin-right: 3%;" >
						<a class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: orange; width: 25%; margin-top: 6%;" href="<?php echo site_url();?>Finance/F_borrower/borrower_update_komersil">Edit</a>
            <?php

                if (@$data_commercial[0]->borrower_employe_status == '' AND @$data_commercial[0]->borrower_montly_income == '' AND @$data_commercial[0]->borrower_collectibility_bi == '' AND @$data_commercial[0]->borrower_business_name == '' AND @$data_business_entity_form[0]->entity_business_name == '' AND @$data_business_field_name[0]->business_field_name == '' AND @$data_commercial[0]->borrower_long_entrepreneurship == '' AND @$data_commercial[0]->borrower_office_number == '' AND @$data_province_commercial[0]->nama == '' AND @$data_city_commercial[0]->nama == '' AND @$data_district_commercial[0]->nama == '' AND @$data_village_commercial[0]->nama == '' AND @$data_commercial[0]->borrower_address_company == '' AND @$data_commercial[0]->borrower_post_code_company == '' AND @$data_industry_type[0]->industry_name == '' AND @$data_commercial[0]->borrower_entity_type == '') {
            ?> 
                  <a class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: black; width: 25%; margin-top: 6%;" href="#" disabled>Next</a>
                  <br>
                  <span style="color: #dd4b39; font-size: 12px">*Please complete your data to proceed to the next step.</span>
            <?php } else { 
              ?>
                <a class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: orange; width: 25%; margin-top: 6%;" href="<?php echo site_url();?>Finance/F_borrower/borrower_file_komersil ">Next</a>
                  <?php } ?>
          
            
					
					</div>
					
				</div>
				<!-- -->
	</div>
	</div>
</div>				
</section>

<script type="text/javascript">
	function check_business_field() {
    var el = document.getElementById("Business");
    var str = el.options[el.selectedIndex].text;
    if(str == "Other") {
        show();
    }else {
        hide();
    }
}
function hide(){
    document.getElementById('textother').style.display='none';
}
function show(){
    document.getElementById('textother').style.display='block';
}


function preview_ktp_spouse() {
     var input = document.getElementById('borrower_ktp_spouse');
     var file = input.files[0];
     var reader = new FileReader();
     var noimage = "<?php echo base_url();?>uploads/Website/slideshow/noimage.jpg";

     reader.onloadend = function() {
         $('#ktp_spouse').attr('src', reader.result);
     }

     if (file) {
         reader.readAsDataURL(file);
     } else {
         $('#ktp_spouse').attr('src', noimage);
     }
 }
</script>
	

		
			
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<div class="showcase" style="padding-bottom: 15px;">
    <div class="container" style="padding-top: 2%;">
        <div class="row">
            <div class="hero loading">
                <ul class="bxslider">
                    <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                        ?>
                        <li>
                            <img src="<?php echo base_url() ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%" />
                            <div>
                                <br><br>
                                <h3>
                                    <?php echo $slideshow_entry->slideshow_name;?>
                                </h3>
                                <p><small style="font-size:18px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                    <?php } ?>
                </ul>

            </div>
        </div>

    </div>
</div>

<style type="text/css">
    .fa1 {
      font-size: 20px;
      text-align: center;
      text-decoration: none;
      margin: 5px 2px;
      border-radius: 50%;
    }
    
    .fa2 {
      font-size: 20px;
      text-align: center;
      text-decoration: none;
      
    }
    
    .fa {
      padding: 20px;
      font-size: 35px;
      width: 75px;
      text-align: center;
      text-decoration: none;
      margin: 5px 2px;
      border-radius: 50%;
    }
    
    .fa:hover {
        opacity: 0.7;
    }
    
    .fa-facebook {
      background: #3B5998;
      color: white;
    }
    
    .fa-file-archive-o {
      background: #726f6f;
      color: white;
    }
    
    .fa-twitter {
      background: #55ACEE;
      color: white;
    }
    
    .fa-google-plus {
      background: #dd4b39;
      color: white;
    }
    
    .fa-linkedin {
      background: #007bb5;
      color: white;
    }
    
    .fa-youtube {
      background: #bb0000;
      color: white;
    }
    
    .fa-whatsapp {
      background: #25d366;
      color: white;
    }
    
    .fa-instagram {
      background: #125688;
      color: white;
    }
    
    .fa-pinterest {
      background: #cb2027;
      color: white;
    }
    
    .fa-snapchat-ghost {
      background: #fffc00;
      color: white;
      text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;
    }
    
    .fa-skype {
      background: #00aff0;
      color: white;
    }
    
    .fa-android {
      background: #a4c639;
      color: white;
    }
    
    .fa-dribbble {
      background: #ea4c89;
      color: white;
    }
    
    .fa-vimeo {
      background: #45bbff;
      color: white;
    }
    
    .fa-tumblr {
      background: #2c4762;
      color: white;
    }
    
    .fa-vine {
      background: #00b489;
      color: white;
    }
    
    .fa-foursquare {
      background: #45bbff;
      color: white;
    }
    
    .fa-stumbleupon {
      background: #eb4924;
      color: white;
    }
    
    .fa-flickr {
      background: #f40083;
      color: white;
    }
    
    .fa-yahoo {
      background: #430297;
      color: white;
    }
    
    .fa-envelope {
      background: #430297;
      color: white;
    }
    
    .fa-soundcloud {
      background: #ff5500;
      color: white;
    }
    
    .fa-reddit {
      background: #ff5700;
      color: white;
    }
    
    .fa-rss {
      background: #ff6600;
      color: white;
    }
    a, a:hover, a:focus {
        color: inherit;
        text-decoration: none;
        transition: all 0.3s;
    }
</style>
<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-bottom: 2%;">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <H3><label style="margin-top: 1%;display: block; text-align: center; line-height: 150%; font-size: .85em;"> Social Connection & Points</label></H3>

                    <b>Connect with : </b>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
                    <a href="#" class="fa fa-facebook" style="font-size:35px;"></a>
                    <a href="#" class="fa fa-twitter" style="font-size:35px;"></a>
                    <a href="#" class="fa fa-google-plus" style="font-size:35px;"></a>
                    <a href="#" class="fa fa-linkedin" style="font-size:35px;"></a>
                    <a href="#" class="fa fa-whatsapp" style="font-size:35px;"></a>
                    <a href="#" class="fa fa-instagram" style="font-size:35px;"></a>
                    <a href="#" class="fa fa-envelope" style="font-size:35px;"></a>
                    <a href="#" class="fa fa-android" style="font-size:35px;"></a>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <label style="margin-top: 3%;display: block; text-align: center; line-height: 150%; font-size: .85em;">Reference code: Lender's ID xxxxxx</label>
                    <label style="margin-top: 1%;display: block; text-align: center; line-height: 150%; font-size: .85em;">Link : http://.......//</label>


                    <label> Steps :</label>
                </div>


                    <div class="col-md-3 col-sm-3 col-xs-6" style="text-align: center;">
                        <img alt="Brand" class=" image center-block" src="<?php echo base_url();?>uploads/base-img/1.png" style="width: 49%">
                        <p>Invite your friend (direct through social media)</p>
                    </div>

                    <div class="col-md-3 col-sm-3 col-xs-6" style="text-align: center;">
                        <img alt="Brand" class=" image center-block" src="<?php echo base_url();?>uploads/base-img/2.png" style="width: 50%">
                        <p>Help them register and enter the refferal number</p>
                    </div>

                    <div class="col-md-3 col-sm-3 col-xs-6" style="text-align: center;">
                        <img alt="Brand" class=" image center-block" src="<?php echo base_url();?>uploads/base-img/3.png" style="width: 50%">
                        <p>Once your friend lend/borrow, we will give points (0.5% from the loan)</p>
                    </div>

                    <div class="col-md-3 col-sm-3 col-xs-6" style="text-align: center;">
                        <img alt="Brand" class="image center-block" src="<?php echo base_url();?>uploads/base-img/4.png" style="width: 50%">
                        <p>Now you can use the points to invest once</p>
                    </div>


                <div class="col-md-12 col-sm-12 col-xs-12">
                  <br>
                    <div class=" form-group" style="text-align: center; ">
                <!-- <label> Withdrawal History</label> -->
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr style="background-color: #726f6f;color: white">
                                <th style="text-align: center;">Date</th>
                                <th style="text-align: center;">Beginning</th>
                                <th style="text-align: center;">In (+)</th>
                                <th style="text-align: center;">Out (-)</th>
                                <th style="text-align: center;">Ending</th>
                                <th style="text-align: center;">Note</th>
                            </tr>
                        </thead>
                      <tbody>
                      <?php
                            $this->load->model("crud_model");
                                  $data_setting = $this->crud_model->get_setting();
                                  $limit   = $data_setting[0]->setting_pagination;
                            $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;
                        
                        if(empty($page)){
                                $position  = 0;
                                $page = 1;
                            } else {
                                $position = ($page-1) * $limit;
                            }

                                $this->load->model('Front_Fintech/connection_model');
                                $data_code = $this->connection_model->get_point_borrower($get_code,$limit,$position)->result();
                                $no = $position+1;

                             if ($data_code != null) {

                              $data_report = array();
                              $i = 0;
                              $ending = 0;
                              $beginning = 0;

                              foreach ($data_code as $code_entry){

                                $entry = new \stdClass;

                                $point_in = $code_entry->reference_point;
                                $entry->tot_point_in = $point_in;

                                $ending = $beginning + $point_in;
                                // $beginning = $beginning + $ending;

                                // $point_out = ;
                                // $tot_point_out = ;


                        ?>
                                <tr style="background-color: whitesmoke;">
                                    <td><?php echo date('d/m/Y', strtotime ($code_entry->reference_date));?></td>
                                    <td><?php echo $beginning;?></td>
                                    <td><?php echo $point_in;?></td>
                                    <td>0</td>
                                    <td><?php echo $ending;?></td>
                                    <td><?php echo $code_entry->reference_name;?></td>
                                </tr>
                            <?php 
                                  $data_report[$i]=$entry;
                                  $i++;
                                  $no++;
                                  $beginning = $ending;
                                  }
                                  ?>

                                  <tr style="background-color: whitesmoke;">
                                    <?php 
                                      $tot_point_in = 0;
                                      $tot_point_beginning = 0;
                                      $tot_point_ending = 0; 
                                     
                                      foreach ($data_report as $report_entry) {
                                        $tot_point_in += $report_entry->tot_point_in;
                                        
                                // var_dump($tot_point_in);
                               }
                        ?>
                                        <td></td>
                                        <td>0</td>
                                        <td><?php echo number_format($tot_point_in,0,".","."); ?></td>
                                        <td>0</td>
                                        <td></td>
                                        <td></td>
                                </tr>
                                 <?php } else {
                                ?>
                                  <tr style="background-color: whitesmoke;">
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                  </tr>
                                <?php  
                                } 
                        ?>
                      </tbody>
                      
                    </table>
                    <?php
                      $data_rows = $this->connection_model->get_point_borrower($get_code)->num_rows();
                      $all_page  = ceil($data_rows/$limit);
                  ?>
                      <center>
                      <ul class="pagination">
                          <li>
                              <?php
                                  if($page > 1){
                                      $prev = $page-1;
                                      echo "<a href='".base_url()."Finance/F_borrower/social_point_borrower?page=$prev'>Previous</a>";
                                  }
                              ?>
                          </li>
                          <li>
                              <?php
                                  for($i=1;$i<=$all_page;$i++)
                                      if ($i != $page){
                                          echo "<a href='".base_url()."Finance/F_borrower/social_point_borrower?page=$i'>$i</a>";
                                      }
                              ?>
                              </li>
                              <li>
                              <?php
                                  if($page < $all_page){
                                      $next=$page+1;
                                      echo "<a href='".base_url()."Finance/F_borrower/social_point_borrower?page=$next'>Next</a>";
                                  }
                              ?>
                          </li>
                      </ul>
                      </center>
                </div>
              </div>
                    <!-- <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr style="background-color: #726f6f;color: white">
                                    <th style="text-align: center;">Date</th>
                                    <th style="text-align: center;">Beginning</th>
                                    <th style="text-align: center;">In (+)</th>
                                    <th style="text-align: center;">Out (-)</th>
                                    <th style="text-align: center;">Ending</th>
                                    <th style="text-align: center;">Note</th>
                                </tr>
                            </thead>
                            <tbody style="background-color: aliceblue;">
                                <tr>
                                    <th style="text-align: center;">1/1/2017</th>
                                    <td style="text-align: center;">0</td>
                                    <td style="text-align: center;"></td>
                                    <td style="text-align: center;"></td>
                                    <td style="text-align: center;">0</td>
                                    <td style="text-align: center;">Refer ID xxx-xxx</td>
                                </tr>
                                <tr>
                                    <th style="text-align: center;">5/1/2017</th>
                                    <td style="text-align: center;">0</td>
                                    <td style="text-align: center;">10</td>
                                    <td style="text-align: center;"></td>
                                    <td style="text-align: center;">10</td>
                                    <td style="text-align: center;">Invest ID xxx-xxx</td>
                                </tr>
                                <tr>
                                    <th style="text-align: center;"></th>
                                    <td style="text-align: center;">10</td>
                                    <td style="text-align: center;"></td>
                                    <td style="text-align: center;">(10)</td>
                                    <td style="text-align: center;">0</td>
                                    <td style="text-align: center;"></td>
                                </tr>

                            </tbody>

                        </table>
                    </div> -->

                    <label> Claim points if it doesn't appear in your account:</label>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class=" form-group">
                        <label> Your Friend's ID</label>
                        <input type="text" placeholder=" Your Friend's ID " name="" class=" form-control">
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class=" form-group">
                        <label> Date Join</label>
                        <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar" style="width: 10px;margin: 0px 3px;padding: 0;font-size: inherit;"></i>
                          </div>
                          <input type="text" name="" class="form-control pull-right datepicker" value <?php echo date('d-m-y');?> placeholder="Date Join" id="">
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class=" form-group">
                        <label></label>
                        <button type="button" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; margin-top: 2%; background-color: orange; width: 100%; color: black;height: 30px;"><b>Submit</b></button>
                    </div>
                </div>


                <div class="col-md-7 col-sm-7 col-xs-12">
                    <div class=" form-group">
                        <label> Pending Point Approval</label>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr style="background-color: #726f6f;color: white">
                                        <th style="text-align: center;">Date of Claim</th>
                                        <th style="text-align: center;">Your Friend ID Number</th>
                                        <th style="text-align: center;">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php 
                                    $this->load->model("crud_model");
                                    $data_setting = $this->crud_model->get_setting();
                                    $limit   = $data_setting[0]->setting_pagination;
                                    $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;
                                
                                if(empty($page)){
                                        $position  = 0;
                                        $page = 1;
                                    } else {
                                        $position = ($page-1) * $limit;
                                    }

                                        $this->load->model('Front_Fintech/connection_model');
                                        $data_code = $this->connection_model->get_point_borrower($get_code,$limit,$position)->result();
                                        $no = $position+1;

                                     if ($data_code != null) {

                                      foreach ($data_code as $code_entry){
                                    ?>
                                        <tr style="background-color: aliceblue;">
                                            <td style="text-align: center;"><?php echo date('d/m/Y', strtotime ($code_entry->reference_date));?></td>
                                            <td style="text-align: center;"></td>
                                            <td style="text-align: center;">Approved</td>
                                        </tr>
                                        
                                    <?php 
                                        }
                                      } else {
                                    ?>



                                    <tr style="background-color: aliceblue;">
                                        <th style="text-align: center;"></th>
                                        <td style="text-align: center;"></td>
                                        <td style="text-align: center;">Approved</td>
                                    </tr>
                                    <tr style="background-color: aliceblue;">
                                        <th style="text-align: center;"></th>
                                        <td style="text-align: center;"></td>
                                        <td style="text-align: center;">Pending</td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-5 col-sm-5 col-xs-12">
                    <div class=" form-group">
                        <label> Your reference to your friend</label>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr style="background-color: #726f6f;color: white">
                                        <th style="text-align: center;">Date</th>
                                        <th style="text-align: center;">ID#</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr style="background-color: aliceblue;">
                                        <th style="text-align: center;"></th>
                                        <td style="text-align: center;"></td>
                                    </tr>
                                    <tr style="background-color: aliceblue;">
                                        <th style="text-align: center;"></th>
                                        <td style="text-align: center;"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style type="text/css">
    table, th, td {
        border: 1px solid #726f6f;
    }
</style>
<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-top: 3%; padding: 10px;  ">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <form class="form-horizontal" style="margin-top: 10%">
                        <div class="form-group">
                            <label class="col-sm-5 control-label" style="text-align: left;">Name :</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control" placeholder="" name="bio_fullname" value="<?php echo $data_code[0]->bio_fullname; ?>" required="true" readonly>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-5 control-label" style="text-align: left;">Borrower ID :</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control" placeholder="" name="register_code" value="<?php echo $data_code[0]->register_code; ?>" required="true" readonly>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <form class="form-horizontal" style="margin-top: 10%">
                        <div class="form-group">
                            <div class="col-sm-3">

                            </div>
                            <label class="col-sm-5 control-label">Average interest rate (%)</label>
                            <div class="col-sm-4" style="width: 100px;">
                                <input type="text" class="form-control" value="<?php echo number_format(@$avg_interest[0]->avg_interest,2); ?>" style="text-align: right;" disabled="true">
                            </div>

                        </div>
                    </form>

                </div>
            </div>
            <div class="row" style="background-color: white; ">
                <div class="col-md-12">
                    <HR style="display: block; border-width: 2px; border-color:black;">
                    <div class="form-group" style="text-align: center; border: 2px solid; width: 100%;margin-top: 10px;margin-bottom: 10px;">
                        <h5>Total Disbursed + &nbsp Not Yet Disbursed + = &nbsp Total Loan</h5>
                    </div>
                    <HR style="display: block; border-width: 2px; border-color:black;">
                </div>
                <div class="col-md-6" style="margin-top: 10px;">

                    <?php
                        $total_crow = 0;
                        $total_dis = 0;
                        $total_loan = 0;

                        foreach ($data_loan as $loan_entry) {
                            $total_loan =  $total_loan + $loan_entry->loan_amount;

                            if($loan_entry->loan_status == "Crowdfunding"){
                                 $total_crow =  $total_crow + $loan_entry->loan_amount;
                            } else if($loan_entry->loan_status == "Disbursed"){
                                 $total_dis =  $total_dis + $loan_entry->loan_amount;
                            } 
                        }


                    ?>

                        <div class=" form-group">
                            <label> Total Disbursed</label>
                            <input type="text" placeholder=" Total Disbursed " value="Rp. <?php echo number_format($total_dis,2); ?>" class=" form-control" disabled style="text-align: right;">
                        </div>
                        <div class=" form-group">
                            <label> Not Yet Disbursed </label>
                            <input type="text" placeholder=" Not Yet Disbursed " value="Rp. <?php echo number_format($total_crow,2); ?>" class=" form-control" disabled style="text-align: right;">
                        </div>

                </div>
                <div class="col-md-6" style="margin-top: 10px;">

                    <div class=" form-group">
                        <label> Total Loan</label>
                        <input type="text" placeholder=" Total Loan " value="Rp. <?php echo number_format($total_loan,2); ?>" class=" form-control" disabled style="text-align: right;">
                    </div>
                </div>
            </div>
            <div class="row" style="background-color: white; margin-top: 0%; margin-bottom: 3%;">
                <div class="col-md-12" align="right">
                    <a href="<?php echo base_url();?>Finance/F_borrower/account_borrower" class="btn btn-info btn-sm" style=" width: 150px; height: 25px; text-align: center; line-height: 1.3 !important;margin-bottom: 3px;" align="right">Disbursed / Ongoing List</a>
                </div>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr style="background-color: #726f6f;color: white">
                                    <th style="text-align: center;width: 5%;">ID#</th>
                                    <th style="text-align: center;width: 10%;">Purposed Date</th>
                                    <th style="text-align: center;width: 10%;">Type of Loan</th>
                                    <th style="text-align: center;width: 15%;">Amount</th>
                                    <th style="text-align: center;width: 5%;">Rating Rate</th>
                                    <th style="text-align: center;width: 5%;">Period</th>
                                    <th style="text-align: center;width: 10%;">Loan Status</th>
                                    <th style="text-align: center;width: 10%;">Payment Status</th>
                                    <th style="text-align: center;">Note</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                                if($data_crowdfunding != null){
                                                $no=0;
                                                foreach ($data_crowdfunding as $loan_entry) {
                                                $no++;
                                            ?>
                                    <tr style="background-color: whitesmoke;">
                                        <td>
                                            <?php echo $loan_entry->id_borrower_loan; ?>
                                        </td>
                                        <td align="center">
                                            <?php echo date("d/m/Y", strtotime($loan_entry->loan_date)); ?>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_type; ?>
                                        </td>
                                        <td align="right">Rp.
                                            <?php echo number_format($loan_entry->loan_amount,2);?>
                                        </td>
                                        <td align="center">
                                            <?php echo $loan_entry->loan_rating; ?> <br>
                                            <?php echo $loan_entry->loan_rate; ?>%</td>
                                        <td align="center">
                                            <?php echo $loan_entry->loan_tenor; ?> month</td>
                                        <td>
                                            <?php echo $loan_entry->loan_status; ?>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_payment; ?>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_note; ?>
                                        </td>
                                    </tr>
                                    <?php }
                                            } else {?>
                                    <tr style="background-color: whitesmoke;">
                                        <td>&nbsp;</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php }?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>

        </div>

    </div>
    </div>
</section>

<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg" style="width:1100px;">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <BR> &nbsp;
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="col-sm-3">
                        <i class="fa fa-circle" style="padding:0;font-size: 20px;color: green; width: 16%"></i>
                        <label class="control-label">On time</label>
                    </div>
                    <div class="col-sm-3">
                        <i class="fa fa-circle" style="padding:0;font-size: 20px;color: yellow; width: 16%"></i>
                        <label class="control-label">Late, already paid</label>
                    </div>
                    <div class="col-sm-3">
                        <i class="fa fa-circle" style="padding:0;font-size: 20px;color: orange; width: 16%"></i>
                        <label class="control-label">Late, not yet paid</label>
                    </div>
                    <div class="col-sm-3">
                        <i class="fa fa-circle" style="padding:0;font-size: 20px;color: red; width: 16%"></i>
                        <label class="control-label">Default</label>
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                    &nbsp;
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div style="overflow-x: auto;">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th colspan="19">Punctuality</th>
                                </tr>
                            </thead>
                            <thead>
                                <tr>
                                    <th rowspan="2" style="vertical-align: middle;text-align: center;">ID</th>
                                    <th rowspan="2" style="vertical-align: middle;text-align: center;">Loan ID</th>
                                    <th rowspan="2" style="vertical-align: middle;text-align: center;">Amount</th>
                                    <th rowspan="2" style="vertical-align: middle;text-align: center;">Period</th>
                                    <th rowspan="2" style="vertical-align: middle;text-align: center;">Rating</th>
                                    <th>Rate</th>
                                    <th rowspan="2" style="vertical-align: middle;text-align: center;">Loan Start</th>
                                    <th colspan="12" style="text-align: center">2017</th>
                                </tr>
                                <tr>

                                    <th style="width:10%">(Effective & Flat)</th>

                                    <th colspan="" style="text-align: center">1</th>
                                    <th colspan="" style="text-align: center">2</th>
                                    <th colspan="" style="text-align: center">3</th>
                                    <th colspan="" style="text-align: center">4</th>
                                    <th colspan="" style="text-align: center">5</th>
                                    <th colspan="" style="text-align: center">6</th>
                                    <th colspan="" style="text-align: center">7</th>
                                    <th colspan="" style="text-align: center">8</th>
                                    <th colspan="" style="text-align: center">9</th>
                                    <th colspan="" style="text-align: center">10</th>
                                    <th colspan="" style="text-align: center">11</th>
                                    <th colspan="" style="text-align: center">12</th>

                                </tr>
                            </thead>

                            <tbody style="background-color: aliceblue;">
                                <tr>
                                    <th rowspan="2" style="text-align: center;">1234</th>
                                    <td rowspan="2" style="text-align: center;">Loan1234</td>
                                    <td rowspan="2" style="text-align: center;">1.000.000</td>
                                    <td rowspan="2" style="text-align: center;">12 months</td>
                                    <td rowspan="2" style="text-align: center;">A+</td>
                                    <td style="text-align: center;">15%</td>
                                    <td rowspan="2" style="text-align: center;">Jan-17</td>
                                    <td rowspan="2" style="text-align: center;background-color: green;"></td>
                                    <td rowspan="2" style="text-align: center;background-color: green;"></td>
                                    <td rowspan="2" style="text-align: center;background-color: green;"></td>
                                    <td rowspan="2" style="text-align: center;background-color: green;"></td>
                                    <td rowspan="2" style="text-align: center;background-color: green;"></td>
                                    <td rowspan="2" style="text-align: center;background-color: green;"></td>
                                    <td rowspan="2" style="text-align: center;background-color: green;"></td>
                                    <td rowspan="2" style="text-align: center;"></td>
                                    <td rowspan="2" style="text-align: center;"></td>
                                    <td rowspan="2" style="text-align: center;"></td>
                                    <td rowspan="2" style="text-align: center;"></td>
                                    <td rowspan="2" style="text-align: center;"></td>

                                </tr>
                                <tr>
                                    <th style="text-align: center;">6.50%</th>
                                    <!-- <td style="text-align: center;">0</td>
                                   <td style="text-align: center;">10</td>
                                   <td style="text-align: center;"></td>
                                   <td style="text-align: center;">10</td>
                                   <td style="text-align: center;">Invest ID xxx-xxx</td> -->
                                </tr>
                            </tbody>


                        </table>
                    </div>
                </div>

                <!--  <div class="col-md-12 col-sm-12 col-xs-12">
                <div style="overflow-x: auto;">
                        <table class="table table-bordered" style="text-align: center">
                          <tr>
                            <th class="" colspan="26">Principal and Interest Report (expected and Actual)</th>
                          </tr>
                          <tr>
                            <td class=""></td>
                            <td class=""></td>
                            <td class="" colspan="24">2018</td>
                          </tr>
                          <tr>
                            <td class=""></td>
                            <td class=""></td>
                            <td class="" colspan="2">15-Jan-17</td>
                            <td class="" colspan="2">15-Feb-17</td>
                            <td class="" colspan="2">March</td>
                            <td class="" colspan="2">April</td>
                            <td class="" colspan="2">May</td>
                            <td class="" colspan="2">June</td>
                            <td class="" colspan="2">July</td>
                            <td class="" colspan="2">August</td>
                            <td class="" colspan="2">September</td>
                            <td class="" colspan="2">October</td>
                            <td class="" colspan="2">November</td>
                            <td class="" colspan="2">December</td>
                          </tr>
                          <tr>
                            <td class=""></td>
                            <td class=""></td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                          </tr>
                          <tr>
                            <td class="">ID</td>
                            <td class="">1234</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">100.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">20.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">100.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">20.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">100.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                            <td class="" rowspan="11">100.000</td>
                            <td class="" rowspan="11">20.000</td>
                          </tr>
                          <tr>
                            <td class="">Loan ID</td>
                            <td class="">Loan1234</td>
                          </tr>
                          <tr>
                            <td class="">Amount</td>
                            <td class="">1.000.000</td>
                          </tr>
                          <tr>
                            <td class="">Period</td>
                            <td class="">12 months</td>
                          </tr>
                          <tr>
                            <td class="">Rating</td>
                            <td class="">A+</td>
                          </tr>
                          <tr>
                            <td class="" rowspan="2">Rate  (Effective &amp; Flat)</td>
                            <td class="">15%</td>
                          </tr>
                          <tr>
                            <td class="">6.5%</td>
                          </tr>
                          <tr>
                            <td class="">Payment Estimate</td>
                            <td class="">1.440.000</td>
                          </tr>
                          <tr>
                            <td class="">Payment Realization</td>
                            <td class="">360.000</td>
                          </tr>
                          <tr>
                            <td class="">Status</td>
                            <td class="">On Going</td>
                          </tr>
                          <tr>
                            <td class="">Loan start</td>
                            <td class="">Jan-17</td>
                          </tr>
                          <tr>
                            <td class=""></td>
                            <td class=""></td>
                            <td class="" colspan="2">30-Jan-17</td>
                            <td class="" colspan="2">28-Feb-17</td>
                            <td class="" colspan="2">March</td>
                            <td class="" colspan="2">April</td>
                            <td class="" colspan="2">May</td>
                            <td class="" colspan="2">June</td>
                            <td class="" colspan="2">July</td>
                            <td class="" colspan="2">August</td>
                            <td class="" colspan="2">September</td>
                            <td class="" colspan="2">October</td>
                            <td class="" colspan="2">November</td>
                            <td class="" colspan="2">December</td>
                          </tr>
                          <tr>
                            <td class=""></td>
                            <td class=""></td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                          </tr>
                          <tr>
                            <td class="">ID</td>
                            <td class="">1234</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">300.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">50.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">300.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">50.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: yellow;vertical-align: bottom">300.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: yellow;vertical-align: bottom">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                            <td class="" rowspan="11">300.000</td>
                            <td class="" rowspan="11">50.000</td>
                          </tr>
                          <tr>
                            <td class="">Loan ID</td>
                            <td class="">Loan1235</td>
                          </tr>
                          <tr>
                            <td class="">Amount</td>
                            <td class="">2.000.000</td>
                          </tr>
                          <tr>
                            <td class="">Period</td>
                            <td class="">6 months</td>
                          </tr>
                          <tr>
                            <td class="">Rating</td>
                            <td class="">A+</td>
                          </tr>
                          <tr>
                            <td class="" rowspan="2">Rate  (Effective &amp; Flat)</td>
                            <td class="">15%</td>
                          </tr>
                          <tr>
                            <td class="">6.5%</td>
                          </tr>
                          <tr>
                            <td class="">Payment Estimate</td>
                            <td class="">2.100.000</td>
                          </tr>
                          <tr>
                            <td class="">Payment Realization</td>
                            <td class="">1.050.000</td>
                          </tr>
                          <tr>
                            <td class="">Status</td>
                            <td class="">On Going</td>
                          </tr>
                          <tr>
                            <td class="">Loan start</td>
                            <td class="">Jan-17</td>
                          </tr>
                          <tr>
                            <td class=""></td>
                            <td class=""></td>
                            <td class="" colspan="2">30-Jan-17</td>
                            <td class="" colspan="2">28-Feb-17</td>
                            <td class="" colspan="2">March</td>
                            <td class="" colspan="2">April</td>
                            <td class="" colspan="2">May</td>
                            <td class="" colspan="2">June</td>
                            <td class="" colspan="2">July</td>
                            <td class="" colspan="2">August</td>
                            <td class="" colspan="2">September</td>
                            <td class="" colspan="2">October</td>
                            <td class="" colspan="2">November</td>
                            <td class="" colspan="2">December</td>
                          </tr>
                          <tr>
                            <td class=""></td>
                            <td class=""></td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                            <td class="">Principal</td>
                            <td class="">Interest</td>
                          </tr>
                          <tr>
                            <td class="">ID</td>
                            <td class="">1234</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">400.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">90.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">400.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">90.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">400.000</td>
                            <td class="" rowspan="11" style="text-align: center;background-color: green;vertical-align: bottom">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">90.000</td>
                            <td class="" rowspan="11">400.000</td>
                            <td class="" rowspan="11">50.000</td>
                          </tr>
                          <tr>
                            <td class="">Loan ID</td>
                            <td class="">Loan1236</td>
                          </tr>
                          <tr>
                            <td class="">Amount</td>
                            <td class="">5.000.000</td>
                          </tr>
                          <tr>
                            <td class="">Period</td>
                            <td class="">12 months</td>
                          </tr>
                          <tr>
                            <td class="">Rating</td>
                            <td class="">A+</td>
                          </tr>
                          <tr>
                            <td class="">Rate  (Effective &amp; Flat)</td>
                            <td class="">15%</td>
                          </tr>
                          <tr>
                            <td class=""></td>
                            <td class="">6.5%</td>
                          </tr>
                          <tr>
                            <td class="">Payment Estimate</td>
                            <td class="">5.880.000</td>
                          </tr>
                          <tr>
                            <td class="">Payment Realization</td>
                            <td class="">1.470.000</td>
                          </tr>
                          <tr>
                            <td class="">Status</td>
                            <td class="">On Going</td>
                          </tr>
                          <tr>
                            <td class="">Loan start</td>
                            <td class="">Jan-17</td>
                          </tr>
                          <tr>
                            <td class="" colspan="2">Subtotal</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                            <td class="">800.000</td>
                            <td class="">160000</td>
                          </tr>
                          <tr>
                            <td class="" colspan="2">Total</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                            <td class="" colspan="2">960.000</td>
                          </tr>
                        </table>
                </div>
            </div> -->

                <div class="col-md-12 col-sm-12 col-xs-12">
                    &nbsp;
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
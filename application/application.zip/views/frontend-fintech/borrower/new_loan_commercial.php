<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
    /* The check_custom */
      .check_custom {
          position: relative;
          padding-left: 35px;
          margin-bottom: 12px;
          margin-right: 10px;
          cursor: pointer;
          font-size: 15px;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
      }
    
      /* Hide the browser's default checkbox */
      .check_custom input {
          position: absolute;
          opacity: 0;
          cursor: pointer;
      }
    
      /* Create a custom checkbox */
      .check_mark {
          position: relative;
          top: 0;
          left: 0;
          height: 25px;
          width: 25px;
          background-color: #eee;
      }
    
      /* On mouse-over, add a grey background color */
      .check_custom:hover input ~ .check_mark {
          background-color: #ccc;
      }
    
      /* When the checkbox is checked, add a blue background */
      .check_custom input:checked ~ .check_mark {
          background-color: #ffd100;
      }
    
      /* Create the check_mark/indicator (hidden when not checked) */
      .check_mark:after {
          content: "";
          position: relative;
          display: none;
          border-radius: 10%;
      }
    
      /* Show the check_mark when checked */
      .check_custom input:checked ~ .check_mark:after {
          display: block;
      }
    
      /* Style the check_mark/indicator */
      .check_custom .check_mark:after {
          left: 10px;
          top: 7px;
          width: 7px;
          height: 10px;
          border: solid white;
          border-width: 0 3px 3px 0;
          -webkit-transform: rotate(45deg);
          -ms-transform: rotate(45deg);
          transform: rotate(45deg);
      }

       /*wizard*/
      .background-step {
          background-color: orange;
      }
      .stepwizard-step p {
          margin-top: 10px;
      }

      .stepwizard-row {
          display: table-row;
      }

      .stepwizard {
          display: table;
          width: 100%;
          position: relative;
      }

      .stepwizard-step button[disabled] {
          opacity: 1 !important;
          filter: alpha(opacity=100) !important;
      }

      .stepwizard-row:before {
          top: 14px;
          bottom: 0;
          position: absolute;
          content:" ";
          width: 100%;
          height: 1px;
          background-color: #ccc;
          z-order: 0;

      }

      .stepwizard-step {
          display: table-cell;
          text-align: center;
          position: relative;
      }

      .btn-circle {
        width: 64px;
        height: 34px;
        text-align: center;
        padding: 3px 0;
        font-size: 12px;
        line-height: 26px;
        border-radius: 8px;
      }
      .btn_modal_ok {
          height: 27px;
          width: 65px;
      }
      .btn_modal_cancel {
          height: 27px;
          width: 70px;
      }

      .form_custom{
        border :0px solid !important;
        border-color: transparent !important;
        background-color: transparent !important;
      }

      table, th, td {
        border: 1px solid #726f6f;
      }

</style>

<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-top: 2%; margin-bottom: 2%;">
                
                <div class="col-md-12 xol-sm-12 col-xs-12">
                   <div class=" form-group" align="center">
                    <label><h2>Business Loan Propose</h2></label>
                  </div>
                  <div class="stepwizard">
                        <div class="stepwizard-row">
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_komersil" class="btn btn-default btn-circle">Step 1</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_file_komersil" class="btn btn-default btn-circle">Step 2</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/new_loan_commercial" class="btn btn-warning btn-circle">Step 3</a>
                            </div>
                        </div>
                    </div>
                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data" id="myForm" onsubmit="return confirm('The proposed loan can not be canceled. are you sure you want to apply for this loan?')">
                    <div class="row" style="margin-left: 1%;">
                        <div class="col-md-3 col-sm-12 col-xs-12"></div>
                        <div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 0%">
                            <br>
                                <div class=" form-group">
                                    <label>Propose Commercial Loan</label>
                                    <select class="form-control select2" name="loan_type" id="input_type" style="margin-left:;" onchange="check_score()">
                                        <option value="0">- Choose Statement -</option>
                                        <!-- <option value="Invoice Financing">Invoice Financing</option> -->
                                        <option value="Fixed Loan">Fixed Loan</option>
                                        <option value="Flexible Loan">Flexible Loan</option>
                                    </select>
                                    <div id="input_type_alert" style="color: red; display: none;">* select the Commercial Loan type being submitted</div>
                                </div>
                                <div class="form-group">
                                    <label style="text-align: left;">Amount</label>
                                    <input type="text" class=" form-control dengan-rupiah" placeholder="Amount" id="input_amount" oninput="check_score()" style="text-align: right;">
                                    <div id="input_amount_alert" style="color: red; display: none;">* input the loan amount being submitted</div>
                                    <div id="min_invest_alert" style="color: red; display: none;">* min loan amount 500.000</div>
                                </div>
                                <div class="form-group">
                                    <label style="text-align: left;">Tenor</label>
                                    <select class="form-control select2" style="margin-left:;" id="input_tenor" onchange="check_score()">
                                        <option value="0">- Choose Periode -</option>
                                        <?php
                                            foreach ($data_periode as $periode_entry){
                                        ?>
                                        <option value="<?php echo $periode_entry->periode; ?>"><?php echo $periode_entry->periode; ?> month</option>
                                        <?php } ?>
                                    </select>
                                    <div id="input_tenor_alert" style="color: red; display: none;">* select the period or tenor being submitted</div>
                                </div>
                                <div class="form-group">
                                    <label style="text-align: left;">Description/Note</label>
                                    <input type="text" class=" form-control" placeholder="" required="true" name="description">
                                    <div id="input_deskripsi" style="color: red; display: none;">* fill in your loan description</div>
                                </div>
                        </div>
                        <div class="col-md-3 col-sm-12 col-xs-12"></div>
                    </div>
                    <div class="row" style="margin-top:3%;">
                        <div class="form-group">
                            <label class="control-label" style="margin-left:3%;">Based on our temporary risk analysis, your loan has been rated as:</label>

                        </div>

                        <div class=" form-group" style="text-align: center;">
                            <div class="table-responsive" style="margin:0 3%;">
                                <table class="table" >
                                    <thead>
                                        <tr style="background-color: #726f6f;color: white" >
                                            <th style="text-align: center;width: 14%;">Type of Loan</th>
                                            <th style="text-align: center;width: 15%;">Amount</th>
                                            <th style="text-align: center;width: 7%;">Tenor</th>
                                            <th style="text-align: center;width: 7%;">Rating</th>
                                            <th style="text-align: center;width: 8%;">Rate %</th>
                                            <th style="text-align: center;width: 15%;">Principal</th>
                                            <th style="text-align: center;width: 15%;">Interest</th>
                                            <th style="text-align: center;width: 15%;">Total Per Month</th>
                                            <th style="text-align: center;width: 8%;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr style="background-color: whitesmoke; ">
                                            <td>
                                            <input type="text" class="form-control form_custom" id="type_loan" disabled="true"></td>
                                            <td>
                                            <input type="hidden" name="amount" id="amount" required="true">
                                            <input type="hidden" name="needs" id="needs" required="true">
                                            <input type="text" class="form-control form_custom" id="amount2" disabled="true"  style="text-align: right;"></td>
                                            <td>
                                            <input type="hidden" name="periode" id="periode" required="true">
                                            <input type="text" class="form-control form_custom" id="periode2" disabled="true"  style="text-align: center;"></td>
                                            <td>
                                            <input type="hidden" name="rating" id="rating" required="true">
                                            <input type="text" class="form-control form_custom" id="rating2" disabled="true"  style="text-align: center;"></td>
                                            <td>
                                            <input type="hidden" name="rate" id="rate" required="true">
                                            <input type="text" class="form-control form_custom" id="rate2" disabled="true"  style="text-align: center;"></td>
                                            <td><input type="text" class="form-control form_custom" id="principal2" disabled="true"  style="text-align: right;"></td>
                                            <td><input type="text" class="form-control form_custom" id="interest2" disabled="true"  style="text-align: right;"></td>
                                            <td>
                                            <input type="hidden" name="principal" id="principal" required="true">
                                            <input type="hidden" name="interest" id="interest" required="true">
                                            <input type="hidden" name="montly" id="montly" required="true">
                                            <input type="text" class="form-control form_custom" id="montly2" disabled="true"  style="text-align: right;"></td>
                                            <td>
                                                <button type="button" id="post_button" class="btn-danger btn-sm btn btnwdt" data-toggle="modal" data-target="#myModal_term" style="background-color: orange; height: 25px;width: 50px; text-align: center; line-height: 1.1 !important;display: none;">Propose</button>
                                                <!-- <a href="#" id="post_button" onclick="save_data()" class="btn-danger btn-sm btn btnwdt" style="background-color: orange; height: 25px; text-align: center; line-height: 1.1 !important;display: none;">Propose</a> -->
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                
                            </div>
                            <div class="form-group">
                                <label class="control-label" style="margin-left:3%;">When it's approved, there's email notification.</label>

                            </div>
                        </div>

                    </div>

                </div>
                <!-- -->
            </div>
        </div>
    </div>
</section>

<div id="myModal_term" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg" style="width: 62%;">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <!-- <h4 class="modal-title" style="text-align: right;">PT One Stop</h4> -->
              <div class="container">
              <div class="row">
                <div class="col-md-3 col-sm-4 col-xs-12">
                
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                  <ul class="nav nav-pills">
                    <a class="navbar-brand" href="#">
                      <img alt="Brand" class="img-responsive img-logo" src="<?php echo base_url();?>uploads/base-img/logoSanders.png">
                    </a>

                  </ul>
                  
                  </div>
                </div>

                    <div class="col-md-9 col-sm-8 col-xs-12">
                      
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <div class="clearfix"> </div>
                                      
                        </div><!-- /.navbar-collapse -->
                    </div>

                  </div> <!-- .row -->
                  </div><!-- /.container-fluid -->
                  <br>
               <h2 style="text-align: center;">TERMS AND CONDITIONS</h2>
          </div>
        
          <div class="col-md-12 col-sm-12 col-xs-12" style="overflow-y: auto;overflow-x: hidden;height: 400px;text-align: justify;">
              <br>
                <?php
                  $date = date('d-m-Y'); 
                  $day = date('D', strtotime($date));
                  $dayList = array(
                    'Sun' => 'Minggu',
                    'Mon' => 'Senin',
                    'Tue' => 'Selasa',
                    'Wed' => 'Rabu',
                    'Thu' => 'Kamis',
                    'Fri' => 'Jumat',
                    'Sat' => 'Sabtu'
                  );
                $idMax = $this->loan_model->loan_code();
                $noUrut =(int) substr($idMax[0]->maxID,3,9);
                $noUrut ++;
                $newID="LN".sprintf("%09s",$noUrut);
                $term_id = $newID."/SA/".date('m/Y');
                $no_sk = $newID."/SK/".date('m/Y');
                ?>
                <div class="WordSection1">

                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">LAMPIRAN
                  II<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" align="right" style="text-align: center;
                  mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">FORM PERJANJIAN PINJAMAN BISNIS<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:1.0pt;mso-line-height-rule:exactly"><!--[if gte vml 1]><v:shapetype
                   id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
                   path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
                   <v:stroke joinstyle="miter"/>
                   <v:formulas>
                    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
                    <v:f eqn="sum @0 1 0"/>
                    <v:f eqn="sum 0 0 @1"/>
                    <v:f eqn="prod @2 1 2"/>
                    <v:f eqn="prod @3 21600 pixelWidth"/>
                    <v:f eqn="prod @3 21600 pixelHeight"/>
                    <v:f eqn="sum @0 0 1"/>
                    <v:f eqn="prod @6 1 2"/>
                    <v:f eqn="prod @7 21600 pixelWidth"/>
                    <v:f eqn="sum @8 21600 0"/>
                    <v:f eqn="prod @7 21600 pixelHeight"/>
                    <v:f eqn="sum @10 21600 0"/>
                   </v:formulas>
                   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
                   <o:lock v:ext="edit" aspectratio="t"/>
                  </v:shapetype><v:shape id="_x0000_s1026" type="#_x0000_t75" style='position:absolute;
                   margin-left:16pt;margin-top:11.65pt;width:529.25pt;height:3.5pt;z-index:-251659264'>
                   <v:imagedata src="file:///C:\Users\MFIQRI~1\AppData\Local\Temp\msohtmlclip1\01\clip_image001.jpg"
                    o:title=""/>
                  </v:shape><![endif]--><!--[if !vml]--><span style="mso-ignore:vglayout;position:
                  absolute;z-index:251657211;margin-left:21px;margin-top:15px;width:706px;
                  height:5px"><img width="706" height="5" src="file:///C:/Users/MFIQRI~1/AppData/Local/Temp/msohtmlclip1/01/clip_image002.jpg" v:shapes="_x0000_s1026"></span><!--[endif]--><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:17.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">PERJANJIAN PINJAMAN<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">No: <?php echo $term_id ;?><o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Tertanggal
                  <?php echo date('d/m/Y');?><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:19.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">antara<o:p></o:p></span></p>

                  
                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>


                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><?php echo $data_commercial[0]->borrower_business_name;?><o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">sebagai
                  Peminjam<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>


                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:19.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">dan<o:p></o:p></span></p>

                  

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:19.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="text-align: center;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">PT SATUSTOP SOLUSI<o:p></o:p></span></b></p>

                  </div>

                  <br><div class="WordSection2">

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span><b><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PERJANJIAN PINJAMAN </span></b><span style="font-size: 12pt; line-height: 118%; font-family: &quot;Times New Roman&quot;, serif;">ini (selanjutnya disebut sebagai “<b>Perjanjian
                  Pinjaman</b>”) dibuat dan<b> </b>ditandatangani
                  tanggal <?php echo date('d-m-Y');?> oleh dan antara:</span></p></div><div class="WordSection3">

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:47.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-30.2pt;
                  line-height:118%;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">1.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial"><?php echo $data_commercial[0]->borrower_business_name;?></span></b><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">, suatu perusahaan yang didirikan
                  berdasarkan hukum Negara Republik Indonesia,<b style="mso-bidi-font-weight:
                  normal"> </b>beralamat di <?php echo $data_commercial[0]->borrower_address_company.",".@$data_province_commercial[0]->nama;?> yang dalam hal ini diwakili oleh
                  <?php echo $data_bio[0]->bio_fullname;?> dalam kedudukannya selaku Direktur, sebagai peminjam (“<b style="mso-bidi-font-weight:
                  normal">Penerima Pinjaman</b>”);<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:47.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-30.2pt;
                  line-height:118%;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">2.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">PT SATUSTOP SOLUSI</span></b><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">, suatu
                  perusahaan yang didirikan berdasarkan hukum Negara<b style="mso-bidi-font-weight:
                  normal"> </b>Republik Indonesia, beralamat di <?php echo $data_contact[0]->contact_us_headquarter;?>, Indonesia, yang dalam hal ini
                  diwakili oleh <?php echo $data_direk[0]->management_menu_person;?> dalam kedudukannya selaku <?php echo $data_direk[0]->management_menu_position;?> yang dalam hal ini
                  bertindak selaku penerima kuasa dari pemberi pinjaman berdasarkan:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:63.0pt;text-indent:-16.0pt;mso-line-height-alt:
                  0pt;mso-list:l0 level2 lfo1;tab-stops:63.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">(a)<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp; </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">surat
                  kuasa No. <?php echo $no_sk;?> tanggal <? echo date('d/m/Y');?>;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:64.0pt;text-indent:-17.0pt;mso-line-height-alt:
                  0pt;mso-list:l0 level2 lfo1;tab-stops:64.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">(b)<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp; </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Surat
                  kuasa No. <?php echo $no_sk;?> tanggal <? echo date('d/m/Y');?>;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:63.0pt;text-indent:-16.0pt;mso-line-height-alt:
                  0pt;mso-list:l0 level2 lfo1;tab-stops:63.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">(c)<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp; </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Surat
                  kuasa No. <?php echo $no_sk;?> tanggal <? echo date('d/m/Y');?>;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">(selanjutnya
                  disebut sebagai “<b style="mso-bidi-font-weight:normal">Pemberi Pinjaman</b>”).<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:16.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:5.0pt;margin-bottom:0cm;
                  margin-left:17.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">(Pemberi Pinjaman, Penerima Pinjaman, masing-masing disebut sebagai ”<b style="mso-bidi-font-weight:normal">Pihak</b>” dan secara bersama-sama disebut
                  sebagai ”<b style="mso-bidi-font-weight:normal">Para Pihak</b>”)<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:17.0pt;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">BAHWA</span></b><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:47.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-32.85pt;
                  line-height:118%;mso-list:l1 level1 lfo2;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">A.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman bersama dengan
                  PT SatuStop Solusi (“<b style="mso-bidi-font-weight:normal">SatuStop</b>”)
                  telah menandatangani Perjanjian Pemberian Fasilitas Pinjaman (“<b style="mso-bidi-font-weight:normal">Perjanjian Pemberian Fasilitas Pinjaman</b>”)
                  yang mana SatuStop bertindak selaku pengatur transaksi pemberian fasilitas
                  pinjaman melalui Situs (sebagaimana didefinisikan di bawah ini) yang dikelola
                  SatuStop sehingga Penerima Pinjaman bisa memperoleh pinjaman dari satu atau
                  lebih investor;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:47.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-32.2pt;
                  line-height:117%;mso-list:l1 level1 lfo2;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">B.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Para Pihak dengan ini sepakat
                  untuk menuangkan kesepakatan Pinjaman yang diberikan oleh Pemberi Pinjaman
                  kepada Penerima Pinjaman melalui sistem dalam Situs yang dikelola oleh
                  SatuStop dalam suatu instrumen hukum yang akan menjadi dasar dari adanya
                  Pinjaman tersebut dari Pemberi Pinjaman kepada Penerima Pinjaman.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:17.0pt;line-height:114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">OLEH KARENA ITU, Para Pihak setuju untuk mengadakan Perjanjian Pinjaman
                  ini berdasarkan syarat-syarat dan ketentuan-ketentuan sebagai berikut:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:337.0pt;margin-bottom:
                  0cm;margin-left:48.0pt;margin-bottom:.0001pt;text-indent:-31.2pt;line-height:
                  205%;mso-list:l2 level1 lfo3;tab-stops:47.25pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">1.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">DEFINISI DAN PENAFSIRAN </span></b><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:205%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"> </span></p></div><div class="WordSection5">

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                  114%"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1.1</span><span style="font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Definisi<o:p></o:p></span></p>

                    

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                  114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Seluruh istilah-istilah yang digunakan dalam
                  Perjanjian Pinjaman ini memiliki arti sebagaimana sebagai berikut:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:1.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">“<b style="mso-bidi-font-weight:normal">Jangka Waktu Pinjaman</b>”
                  adalah sebagaimana dimaksud dalam Pasal 3 Perjanjian Pinjaman ini;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                  118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">“<b style="mso-bidi-font-weight:normal">Jaminan
                  Pribadi</b>” adalah akta jaminan pribadi dan ganti kerugian yang apabila
                  diminta oleh SatuStop untuk ditandatangani dan akan dibuat di hadapan notaris
                  di Jakarta, oleh dan antara pemberi jaminan pribadi dan pihak yang bertindak
                  mewakili Pemberi Pinjaman;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">“<b style="mso-bidi-font-weight:normal">Klien</b>” adalah klien yang tercatat dalam
                  Lampiran I Perjanjian Pinjaman ini;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:1.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">“<b style="mso-bidi-font-weight:normal">Pelunasan Dipercepat</b>” adalah
                  sebagaimana dimaksud dalam Pasal 4.2.1 Perjanjian Pinjaman ini;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:8.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">“<b style="mso-bidi-font-weight:normal">Pinjaman</b>” adalah pinjaman
                  yang diberikan oleh Pemberi Pinjaman kepada Penerima Pinjaman melalui Situs
                  yang didasarkan pada Piutang yang Memenuhi Syarat;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">“<b style="mso-bidi-font-weight:normal">Piutang</b>” adalah yang
                  berkenaan dengan setiap kontrak pekerjaan, piutang yang harus dibayarkan oleh
                  Klien kepada Penerima Pinjaman dalam jumlah yang setara dengan nilai tagihan
                  dari suatu kontrak pekerjaan, termasuk Pajak berdasarkan kontrak pekerjaan
                  tersebut.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">“<b style="mso-bidi-font-weight:normal">Piutang Yang Memenuhi Syarat</b>” adalah
                  setiap piutang yang memenuhi kriteria berikut:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.25pt;mso-line-height-alt:
                  0pt;mso-list:l3 level1 lfo4;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">a.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">dinyatakan dalam mata uang rupiah;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.95pt;mso-line-height-alt:
                  0pt;mso-list:l3 level1 lfo4;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">b.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">terkait dengan Penerima Pinjaman yang tidak
                  melanggar jaminan atau janji apa pun; dan<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.25pt;mso-line-height-alt:
                  0pt;mso-list:l3 level1 lfo4;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">c.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">terkait dengan suatu kontrak pekerjaan;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.95pt;line-height:
                  114%;mso-list:l3 level1 lfo4;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">d.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">yang disetujui oleh koordinator
                  fasilitas sebagaimana diatur dalam Perjanjian Pemberian Fasilitas Pinjaman. ;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.25pt;line-height:
                  114%;mso-list:l3 level1 lfo4;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">e.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">yang nilai tagihannya, pada saat
                  dijumlahkan dengan jumlah keseluruhan yang masih terutang berdasarkan pinjaman
                  tidak melebihi jumlah maksimum pinjaman yang tersedia;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:9.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">“<b style="mso-bidi-font-weight:normal">Rekening Pembayaran Pinjaman</b>”
                  adalah sebagaimana dimaksud dalam Pasal 4.1.2 Perjanjian Pinjaman ini;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">“<b style="mso-bidi-font-weight:normal">Situs</b>” adalah situs </span><a href="https://www.sanders.co.id/"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial;color:#0000CC">www.sanders.co.id</span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial;
                  color:windowtext"> </span></a><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">yang dikelola oleh SatuStop;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                  118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">“<b style="mso-bidi-font-weight:normal">Tagihan</b>”
                  adalah tagihan Penerima Pinjaman kepada Klien berdasarkan kontrak pekerjaan
                  antara Penerima Pinjaman dan Klien yang merupakan dokumen yang mendasari
                  Pinjaman yang akan diterima oleh Penerima Pinjaman sebagaimana tersebut dalam
                  Lampiran I Perjanjian Pinjaman ini;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">“<b style="mso-bidi-font-weight:normal">Tanggal Jatuh Tempo</b>” adalah
                  tanggal yang tercantum dalam Tagihan yang mana tanggal pembayaran Klien kepada
                  Penerima Pinjaman;<o:p></o:p></span></p>

                  </div>

                  <div class="WordSection6"><p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><br></p></div><div class="WordSection7">

                  <p class="MsoNormal" style="margin-left:79.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">“<b style="mso-bidi-font-weight:normal">Wanprestasi</b>” adalah sebagaimana
                  dimaksud dalam Pasal 10 Perjanjian Pinjaman ini;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                  line-height:116%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1.2</span><span style="font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Judul-judul yang digunakan dalam Perjanjian Pinjaman ini hanya untuk
                  kemudahan dan tidak mempunyai pengaruh apapun terhadap konstruksi Perjanjian
                  Pinjaman serta tidak dapat digunakan untuk menafsirkan ketentuan pasal yang
                  bersangkutan.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                  line-height:116%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1.3</span><span style="font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Kecuali ditentukan lain, referensi pada ketentuan peraturan
                  perundang-undangan adalah ketentuan peraturan perundang-undangan yang
                  bersangkutan beserta perubahannya dari waktu ke waktu.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                  line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1.4</span><span style="font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Kecuali disyaratkan lain, acuan terhadap suatu pasal, ayat atau lampiran
                  Perjanjian Pinjaman ini adalah acuan terhadap pasal, ayat atau lampiran adalah
                  acuan terhadap pasal, ayat atau lampiran Perjanjian Pinjaman ini, dan acuan
                  terhadap Perjanjian Pinjaman ini adalah acuan terhadap Perjanjian Pinjaman ini
                  beserta lampirannya.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                  0pt;mso-list:l4 level1 lfo5;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">2.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PENYEDIAAN
                  PINJAMAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:47.0pt;margin-bottom:.0001pt;text-align:justify;line-height:116%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Dengan tunduk pada ketentuan-ketentuan dari Perjanjian Pinjaman ini dan
                  yang terdapat dalam Situs dan Perjanjian Pemberian Fasilitas Pinjaman, Pemberi
                  Pinjaman telah setuju untuk menyediakan suatu Pinjaman sebagaimana dirinci
                  dalam Lampiran I.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.35pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                  0pt;mso-list:l4 level1 lfo5;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">3.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">JANGKA
                  WAKTU PINJAMAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:47.0pt;margin-bottom:.0001pt;text-align:justify;line-height:116%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Jangka waktu Pinjaman ditetapkan terhitung sejak tanggal pengiriman atas
                  seluruh jumlah Pinjaman secara penuh sampai dengan Tanggal Jatuh Tempo yaitu
                  tanggal :loan due date dan dapat diperpanjang sesuai dengan kesepakatan dari
                  Para Pihak (“<b style="mso-bidi-font-weight:normal">Jangka Waktu Pinjaman</b>”).<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.35pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:160.0pt;margin-bottom:
                  0cm;margin-left:48.0pt;margin-bottom:.0001pt;text-indent:-31.2pt;line-height:
                  205%;mso-list:l4 level1 lfo5;tab-stops:47.25pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">4.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">PEMBAYARAN PINJAMAN DAN PELUNASAN DIPERCEPAT </span></b></p>

                  <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                  tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">4.1</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:
                  normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Pembayaran Pinjaman<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:1.0pt;mso-line-height-rule:exactly"><!--[if gte vml 1]><v:line
                   id="_x0000_s1027" style='position:absolute;z-index:-251658240' from="434.4pt,-87.9pt"
                   to="440.4pt,-87.9pt" o:userdrawn="t" strokeweight="1pt"/><![endif]--><!--[if !vml]--><span style="mso-ignore:vglayout;position:relative;z-index:251658235"><span style="position:absolute;left:578px;top:-118px;width:10px;height:2px"><img width="10" height="2" src="file:///C:/Users/MFIQRI~1/AppData/Local/Temp/msohtmlclip1/01/clip_image003.gif" v:shapes="_x0000_s1027"></span></span><!--[endif]--><!--[if gte vml 1]><v:line
                   id="_x0000_s1028" style='position:absolute;z-index:-251657216' from="457.7pt,-87.9pt"
                   to="463.7pt,-87.9pt" o:userdrawn="t" strokeweight="1pt"/><![endif]--><!--[if !vml]--><span style="mso-ignore:vglayout;position:relative;z-index:251659259"><span style="position:absolute;left:609px;top:-118px;width:10px;height:2px"><img width="10" height="2" src="file:///C:/Users/MFIQRI~1/AppData/Local/Temp/msohtmlclip1/01/clip_image003.gif" v:shapes="_x0000_s1028"></span></span><!--[endif]--><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:17.95pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:112.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                  line-height:116%;tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.1<span style="mso-tab-count:
                  1">&nbsp; </span>Pinjaman dan jumlah lain yang terutang berdasarkan Perjanjian
                  Pinjaman harus dilunasi oleh Penerima Pinjaman dalam Jangka Waktu Pinjaman
                  sebagaimana diatur dalam Pasal 3 Perjanjian Pinjaman ini.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:112.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:116%;tab-stops:111.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.2<span style="mso-tab-count:1">&nbsp; </span>Pembayaran atas Angsuran dilakukan oleh
                  Penerima Pinjaman kepada Pemberi Pinjaman pada Hari Kerja ke rekening bank yang
                  ditentukan pada Lampiran II dari Perjanjian ini (“ <b style="mso-bidi-font-weight:
                  normal">Rekening Pembayaran Pinjaman</b>”).<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:112.0pt;margin-bottom:.0001pt;text-indent:-31.45pt;line-height:
                  114%;tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.3<span style="mso-tab-count:
                  1">&nbsp; </span>Setiap pembayaran dari Penerima Pinjaman, akan dipergunakan untuk
                  pembayaran dengan urutan sebagai berikut:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:142.0pt;text-indent:-30.0pt;mso-line-height-alt:
                  0pt;mso-list:l5 level1 lfo6;tab-stops:142.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">a.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">biaya-biaya;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:142.0pt;text-indent:-30.7pt;mso-line-height-alt:
                  0pt;mso-list:l5 level1 lfo6;tab-stops:142.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">b.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">denda yang belum dibayarkan;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:142.0pt;text-indent:-30.0pt;mso-line-height-alt:
                  0pt;mso-list:l5 level1 lfo6;tab-stops:142.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">c.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Suku Bunga; dan<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.4pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:111.0pt;text-indent:0cm;mso-line-height-alt:
                  0pt;mso-list:l5 level1 lfo6"><!--[if !supportLists]--><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;"><span style="mso-list:Ignore">d.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">pokok pinjaman yang terutang<o:p></o:p></span></p>

                  </div>

                  <div class="WordSection8"><p class="MsoNormal" style="line-height:16.5pt;mso-line-height-rule:exactly"><br></p></div><div class="WordSection9">

                  <p class="MsoNormal" style="margin-left:112.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:114%;tab-stops:111.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.4<span style="mso-tab-count:1">&nbsp; </span>Apabila pembayaran atas Angsuran jatuh pada
                  hari libur nasional di Indonesia atau pada hari Sabtu atau Minggu, maka
                  pembayaran harus dilakukan pada Hari Kerja sebelumnya.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:112.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:117%;tab-stops:111.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.5<span style="mso-tab-count:1">&nbsp; </span>Pelunasan Pinjaman apa pun dan jumlah lain apa
                  pun yang harus dibayarkan harus dilakukan dengan jumlah hasil piutang yang
                  terkait dengan Pinjaman tersebut. Apabila dengan alasan apa pun, Pemberi
                  Pinjaman tidak menerima jumlah tersebut dalam Rekening Pembayaran Pinjaman
                  sampai dengan Tanggal Jatuh Tempo, Pemberi Pinjaman berwenang untuk melakukan
                  tindakan yang diperlukan berdasarkan Perjanjian Pinjaman ini dan/atau
                  Perjanjian Pemberian Fasilitas Pinjaman.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:11.75pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                  tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">4.2</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:
                  normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Pelunasan Dipercepat<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:112.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:117%;tab-stops:111.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.2.1<span style="mso-tab-count:1">&nbsp; </span>Penerima Pinjaman diperkenankan untuk
                  melakukan pembayaran seluruh Pinjaman lebih cepat dari waktu yang ditetapkan
                  dengan melakukan pemberitahuan tertulis sedikitnya 5 (lima) hari kerja sebelum
                  tanggal pelunasan dipercepat yang direncakan (“<b style="mso-bidi-font-weight:
                  normal">Pelunasan</b> <b style="mso-bidi-font-weight:normal">Dipercepat</b>”)
                  kepada Pemberi Pinjaman.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:112.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:117%;tab-stops:111.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.2.2<span style="mso-tab-count:1">&nbsp; </span>Penerima Pinjaman tidak dikenakan denda
                  terhadap Pelunasan Dipercepat, namun Penerima Pinjaman diwajibkan melunasi
                  bunga kepada Pemberi Pinjaman senilai nominal yang akan terhutang apabila
                  seolah-olah Penerima Pinjaman tidak melakukan pembayaran dipercepat secara
                  sukarela.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:11.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                  tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">4.3</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:
                  normal"><span style="font-size:11.5pt;mso-bidi-font-size:10.0pt;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Pembayaran Sebagian<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:15.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                  117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Apabila Pemberi Pinjaman menerima pembayaran yang
                  tidak mencukupi untuk melunasi semua jumlah yang pada saat itu telah jatuh
                  tempo dan harus dibayarkan oleh Penerima Pinjaman, Pemberi Pinjaman akan
                  memotong pembayaran tersebut dari kewajiban-kewajiban Penerima Pinjaman
                  tersebut dengan urutan sebagai berikut:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-align:justify;text-indent:
                  -29.25pt;line-height:118%;mso-list:l6 level1 lfo7;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">a.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">pertama</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">, pada saat atau menjelang
                  pembayaran secara pro rata atas setiap biaya, ongkos<b style="mso-bidi-font-weight:
                  normal"> </b>dan pengeluaran yang belum dibayarkan kepada Pemberi Pinjaman dan
                  agen lain yang ditunjuk oleh Pemberi Pinjaman;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-align:justify;text-indent:
                  -29.95pt;line-height:118%;mso-list:l6 level1 lfo7;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">b.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">kedua</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">, pada saat atau menjelang
                  pembayaran secara pro rata atas setiap bunga yang<b style="mso-bidi-font-weight:
                  normal"> </b>terakumulasi, biaya, komisi, ongkos, ganti rugi dan pengeluaran
                  (selain yang ditentukan dalam poin (a) Pasal 4.3 di atas) yang telah jatuh
                  tempo tetapi belum dibayarkan berdasarkan Perjanjian Pinjaman ini;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:1.0pt;margin-bottom:0cm;
                  margin-left:109.0pt;margin-bottom:.0001pt;text-indent:-29.25pt;line-height:
                  118%;mso-list:l6 level1 lfo7;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">c.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">ketiga</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">, pada saat atau menjelang
                  pembayaran secara pro rata atas setiap jumlah pokok<b style="mso-bidi-font-weight:
                  normal"> </b>yang telah jatuh tempo tetapi belum dibayarkan berdasarkan
                  Perjanjian Pinjaman ini; dan<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.95pt;line-height:
                  118%;mso-list:l6 level1 lfo7;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">d.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">keempat</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">, pada saat atau menjelang
                  pembayaran secara pro rata atas jumlah lain apa pun<b style="mso-bidi-font-weight:
                  normal"> </b>yang telah jatuh tempo tetapi belum dibayarkan.</span></p></div><div class="WordSection11">

                  <p class="MsoNormal" style="line-height:14.3pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                  0pt;mso-list:l7 level1 lfo8;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">5.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">SUKU
                  BUNGA, BIAYA-BIAYA DAN DENDA KETERLAMBATAN</span></b><span style="font-size:
                  12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                  tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">5.1</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:
                  normal"><span style="font-size:11.5pt;mso-bidi-font-size:10.0pt;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Suku Bunga<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:15.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;line-height:114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Suku bunga yang digunakan terhadap Pinjaman adalah sebagaimana
                  disebutkan dalam term sheet dan Lampiran I Perjanjian Pinjaman ini.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                  tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">5.2</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:
                  normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Biaya-biaya<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;line-height:114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Atas Pinjaman yang diberikan oleh Pemberi Pinjaman, Penerima Pinjaman
                  wajib membayar biaya dan pengeluaran sebagai berikut :<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-align:justify;text-indent:
                  -29.25pt;line-height:117%;mso-list:l8 level1 lfo9;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">a.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman setuju untuk
                  membayar seluruh biaya-biaya (termasuk biaya hukum) sehubungan dengan
                  penandatanganan, pelaksanaan termasuk eksekusi dari Perjanjian, atau perjanjian
                  lainnya yang disebutkan di sini yang pembayarannya akan dilakukan dengan cara
                  pengurangan langsung dari jumlah yang ditarik atau cara lain yang merupakan
                  diskresi dari Pemberi Pinjaman.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-align:justify;text-indent:
                  -29.95pt;line-height:117%;mso-list:l8 level1 lfo9;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">b.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Apabila Penerima Pinjaman meminta
                  perubahan, pelepasan hak atau izin, Penerima Pinjaman harus, dalam jangka waktu
                  5 (lima) Hari Kerja setelah diminta, memberikan penggantian biaya kepada
                  Pemberi Pinjaman atas jumlah dari semua biaya dan pengeluaran (termasuk biaya
                  hukum) yang ditanggung secara wajar oleh pihak tersebut dalam menanggapi,
                  mengevaluasi, merundingkan atau memenuhi permintaan atau persyaratan tersebut.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:11.75pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                  tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">5.3</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:
                  normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Denda Keterlambatan<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;line-height:114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Pemberi Pinjaman dapat mengenakan denda keterlambatan kepada Penerima
                  Pinjaman sebagaimana diatur pada ketentuan-ketentuan pinjaman Lampiran I
                  Perjanjian Pinjaman ini.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                  0pt;mso-list:l9 level1 lfo10;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">6.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">JAMINAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                  116%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">6.1Apabila disyaratkan oleh SatuStop, Penerima
                  Pinjaman akan memberikan Jaminan Pribadi kepada Penerima Pinjaman guna menjamin
                  pelaksanaan pembayaran Pinjaman yang diterima oleh Penerima Pinjaman
                  berdasarkan Perjanjian Pinjaman ini;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                  117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">6.2&nbsp; &nbsp; &nbsp;Selain Jaminan Pribadi, selama masih terdapat
                  jumlah yang belum dibayarkan oleh Penerima Pinjaman berdasarkan Perjanjian
                  Pinjaman ini, apabila disyaratkan, Penerima Pinjaman wajib memberikan jaminan
                  sebagai agunan kepada Pemberi Pinjaman dalam bentuk, jumlah, nilai serta dengan
                  cara dan persyaratan yang ditentukan oleh Pemberi Pinjaman, termasuk namun
                  tidak terbatas pada jaminan tambahan atau jaminan pengganti segera setelah
                  diminta oleh Pemberi Pinjaman.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.2pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">6.3&nbsp; &nbsp;&nbsp;</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt; text-align: justify;">Apabila ada jaminan tambahan atau jaminan pengganti
                  yang diminta oleh Pemberi Pinjaman, maka&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Para Pihak, sehubungan dengan pemberian
                  jaminan tersebut, dengan adanya persetujuan tertulis&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;terlebih dahulu dari
                  pihak-pihak yang berwenang, akan membuat dan menandatangani suatu&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;perjanjian
                  jaminan bersama dan/atau dokumen jaminan lainnya.</span></p></div><div class="WordSection13">

                  <p class="MsoNormal" style="line-height:12.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                  0pt;mso-list:l10 level1 lfo11;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">7.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PEMULIHAN
                  PINJAMAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-align:justify;line-height:
                  117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Untuk lebih menjamin ketertiban pembayaran kembali
                  atas segala apa yang terutang oleh Penerima Pinjaman kepada Pemberi Pinjaman
                  baik karena utang-utang pokok, bunga, biaya-biaya lain sehubungan dengan
                  Pinjaman yang telah lewat tanggal jatuh tempo, Penerima Pinjaman dengan ini
                  mengizinkan Pemberi Pinjaman atau kuasanya untuk melakukan upaya yang
                  diperlukan oleh Pemberi Pinjaman termasuk namun tidak terbatas pada (i)
                  menghubungi Penerima Pinjaman (ii) menggunakan jasa pihak ketiga untuk
                  melakukan penagihan atas segala yang terutang dan telah melewati tanggal jatuh
                  tempo.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.3pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                  0pt;mso-list:l10 level1 lfo11;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">8.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">HAL YANG
                  DILARANG</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                  117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">8.1&nbsp; &nbsp; &nbsp;Kecuali ditentukan lain oleh Pemberi Pinjaman
                  atau kuasanya, terhitung sejak tanggal Perjanjian Pinjaman sampai dengan
                  dilunasinya seluruh kewajiban yang terutang oleh Penerima Pinjaman kepada Pemberi
                  Pinjaman, Penerima Pinjaman dilarang mengalihkan setiap hak dan kewajiban di
                  Perjanjian Pinjaman dan Perjanjian Pemberian Fasilitas Pinjaman (termasuk juga
                  hak dan kewajiban dan setiap dokumen pelengkapnya) kepada pihak manapun.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                  117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">8.2&nbsp; &nbsp; &nbsp; Penerima Pinjaman menyatakan dan menjamin kepada
                  Pemberi Pinjaman bahwa Penerima Pinjaman tidak akan mengalihkan, menjual,
                  menganjakpiutangkan, menjaminkan atau menggunakan Tagihan sebagai dasar untuk
                  memperoleh pinjaman dari pihak ketiga manapun atas Tagihan.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.2pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                  0pt;mso-list:l10 level1 lfo11;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">9.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PERNYATAAN
                  DAN JAMINAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;line-height:114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Penerima Pinjaman dengan ini berjanji, menyatakan dan menjamin kepada
                  Pemberi Pinjaman sebagai berikut:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -29.5pt;line-height:117%;mso-list:l10 level2 lfo11;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">a.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman memiliki hak
                  yang sah, kekuasaan dan kewenangan penuh untuk menandatangani, pelaksanaan dan
                  pemenuhan Perjanjian Pinjaman ini. Penandatanganan dan pemenuhan Perjanjian
                  Pinjaman ini adalah sah dan mengikat untuk dilaksanakan dalam segala hal
                  terhadap Penerima Pinjaman;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -30.2pt;line-height:116%;mso-list:l10 level2 lfo11;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">b.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Perjanjian Pinjaman ini dan
                  dokumen lain yang disebutkan dalam Perjanjian Pinjaman ini, merupakan kewajiban
                  yang sah dan mengikat untuk dilaksanakan sesuai dengan ketentuannya
                  masing-masing;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -29.5pt;line-height:117%;mso-list:l10 level2 lfo11;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">c.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">tidak terdapat perkara di
                  pengadilan atau tidak terdapat gugatan atau kemungkinan perkara terhadap
                  Penerima Pinjaman termasuk juga perkara apapun yang berhubungan dengan badan
                  pemerintahan atau badan administratif lainnya atau hal-hal lainnya yang
                  mengancam Penerima Pinjaman yang apabila terjadi dan diputuskan tidak memihak
                  kepada Penerima Pinjaman akan mempengaruhi kemampuan keuangan Penerima Pinjaman
                  atau kemampuannya untuk membayar secara tepat waktu setiap jumlah terutang
                  berdasarkan Perjanjian Pinjaman dan/atau&nbsp;</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">dokumen
                  lainnya atau setiap perubahan atau pelengkapnya;</span></p></div><div class="WordSection15">

                  <p class="MsoNormal" style="line-height:13.35pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -30.2pt;line-height:117%;mso-list:l11 level2 lfo12;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">d.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penandatanganan dan pelaksanaan Perjanjian
                  Pinjaman ini oleh Penerima Pinjaman, dan transaksi-transaksi yang diatur dalam
                  Perjanjian tersebut, tidak dan tidak akan bertentangan dengan: (i)
                  undang-undang atau peraturan yang berlaku; atau (ii) setiap perjanjian atau
                  instrumen yang mengikat atas Penerima Pinjaman atau salah satu aset miliknya
                  atau merupakan suatu Wanprestasi atau peristiwa pengakhiran berdasarkan setiap
                  perjanjian atau instrumen apapun yang memiliki atau secara wajar kemungkinan
                  memiliki suatu dampak yang bersifat material terhadap Penerima Pinjaman;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.8pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -29.5pt;line-height:117%;mso-list:l11 level2 lfo12;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">e.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman menyatakan dan
                  menjamin kepada Pemberi Pinjaman bahwa Penerima Pinjaman tidak akan
                  mengalihkan, menjual, menganjakpiutangkan, menjaminkan atau menggunakan Tagihan
                  sebagai dasar untuk memperoleh pinjaman dari pihak ketiga manapun atas Tagihan;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -28.2pt;line-height:116%;mso-list:l11 level2 lfo12;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">f.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman akan segera
                  memberitahu kepada Pemberi Pinjaman setiap terjadinya Wanprestasi kejadian lain
                  yang dengan diberitahukan atau lewatnya waktu atau keduanya akan merupakan
                  Wanprestasi;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -30.2pt;line-height:117%;mso-list:l11 level2 lfo12;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">g.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman tidak sedang
                  dan tidak akan mengajukan permohonan penundaan pembayaran (surenseance van
                  betaling) terhadap Fasiltas Pinjaman yang diberikan berdasarkan Perjanjian ini
                  dan tidak menjadi insolvent atau dinyatakan pailit dan tidak kehilangan haknya
                  untuk mengurus atau menguasai harta bendanya;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -30.2pt;line-height:117%;mso-list:l11 level2 lfo12;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">h.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">semua informasi baik tertulis
                  maupun tidak tertulis yang diberikan kepada Pemberi Pinjaman melalui Situs oleh
                  Penerima Pinjaman dan perwakilannya, sewaktu diberikan dan setiap saat
                  setelahnya berdasarkan pengetahuan terbaiknya adalah benar, lengkap dan tepat
                  serta tidak menyesatkan dalam hal apapun dan tidak ada fakta yang tidak
                  diungkapakan yang memuat setiap informasi yang diberikan kepada Pemberi
                  Pinjaman atau kuasanya oleh Penerima Pinjaman menjadi tidak tepat atau menyesatkan.
                  Dalam hal terdapat perubahan atas dokumen persyaratan-persyaratan Penerima
                  Pinjaman diwajibkan untuk melakukan pembaharuan dan/atau pengkinian atas
                  informasi yang tersedia pada akun Penerima Pinjaman dan mengirimkan
                  dokumen-dokumen tersebut kepada Pemberi Pinjaman.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.05pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-36.2pt;mso-line-height-alt:
                  0pt;mso-list:l12 level1 lfo13;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">10.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">WANPRESTASI</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-align:justify;line-height:
                  117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Dengan memperhatikan ketentuan dalam Perjanjian
                  Pinjaman ini, dengan terjadinya salah satu dari kejadian-kejadian di bawah ini
                  (selanjutnya disebut sebagai "Wanprestasi") maka seluruh jumlah yang
                  terutang berdasarkan Perjanjian Pinjaman ini akan menjadi jatuh tempo dan harus
                  dibayar oleh Penerima Pinjaman kepada Pemberi Pinjaman dan Pemberi Pinjaman
                  dapat melakukan tindakan apapun juga yang dianggap perlu berdasarkan Perjanjian
                  Pinjaman dan/atau Perjanjian Pemberian Fasilitas Pinjaman, perjanjian lainnya
                  yang dilakukan oleh Penerima Pinjaman dan Pemberi Pinjaman, sesuai dengan
                  peraturan perundang-undangan yang berlaku untuk menjamin pembayaran atas
                  padanya:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.8pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -29.5pt;line-height:114%;mso-list:l12 level2 lfo13;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">a.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman tidak
                  melaksanakan kewajibannya berdasarkan Perjanjian ini dan/atau perjanjian
                  lainnya yang dilakukan antara Pemberi Pinjaman dan Penerima Pinjaman yang&nbsp;</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">mengakibatkan berakhirnya Perjanjian Pinjaman
                  dan/atau Perjanjian Pemberian Fasilitas Pinjaman, ini dan perjanjian lainnya
                  yang dilakukan antara Pemberi Pinjaman dan Penerima Pinjaman;</span></p></div><div class="WordSection17">

                  <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -30.2pt;line-height:117%;mso-list:l13 level2 lfo14;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">b.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp; &nbsp; &nbsp; &nbsp; </span></span></span><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">apabila pernyataan, jaminan dan
                  janji Penerima Pinjaman dalam Perjanjian Pinjaman ini dan perjanjian lainnya
                  yang dilakukan antara Pemberi Pinjaman dan Penerima Pinjaman yang disebutkan di
                  sini menjadi atau dapat dibuktikan menjadi tidak benar, tidak akurat atau
                  menyesatkan;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -29.5pt;line-height:117%;mso-list:l13 level2 lfo14;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">c.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman (i) mengajukan
                  permohonan pernyataan kepailitan atas dirinya atau (ii) memiliki tindakan atas
                  dirinya yang apabila tidak dihentikan dalam waktu 30 (tiga puluh) hari kalender
                  dapat mengarah kepada pernyataan tidak mampu membayar utang atau pailit oleh
                  Penerima Pinjaman;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -30.2pt;line-height:116%;mso-list:l13 level2 lfo14;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">d.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">pengadilan atau badan
                  pemerintahan lainnya menyatakan bahwa Perjanjian Pinjaman atau dokumen-dokumen
                  atau bagian daripadanya adalah batal demi hukum atau menjadi tidak mengikat
                  Para Pihak; atau<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                  -29.5pt;line-height:117%;mso-list:l13 level2 lfo14;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">e.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">terjadinya gangguan di dalam
                  pasar keuangan atau situasi ekonomi atau perubahan lainnya yang berdampak
                  negatif termasuk dan tidak terbatas pada setiap tindakan dari pihak yang
                  berwenang untuk melikuidasi atau menghentikan usaha bisnis atau pekerjaan
                  Penerima Pinjaman yang menurut pendapat Pemberi Pinjaman dapat menghalangi,
                  menunda atau membuat Penerima Pinjaman tidak mampu memenuhi
                  kewajiban-kewajibannya dalam Perjanjian ini.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.35pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-36.2pt;mso-line-height-alt:
                  0pt;mso-list:l14 level1 lfo15;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">11.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">HUKUM
                  YANG BERLAKU DAN PENYELESAIAN SENGKETA<span style="mso-spacerun:yes">&nbsp; </span></span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                  114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">11.1 Perjanjian ini dan pelaksanaanya ini diatur
                  oleh dan ditafsirkan sesuai dengan hukum yang berlaku di Republik Indonesia.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                  117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">11.2 Apabila terjadi perselisihan antara Para Pihak
                  sehubungan dengan pelaksanaan Perjanjian Pinjaman ini, Para Pihak sepakat untuk
                  menyelesaikannya secara musyawarah. Apabila cara musyawarah tidak tercapai,
                  maka Para Pihak sepakat untuk menyerahkan penyelesaiannya melalui Arbitrase
                  yang akan dilaksanakan di Jakarta, pada Kantor Badan Arbitrase Nasional
                  Indonesia (“BANI”), oleh 3 (tiga) Arbitrator yang ditunjuk sesuai dengan
                  ketentuan peraturan dan prosedur yang diberlakukan BANI. Keputusan arbiter
                  adalah keputusan yang final, mengikat dan terhadapnya tidak diperbolehkan upaya
                  hukum perlawanan, banding atau kasasi.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.3pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-36.2pt;mso-line-height-alt:
                  0pt;mso-list:l14 level1 lfo15;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">12.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">KETENTUAN
                  LAIN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                  116%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">12.1 Setiap komunikasi yang akan dilakukan antara
                  Para Pihak berdasarkan atau sehubungan dengan Perjanjian ini dapat dilakukan
                  melalui surat elektronik atau media elektronik lainnya, apabila Para Pihak:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.25pt;line-height:
                  114%;mso-list:l14 level3 lfo15;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">a.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">menyetujui bahwa, kecuali dan
                  sampai diberikan pemberitahuan yang bertentangan, surat elektronik atau media
                  elektronik tersebut akan menjadi bentuk komunikasi yang diterima;<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:109.0pt;text-align:justify;text-indent:
                  -29.95pt;line-height:114%;mso-list:l14 level3 lfo15;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">b.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">memberitahukan secara tertulis
                  kepada satu sama lain alamat surat elektronik mereka dan/atau informasi lain
                  apa pun yang diperlukan untuk memungkinkan pengiriman dan&nbsp;</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">penerimaan
                  informasi melalui media tersebut; dan</span></p></div><div class="WordSection19">

                  <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:109.0pt;margin-bottom:.0001pt;text-indent:-29.25pt;line-height:
                  114%;mso-list:l15 level1 lfo16;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">c.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">memberitahukan kepada satu sama
                  lain setiap perubahan pada alamat surat elektronik (email) mereka atau
                  informasi lain apa pun yang diserahkan oleh mereka.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;line-height:117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">Setiap Pihak akan memberitahukan kepada Pihak lain segera setelah
                  mengetahui bahwa sistem surat elektronik miliknya tidak berfungsi karena adanya
                  kerusakan teknis (dan kerusakan tersebut akan berlanjut atau mungkin akan
                  berlanjut selama lebih dari 24 jam). Setelah disampaikannya pemberitahuan
                  tersebut, sampai Pihak tersebut memberitahukan kepada Pihak lainnya bahwa
                  kerusakan teknis itu telah diperbaiki, semua pemberitahuan antara Para Pihak
                  tersebut akan dikirimkan melalui faks atau surat sesuai dengan Pasal 12.1 ini.
                  Pemberitahuan dan komunikasi sehubungan dengan Perjanjian ini akan disampaikan
                  kepada Para Pihak dengan alamat sebagai berikut:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.65pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                  tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Pemberi Pinjaman:</span><span style="font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:11.5pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima
                  Pinjaman:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:19.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                  tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">U.p: PT. SATUSTOP SOLUSI</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-size:11.5pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">U.p: <?php echo $data_bio[0]->bio_fullname;?><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:19.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                  tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Alamat Surat Elektronik:</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Alamat
                  Surat Elektronik:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:2.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                  tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><?php echo $data_contact[0]->contact_us_email;?></span><span style="font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><?php echo $check_data[0]->register_email;?><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:19.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                  tab-stops:345.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">No. Telp:</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></span><span style="font-size:11.5pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">No. Telp:<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:2.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                  tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><?php echo $data_contact[0]->contact_us_phone;?></span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><?php echo $data_commercial[0]->borrower_office_number;?><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                  line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">12.2<span style="mso-tab-count:
                  1">&nbsp;&nbsp; </span>Setiap syarat atau ketentuan dari Perjanjian Pinjaman ini dapat
                  dikesampingkan setiap saat oleh Pihak yang berhak atas manfaat daripadanya,
                  tetapi pengesampingan tersebut tidak akan efektif kecuali dituangkan dalam
                  bentuk tertulis yang dilaksanakan sebagaimana mestinya oleh atau atas nama
                  Pihak yang mengesampingkan syarat atau ketentuan tersebut. Tidak ada
                  pengesampingan oleh Pihak manapun akan syarat atau ketentuan apapun dalam
                  Perjanjian Pinjaman ini, dalam satu atau lebih hal, harus dianggap atau
                  ditafsirkan sebagai pengesampingan akan syarat dan ketentuan yang sama ataupun
                  lain dari Perjanjian Pinjaman ini pada setiap kesempatan di masa depan. Semua
                  upaya hukum, baik berdasarkan Perjanjian Pinjaman ini atau oleh Hukum atau
                  lainnya yang dapat diberikan, akan berlaku secara kumulatif dan bukan
                  alternatif.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.65pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                  margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                  line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">12.3<span style="mso-tab-count:
                  1">&nbsp;&nbsp; </span>Tidak ada perubahan, amandemen atau pengesampingan Perjanjian
                  Pinjaman ini yang akan berlaku atau mengikat kecuali dibuat secara tertulis
                  dan, dalam hal perubahan atau amandemen, ditandatangani oleh Para Pihak dan
                  dalam hal pengesampingan, oleh Pihak yang mengesampingkan terhadap siapa
                  pengesampingan akan dilakukan. Setiap pengesampingan oleh salah satu Pihak akan
                  hak apapun dalam Perjanjian Pinjaman ini atau setiap pelanggaran Perjanjian
                  Pinjaman ini oleh Pihak lain tidak dapat diartikan sebagai diabaikannya hak
                  lainnya atau bentuk pelanggaran lainnya oleh Pihak lain tersebut, baik dengan
                  sifat yang sama atau sifat berbeda daripadanya.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.95pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:78.0pt;text-indent:-1.0cm;line-height:
                  114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">12.4<span style="mso-spacerun:yes">&nbsp; </span>Jika
                  ketentuan apapun dalam Perjanjian Pinjaman ini dianggap ilegal, tidak sah atau
                  tidak dapat dilaksanakan berdasarkan Hukum yang berlaku sekarang atau di masa
                  depan, dan apabila hak-</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt; text-align: justify;">hak atau kewajiban dari tiap-tiap Pihak dari
                  Perjanjian berdasarkan Perjanjian Pinjaman ini tidak akan terpengaruh secara
                  material dan dengan demikian, (a) ketentuan tersebut akan sepenuhnya terpisah,
                  (b) Perjanjian Pinjaman ini akan ditafsirkan dan dilaksanakan seolah-olah
                  ketentuan yang ilegal, tidak sah atau tidak dapat dilaksanakan tersebut tidak
                  pernah menjadi bagian dari Perjanjian Pinjaman ini dan (c) sisa ketentuan
                  berdasarkan Perjanjian Pinjaman ini akan tetap berlaku dan tidak akan
                  terpengaruh oleh ketentuan yang ilegal, tidak sah atau tidak dapat dilaksanakan
                  tersebut.</span></p></div><div class="WordSection21">

                  <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">12.5<span style="mso-tab-count:1">&nbsp;&nbsp; </span>Kegagalan oleh masing-masing Pihak untuk
                  melaksanakan sebagian atau seluruh hak-hak dalam Perjanjian Pinjaman ini, atau
                  pelaksanaan sebagian dari hal itu, tidak dapat dianggap sebagai tindakan
                  pelepasan atau pengesampingan terhadap hak-hak yang dimiliki tersebut atau
                  secara umum tanpa harus menunda terjadinya atau terjadinya kembali peristiwa
                  yang serupa atau peristiwa lain yang memunculkan hak tersebut.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">12.6<span style="mso-tab-count:1">&nbsp;&nbsp; </span>Perjanjian Pinjaman ini akan mengikat dan
                  berlaku untuk keuntungan masing-masing Pihak dan berlaku untuk pewaris, penerus
                  dan mereka yang ditunjuk. Perjanjian Pinjaman ini tidak memberi hak kepada
                  orang atau badan hukum manapun yang bukan merupakan pihak berdasarkan
                  Perjanjian Pinjaman ini, kecuali dinyatakan secara jelas dalam Perjanjian
                  Pinjaman ini.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:114%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">12.7<span style="mso-tab-count:1">&nbsp;&nbsp; </span>Mengenai Perjanjian Pinjaman ini Penerima
                  Pinjaman dan Pemberi Pinjaman sepakat untuk melepaskan ketentuan Pasal 1266
                  dari Kitab Undang-undang Hukum Perdata Indonesia.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:114%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">12.8<span style="mso-tab-count:1">&nbsp;&nbsp; </span>Masing-masing Pihak harus menanggung Pajak
                  sehubungan dengan pelaksanaan Perjanjian sesuai dengan ketentuan hukum yang
                  berlaku.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                  -31.45pt;line-height:114%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                  mso-bidi-font-size:10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">12.9<span style="mso-tab-count:1">&nbsp;&nbsp; </span>Seluruh lampiran-lampiran, perubahan,
                  penambahan dan/atau addendum dari Perjanjian Pinjaman ini merupakan satu
                  kesatuan dan tidak dapat dipisahkan.</span><span style="font-family: &quot;Times New Roman&quot;, serif;">&nbsp;</span></p></div>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:12.3pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:17.0pt;line-height:118%"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                  &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">DEMIKIAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                  &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                  Arial">, Perjanjian Pinjaman ini ditandatangani dengan menggunakan tanda tangan
                  elektronik<b style="mso-bidi-font-weight:normal"> </b>sebagaimana diatur dalam
                  Undang-undang Republik Indonesia No.11 Tahun 2008 tentang Informasi dan
                  Transaksi Elektronik oleh Para Pihak atau perwakilannya yang sah pada tanggal sebagaimana
                  disebutkan di bagian awal Perjanjian Pinjaman ini dan akan mempunyai kekuatan
                  hukum yang sama dengan Perjanjian yang dibuat dan ditandatangani secara basah.<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:14.4pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:94.0pt;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Untuk dan atas nama<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:13.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:88.0pt;mso-line-height-alt:0pt;
                  tab-stops:345.0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PEMBERI
                  PINJAMAN</span></b><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:normal"><span style="font-size:11.5pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">PENERIMA PINJAMAN<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:17.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:79.0pt;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                  10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">PT SATUSTOP SOLUSI<o:p></o:p></span></b></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="line-height:17.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <!-- <p class="MsoNormal" style="margin-left:35.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">______________________________________<o:p></o:p></span></p> -->
                  <p class="MsoNormal" style="margin-left:35.0pt;mso-line-height-alt:0pt;tab-stops:297.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">______________________________________</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">______________________________________<o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:1.0pt;mso-line-height-rule:exactly"><!--[if gte vml 1]><v:line
                   id="_x0000_s1029" style='position:absolute;z-index:-251656192' from="298.05pt,-.45pt"
                   to="526.05pt,-.45pt" o:userdrawn="t" strokeweight="1pt"/><![endif]--><!--[if !vml]--><span style="mso-ignore:vglayout;position:relative;z-index:251660283"><span style="position:absolute;left:396px;top:-2px;width:307px;height:3px"><img width="307" height="3" src="file:///C:/Users/MFIQRI~1/AppData/Local/Temp/msohtmlclip1/01/clip_image004.gif" v:shapes="_x0000_s1029"></span></span><!--[endif]--><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                  <p class="MsoNormal" style="line-height:16.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                  <p class="MsoNormal" style="margin-left:33.0pt;mso-line-height-alt:0pt;
                  tab-stops:394.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                  font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                  mso-bidi-font-family:Arial">Nama : <?php echo $data_direk[0]->management_menu_person;?></span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                  mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Nama : <?php echo $data_bio[0]->bio_fullname;?><o:p></o:p></span></p>
          </div>
        
        
        <div class="modal-footer">
          <button type="submit" class="btn-danger btn-sm btn btnwdt" style="background-color: orange; height: 22px;width: 50px; text-align: center; line-height: 1.1 !important;margin-top: 2%;">I Agree</button>
                  
          <button type="button" class="btn btn-default" data-dismiss="modal" style="width: 60px;margin-top: 2%;">Close</button>
        </div>
        </form>
      </div>

    </div>
</div>

<script type="text/javascript">

function check_score(){

        var input_type = $('#input_type').val();
        var input_amount = $('#input_amount').val();
        var input_tenor = $('#input_tenor').val();

        var amount_valid = input_amount.replace(/\D/g,'');

        if (amount_valid >= 500000){  
          $("#min_invest_alert").hide();
          if (input_type == 0){
              $("#input_type_alert").show();
              $("#input_amount_alert").hide();
              $("#input_tenor_alert").hide();

                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('montly2').value = '';

              $("#post_button").hide();

          } else if (input_amount == ''){
              $("#input_amount_alert").show();
              $("#input_tenor_alert").hide();
              $("#input_type_alert").hide();

                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('montly2').value = '';

              $("#post_button").hide();

          } else if (input_tenor == 0){
              $("#input_tenor_alert").show();
              $("#input_amount_alert").hide();
              $("#input_type_alert").hide();

                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('montly2').value = '';

              $("#post_button").hide();

          } else {
              $("#input_deskripsi").show();
              $("#input_type_alert").hide();
              $("#input_amount_alert").hide();
              $("#input_tenor_alert").hide();

              $.ajax({
                  url: <?php echo "'". site_url("Finance/F_borrower/check_score")."'";?>,
                  type: 'POST',
                  dataType: 'json',
                  data: {type_loan: input_type, amount: input_amount, periode: input_tenor},
                  timeout: 180000,
                  beforeSend: function() {
                  },
                  success: function(data) {
                      console.log(data);
                      if(data.alert_error_income==true){  
                          document.getElementById('modal_alert').innerHTML = data.alert_message_income;
                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('montly2').value = '';

                          $("#myModal").modal();
                          $("#post_button").hide();
                      } else if(data.alert_error==true){
                          document.getElementById('modal_alert').innerHTML = data.alert_message;
                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('montly2').value = '';

                          $("#myModal").modal();
                          $("#post_button").hide();
                      } else {
                          var rate = data.loan_rate/100;
                          var bunga = (data.loan_amount * rate) * (data.loan_tenor / 12);
                          //var bunga = data.loan_amount * rate;

                          // var t_pokok = Math.round(data.loan_amount / data.loan_tenor);
                          // var t_bunga = Math.round(bunga / data.loan_tenor);

                          var t_pokok =  data.loan_amount /  data.loan_tenor;
                          var t_bunga =  bunga /  data.loan_tenor;
                          
                          var pokok_bunga = parseFloat(t_pokok) + parseFloat(t_bunga);
                          var montly = pokok_bunga;
                          var montly2 = Math.round(pokok_bunga);
                          var t_pokok2 = Math.round(t_pokok);
                          var t_bunga2 = Math.round(t_bunga);
                          
                          document.getElementById('type_loan').value = data.loan_type;
                          document.getElementById('periode').value = data.loan_tenor;
                          document.getElementById('rating').value = data.loan_rating;
                          document.getElementById('rate').value = data.loan_rate;
                          document.getElementById('needs').value = data.loan_needs;
                          document.getElementById('periode2').value = data.loan_tenor;
                          document.getElementById('rating2').value = data.loan_rating;
                          document.getElementById('rate2').value = data.loan_rate;

                          document.getElementById('amount').value = data.loan_amount;
                          document.getElementById('principal').value = t_pokok;
                          document.getElementById('interest').value = t_bunga;
                          document.getElementById('principal2').value = "Rp. " + addCommas(t_pokok2);
                          document.getElementById('interest2').value = "Rp. " + addCommas(t_bunga2);
                          document.getElementById('montly').value = montly;
                          document.getElementById('amount2').value = "Rp. " + addCommas(data.loan_amount);
                          document.getElementById('montly2').value = "Rp. " + addCommas(montly2);

                          $("#post_button").show();
                      }
                  },
                  error: function(x, t, m) {

                  }
              });
          }
        } else {
          $("#input_amount_alert").hide();
              $("#input_tenor_alert").hide();
              $("#min_invest_alert").show();

                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('montly2').value = '';

          $("#post_button").hide();
        }
}

function addCommas(nStr) {
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + '.' + '$2');
    }
    return x1 + x2;
}

function save_data()
{
    bootbox.confirm({
    title: "Are You Sure?",
    message: "The proposed loan can not be canceled. are you sure you want to apply for this loan?",
    buttons: {
        cancel: {
            label: '<i class="fa fa-times"></i> Cancel',
            className: 'btn_modal_ok btn-default'
        },
        confirm: {
            label: '<i class="fa fa-check"></i> Yes',
            className: 'btn_modal_ok btn-success'
        }
    },
    callback: function (result) {
        if (result == true){
            document.getElementById("myForm").submit();
        } else {
            event.preventDefault();
        }
    }
    });
}
</script>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Notice !!</h4>
      </div>
      <div class="modal-body">
        <div id="modal_alert"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
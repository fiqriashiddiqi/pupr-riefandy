<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
    /* The check_custom */
      .check_custom {
          position: relative;
          padding-left: 35px;
          margin-bottom: 12px;
          margin-right: 10px;
          cursor: pointer;
          font-size: 15px;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
      }
    
      /* Hide the browser's default checkbox */
      .check_custom input {
          position: absolute;
          opacity: 0;
          cursor: pointer;
      }
    
      /* Create a custom checkbox */
      .check_mark {
          position: absolute;
          top: 0;
          left: 0;
          height: 25px;
          width: 25px;
          background-color: #eee;
      }
    
      /* On mouse-over, add a grey background color */
      .check_custom:hover input ~ .check_mark {
          background-color: #ccc;
      }
    
      /* When the checkbox is checked, add a blue background */
      .check_custom input:checked ~ .check_mark {
          background-color: #ffd100;
      }
    
      /* Create the check_mark/indicator (hidden when not checked) */
      .check_mark:after {
          content: "";
          position: absolute;
          display: none;
          border-radius: 10%;
      }
    
      /* Show the check_mark when checked */
      .check_custom input:checked ~ .check_mark:after {
          display: block;
      }
    
      /* Style the check_mark/indicator */
      .check_custom .check_mark:after {
          left: 10px;
          top: 7px;
          width: 7px;
          height: 10px;
          border: solid white;
          border-width: 0 3px 3px 0;
          -webkit-transform: rotate(45deg);
          -ms-transform: rotate(45deg);
          transform: rotate(45deg);
      }

      /*wizard*/
      .background-step {
          background-color: orange;
      }
      .stepwizard-step p {
          margin-top: 10px;
      }

      .stepwizard-row {
          display: table-row;
      }

      .stepwizard {
          display: table;
          width: 100%;
          position: relative;
      }

      .stepwizard-step button[disabled] {
          opacity: 1 !important;
          filter: alpha(opacity=100) !important;
      }

      .stepwizard-row:before {
          top: 14px;
          bottom: 0;
          position: absolute;
          content:" ";
          width: 100%;
          height: 1px;
          background-color: #ccc;
          z-order: 0;

      }

      .stepwizard-step {
          display: table-cell;
          text-align: center;
          position: relative;
      }

      .btn-circle {
        width: 64px;
        height: 34px;
        text-align: center;
        padding: 3px 0;
        font-size: 12px;
        line-height: 26px;
        border-radius: 8px;
      }
      .btn_modal_ok {
          height: 27px;
          width: 65px;
      }
      .btn_modal_cancel {
          height: 27px;
          width: 70px;
      }
</style>
<style>
    .tool_tip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }
    
    .tool_tip .tool_tiptext {
        visibility: hidden;
        width: 180px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 0px;
        padding: 5px 0;
    
        /* Position the tool_tip */
        position: absolute;
        z-index: 1;
    }
    
    .tool_tip:hover .tool_tiptext {
        visibility: visible;
    }
</style>

<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <?php if ($this->session->flashdata('alert_success')) { ?>
        <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                <?php echo $this->session->flashdata('alert_success'); ?>
            </p>
        </div>
        <?php } ?>

        <?php if ($this->session->flashdata('alert_error')) { ?>
        <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                <?php echo $this->session->flashdata('alert_error'); ?>
            </p>
        </div>
        <?php } ?>
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-top: 2%; margin-bottom: 2%;">
              
                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
                  
                    <div class="col-md-12 col-sm-12 col-xs-12">
                      <div class=" form-group" align="center">
                         <label><h2>Personal Loan Update Bio</h2></label>
                      </div>
                      <div class="stepwizard">
                        <div class="stepwizard-row">
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_konsumtif" type="button" class="btn btn-warning btn-circle">Step 1</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_file_konsumtif" type="button" class="btn btn-default btn-circle">Step 2</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/new_loan_consumtive" type="button" class="btn btn-default btn-circle">Step 3</a>
                            </div>
                        </div>
                    </div>
                        <br>
                        <div class="col-md-6 col-sm-12 col-xs-12">
                            <br>
                            <br>
                            <div class=" form-group">
                                <input type="hidden" value="<?php echo $get_code; ?>" name="register_code" />
                                <label>Personal's/ Entity Name</label>
                                <input type="text" class="form-control" value="<?php echo $data_code[0]->bio_fullname; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label> Phone/WA </label>
                                <input type="number" class="form-control" value="<?php echo $data_code[0]->bio_phone; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label> Province </label>
                                <input type="text" class="form-control" value="<?php echo @$data_province[0]->nama; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label> City</label>
                                <input type="text" class="form-control" value="<?php echo @$data_city[0]->nama; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label>District </label>
                                <input type="text" placeholder="" class="form-control" value="<?php echo @$data_district[0]->nama; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label>Village </label>
                                <input type="text" placeholder="" class="form-control" value="<?php echo @$data_village[0]->nama; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label>Address</label>
                                <textarea placeholder="" rows="3" class="form-control" disabled=""><?php echo $data_code[0]->bio_address; ?></textarea>
                            </div>
                            <div class=" form-group">
                                <label> Post Code</label>
                                <input type="number" class="form-control" value="<?php echo $data_code[0]->bio_post_code; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label>Your Email</label>
                                <input type="text" class="form-control" value="<?php echo $data_register[0]->register_email; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label>Mother Name </label>
                                <input type="text" class="form-control" value="<?php echo $data_code[0]->bio_mother_name; ?>" disabled>
                            </div>
                            <div class=" form-group">
                                <label>Last Education </label>
                                <input type="text" class="form-control" value="<?php echo $data_code[0]->bio_last_education; ?>" disabled>
                            </div>


                             <div class=" form-group">
                              <?php 
                                if (@$data_consumtive[0]->borrower_employe_status == 'Permanent'){
                                    $activated = "selected"; 
                                    $deactivated = "";
                                } else {
                                    $activated = "";
                                    $deactivated = "selected";
                                }
                              ?>
                              <label>Employe Status </label>
                              <select class="form-control select2" name="borrower_employe_status" style="width: 100%;" required="true">
                                <option value="">- Choose Status -</option>
                                <option value="Permanent"<?php echo @$activated ?>>Permanent</option>
                                <option value="Contract"<?php echo @$deactivated ?>>Contract</option>
                              </select>
                            </div>
                             <div class=" form-group">
                                <label>Collectibility BI </label>
                                <select class="form-control select2" name="borrower_collectibility_bi" style="width: 100%;" required="required">
                             <?php   
                                    if ($data_consumtive[0]->borrower_collectibility_bi =='1') {
                                      $Lancar  = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='2') {
                                      $Watch   = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='3') {
                                      $DPK   = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='4') {
                                      $Kurang   = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='5') {
                                      $Ragu   = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='6') {
                                      $Macet   = 'selected';
                                    } else {
                                      $default  = 'selected';
                                    }
                                   ?>
                                  <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                                  <option value="1"<?php echo @$Lancar;?>>Lancar</option>
                                  <option value="2"<?php echo @$Watch;?>>Watchlist</option>
                                  <option value="3"<?php echo @$DPK;?>>DPK</option>
                                  <option value="4"<?php echo @$Kurang;?>>Kurang Lancar</option>
                                  <option value="5"<?php echo @$Ragu;?>>Diragukan</option>
                                  <option value="6"<?php echo @$Macet;?>>Macet</option>
                               </select>
                            </div>
                            <div class=" form-group">
                                <label>Length of Current Residency</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                                <input type="number" class="form-control" name="borrower_loc_residen" placeholder="Length of Current Residency" value="<?php echo @$data_consumtive[0]->borrower_loc_residen; ?>" required="required">
                            </div>
                            <div class=" form-group">
                                <label> Status of Ownership of Residence</label>
                                <select class="form-control select2" name="borrower_status_owner" style="width: 100%;" required="required" id="Ownership">                               
                                   <?php   
                                    if ($data_consumtive[0]->borrower_status_owner =='Pribadi') {
                                      $Pribadi  = 'selected';
                                    } else if ($data_consumtive[0]->borrower_status_owner =='Kontrakan') {
                                      $Kontrakan  = 'selected';
                                    } else {
                                      $default  = 'selected';
                                    }
                                   ?>
                                  <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                                  <option value="Pribadi"<?php echo @$Pribadi;?>>Personal</option>
                                  <option value="Kontrakan"<?php echo @$Kontrakan;?>>Rent</option>
                               </select>
                              </div>

                            <div class=" form-group">
                                <label> Age of Retirement</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                                <input type="number" class="form-control" name="borrower_age_retirement" value="<?php echo @$data_consumtive[0]->borrower_age_retirement; ?>" required="required">
                            </div>

                        </div>
                        <br>
                        <br>
                        <div class="col-md-6 col-sm-12 col-xs-12">
                            <div class=" form-group">
                                <label>Monthly Income </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                                <input type="text" class="form-control dengan-rupiah" name="borrower_montly_income" value="Rp. <?php echo number_format(@$data_consumtive[0]->borrower_montly_income,0,".","."); ?>" required="required">
                            </div>
                            <div class=" form-group">
                                <label> Number of dependents</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Click For Detail Information</span></a>
                                <input type="number" placeholder="" name="borrower_dependents" class="form-control" value="<?php echo @$data_consumtive[0]->borrower_dependents; ?>" required="required">
                            </div>
                            <div class=" form-group">
                                <label>Name of Company / Agency</label>
                                <input type="text" name="borrower_name_company" class="form-control" value="<?php echo @$data_consumtive[0]->borrower_name_company; ?>" required="required">
                            </div>
                            <div class=" form-group">
                                <label> Phone Office</label>
                                <input type="number" placeholder="" name="borrower_phone_company" class="form-control" value="<?php echo @$data_consumtive[0]->borrower_phone_company; ?>" required="required">
                            </div>
                            <div class="form-group">
                                <label>Province</label>
                                
                                <select id="borrower_province_select" type="text" name="borrower_province_company" class="form-control select2" required ="required">
                                    <option value="">- Choose Province -</option>
                                    <?php 
                                   
                                    $this->load->model('Front_Fintech/indonesia_model');
                                    $province = $this->indonesia_model->get_province_business_by_id($data_consumtive[0]->borrower_province_company);

                                        foreach ($data_indonesia as $province_entry) {

                                            if ($province[0]->id_indonesia_provinsi == $province_entry->id_indonesia_provinsi){
                                            echo "<option value='".$province_entry->id_indonesia_provinsi."' selected>".$province_entry->nama."</option>";

                                            } else {

                                            echo "<option value='".$province_entry->id_indonesia_provinsi."'>".$province_entry->nama."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>City</label>
                                
                                <select id="borrower_city_select" type="text" name="borrower_city_company" class="form-control select2" required ="required">
                                    <option value="">- Choose City -</option>
                                    <?php
                                        $id_indonesia_provinsi = $data_consumtive[0]->borrower_province_company;
                                        $id_indonesia_kota_kab = $data_consumtive[0]->borrower_city_company;
                                        $data = $this->indonesia_model->get_city($id_indonesia_provinsi);

                                        foreach ($data as $data_entry){
                                            if($data_entry->id_indonesia_kota_kab == $id_indonesia_kota_kab){
                                                echo "<option value='".$data_entry->id_indonesia_kota_kab."' selected>".$data_entry->nama."</option>";
                                            } else {
                                                echo "<option value='".$data_entry->id_indonesia_kota_kab."'>".$data_entry->nama."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>District</label>
                                
                                <select id="borrower_district_select" type="text" name="borrower_district_company" class="form-control select2" required ="required">
                                    <option value="">- Choose District -</option>
                                    <?php
                                        $id_indonesia_kota_kab = $data_consumtive[0]->borrower_city_company;
                                        $id_indonesia_kec = $data_consumtive[0]->borrower_district_company;
                                        $data = $this->indonesia_model->get_district($id_indonesia_kota_kab);

                                        foreach ($data as $data_entry){
                                            if($data_entry->id_indonesia_kec == $id_indonesia_kec){
                                                echo "<option value='".$data_entry->id_indonesia_kec."' selected>".$data_entry->nama."</option>";
                                            } else {
                                                echo "<option value='".$data_entry->id_indonesia_kec."'>".$data_entry->nama."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Village</label>
                                
                                <select id="borrower_village_select" type="text" name="borrower_village_company" class="form-control select2" required ="required">
                                    <option value="">- Choose Village -</option>
                                    <?php
                                        $id_indonesia_kec = $data_consumtive[0]->borrower_district_company;
                                        $id_indonesia_kel_des = $data_consumtive[0]->borrower_village_company;
                                        $data = $this->indonesia_model->get_village($id_indonesia_kec);

                                        foreach ($data as $data_entry){
                                            if($data_entry->id_indonesia_kel_des == $id_indonesia_kel_des){
                                                echo "<option value='".$data_entry->id_indonesia_kel_des."' selected>".$data_entry->nama."</option>";
                                            } else {
                                                echo "<option value='".$data_entry->id_indonesia_kel_des."'>".$data_entry->nama."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class=" form-group">
                                <label>Company Address / Agency</label>
                                <textarea placeholder="" rows="3" name="borrower_address_company" class="form-control" required="required"><?php echo @$data_consumtive[0]->borrower_address_company; ?></textarea>
                            </div>

                            <div class=" form-group">
                                <label> Industry Type</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                                <select class="form-control select2"  name="borrower_industry_type" style="width: 100%;" required="required">
                                  <option value="">- Choose Industry Type -</option>
                                 <?php
                                    $this->load->model('Front_Fintech/param_model');
                                    $data = $this->param_model->get_industry_by_id($data_consumtive[0]->borrower_industry_type);
                                    foreach ($data_industry_cons as $industry_entry) {
                                      if ($data[0]->id_param_industry == $industry_entry->id_param_industry) {
                                        echo "<option value='".$industry_entry->id_param_industry."' selected>".$industry_entry->industry_name."</option>";
                                      } else {
                                        echo "<option value='".$industry_entry->id_param_industry."'>".$industry_entry->industry_name."</option>";
                                      }
                                 
                                    }
                                ?>
                             </select>
                            </div>
                            <div class=" form-group">
                                <label>Purpose Of Loan</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                                <select class="form-control select2" name="borrower_entity_type" style="width: 100%;" required="required" id="Entity">
                                <?php
                                  foreach ($data_entity as $entity_entry) {
                                ?>
                                 <option value="<?php echo $entity_entry->id_param_entity; ?>"><?php echo $entity_entry->entity_name; ?></option>

                                <?php
                                 }
                                ?>
                            </select>
                            </div>

                            <div class="row" style="text-align: center; ">
                                <button type="submit" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; margin-top: 4%; background-color: orange; width: 25%; color: white ;height: 30px;"><b>Update</b>
                                </button>

                            </div>

                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    function check_entity_type() {
        var el = document.getElementById("Entity");
        var str = el.options[el.selectedIndex].text;
        if(str == "Other") {
            show();
        }else {
            hide();
        }
    }
    function hide(){
        document.getElementById('textother').style.display='none';
    }
    function show(){
        document.getElementById('textother').style.display='block';
    }
</script>

<script type="text/javascript">
    function check_Ownership() {
        var el = document.getElementById("Ownership");
        var str = el.options[el.selectedIndex].text;
        if(str == "Other") {
            show();
        }else {
            hide();
        }
    }
    function hide(){
        document.getElementById('textowner').style.display='none';
    }
    function show(){
        document.getElementById('textowner').style.display='block';
    }
</script>
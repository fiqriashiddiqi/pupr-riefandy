<?php date_default_timezone_set("Asia/Jakarta"); ?>
<div class="wrap-banner1">
	<div class="container div-banner1">
		<div class="row">
				  <!-- Wrapper for slides -->
			<div class="carousel-inner" role="listbox">
			<img src="<?php echo base_url();?>uploads/Website/artikel/<?php echo $data_artikel[0]->blog_picture_url;?>" style="height: 320px; width: 100%;">
			</div>
		</div>
	</div>
</div>

	
		
			
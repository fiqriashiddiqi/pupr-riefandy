<?php date_default_timezone_set("Asia/Jakarta"); ?>
   <style>

  /* The check_custom */
  .check_custom {
      position: relative;
      padding-left: 35px;
      margin-bottom: 12px;
      margin-right: 10px;
      cursor: pointer;
      font-size: 15px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  /* Hide the browser's default checkbox */
  .check_custom input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
  }

  /* Create a custom checkbox */
  .check_mark {
      position: absolute;
      top: 0;
      left: 0;
      height: 25px;
      width: 25px;
      background-color: #eee;
  }

  /* On mouse-over, add a grey background color */
  .check_custom:hover input ~ .check_mark {
      background-color: #ccc;
  }

  /* When the checkbox is checked, add a blue background */
  .check_custom input:checked ~ .check_mark {
      background-color: #ffd100;
  }

  /* Create the check_mark/indicator (hidden when not checked) */
  .check_mark:after {
      content: "";
      position: absolute;
      display: none;
      border-radius: 10%;
  }

  /* Show the check_mark when checked */
  .check_custom input:checked ~ .check_mark:after {
      display: block;
  }

  /* Style the check_mark/indicator */
  .check_custom .check_mark:after {
      left: 10px;
      top: 7px;
      width: 7px;
      height: 10px;
      border: solid white;
      border-width: 0 3px 3px 0;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
  }

   /*wizard*/
      .background-step {
          background-color: orange;
      }
      .stepwizard-step p {
          margin-top: 10px;
      }

      .stepwizard-row {
          display: table-row;
      }

      .stepwizard {
          display: table;
          width: 100%;
          position: relative;
      }

      .stepwizard-step button[disabled] {
          opacity: 1 !important;
          filter: alpha(opacity=100) !important;
      }

      .stepwizard-row:before {
          top: 14px;
          bottom: 0;
          position: absolute;
          content:" ";
          width: 100%;
          height: 1px;
          background-color: #ccc;
          z-order: 0;

      }

      .stepwizard-step {
          display: table-cell;
          text-align: center;
          position: relative;
      }

      .btn-circle {
        width: 64px;
        height: 34px;
        text-align: center;
        padding: 3px 0;
        font-size: 12px;
        line-height: 26px;
        border-radius: 8px;
      }
      .btn_modal_ok {
          height: 27px;
          width: 65px;
      }
      .btn_modal_cancel {
          height: 27px;
          width: 70px;
      }
  </style>
  <style>
    .tool_tip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }
    
    .tool_tip .tool_tiptext {
        visibility: hidden;
        width: 180px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 0px;
        padding: 5px 0;
    
        /* Position the tool_tip */
        position: absolute;
        z-index: 1;
    }
    
    .tool_tip:hover .tool_tiptext {
        visibility: visible;
    }
</style>

				
<section class="container home" >
	<div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
		 <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
       <?php } ?>
		<div class="container div-feedback" >
		<div class="row" style="background-color: white; margin-top: 2%; margin-bottom: 2%;">
		  <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
			<div class="col-md-12 col-sm-12 col-xs-12" >
        <div class=" form-group" align="center">
          <label><h2>Commercial Loan Update bio</h2></label>
        </div>
        <div class="stepwizard">
            <div class="stepwizard-row">
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_komersil" class="btn btn-warning btn-circle">Step 1</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_file_komersil" class="btn btn-default btn-circle">Step 2</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/new_loan_commercial" class="btn btn-default btn-circle">Step 3</a>
                            </div>
                        </div>
        </div>
				<br>
				<div class="col-md-6 col-sm-12 col-xs-12" >
					<br>
					<br>
					<div class=" form-group" >
						<input type="hidden" value="<?php echo $get_code; ?>" name="register_code"/>
						<label>Personal's/ Entity Name</label>
						<input type="text" class="form-control" value="<?php echo @$data_code[0]->bio_fullname; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
						<label>Place/Date of Birth</label>
						<input type="text" class="form-control" placeholder="Place" name="birth_place" value="<?php echo $data_code[0]->bio_place_birth_date; ?>" disabled>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" value="<?php echo @$data_code[0]->bio_birth_date; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
						<label>Gender</label>
						<input type="text" class="form-control" value="<?php echo @$data_code[0]->bio_gender; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
					<div class=" form-group" >
						<label> Province</label>
						<input type="text" class="form-control" value="<?php echo @$data_province[0]->nama; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
						<label> City</label>
						<input type="text" class="form-control" value="<?php echo @$data_city[0]->nama; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
						<label> District</label>
						<input type="text" placeholder=" " class=" form-control" value="<?php echo @$data_district[0]->nama; ?>" disabled>
					</div>
					<div class=" form-group" >
						<label> Village </label>
						<input type="text" placeholder=" " class=" form-control" value="<?php echo @$data_village[0]->nama; ?>" disabled>
					</div>
					<label>Address</label>
						<textarea  rows="3" name="bio_address" class="form-control" disabled=""><?php echo @$data_code[0]->bio_address; ?></textarea>
					</div>
					<div class=" form-group" >
						<label> Post Code</label>
						<input type="Number" class="form-control" name="bio_post_code" value="<?php echo @$data_code[0]->bio_post_code; ?>" required="true" disabled>
					</div>
					<div class=" form-group" >
						<label> Phone Number </label>
						<input type="Number" class="form-control" value="<?php echo @$data_code[0]->bio_phone; ?>" required="true" disabled>
					</div>
					<div class="form-group">
              <label>Marital Status</label>
              <input type="hidden" class="form-control" name="bio_marriage_status" value="<?php echo @$data_code[0]->bio_marriage_status; ?>">
              <select id="borrower_status" required="required" class="form-control select2" onchange="check_status_marriage_commercial();" style="width: 100%;" disabled="true">
                          <?php   
                              if ($data_code[0]->bio_marriage_status == 'Married') {
                                      $Married  = 'selected';
                                      $display = 'block';
                                  } else if ($data_code[0]->bio_marriage_status == 'Single') {
                                      $Single = 'selected';
                                      $display = 'none';
                                  } else {
                                      $default  = 'selected';
                                  }
                          ?>
                    <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                    <option value="Married" <?php echo @$Married;?>>Married</option>
                    <option value="Single" <?php echo @$Single;?>>Single</option>  
                           
              </select>
          </div>
					<div class=" form-group" id="spouse_name_borrower" style="display: <?php echo @$display;?>;">
						<label>Name of Spouse (Husband/Wife) </label>
						<input type="text" class="form-control" value="<?php echo @$data_code[0]->bio_spouse_name; ?>" disabled >
					</div>
          <div class=" form-group" id="spouse_phone_borrower" style="display: <?php echo @$display;?>;">
            <label>Phone Number Spouse (Husband/Wife) </label>
            <input type="number" class="form-control" value="<?php echo @$data_code[0]->bio_spouse_phone; ?>" disabled >
          </div>
          <?php
            if ($data_code[0]->bio_marriage_status == 'Married') {
                if ($data_check == 0){
                   $required = 'required';
                } else {
                   $required = '';
                }
            }
          ?>
					<div class=" form-group" id="spouse_ktp_borrower" style="display: <?php echo @$display;?>;">
						<label>Number ID Card(KTP) Spouse </label>
						<input type="number" placeholder="" name="borrower_ktp_spouse" id="spouse_ktp_nik" class="form-control" value="<?php echo @$data_commercial[0]->borrower_ktp_spouse; ?>" <?php echo @$required;?>>
             <p id="hasil_cari_nik_spouse" ></p>
						<br>
						<?php
            if (@$data_commercial[0]->borrower_ktp_spouse_picture == "") {
            ?>  
            <img id="borrower_ktp_spouse" src="<?php echo base_url();?>uploads/Fintech/ktp_spouse_borrower/noimage.jpg " style="width: 100%; height: 150px; border: 1px solid;">
            <?php   
            }else{
             ?>
            <img id="borrower_ktp_spouse" src="<?php echo base_url();?>uploads/Fintech/ktp_spouse_borrower/<?php echo @$data_commercial[0]->borrower_ktp_spouse_picture; ?>" style="width: 100%; height: 150px; border: 1px solid;">
            <?php  
            }
            ?>
						<br>
						<label>Upload KTP</label>
                        <input type="file" placeholder="Upload Spouse KTP" onchange="preview_ktp_spouse()" id="borrower_spouse_id_picture" name="borrower_ktp_spouse_picture" class="form-control" <?php echo @$required;?>>
                        <span style="color: #dd4b39; font-size: 12px">*file size picture max 5mb</span>
                        <span style="color: #dd4b39; font-size: 12px">& file type picture jpg/png/jpeg .</span>
					</div>
					<!-- <div class=" form-group">
                        <label>Repayment Capacity </label>
                        <input type="Number" class="form-control" name="borrower_repayment_capacity" value="<?php echo @$data_commercial[0]->borrower_repayment_capacity; ?>" required="true">
                    </div> -->
                    
                    <div class=" form-group">
                        <label>Collectibility BI </label>
                        <select class="form-control select2" name="borrower_collectibility_bi" value="<?php echo @$data_commercial[0]->borrower_collectibility_bi; ?>" style="width: 100%;" required="required">
                             <?php   
                                    if ($data_commercial[0]->borrower_collectibility_bi =='1') {
                                      $Lancar  = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='2') {
                                      $Watch   = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='3') {
                                      $DPK   = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='4') {
                                      $Kurang   = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='5') {
                                      $Ragu   = 'selected';
                                    } else if ($data_commercial[0]->borrower_collectibility_bi =='6') {
                                      $Macet   = 'selected';
                                    } else {
                                      $default  = 'selected';
                                    }
                                   ?>
                                  <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                                  <option value="1"<?php echo @$Lancar;?>>Lancar</option>
                                  <option value="2"<?php echo @$Watch;?>>Watchlist</option>
                                  <option value="3"<?php echo @$DPK;?>>DPK</option>
                                  <option value="4"<?php echo @$Kurang;?>>Kurang Lancar</option>
                                  <option value="5"<?php echo @$Ragu;?>>Diragukan</option>
                                  <option value="6"<?php echo @$Macet;?>>Macet</option>
                               </select>
                    </div>
					
				</div>
					<br>
					<br>		
				<div class="col-md-6 col-sm-12 col-xs-12" >
          <div class=" form-group">
              <label>Monthly Income </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
              <input type="text" class="form-control dengan-rupiah" name="borrower_montly_income" value="Rp. <?php echo @number_format($data_commercial[0]->borrower_montly_income,0,".","."); ?>" required="true">
          </div>
          <div class=" form-group">
              <label>Operating Costs </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
              <input type="text" class="form-control dengan-rupiah1" name="borrower_operating_costs" value="Rp. <?php echo @number_format($data_commercial[0]->borrower_operating_costs,0,".","."); ?>" required="true">
          </div>
          <div class=" form-group">
              <label>Additional Costs </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
              <input type="text" class="form-control dengan-rupiah2" name="borrower_additional_costs" value="Rp. <?php echo @number_format($data_commercial[0]->borrower_additional_costs,0,".","."); ?>" required="true">
          </div>
					<div class=" form-group" >
						<label>Name of Business Entity</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
						<input type="text" placeholder="Name of Business Entity" name="borrower_business_name" value="<?php echo @$data_commercial[0]->borrower_business_name; ?>" class="form-control" required="true">
					</div>
					<div  class=" form-group">
						<label>Form of Business Entity</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
						<select class="form-control select2" name="borrower_business_form" style="width: 100%;" value="<?php echo @$data_commercial[0]->borrower_business_form; ?>" required="true">
							   <option value="">- Choose Business Entity -</option>
					       
                                <?php
                                    $this->load->model('Front_Fintech/param_model');
                                    $data = $this->param_model->get_entity_business_by_id($data_commercial[0]->borrower_business_form);
                                    foreach ($data_business_entity_cons as $business_entity_entry) {
                                      if ($data[0]->id_param_entity_business == $business_entity_entry->id_param_entity_business) {
                                        echo "<option value='".$business_entity_entry->id_param_entity_business."' selected>".$business_entity_entry->entity_business_name."</option>";
                                      } else {
                                        echo "<option value='".$business_entity_entry->id_param_entity_business."'>".$business_entity_entry->entity_business_name."</option>";
                                      }
                                 
                                    }
                                ?>
					        
                 		</select>
					</div>
					<div class=" form-group">
                                <label> Industry Type</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                                <select class="form-control select2"  name="borrower_industry_type" style="width: 100%;" required ="required">
                                  <option value="">- Choose Industry Type -</option>
                                  <!-- <option value="" style="" readonly><?php echo @$data_consumtive[0]->borrower_industry_type; ?></option> -->
                                 <?php
                                    $this->load->model('Front_Fintech/param_model');
                                    $data = $this->param_model->get_industry_by_id($data_commercial[0]->borrower_industry_type);
                                    foreach ($data_industry_cons as $industry_entry) {
                                      if ($data[0]->id_param_industry == $industry_entry->id_param_industry) {
                                        echo "<option value='".$industry_entry->id_param_industry."' selected>".$industry_entry->industry_name."</option>";
                                      } else {
                                        echo "<option value='".$industry_entry->id_param_industry."'>".$industry_entry->industry_name."</option>";
                                      }
                                 
                                    }
                                ?>
                             </select>
                            </div>
          		     <div  class=" form-group">
						<label> Business Field</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
					        <select class="form-control select2" name="borrower_business_field" style="width: 100%;" value="<?php echo @$data_commercial[0]->borrower_business_field; ?>" required="true" onChange="check_business_field();" id="Business">
					        	  <option value="">- Choose Business Field -</option>
                                  <!-- <option value="" style="" readonly><?php echo @$data_consumtive[0]->borrower_industry_type; ?></option> -->
                                 <?php
                                    $this->load->model('Front_Fintech/param_model');
                                    $data = $this->param_model->get_field_business_by_id($data_commercial[0]->borrower_business_field);
                                    foreach ($data_business_field_cons as $field_entry) {
                                      if ($data[0]->id_param_business_field == $field_entry->id_param_business_field) {
                                        echo "<option value='".$field_entry->id_param_business_field."' selected>".$field_entry->business_field_name."</option>";
                                      } else {
                                        echo "<option value='".$field_entry->id_param_business_field."'>".$field_entry->business_field_name."</option>";
                                      }
                                 
                                    }
                                ?>
					            
               				 </select>
               				 
               				 <input class="form-control select2" name="borrower_business_field_other" value="<?php echo @$data_commercial[0]->borrower_business_field; ?>" placeholder="Write your Statement" type = "text" id ="textother" visible="false" style="display: none;"/>
          		     </div>
					<div class=" form-group">
						<label>Long Entrepreneurship</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
						<input type="number" placeholder="" name="borrower_long_entrepreneurship" value="<?php echo @$data_commercial[0]->borrower_long_entrepreneurship; ?>" class=" form-control" required>
					</div>
					<div class="form-group">
                        <label>Province</label>
                                
                        <select id="borrower_province_select" type="text" name="borrower_province_company" class="form-control select2" required ="required">
                            <option value="">- Choose Province -</option>
                            <?php 
                                   
                            $this->load->model('Front_Fintech/indonesia_model');
                                    $province = $this->indonesia_model->get_province_business_by_id($data_commercial[0]->borrower_province_company);



                                foreach ($data_indonesia as $province_entry) {

                                    if ($province[0]->id_indonesia_provinsi == $province_entry->id_indonesia_provinsi){
                                    echo "<option value='".$province_entry->id_indonesia_provinsi."' selected>".$province_entry->nama."</option>";

                                    } else {

                                    echo "<option value='".$province_entry->id_indonesia_provinsi."'>".$province_entry->nama."</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>City</label>
                                
                        <select id="borrower_city_select" type="text" name="borrower_city_company" class="form-control select2" required ="required">
                            <option value="">- Choose City -</option>
                            <?php
                                $id_indonesia_provinsi = $data_commercial[0]->borrower_province_company;
                                $id_indonesia_kota_kab = $data_commercial[0]->borrower_city_company;
                                $data = $this->indonesia_model->get_city($id_indonesia_provinsi);

                                foreach ($data as $data_entry){
                                    if($data_entry->id_indonesia_kota_kab == $id_indonesia_kota_kab){
                                        echo "<option value='".$data_entry->id_indonesia_kota_kab."' selected>".$data_entry->nama."</option>";
                                    } else {
                                        echo "<option value='".$data_entry->id_indonesia_kota_kab."'>".$data_entry->nama."</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>District</label>
                                
                        <select id="borrower_district_select" type="text" name="borrower_district_company" class="form-control select2" required ="required">
                            <option value="">- Choose District -</option>
                            <?php
                                $id_indonesia_kota_kab = $data_commercial[0]->borrower_city_company;
                                $id_indonesia_kec = $data_commercial[0]->borrower_district_company;
                                $data = $this->indonesia_model->get_district($id_indonesia_kota_kab);

                                foreach ($data as $data_entry){
                                    if($data_entry->id_indonesia_kec == $id_indonesia_kec){
                                        echo "<option value='".$data_entry->id_indonesia_kec."' selected>".$data_entry->nama."</option>";
                                    } else {
                                        echo "<option value='".$data_entry->id_indonesia_kec."'>".$data_entry->nama."</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Village</label>
                                
                        <select id="borrower_village_select" type="text" name="borrower_village_company" class="form-control select2" required ="required">
                            <option value="">- Choose Village -</option>
                            <?php
                                $id_indonesia_kec = $data_commercial[0]->borrower_district_company;
                                $id_indonesia_kel_des = $data_commercial[0]->borrower_village_company;
                                $data = $this->indonesia_model->get_village($id_indonesia_kec);

                                foreach ($data as $data_entry){
                                    if($data_entry->id_indonesia_kel_des == $id_indonesia_kel_des){
                                        echo "<option value='".$data_entry->id_indonesia_kel_des."' selected>".$data_entry->nama."</option>";
                                    } else {
                                        echo "<option value='".$data_entry->id_indonesia_kel_des."'>".$data_entry->nama."</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>					
					<div class=" form-group">
						<label> Business Address</label>
						<label>Street </label>
						<textarea rows="3" placeholder="" name="borrower_address_company" class=" form-control" required ="required"><?php echo @$data_commercial[0]->borrower_address_company; ?></textarea>
					</div>
					<div class=" form-group">
						<label> Post Code </label>
						<input type="Number" placeholder="" name="borrower_post_code_company" required ="required" value="<?php echo @$data_commercial[0]->borrower_post_code_company; ?>" class=" form-control">
					</div>
					<div class=" form-group">
						<label>Office Phone Number</label>
						<input type="Number" placeholder="" name="borrower_office_number" required ="required" class="form-control" value="<?php echo @$data_commercial[0]->borrower_office_number; ?>">
					</div>
		<!-- 			<div class="row">
					<div class=" form-group">
					<div class="col-sm-2" style="text-align: right">
						
							<label class="check_custom" style="font-weight: normal;">
					            <input type="checkbox" name="" >
		                        <span class="check_mark"></span>
		                    </label>
						
					</div>
					<div class="col-sm-10">
						<label>Commercial Loan Data</label><br>
						<span style="color: #dd4b39;">* press the checkbox when you're done</span>
					</div>	
				</div>
				</div> -->
					<div class="row" style="text-align: right; margin-right: 3%;" >
						<button type="submit" class="btn btn-warning btn-sm btnwdt next_button" style="margin-bottom: 4%; margin-top: 6%; background-color: orange; width: 25%; color: white ;height: 35px;" ><b>Update</b></button>
	
					</div>	
					
					</div>
					
				</div>
			</form>
				<!-- -->
	</div>
	</div>
</div>				
</section>

<script type="text/javascript">
	function check_business_field() {
    var el = document.getElementById("Business");
    var str = el.options[el.selectedIndex].text;
    if(str == "Other") {
        show();
    }else {
        hide();
    }
}
function hide(){
    document.getElementById('textother').style.display='none';
}
function show(){
    document.getElementById('textother').style.display='block';
}

function preview_ktp_spouse() {
     var input = document.getElementById('borrower_ktp_spouse');
     var file = input.files[0];
     var reader = new FileReader();
     var noimage = "<?php echo base_url();?>uploads/Fintech/ktp_spouse_borrower/noimage.jpg";

     reader.onloadend = function() {
         $('#ktp_spouse').attr('src', reader.result);
     }

     if (file) {
         reader.readAsDataURL(file);
     } else {
         $('#ktp_spouse').attr('src', noimage);
     }
 }
</script>

<script type="text/javascript">

    $("#spouse_ktp_nik").on('input', function(){

        
        $.ajax({
            url: <?php echo "'". site_url("Finance/F_borrower/cek_nik_spouse")."'";?>,
            type: 'POST',
            dataType: 'json',
            data: $('#spouse_ktp_nik').serialize(),
            timeout: 180000,
            beforeSend: function() {
                $('.next_button').addClass('btn-default');
                $('.next_button').removeClass('btn-warning');
                $(".next_button").prop('disabled', true);
            },
            success: function(data) {
                console.log(data);
                $("#hasil_cari_nik_spouse").html(data.message);
                if(data.is_success==true){                    
                    $('#hasil_cari_nik_spouse').css('color', 'green');
                    $('.next_button').addClass('btn-warning');
                    $('.next_button').removeClass('btn-default');
                    $(".next_button").prop('disabled', false);
                }else{
                    $('#hasil_cari_nik_spouse').css('color', 'red');
                    $('.next_button').addClass('btn-default');
                    $('.next_button').removeClass('btn-warning');
                    $(".next_button").prop('disabled', true);

                }
            
            },
            error: function(x, t, m) {

            }
        });
    });
</script>
	

		
			
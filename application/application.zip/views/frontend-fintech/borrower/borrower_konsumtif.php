<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
    /* The check_custom */
      .check_custom {
          position: relative;
          padding-left: 35px;
          margin-bottom: 12px;
          margin-right: 10px;
          cursor: pointer;
          font-size: 15px;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
      }
    
      /* Hide the browser's default checkbox */
      .check_custom input {
          position: absolute;
          opacity: 0;
          cursor: pointer;
      }
    
      /* Create a custom checkbox */
      .check_mark {
          position: absolute;
          top: 0;
          left: 0;
          height: 25px;
          width: 25px;
          background-color: #eee;
      }
    
      /* On mouse-over, add a grey background color */
      .check_custom:hover input ~ .check_mark {
          background-color: #ccc;
      }
    
      /* When the checkbox is checked, add a blue background */
      .check_custom input:checked ~ .check_mark {
          background-color: #ffd100;
      }
    
      /* Create the check_mark/indicator (hidden when not checked) */
      .check_mark:after {
          content: "";
          position: absolute;
          display: none;
          border-radius: 10%;
      }
    
      /* Show the check_mark when checked */
      .check_custom input:checked ~ .check_mark:after {
          display: block;
      }
    
      /* Style the check_mark/indicator */
      .check_custom .check_mark:after {
          left: 10px;
          top: 7px;
          width: 7px;
          height: 10px;
          border: solid white;
          border-width: 0 3px 3px 0;
          -webkit-transform: rotate(45deg);
          -ms-transform: rotate(45deg);
          transform: rotate(45deg);
      }

       /*wizard*/
      .background-step {
          background-color: orange;
      }
      .stepwizard-step p {
          margin-top: 10px;
      }

      .stepwizard-row {
          display: table-row;
      }

      .stepwizard {
          display: table;
          width: 100%;
          position: relative;
      }

      .stepwizard-step button[disabled] {
          opacity: 1 !important;
          filter: alpha(opacity=100) !important;
      }

      .stepwizard-row:before {
          top: 14px;
          bottom: 0;
          position: absolute;
          content:" ";
          width: 100%;
          height: 1px;
          background-color: #ccc;
          z-order: 0;

      }

      .stepwizard-step {
          display: table-cell;
          text-align: center;
          position: relative;
      }

      .btn-circle {
        width: 64px;
        height: 34px;
        text-align: center;
        padding: 3px 0;
        font-size: 12px;
        line-height: 26px;
        border-radius: 8px;
      }
      .btn_modal_ok {
          height: 27px;
          width: 65px;
      }
      .btn_modal_cancel {
          height: 27px;
          width: 70px;
      }
</style>
<style>
    .tool_tip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }
    
    .tool_tip .tool_tiptext {
        visibility: hidden;
        width: 180px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 0px;
        padding: 5px 0;
    
        /* Position the tool_tip */
        position: absolute;
        z-index: 1;
    }
    
    .tool_tip:hover .tool_tiptext {
        visibility: visible;
    }
</style>

<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
       <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
       <?php } ?>
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-top: 2%; margin-bottom: 2%;">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class=" form-group" align="center">
                     <label><h2>Personal Loan Detail</h2></label>
                  </div>
                  <div class="stepwizard">
                        <div class="stepwizard-row">
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_konsumtif" type="button" class="btn btn-warning btn-circle">Step 1</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_file_konsumtif" type="button" class="btn btn-default btn-circle">Step 2</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/new_loan_consumtive" type="button" class="btn btn-default btn-circle">Step 3</a>
                            </div>
                        </div>
                    </div>
                    <br>


                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <br>
                        <br>
                        <div class=" form-group">
                            <label>Personal's/Entity Name</label>
                            <input type="text" class="form-control" value="<?php echo $data_code[0]->bio_fullname; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> Phone/WA </label>
                            <input type="text" class="form-control" value="<?php echo $data_code[0]->bio_phone; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> Province </label>
                            <input type="text" class="form-control" value="<?php echo @$data_province[0]->nama; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> City</label>
                            <input type="text" class="form-control" value="<?php echo @$data_city[0]->nama; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>District</label>
                            <input type="text"  class=" form-control" value="<?php echo @$data_district[0]->nama; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>Village </label>
                            <input type="text"  class=" form-control" value="<?php echo @$data_village[0]->nama; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>Address</label>
                            <textarea  rows="3" class="form-control" disabled><?php echo $data_code[0]->bio_address; ?></textarea>
                        </div>
                        <div class=" form-group">
                            <label> Post Code</label>
                            <input type="text" class="form-control" value="<?php echo $data_code[0]->bio_post_code; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> Your Email</label>
                            <input type="text" class="form-control" value="<?php echo $data_register[0]->register_email; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>Mother Name </label>
                            <input type="text" class="form-control" value="<?php echo $data_code[0]->bio_mother_name; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>Last Education </label>
                            <input type="text" class="form-control" value="<?php echo $data_code[0]->bio_last_education; ?>" disabled>
                        </div>
                         <div class=" form-group">
                            <label>Employee Status </label>
                            <input type="text" class="form-control" value="<?php echo @$data_consumtive[0]->borrower_employe_status; ?>" disabled>
                        </div>
                         <div class=" form-group">
                            <label>Collectibility BI </label>
                            <select class="form-control select2" name="borrower_collectibility_bi" style="width: 100%;" disabled>
                             <?php   
                                    if ($data_consumtive[0]->borrower_collectibility_bi =='1') {
                                      $Lancar  = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='2') {
                                      $Watch   = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='3') {
                                      $DPK   = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='4') {
                                      $Kurang   = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='5') {
                                      $Ragu   = 'selected';
                                    } else if ($data_consumtive[0]->borrower_collectibility_bi =='6') {
                                      $Macet   = 'selected';
                                    } else {
                                      $default  = 'selected';
                                    }
                                   ?>
                                  <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                                  <option value="1"<?php echo @$Lancar;?>>Lancar</option>
                                  <option value="2"<?php echo @$Watch;?>>Watchlist</option>
                                  <option value="3"<?php echo @$DPK;?>>DPK</option>
                                  <option value="4"<?php echo @$Kurang;?>>Kurang Lancar</option>
                                  <option value="5"<?php echo @$Ragu;?>>Diragukan</option>
                                  <option value="6"<?php echo @$Macet;?>>Macet</option>
                               </select>
                        </div>
                        <div class=" form-group">
                            <label>Length of Current Residency</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                            <input type="number" value="<?php echo @$data_consumtive[0]->borrower_loc_residen; ?>" class=" form-control" disabled>
                        </div>
                        <div class=" form-group">
                            <label> Status of Ownership of Residence</label>
                            <input type="text" class="form-control" value="<?php echo @$data_consumtive[0]->borrower_status_owner; ?>" disabled>
                       </div>
                        <div class=" form-group">
                            <label> Age of Retirement</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                            <input type="number"  class=" form-control" value="<?php echo @$data_consumtive[0]->borrower_age_retirement; ?>" disabled>
                        </div>

                    </div>
                    <br>
                    <br>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class=" form-group">
                            <label>Monthly Income </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                            <input type="text" class="form-control" value="Rp. <?php echo number_format(@$data_consumtive[0]->borrower_montly_income,0,".","."); ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> Number of dependents</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Click For Detail Information</span></a>
                            <input type="number"  class=" form-control" value="<?php echo @$data_consumtive[0]->borrower_dependents; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>Name of Company/Agency</label>
                            <input type="text"  class=" form-control" value="<?php echo @$data_consumtive[0]->borrower_name_company; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> Phone Office</label>
                            <input type="number"  class=" form-control" value="<?php echo @$data_consumtive[0]->borrower_phone_company; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> Province of Company </label>
                            <input type="text" class="form-control" value="<?php echo @$data_province_consumtive[0]->nama; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> City of Company</label>
                            <input type="text" class="form-control" value="<?php echo @$data_city_consumtive[0]->nama; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>District of Company</label>
                            <input type="text"  class=" form-control" value="<?php echo @$data_district_consumtive[0]->nama; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>Village of Company </label>
                            <input type="text"  class=" form-control" value="<?php echo @$data_village_consumtive[0]->nama; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label>Company Address/Agency</label>
                            <textarea  rows="3" class="form-control" disabled><?php echo @$data_consumtive[0]->borrower_address_company; ?></textarea>
                        </div>

                        <div class=" form-group">
                            <label> Industry Type</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                            <input type="text"  class=" form-control" value="<?php echo @$data_industry_type[0]->industry_name; ?>" disabled>
                        </div>
                        <div class=" form-group">
                            <label> Purpose Of Loan</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a> 
                            <input type="text"  class=" form-control" value="<?php echo @$data_entity_type[0]->entity_name; ?>" disabled>
                        </div>
                        <div class="row" style="text-align: center; ">
                        	<a class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: orange; width: 25%; margin-top: 6%;" href="<?php echo site_url();?>Finance/F_borrower/borrower_update_konsumtif">Edit</a>
                          <?php

                            if (@$data_consumtive[0]->borrower_employe_status == '' AND @$data_consumtive[0]->borrower_montly_income == '' AND @$data_consumtive[0]->borrower_collectibility_bi == '' AND @$data_consumtive[0]->borrower_loc_residen == '' AND @$data_consumtive[0]->borrower_status_owner == '' AND @$data_consumtive[0]->borrower_age_retirement == '' AND @$data_consumtive[0]->borrower_name_company == '' AND @$data_consumtive[0]->borrower_phone_company == '' AND @$data_province_consumtive[0]->nama == '' AND @$data_city_consumtive[0]->nama == '' AND @$data_district_consumtive[0]->nama == '' AND @$data_village_consumtive[0]->nama == '' AND @$data_consumtive[0]->borrower_address_company == '' AND @$data_industry_type[0]->industry_name == '' AND @$data_consumtive[0]->borrower_entity_type == '') {
                             ?> 
                              <a class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: black; width: 25%; margin-top: 6%;" href="#" disabled>Next</a>
                              <br>
                              <span style="color: #dd4b39; font-size: 12px">*Please complete your data to proceed to the next step.</span>
                           <?php } else { 
                          ?>
                            <a class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: orange; width: 25%; margin-top: 6%;" href="<?php echo site_url();?>Finance/F_borrower/borrower_file_konsumtif ">Next</a>
                          <?php } ?>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
    function check_Ownership() {
        var el = document.getElementById("Ownership");
        var str = el.options[el.selectedIndex].text;
        if(str == "Other") {
            show();
        }else {
            hide();
        }
    }
    function hide(){
        document.getElementById('textowner').style.display='none';
    }
    function show(){
        document.getElementById('textowner').style.display='block';
    }
</script>
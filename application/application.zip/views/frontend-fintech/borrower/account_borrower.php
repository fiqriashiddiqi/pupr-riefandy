<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style type="text/css">
    table, th, td {
        border: 1px solid #726f6f;
    }
</style>
<style>
    .tool_tip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }
    
    .tool_tip .tool_tiptext {
        visibility: hidden;
        width: 180px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 0px;
        padding: 5px 0;
    
        /* Position the tool_tip */
        position: absolute;
        z-index: 1;
    }
    
    .tool_tip:hover .tool_tiptext {
        visibility: visible;
    }


</style>
<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-top: 3%; padding: 10px;  ">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <form class="form-horizontal" style="margin-top: 10%">
                        <div class="form-group">
                            <label class="col-sm-5 control-label" style="text-align: left;">Name :</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control" placeholder="" name="bio_fullname" value="<?php echo $data_code[0]->bio_fullname; ?>" required="true" readonly>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-5 control-label" style="text-align: left;">Borrower ID :</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control" placeholder="" name="register_code" value="<?php echo $data_code[0]->register_code; ?>" required="true" readonly>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-5 control-label" style="text-align: left;">Virtual Account :</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control" placeholder="0980-xxxx-xxx" name="virtual_account" value="" required="true" readonly>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <form class="form-horizontal" style="margin-top: 10%">
                        <div class="form-group">
                            <div class="col-sm-3">
                                <?php
                                    $loan_interest_total=0;
                                    foreach ($avg_loan as $entry_avg){
                                        $loan_amount = @$entry_avg->loan_amount;
                                        $loan_rate = @$entry_avg->loan_rate;
                                        $loan_interest = $loan_amount * ($loan_rate / 100);

                                        $loan_interest_total = $loan_interest_total + $loan_interest;
                                    }

                                    @$weighted_amount =   @$loan_interest_total / @$sum_loan[0]->amount;
                                    $weighted_percen = $weighted_amount * 100;

                                ?>
                            </div>
                            <label class="col-sm-5 control-label">Average interest rate</label>
                            <div class="col-sm-4" style="width: 100px;">
                                <input type="text" class="form-control" value="<?php echo number_format(@$weighted_percen,2); ?> %" style="text-align: center;" disabled="true">
                            </div>

                        </div>
                    </form>

                </div>
            </div>
            <div class="row" style="background-color: white; ">
                <div class="col-md-12">
                    <HR style="display: block; border-width: 2px; border-color:black;">
                    <div class="form-group" style="text-align: center; border: 2px solid; width: 100%;margin-top: 10px;margin-bottom: 10px;">
                        <h5>Total Disbursed&nbsp + &nbsp Not Yet Disbursed&nbsp = &nbsp Total Loan</h5>
                    </div>
                    <HR style="display: block; border-width: 2px; border-color:black;">
                </div>
                <div class="col-md-6" style="margin-top: 10px;">

                    <?php
                        $total_crow = 0;
                        $total_dis = 0;
                        $total_loan = 0;

                        foreach ($data_loan as $loan_entry) {
                            $total_loan =  $total_loan + $loan_entry->loan_amount;

                            if($loan_entry->loan_status == "Crowdfunding"){
                                 $total_crow =  $total_crow + $loan_entry->loan_amount;
                            } else if($loan_entry->loan_status == "Disbursed"){
                                 $total_dis =  $total_dis + $loan_entry->loan_amount;
                            } 
                        }


                    ?>

                        <div class=" form-group">
                            <label> Total Disbursed</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Total Disbursed</span></a>
                            <input type="text" placeholder=" Total Disbursed " value="Rp. <?php echo number_format($total_dis,0,".","."); ?>" class=" form-control" disabled style="text-align: right;">
                        </div>
                        <div class=" form-group">
                            <label> Not Yet Disbursed </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Not Yet Disbursed</span></a>
                            <input type="text" placeholder=" Not Yet Disbursed " value="Rp. <?php echo number_format($total_crow,0,".","."); ?>" class=" form-control" disabled style="text-align: right;">
                        </div>

                </div>
                <div class="col-md-6" style="margin-top: 10px;">

                    <div class=" form-group">
                        <label> Total Loan</label>
                        <input type="text" placeholder=" Total Loan " value="Rp. <?php echo number_format($total_loan,0,".","."); ?>" class=" form-control" disabled style="text-align: right;">
                    </div>
                </div>
            </div>
            <div class="row" style="background-color: white; margin-top: 0%; margin-bottom: 0%;">
                <div class="col-md-12">
                    <br>
                    <h4><strong>Crowdfunding</strong></h4>
                    <!-- <a href="<?php echo base_url();?>Finance/F_borrower/account_borrower" class="btn btn-info btn-sm" style=" width: 150px; height: 25px; text-align: center; line-height: 1.3 !important;margin-bottom: 3px;" align="right">Disbursed / Ongoing List</a> -->
                </div>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table" style="text-align: center;">
                            <thead>
                                <tr style="background-color: #726f6f;color: white">
                                    <th style="text-align: center;width: 5%;">Loan ID</th>
                                    <th style="text-align: center;width: 10%;">Proposed Date</th>
                                    <th style="text-align: center;width: 10%;">Type of Loan</th>
                                    <th style="text-align: center;width: 15%;">Amount</th>
                                    <th style="text-align: center;width: 5%;">Rating Rate</th>
                                    <th style="text-align: center;width: 5%;">Period</th>
                                    <th style="text-align: center;width: 10%;">Loan Status</th>
                                    <th style="text-align: center;width: 10%;">Payment Status</th>
                                    <th style="text-align: center;">Note</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                        $this->load->model("crud_model");
                                        $data_setting = $this->crud_model->get_setting();
                                        $limit   = $data_setting[0]->setting_pagination;
                                        $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;
                                        
                                        if(empty($page)){
                                            $position  = 0;
                                            $page = 1;
                                        } else {
                                            $position = ($page-1) * $limit;
                                        }

                                            $this->load->model('Front_Fintech/loan_model');
                                            $data_crowdfunding = $this->loan_model->get_crowdfunding_list($limit,$position,$get_code)->result();
                                            $no = $position+1;
                                                if(@$data_crowdfunding != null){
                                                $no=0;
                                                foreach ($data_crowdfunding as $loan_entry) {
                                                
                                            ?>
                                    <tr style="background-color: whitesmoke;">
                                        <td>
                                            <?php echo $loan_entry->id_borrower_loan; ?>
                                        </td>
                                        <td align="center">
                                            <?php echo date("d/m/Y", strtotime($loan_entry->loan_date)); ?>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_type; ?>
                                        </td>
                                        <td align="right">Rp.
                                            <?php echo number_format($loan_entry->loan_amount,0,".",".");?>
                                        </td>
                                        <td align="center">
                                            <?php echo $loan_entry->loan_rating; ?> <br>
                                            <?php echo number_format($loan_entry->loan_rate,2); ?>%</td>
                                        <td align="center">
                                            <?php echo $loan_entry->loan_tenor; ?> month</td>
                                        <td>
                                            <?php echo $loan_entry->loan_status; ?>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_payment; ?>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_note; ?>
                                        </td>
                                    </tr>
                                    <?php 
                                        $no++;
                                        }
                                            } else {?>
                                    <tr style="background-color: whitesmoke;">
                                        <td>&nbsp;</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php }?>
                            </tbody>

                        </table>
                        <?php
                            $data_rows = $this->loan_model->get_crowdfunding_list(null,null,$get_code)->num_rows();
                            $all_page  = ceil($data_rows/$limit);
                        ?>
                            <center>
                            <ul class="pagination">
                                <li>
                                    <?php
                                        if($page > 1){
                                            $prev = $page-1;
                                            echo "<a href='".base_url()."Finance/F_borrower/account_borrower?page=$prev'>Previous</a>";
                                        }
                                    ?>
                                </li>
                                <li>
                                    <?php
                                        for($i=1;$i<=$all_page;$i++)
                                            if ($i != $page){
                                                echo "<a href='".base_url()."Finance/F_borrower/account_borrower?page=$i'>$i</a>";
                                            }
                                    ?>
                                    </li>
                                    <li>
                                    <?php
                                        if($page < $all_page){
                                            $next=$page+1;
                                            echo "<a href='".base_url()."Finance/F_borrower/account_borrower?page=$next'>Next</a>";
                                        }
                                    ?>
                                </li>
                            </ul>
                            </center>
                    </div>
                </div>
            </div>

            <div class="row" style="background-color: white; margin-top: 0%; margin-bottom: 0%;">
                <div class="col-md-12">
                    <h4><strong>Disbursed</strong></h4>
                    <!-- <a href="<?php echo base_url();?>Finance/F_borrower/crowdfunding" class="btn btn-info btn-sm" style=" width: 120px; height: 25px; text-align: center; line-height: 1.3 !important;margin-bottom: 3px;" align="right">Crowdfunding List</a> -->
                </div>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table" style="text-align: center;">
                            <thead>
                                <tr style="background-color: #726f6f;color: white">
                                    <th style="text-align: center;width: 5%;">Loan ID</th>
                                    <th style="text-align: center;width: 10%;">Proposed Date</th>
                                    <th style="text-align: center;width: 10%;">Type of Loan</th>
                                    <th style="text-align: center;width: 15%;">Amount</th>
                                    <th style="text-align: center;width: 5%;">Rating Rate</th>
                                    <th style="text-align: center;width: 5%;">Period</th>
                                    <th style="text-align: center;width: 10%;">Loan Status</th>
                                    <th style="text-align: center;width: 10%;">Payment Status</th>
                                    <th style="text-align: center;width: 5%;">Payment Table</th>
                                    <th style="text-align: center;">Note</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                                if($data_disbursed != null){
                                                $no=0;
                                                foreach ($data_disbursed as $loan_entry) {
                                                $no++;
                                            ?>
                                    <tr style="background-color: whitesmoke;">
                                        <td>
                                            <?php echo $loan_entry->id_borrower_loan; ?>
                                        </td>
                                        <td align="center">
                                            <?php echo date("d/m/Y", strtotime($loan_entry->loan_date)); ?>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_type; ?>
                                        </td>
                                        <td align="right">Rp.
                                            <?php echo number_format($loan_entry->loan_amount,0,".",".");?>
                                        </td>
                                        <td align="center">
                                            <?php echo $loan_entry->loan_rating; ?> <br>
                                            <?php echo number_format($loan_entry->loan_rate,0,".","."); ?>%</td>
                                        <td align="center">
                                            <?php echo $loan_entry->loan_tenor; ?> month</td>
                                        <td>
                                            <?php echo $loan_entry->loan_status; ?>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_payment; ?>
                                        </td>
                                        <td align="center">
                                            <a href="#" data-toggle="modal" data-id="<?php echo $loan_entry->id_borrower_loan ?>" data-target="#myModal" class="fa fa-file-archive-o tool_tip" style="margin:0;padding:0;border-radius:0;width: 20px;"><span class="tool_tiptext">Detail Account</span></a>
                                            <a href="#" data-toggle="modal" data-id="<?php echo $loan_entry->id_borrower_loan ?>" data-target="#myModal_term" class="fa fa-file-archive-o tool_tip" style="margin:0;padding:0;border-radius:0;width: 20px;"><span class="tool_tiptext">Agreement</span></a>
                                        </td>
                                        <td>
                                            <?php echo $loan_entry->loan_note; ?>
                                        </td>
                                    </tr>
                                    <?php }
                                            } else {?>
                                    <tr style="background-color: whitesmoke;">
                                        <td>&nbsp;</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php }?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
</section>

<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg" style="width:1100px;">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">

            <div class="fetched-data"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="width: 70px;height: 30px;">Close</button>
                <a id="linkPdf" class="btn btn-primary" style="width: 70px;height: 30px;"><i class="fa fa-download"></i>&nbsp;PDF</a>
            </div>
        </div>

    </div>
</div>
<div id="myModal_term" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg" style="width:62%;">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">

            <div class="data-term"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="width: 70px;height: 30px;">Close</button>
                <a id="Pdf_term" class="btn btn-primary" style="width: 70px;height: 30px;"><i class="fa fa-download"></i>&nbsp;PDF</a>
            </div>
        </div>

    </div>
</div>

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
        $('#myModal').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            // console.log(rowid);
            //menggunakan fungsi ajax untuk pengambilan data
            $.ajax({
                type : 'get',
                url : 'detail/'+rowid,
                success : function(data){
                $('.fetched-data').html(data);//menampilkan data ke dalam modal
                $('#linkPdf').attr('href', "<?php echo site_url('Export_Pdf/pdf_detail/'); ?>"+rowid);
                }
            });
         });
    });
  </script>
  <script type="text/javascript">
    $(document).ready(function(){
        $('#myModal_term').on('show.bs.modal', function (e) {
            var id_bor = $(e.relatedTarget).data('id');
            // console.log(id_bor);
            //menggunakan fungsi ajax untuk pengambilan data
            $.ajax({
                type : 'get',
                url : 'term_borrower/'+id_bor,
                success : function(data){
                $('.data-term').html(data);//menampilkan data ke dalam modal
                $('#Pdf_term').attr('href', "<?php echo site_url('Export_Pdf/pdf_term_borrower/'); ?>" + id_bor);
                }
            });
         });
    });
  </script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
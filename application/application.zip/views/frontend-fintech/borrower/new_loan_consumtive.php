<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
    /* The check_custom */
      .check_custom {
          position: relative;
          padding-left: 35px;
          margin-bottom: 12px;
          margin-right: 10px;
          cursor: pointer;
          font-size: 15px;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
      }
    
      /* Hide the browser's default checkbox */
      .check_custom input {
          position: absolute;
          opacity: 0;
          cursor: pointer;
      }
    
      /* Create a custom checkbox */
      .check_mark {
          position: relative;
          top: 0;
          left: 0;
          height: 25px;
          width: 25px;
          background-color: #eee;
      }
    
      /* On mouse-over, add a grey background color */
      .check_custom:hover input ~ .check_mark {
          background-color: #ccc;
      }
    
      /* When the checkbox is checked, add a blue background */
      .check_custom input:checked ~ .check_mark {
          background-color: #ffd100;
      }
    
      /* Create the check_mark/indicator (hidden when not checked) */
      .check_mark:after {
          content: "";
          position: relative;
          display: none;
          border-radius: 10%;
      }
    
      /* Show the check_mark when checked */
      .check_custom input:checked ~ .check_mark:after {
          display: block;
      }
    
      /* Style the check_mark/indicator */
      .check_custom .check_mark:after {
          left: 10px;
          top: 7px;
          width: 7px;
          height: 10px;
          border: solid white;
          border-width: 0 3px 3px 0;
          -webkit-transform: rotate(45deg);
          -ms-transform: rotate(45deg);
          transform: rotate(45deg);
      }

       /*wizard*/
      .background-step {
          background-color: orange;
      }
      .stepwizard-step p {
          margin-top: 10px;
      }

      .stepwizard-row {
          display: table-row;
      }

      .stepwizard {
          display: table;
          width: 100%;
          position: relative;
      }

      .stepwizard-step button[disabled] {
          opacity: 1 !important;
          filter: alpha(opacity=100) !important;
      }

      .stepwizard-row:before {
          top: 14px;
          bottom: 0;
          position: absolute;
          content:" ";
          width: 100%;
          height: 1px;
          background-color: #ccc;
          z-order: 0;

      }

      .stepwizard-step {
          display: table-cell;
          text-align: center;
          position: relative;
      }

      .btn-circle {
        width: 64px;
        height: 34px;
        text-align: center;
        padding: 3px 0;
        font-size: 12px;
        line-height: 26px;
        border-radius: 8px;
      }
      .btn_modal_ok {
          height: 27px;
          width: 65px;
      }
      .btn_modal_cancel {
          height: 27px;
          width: 70px;
      }

      .form_custom{
        border :0px solid !important;
        border-color: transparent !important;
        background-color: transparent !important;
      }

      table, th, td {
        border: 1px solid #726f6f;
      }
</style>

<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-top: 2%; margin-bottom: 2%;">
                
                <div class="col-md-12 xol-sm-12 col-xs-12">
                  <div class=" form-group" align="center">
                     <label><h2>Personal Loan Propose</h2></label>
                  </div>
                  <div class="stepwizard">
                        <div class="stepwizard-row">
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_konsumtif" class="btn btn-default btn-circle">Step 1</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_file_konsumtif" class="btn btn-default btn-circle">Step 2</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/new_loan_consumtive" class="btn btn-warning btn-circle">Step 3</a>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-left: 1%;">
                        <div class="col-md-4 col-sm-12 col-xs-12"></div>
                        <div class="col-md-4 col-sm-12 col-xs-12" style="text-align: center">
                            <br>
                        </div>
                        <div class="col-md-4 col-sm-12 col-xs-12"></div>
                    </div>
                    <div class="row" style="margin-left: 1%;">
                        <div class="col-md-3 col-sm-12 col-xs-12"></div>
                        <div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 0%">
                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data" id="myForm" onsubmit="return confirm('The proposed loan can not be canceled. are you sure you want to apply for this loan?')">
                                    <input type="hidden" name="loan_type" value="Personal Loan" required="true">        
                                <div class="form-group">
                                    <label style="text-align: left;">Amount</label>
                                    <input type="text" class=" form-control dengan-rupiah" placeholder="Amount" id="input_amount" oninput="check_score()" style="text-align: right;">
                                    <div id="input_amount_alert" style="color: red; display: none;">* input the loan amount to be submitted</div>
                                    <div id="min_invest_alert" style="color: red; display: none;">* min loan amount 500.000</div>
                                </div>
                                <div class="form-group">
                                    <label style="text-align: left;">Tenor</label>
                                    <select class="form-control select2" style="margin-left:;" id="input_tenor" onchange="check_score()">
                                        <option value="0">- Choose Periode -</option>
                                        <?php
                                            foreach ($data_periode as $periode_entry){
                                        ?>
                                        <option value="<?php echo $periode_entry->periode; ?>"><?php echo $periode_entry->periode; ?> month</option>
                                        <?php } ?>
                                    </select>
                                    <div id="input_tenor_alert" style="color: red; display: none;">* select the period or tenor being submitted</div>
                                </div>
                                <div class="form-group">
                                    <label style="text-align: left;">Description / Note</label>
                                    <input type="text" class=" form-control" placeholder="" required="true" name="description">
                                    <div id="input_deskripsi" style="color: red; display: none;">* fill in your loan description</div>
                                </div>
                        </div>
                        <div class="col-md-3 col-sm-12 col-xs-12"></div>
                    </div>
                    <div class="row" style="margin-top:3%;">
                        <div class="form-group">
                            <label class="control-label" style="margin-left:3%;">Based on our temporary risk analysis, your loan has been rated as:</label>

                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class=" form-group" style="text-align: center;">
                            <div class="table-responsive">
                                <table class="table" >
                                    <thead>
                                        <tr style="background-color: #726f6f;color: white" >
                                            <th style="text-align: center;width: 100px;">Type of Loan</th>
                                            <th style="text-align: center;width: 100px;">Amount</th>
                                            <th style="text-align: center;width: 100px;">Tenor</th>
                                            <th style="text-align: center;width: 100px;">Rating</th>
                                            <th style="text-align: center;width: 100px;">Rate %</th>
                                            <th style="text-align: center;width: 100px;">Principal</th>
                                            <th style="text-align: center;width: 100px;">Interest</th>
                                            <th style="text-align: center;width: 100px;">Total Per Month</th>
                                            <th style="text-align: center;width: 8%;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody> 
                                        <tr style="background-color: whitesmoke; ">
                                            <td>
                                            <input type="text" class="form-control form_custom" id="type_loan" disabled="true"></td>
                                            <td>
                                            <input type="hidden" name="amount" id="amount" required="true">
                                            <input type="hidden" name="needs" id="needs" required="true">
                                            <input type="text" class="form-control form_custom" id="amount2" disabled="true"  style="text-align: right;"></td>
                                            <td>
                                            <input type="hidden" name="periode" id="periode" required="true">
                                            <input type="text" class="form-control form_custom" id="periode2" disabled="true"  style="text-align: center;"></td>
                                            <td>
                                            <input type="hidden" name="rating" id="rating" required="true">
                                            <input type="text" class="form-control form_custom" id="rating2" disabled="true"  style="text-align: center;"></td>
                                            <td>
                                            <input type="hidden" name="rate" id="rate" required="true">
                                            <input type="text" class="form-control form_custom" id="rate2" disabled="true"  style="text-align: center;"></td>
                                            <td><input type="text" class="form-control form_custom" id="principal2" disabled="true"  style="text-align: right;"></td>
                                            <td><input type="text" class="form-control form_custom" id="interest2" disabled="true"  style="text-align: right;"></td>
                                            <td>
                                            <input type="hidden" name="principal" id="principal" required="true">
                                            <input type="hidden" name="interest" id="interest" required="true">
                                            <input type="hidden" name="montly" id="montly" required="true">
                                            <input type="text" class="form-control form_custom" id="montly2" disabled="true"  style="text-align: right;"></td>
                                            <td>
                                                <button type="button" id="post_button" class="btn-danger btn-sm btn btnwdt" data-toggle="modal" data-target="#myModal_term" style="background-color: orange; height: 25px;width: 50px; text-align: center; line-height: 1.1 !important;display: none;">Propose</button>
                                                <!-- <a href="" id="post_button" onclick="save_data()" class="btn-danger btn-sm btn btnwdt" style="background-color: orange; height: 25px; text-align: center; line-height: 1.1 !important;display: none;">Propose</a> -->
                                                <!-- <button type="submit" id="post_button" onclick="save_data()" class="btn-danger btn-sm btn btnwdt" value="Propose" style="background-color: orange; height: 25px;width: 65px text-align: center; line-height: 1.1 !important;display: none;"></button> --> 
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                
                            </div>
                            <div class="form-group">
                                <label class="control-label" style="margin-left:3%;">When it's approved, there's email notification.</label>

                            </div>
                        </div>
                      </div>
                    </div>

                </div>
                <!-- -->
            </div>
        </div>
    </div>
</section>

<div id="myModal_term" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg" style="width: 62%;">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <!-- <h4 class="modal-title" style="text-align: right;">PT One Stop</h4> -->
              <div class="container">
              <div class="row">
                <div class="col-md-3 col-sm-4 col-xs-12">
                
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                  <ul class="nav nav-pills">
                    <a class="navbar-brand" href="#">
                      <img alt="Brand" class="img-responsive img-logo" src="<?php echo base_url();?>uploads/base-img/logoSanders.png">
                    </a>

                  </ul>
                  
                  </div>
                </div>

                    <div class="col-md-9 col-sm-8 col-xs-12">
                      
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <div class="clearfix"> </div>
                                      
                        </div><!-- /.navbar-collapse -->
                    </div>

                  </div> <!-- .row -->
                  </div><!-- /.container-fluid -->
                  <br>
               <h2 style="text-align: center;">TERMS AND CONDITIONS</h2>
          </div>
        
          <div class="col-md-12 col-sm-12 col-xs-12" style="overflow-y: auto;overflow-x: hidden;height: 400px;text-align: justify;">
              <br>
                <?php
                  $date = date('d-m-Y'); 
                  $day = date('D', strtotime($date));
                  $dayList = array(
                    'Sun' => 'Minggu',
                    'Mon' => 'Senin',
                    'Tue' => 'Selasa',
                    'Wed' => 'Rabu',
                    'Thu' => 'Kamis',
                    'Fri' => 'Jumat',
                    'Sat' => 'Sabtu'
                  );
                  $idMax = $this->loan_model->loan_code();
                  $noUrut =(int) substr($idMax[0]->maxID,3,9);
                  $noUrut ++;
                  $newID="LN".sprintf("%09s",$noUrut);
                  $term_id = $newID."/SA/".date('m/Y');
                  $no_sk = $newID."/SK/".date('m/Y');
                ?>
                <p class="MsoNormal" align="center" style="margin-right:-16.95pt;text-align:center;
                mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">LAMPIRAN
                I<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:152.0pt;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">FORM PERJANJIAN PINJAMAN KARYAWAN<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:1.0pt;mso-line-height-rule:exactly"><!--[if gte vml 1]><v:shapetype
                 id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
                 path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
                 <v:stroke joinstyle="miter"/>
                 <v:formulas>
                  <v:f eqn="if lineDrawn pixelLineWidth 0"/>
                  <v:f eqn="sum @0 1 0"/>
                  <v:f eqn="sum 0 0 @1"/>
                  <v:f eqn="prod @2 1 2"/>
                  <v:f eqn="prod @3 21600 pixelWidth"/>
                  <v:f eqn="prod @3 21600 pixelHeight"/>
                  <v:f eqn="sum @0 0 1"/>
                  <v:f eqn="prod @6 1 2"/>
                  <v:f eqn="prod @7 21600 pixelWidth"/>
                  <v:f eqn="sum @8 21600 0"/>
                  <v:f eqn="prod @7 21600 pixelHeight"/>
                  <v:f eqn="sum @10 21600 0"/>
                 </v:formulas>
                 <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
                 <o:lock v:ext="edit" aspectratio="t"/>
                </v:shapetype><v:shape id="_x0000_s1026" type="#_x0000_t75" style='position:absolute;
                 margin-left:16pt;margin-top:11.65pt;width:529.25pt;height:3.5pt;z-index:-251661312'>
                 <v:imagedata src="file:///C:\Users\MFIQRI~1\AppData\Local\Temp\msohtmlclip1\01\clip_image001.jpg"
                  o:title=""/>
                </v:shape><![endif]--><!--[if !vml]--><span style="mso-ignore:vglayout;position:
                absolute;z-index:251655166;margin-left:21px;margin-top:15px;width:706px;
                height:5px"><img width="706" height="5" src="file:///C:/Users/MFIQRI~1/AppData/Local/Temp/msohtmlclip1/01/clip_image002.jpg" v:shapes="_x0000_s1026"></span><!--[endif]--><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:19.35pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" align="center" style="margin-right:-16.95pt;text-align:center;
                mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PERJANJIAN
                PINJAMAN<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:9.0pt;margin-bottom:0cm;
                margin-left:17.0pt;margin-bottom:.0001pt;line-height:118%"><b style="mso-bidi-font-weight:
                normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:
                118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">PERJANJIAN PINJAMAN </span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">ini (selanjutnya disebut sebagai “<b style="mso-bidi-font-weight:normal">Perjanjian
                Pinjaman</b>”) dibuat dan<b style="mso-bidi-font-weight:normal"> </b>ditandatangani
                pada hari <?php echo $dayList[$day];?>, tanggal <?php echo $date;?> oleh dan antara:<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-align:justify;text-indent:
                -30.2pt;line-height:118%;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">1.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">PT SATUSTOP SOLUSI</span></b><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">, sebuah
                perseroan terbatas yang didirikan berdasarkan hukum<b style="mso-bidi-font-weight:
                normal"> </b>Negara Republik Indonesia, beralamat di <?php echo $data_contact[0]->contact_us_headquarter; ?> yang dalam hal ini
                diwakili oleh <?php echo $data_direk[0]->management_menu_person;?> dalam kedudukannya selaku <?php echo $data_direk[0]->management_menu_position;?> yang dalam hal ini
                bertindak selaku penerima kuasa dari pemberi pinjaman berdasarkan:<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:63.0pt;text-indent:-16.0pt;mso-line-height-alt:
                0pt;mso-list:l0 level2 lfo1;tab-stops:63.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">(a)<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp; </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">surat
                kuasa No. <?php echo $no_sk;?> tanggal <?php echo date('d/m/Y');?>;<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:64.0pt;text-indent:-17.0pt;mso-line-height-alt:
                0pt;mso-list:l0 level2 lfo1;tab-stops:64.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">(b)<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp; </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Surat
                kuasa No. <?php echo $no_sk;?> tanggal <?php echo date('d/m/Y');?>;<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">(selanjutnya
                disebut sebagai “<b style="mso-bidi-font-weight:normal">Pemberi Pinjaman</b>”).<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;line-height:
                114%;mso-list:l1 level1 lfo2;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">2.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><?php echo $data_bio[0]->bio_fullname;?>, <?php if ($data_bio[0]->bio_cityzenship == "WNI") {
                  echo "warga negara Indonesia, pemegang Kartu Tanda Penduduk No. ".$data_bio[0]->bio_nik.", yang beralamat di ".$data_bio[0]->bio_address;
                } else {
                  echo "warga negara Asing, bertempat tinggal di ".$data_bio[0]->bio_address. ", pemegang Passport No. ".$data_bio[0]->bio_passport;
                } ?>,
                (untuk selanjutnya disebut sebagai “Penerima Pinjaman”)<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:2.0pt;margin-bottom:0cm;
                margin-left:17.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">(Pemberi Pinjaman, Penerima Pinjaman, masing-masing disebut sebagai ”<b style="mso-bidi-font-weight:normal">Pihak</b>” dan secara bersama-sama disebut
                sebagai ”<b style="mso-bidi-font-weight:normal">Para Pihak</b>”)<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:17.0pt;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">BAHWA</span></b><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">:<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-32.85pt;line-height:
                114%;mso-list:l2 level1 lfo3;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">A.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></span><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman memiliki
                keinginan untuk meminjam dana sejumlah maksimum <span id="amount3"></span> dari Pemberi
                Pinjaman.</span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-align:justify;text-indent:
                -32.2pt;line-height:117%;mso-list:l2 level1 lfo3;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">B.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></span><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Pemberi Pinjaman telah setuju
                untuk meminjamkan Fasilitas Pinjaman (sebagaimana didefinisikan dibawah ini)
                kepada Penerima Pinjaman dan Para Pihak berniat untuk mencatat pinjaman
                tersebut di dalam suatu instrumen hukum yang akan menjadi dasar dari adanya
                pinjaman tersebut dari Pemberi Pinjaman kepada Penerima Pinjaman.<o:p></o:p></span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:4.0pt;margin-bottom:0cm;
                margin-left:17.0pt;margin-bottom:.0001pt;line-height:118%"><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:
                118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">OLEH KARENA ITU</span></b><span style="font-size:
                12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">, Para
                Pihak setuju untuk mengadakan Perjanjian Pinjaman ini berdasarkan<b> </b>syaratsyarat dan ketentuan-ketentuan
                berikut:<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                0pt;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">1.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">DEFINISI
                DAN INTERPRETASI</span></b><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p></o:p></span></p><p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.45pt;line-height:
                114%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1.1</span><span style="font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Seluruh istilah-istilah yang digunakan dalam Perjanjian Pinjaman ini
                memiliki arti sebagaimana sebagai berikut:<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">“<b>Akun
                Penerima Pinjaman</b>” berarti suatu akun yang dibuat oleh Penerima Pinjaman
                pada Situs yang memuat informasi antara lain (i) informasi Penerima Pinjaman
                (ii) jumlah pinjaman yang akan diajukan (iii) jangka waktu pinjaman dan (iv)
                informasi lainnya;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">“<b>Angsuran</b>”
                adalah jumlah pembayaran cicilan tetap secara bulanan yang wajib dibayar oleh
                Penerima Pinjaman selama Jangka Waktu Fasilitas Pinjaman yang besarnya dan
                tanggal jatuh tempo angsuran diatur berdasarkan Perjanjian Pinjaman;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:7.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Biaya Layanan Platform SatuStop</b>”
                adalah biaya yang dikenakan sehubungan dengan penggunaan layanan Platform
                SatuStop;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:1.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Fasilitas Pinjaman</b>” adalah
                fasilitas pinjaman yang diberikan oleh Pemberi Pinjaman melalui SatuStop
                kepada Penerima Pinjaman sebesar <span id="amount4"></span>;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">“<b>Hari Kerja</b>”
                adalah hari, selain hari Sabtu, Minggu dan hari libur resmi nasional, dimana
                bank buka untuk melakukan kegiatan usahanya sesuai dengan ketentuan Bank
                Indonesia;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">“<b>Informasi
                Rahasia</b>” berarti informasi apapun mengenai Perjanjian Pinjaman serta
                informasi apapun yang saling dipertukarkan di antara para pihak dan
                perwakilannya masing-masing sehubungan dengan Perjanjian Pinjaman ini atau
                menurut Perjanjian Pinjaman ini. Informasi Rahasia tidak meliputi informasi
                yang dapat atau akan dapat diakses secara publik (selain karena penggunaan atau
                publikasi yang tidak sah) atau informasi apa pun yang diberikan ke salah satu
                Pihak oleh pihak ketiga yang diberikan wewenang untuk memberikan informasi
                tersebut kecuali informasi yang diberikan tersebut dinyatakan sebagai rahasia;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:7.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>SatuStop</b>” adalah PT
                SATU STOP SOLUSI sebuah perseroan terbatas yang didirikan berdasarkan
                hukum Negara Republik Indonesia, beralamat di <?php echo $data_contact[0]->contact_us_headquarter; ?>.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:2.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Jangka Waktu Fasilitas Pinjaman</b>”
                adalah jangka waktu dari suatu fasilitas pinjaman sejak ditandatanganinya
                Perjanjian Pinjaman sampai dengan Tanggal Jatuh Tempo;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Ketentuan-ketentuan Pinjaman</b>”
                adalah ketentuan-ketentuan yang disetujui dari Permohonan Pinjaman yang telah
                diajukan termasuk informasi sehubungan dengan, antara lain,<o:p></o:p></span></p><p class="MsoNormal" style="line-height:.5pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                .25pt;line-height:117%;mso-list:l1 level1 lfo2;tab-stops:93.95pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">(i)<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">pagu maksimum pinjaman (ii)
                Jangka Waktu Fasilitas Pinjaman (iii) Suku Bunga (iv) denda keterlambatan dan
                (v) kesediaan Penerima Pinjaman untuk menerima Fasilitas Pinjaman apabila dana
                yang terkumpul selama masa penawaran sedikitnya 80% dari nilai pinjaman yang
                diajukan oleh Penerima Pinjaman dan Lampiran III Perjanjian Pinjaman ini.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:117%;mso-list:l2 level1 lfo3;tab-stops:47.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">

                <span style="font-size: 12pt;">“<b>Pelunasan Dipercepat</b>” berarti
                sebagaimana yang didefinisikan pada Pasal 4.2.1;</span><br></span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:5.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Pemberi Pinjaman</b>” adalah
                pihak yang bertindak selaku pemberi pinjaman atas Fasilitas Pinjaman atau
                melalui kuasanya yang ditunjuk yang diatur dalam Perjanjian Pinjaman ini;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:2.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Penawaran Pinjaman</b>” berarti
                yang suatu penawaran Fasilitas Pinjaman yang diajukan oleh seorang Pemberi
                Pinjaman kepada Penerima Pinjaman;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Penerima Pinjaman</b>” adalah
                perseroangan yang menerima Fasilitas Pinjaman dari Pemberi Pinjaman melalui
                SatuStop;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:1.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Platform SatuStop</b>” adalah
                suatu laman yang tersedia pada Situs yang menyediakan berbagai informasi antara
                lain Permohonan Pinjaman, Akun Penerima Pinjaman;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">“<b>Rekening SatuStop</b>” adalah suatu
                rekening bank yang terdaftar atas nama SatuStop;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:5.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Rekening Pembayaran Fasilitas
                Pinjaman</b>” sebagaimana yang didefinisikan pada Pasal 4.1.2;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">“<b>Situs</b>” adalah situs www.sanders.co.id
                yang dikelola oleh PT SATU STOP SOLUSI;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">“<b>Suku Bunga</b>”
                adalah persentase bunga dalam jangka waktu tertentu yang bersifat tetap selama
                masa pinjaman dan dihitung dari besar Fasilitas Pinjaman;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;line-height:118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">“<b>Syarat dan Ketentuan Umum</b>”
                adalah syarat dan ketentuan umum penggunaan perjanjian pinjaman yang terdapat
                pada Situs.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                118%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">“<b>Tanggal
                Jatuh Tempo</b>” adalah berarti tanggal yang ditetapkan di Lampiran I kecuali
                apabila hari tersebut jatuh pada bukan Hari Kerja, maka dalam hal ini Tanggal
                Jatuh Tempo adalah Hari Kerja sebelumnya, atau tanggal lain di mana pembayaran
                terakhir pokok Pinjaman jatuh tempo dan harus dibayar sebagaimana ditetapkan
                dalam Perjanjian ini dan berdasarkan Perjanjian Pinjaman ini.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                -31.45pt;line-height:116%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1.2</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp; &nbsp;</span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Judul-judul yang digunakan dalam Perjanjian Pinjaman ini hanya untuk
                kemudahan dan tidak mempunyai pengaruh apapun terhadap konstruksi Perjanjian
                Pinjaman serta tidak dapat digunakan untuk menafsirkan ketentuan pasal yang
                bersangkutan.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                -31.45pt;line-height:116%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1.3</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp; &nbsp;&nbsp;</span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Kecuali ditentukan lain, referensi pada ketentuan peraturan
                perundang-undangan adalah ketentuan peraturan perundang-undangan yang
                bersangkutan beserta perubahannya dari waktu ke waktu.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                -31.45pt;line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1.4</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;&nbsp;&nbsp;</span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Kecuali disyaratkan lain, acuan terhadap suatu pasal, ayat atau lampiran
                Perjanjian Pinjaman ini adalah acuan terhadap pasal, ayat atau lampiran adalah
                acuan terhadap pasal, ayat atau lampiran Perjanjian Pinjaman ini, dan acuan
                terhadap Perjanjian Pinjaman ini adalah acuan terhadap Perjanjian Pinjaman ini
                beserta lampirannya.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;line-height:
                118%;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">2.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">PENYEDIAAN FASILITAS PINJAMAN DAN TUJUAN PENGGUNAAN FASILITAS PINJAMAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial"><o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:47.0pt;text-align:justify;text-indent:
                -32.2pt;line-height:117%;mso-list:l2 level1 lfo3;tab-stops:47.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">

                <span style="font-size: 12pt;">&nbsp; &nbsp; &nbsp; &nbsp;Dengan
                tunduk pada ketentuan-ketentuan dari Perjanjian Pinjaman ini dan yang terdapat
                dalam Situs termasuk Syarat dan Ketentuan Umum, Pemberi Pinjaman telah setuju
                untuk menyediakan suatu&nbsp;</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">Fasilitas
                Pinjaman dalam jumlah sebesar <span id="amount5"></span> (<span id="output"></span> Rupiah).</span><span style="font-size: 12pt;"><br></span></span></p>

                <p class="MsoNormal" style="line-height:14.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                0pt;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">3.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">JANGKA
                WAKTU FASILITAS PINJAMAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:47.0pt;margin-bottom:.0001pt;text-align:justify;line-height:116%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Jangka waktu Fasilitas Pinjaman ditetapkan selama <span id="periode3"></span> bulan terhitung
                sejak tanggal pengiriman atas seluruh jumlah Fasilitas Pinjaman secara penuh
                dan dapat diperpanjang sesuai dengan kesepakatan dari Para Pihak (“<b>Jangka Waktu Fasilitas Pinjaman</b>”).<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.35pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:94.0pt;margin-bottom:
                0cm;margin-left:48.0pt;margin-bottom:.0001pt;text-indent:-31.2pt;line-height:
                205%;mso-list:l0 level1 lfo1;tab-stops:47.25pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">4.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">PEMBAYARAN FASILITAS PINJAMAN DAN PELUNASAN DIPERCEPAT </span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">4.1 <b>Pembayaran Fasilitas Pinjaman</b><o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:.6pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:112.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:116%;tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.1&nbsp; Fasilitas Pinjaman dan jumlah lain yang terutang berdasarkan
                Perjanjian Pinjaman harus dilunasi oleh Penerima Pinjaman dalam Jangka Waktu
                Fasilitas Pinjaman sesuai dengan jadwal pembayaran pinjaman yang dimuat pada
                Lampiran I<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-left:112.0pt;text-align:justify;text-indent:
                -31.45pt;line-height:116%;tab-stops:111.0pt"><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.2&nbsp; Pembayaran atas Angsuran dilakukan oleh
                Penerima Pinjaman kepada Pemberi Pinjaman pada Hari Kerja ke rekening bank yang
                ditentukan pada Lampiran II dari Perjanjian ini (“ <b>Rekening Pembayaran Fasilitas Pinjaman</b>”).<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:112.0pt;margin-bottom:.0001pt;text-indent:-31.45pt;line-height:
                114%;tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.3&nbsp; Setiap pembayaran dari Penerima Pinjaman, akan dipergunakan untuk
                pembayaran dengan urutan sebagai berikut:<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-left:142.0pt;text-indent:-30.0pt;mso-line-height-alt:
                0pt;mso-list:l1 level1 lfo2;tab-stops:142.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">a.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">biaya-biaya;<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-left:142.0pt;text-indent:-30.7pt;mso-line-height-alt:
                0pt;mso-list:l1 level1 lfo2;tab-stops:142.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">b.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">denda yang belum dibayarkan;<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-left:142.0pt;text-indent:-30.0pt;mso-line-height-alt:
                0pt;mso-list:l1 level1 lfo2;tab-stops:142.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">c.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Suku Bunga; dan<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:14.5pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-left:142.0pt;text-indent:-30.7pt;mso-line-height-alt:
                0pt;mso-list:l1 level1 lfo2;tab-stops:142.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">d.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">pokok pinjaman yang terutang.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:112.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:114%;tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.1.4&nbsp; Apabila pembayaran atas Angsuran jatuh pada hari libur nasional di
                Indonesia atau pada hari Sabtu atau Minggu, maka pembayaran harus dilakukan
                pada Hari Kerja sebelumnya.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">4.2</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Pelunasan Dipercepat<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:112.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:117%;tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.2.1&nbsp; Penerima Pinjaman diperkenankan untuk melakukan pembayaran seluruh
                Fasilitas Pinjaman lebih cepat dari waktu yang ditetapkan dengan melakukan
                permohonan untuk itu melalui Akun Penerima Pinjaman sedikitnya 5 (lima) Hari
                Kerja sebelum tanggal pelunasan dipercepat yang direncakan (“<b>Pelunasan Dipercepat</b>”).<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:112.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:116%;tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.2.2&nbsp; Penerima Pinjaman tidak diperkenankan untuk melakukan pelunasan
                dipercepat sebagian melainkan harus untuk seluruh Fasilitas Pinjaman yang
                diterimanya dari Pemberi Pinjaman yang memberikan.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:112.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:116%;tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">4.2.3&nbsp; Pelunasan Dipercepat dikenakan biaya sebesar dua bulan bunga tanpa
                memperhitungkan masa angsuran berjalan ditambah biaya administrasi sebesar Rp.
                200.000 (dua ratus ribu Rupiah);</span></p><p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:112.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:116%;tab-stops:111.0pt"><font face="Times New Roman, serif">&nbsp;&nbsp;</font><span style="font-family: &quot;Times New Roman&quot;, serif;">&nbsp;</span><span style="font-size: 12pt; font-family: &quot;Times New Roman&quot;, serif;">Ketentuan
                mengenai pembayaran di atas dapat berubah sewaktu-waktu sesuai dengan&nbsp;</span><span style="font-size: 12pt; font-family: &quot;Times New Roman&quot;, serif;">kebijaksanaan SatuStop, dengan pemberitahuan terlebih
                dahulu kepada Penerima Pinjaman.</span></p><p class="MsoNormal" style="line-height:12.4pt;mso-line-height-rule:exactly"><p class="MsoNormal" style="margin-top:0cm;margin-right:140.0pt;margin-bottom:
                0cm;margin-left:48.0pt;margin-bottom:.0001pt;text-indent:-31.2pt;line-height:
                205%;mso-list:l0 level1 lfo1;tab-stops:47.25pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">5.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">SUKU BUNGA, BIAYA-BIAYA DAN DENDA KETERLAMBATAN </span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:205%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">5.1 <b style="mso-bidi-font-weight:normal">Suku Bunga</b><o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:.6pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:112.0pt;text-align:justify;text-indent:
                -31.45pt;line-height:116%;tab-stops:111.0pt"><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">5.1.1<span style="mso-tab-count:1">&nbsp; </span>Suku Bunga yang digunakan terhadap suatu
                Fasilitas Pinjaman adalah Suku Bunga berlaku pada hari terakhir Periode
                Penawaran pada pukul 17:00 Waktu Indonesian Barat yang tersedia pada laman
                Platform SatuStop.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.4pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                tab-stops:111.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">5.1.2<span style="mso-tab-count:1">&nbsp; </span>Suku Bunga
                atas Fasilitas Pinjaman akan diperhitungkan secara harian dengan ketentuan<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:2.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:112.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">1 (satu)
                tahun sama dengan 360 (tiga ratus enam puluh) hari.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:14.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">5.2</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:
                normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Biaya-biaya<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Atas Fasilitas Pinjaman yang diberikan oleh Pemberi
                Pinjaman, Penerima Pinjaman wajib membayar biaya dan pengeluaran sebagai
                berikut :<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:109.0pt;text-align:justify;text-indent:
                -29.25pt;line-height:116%;mso-list:l1 level1 lfo2;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">a.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman akan membayar
                kepada SatuStop Biaya Layanan Platform SatuStop sebesar 5% (lima persen) dari
                jumlah Fasilitas Pinjaman yang pembayarannya akan dilakukan dengan cara
                pengurangan langsung dari jumlah Fasilitas Pinjaman.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:109.0pt;text-align:justify;text-indent:
                -29.95pt;line-height:117%;mso-list:l1 level1 lfo2;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">b.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman setuju untuk
                membayar seluruh biaya-biaya (termasuk biaya hukum) sehubungan dengan
                penandatanganan, pelaksanaan termasuk eksekusi dari Perjanjian, atau perjanjian
                lainnya yang disebutkan di sini yang pembayarannya akan dilakukan dengan cara
                pengurangan langsung dari jumlah yang ditarik atau cara lain yang merupakan
                diskresi dari SatuStop.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:11.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:48.0pt;mso-line-height-alt:0pt;
                tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">5.3</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:
                normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Denda Keterlambatan<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:15.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:79.0pt;line-height:114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Pemberi Pinjaman dapat mengenakan denda keterlambatan kepada Penerima
                Pinjaman sebagaimana diatur pada Ketentuan-ketentuan Pinjaman.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                0pt;mso-list:l2 level1 lfo3;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">6.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PEMULIHAN
                FASILITAS PINJAMAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-align:justify;line-height:
                117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Untuk lebih menjamin ketertiban pembayaran kembali
                atas segala apa yang terutang oleh Penerima Pinjaman kepada Pemberi Pinjaman
                baik karena utang-utang pokok, bunga, biayabiaya lain sehubungan dengan
                Fasilitas Pinjaman yang telah lewat Tanggal Jatuh Tempo, Penerima Pinjaman
                dengan ini mengizinkan Pemberi Pinjaman atau melalui SatuStop selaku kuasanya
                untuk melakukan upaya yang diperlukan oleh Pemberi Pinjaman termasuk namun
                tidak terbatas pada (i) menghubungi Penerima Pinjaman (ii) menggunakan jasa
                pihak ketiga untuk melakukan penagihan atas segala yang terutang dan telah
                melewati Tanggal Jatuh Tempo.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.3pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                0pt;mso-list:l2 level1 lfo3;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;"><span style="mso-list:Ignore">7.<span style="font:7.0pt &quot;Times New Roman&quot;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><!--[endif]--><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">HAL YANG
                DILARANG</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:47.0pt;text-align:justify;line-height:
                116%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Kecuali ditentukan lain oleh Pemberi Pinjaman atau
                kuasanya, terhitung sejak tanggal Perjanjian Pinjaman sampai dengan dilunasinya
                seluruh kewajiban yang terutang oleh Penerima Pinjaman kepada Pemberi Pinjaman,
                Penerima Pinjaman dilarang mengalihkan setiap hak dan kewajiban di&nbsp;<o:p></o:p></span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">Perjanjian Pinjaman dan Syarat dan Ketentuan Umum (termasuk juga hak dan
                kewajiban dan setiap dokumen pelengkapnya) kepada pihak manapun;</span></p></p><p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                0pt;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">8.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PERNYATAAN
                DAN JAMINAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p></o:p></span></p><p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:47.0pt;line-height:114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">Penerima Pinjaman dengan ini berjanji, menyatakan dan menjamin kepada
                Pemberi Pinjaman sebagai berikut:</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -29.5pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">a.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman memiliki hak
                yang sah, kekuasaan dan kewenangan penuh untuk menandatangani, pelaksanaan dan
                pemenuhan Perjanjian Pinjaman ini. Penandatanganan dan pemenuhan Perjanjian
                Pinjaman ini adalah sah dan mengikat untuk dilaksanakan dalam segala hal
                terhadap Penerima Pinjaman;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -30.2pt;line-height:116%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">b.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></span><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Perjanjian Pinjaman ini dan
                dokumen lain yang disebutkan dalam Perjanjian Pinjaman ini, merupakan kewajiban
                yang sah dan mengikat untuk dilaksanakan sesuai dengan ketentuannya
                masing-masing;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -29.5pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">c.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">tidak terdapat perkara di
                pengadilan atau tidak terdapat gugatan atau kemungkinan perkara terhadap
                Penerima Pinjaman termasuk juga perkara apapun yang berhubungan dengan badan
                pemerintahan atau badan administratif lainnya atau hal-hal lainnya yang
                mengancam Penerima Pinjaman yang apabila terjadi dan diputuskan tidak memihak
                kepada Penerima Pinjaman akan mempengaruhi kemampuan keuangan Penerima Pinjaman
                atau kemampuannya untuk membayar secara tepat waktu setiap jumlah terutang
                berdasarkan Perjanjian Pinjaman dan/atau dokumen lainnya atau setiap perubahan
                atau pelengkapnya;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -30.2pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">d.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp; &nbsp; &nbsp; &nbsp;</span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penandatanganan dan pelaksanaan
                Perjanjian Pinjaman ini oleh Penerima Pinjaman, dan transaksi-transaksi yang
                diatur dalam Perjanjian tersebut, tidak dan tidak akan bertentangan dengan: (i)
                undang-undang atau peraturan yang berlaku; atau (ii) setiap perjanjian atau
                instrumen yang mengikat atas Penerima Pinjaman atau salah satu aset miliknya
                atau merupakan suatu Wanprestasi atau peristiwa pengakhiran berdasarkan setiap
                perjanjian atau instrumen apapun yang memiliki atau secara wajar kemungkinan
                memiliki suatu dampak yang bersifat material terhadap Penerima Pinjaman;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -29.5pt;line-height:116%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">e.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></span><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman akan segera
                memberitahu kepada Pemberi Pinjaman setiap terjadinya Wanprestasi kejadian lain
                yang dengan diberitahukan atau lewatnya waktu atau keduanya akan merupakan
                Wanprestasi;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -28.2pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">f.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman tidak sedang
                dan tidak akan mengajukan permohonan penundaan pembayaran (surenseance van
                betaling) terhadap Fasiltas Pinjaman yang diberikan berdasarkan Perjanjian ini
                dan tidak menjadi insolvent atau dinyatakan pailit dan tidak kehilangan haknya
                untuk mengurus atau menguasai harta bendanya;<o:p></o:p></span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -28.2pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">g.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-size: 12pt; font-family: &quot;Times New Roman&quot;, serif; text-indent: -28.2pt;">semua
                informasi baik tertulis maupun tidak tertulis yang diberikan kepada Pemberi
                Pinjaman melalui Situs oleh Penerima Pinjaman dan perwakilannya, sewaktu
                diberikan dan setiap saat setelahnya berdasarkan pengetahuan terbaiknya adalah
                benar, lengkap dan tepat serta tidak menyesatkan dalam hal apapun dan tidak ada
                fakta yang tidak diungkapakan yang memuat setiap informasi yang diberikan kepada
                Pemberi Pinjaman atau SatuStop oleh Penerima Pinjaman menjadi tidak tepat atau
                menyesatkan. Dalam hal terdapat perubahan atas dokumen&nbsp;</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">persyaratan-persyaratan Penerima Pinjaman diwajibkan untuk
                melakukan pembaharuan dan/atau pengkinian atas informasi yang tersedia pada
                Akun Penerima Pinjaman dan mengirimkan dokumen-dokumen tersebut kepada
                SatuStop.</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -28.2pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;"><br></span></p><p class="MsoNormal" style="margin-left:47.0pt;text-indent:-30.2pt;mso-line-height-alt:
                0pt;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">9.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">WANPRESTASI</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p><p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:47.0pt;text-align:justify;line-height:
                117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Dengan memperhatikan ketentuan dalam Perjanjian
                Pinjaman ini, dengan terjadinya salah satu dari kejadian-kejadian di bawah ini
                (selanjutnya disebut sebagai "Wanprestasi") maka seluruh jumlah yang
                terutang berdasarkan Perjanjian Pinjaman ini akan menjadi jatuh tempo dan harus
                dibayar oleh Penerima Pinjaman kepada Pemberi Pinjaman dan Pemberi Pinjaman
                dapat melakukan tindakan apapun juga yang dianggap perlu berdasarkan Perjanjian
                Pinjaman dan/atau Perjanjian Pemberian Fasilitas Pinjaman, perjanjian lainnya
                yang dilakukan oleh Penerima Pinjaman dan Pemberi Pinjaman, sesuai dengan peraturan
                perundang-undangan yang berlaku untuk menjamin pembayaran atas padanya:<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.8pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -29.5pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">a.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman tidak
                melaksanakan kewajibannya berdasarkan Perjanjian ini dan/atau perjanjian
                lainnya yang dilakukan antara Pemberi Pinjaman dan Penerima Pinjaman yang
                mengakibatkan berakhirnya Perjanjian Pinjaman dan/atau Perjanjian Pemberian
                Fasilitas Pinjaman, ini dan perjanjian lainnya yang dilakukan antara Pemberi
                Pinjaman dan Penerima Pinjaman;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -30.2pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">b.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">apabila pernyataan, jaminan dan
                janji Penerima Pinjaman dalam Perjanjian Pinjaman ini dan perjanjian lainnya
                yang dilakukan antara Pemberi Pinjaman dan Penerima Pinjaman yang disebutkan di
                sini menjadi atau dapat dibuktikan menjadi tidak benar, tidak akurat atau
                menyesatkan;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -29.5pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">c.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima Pinjaman (i) mengajukan
                permohonan pernyataan kepailitan atas dirinya atau (ii) memiliki tindakan atas
                dirinya yang apabila tidak dihentikan dalam waktu 30 (tiga puluh) hari kalender
                dapat mengarah kepada pernyataan tidak mampu membayar utang atau pailit oleh
                Penerima Pinjaman;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.7pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -30.2pt;line-height:116%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">d.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">pengadilan atau badan pemerintahan
                lainnya menyatakan bahwa Perjanjian Pinjaman atau dokumen-dokumen atau bagian
                daripadanya adalah batal demi hukum atau menjadi tidak mengikat Para Pihak;
                atau<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -29.5pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">e.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">terjadinya gangguan di dalam
                pasar keuangan atau situasi ekonomi atau perubahan lainnya yang berdampak
                negatif termasuk dan tidak terbatas pada setiap tindakan dari pihak yang
                berwenang untuk melikuidasi atau menghentikan usaha bisnis atau pekerjaan
                Penerima Pinjaman yang menurut pendapat Pemberi Pinjaman dapat menghalangi,
                menunda atau membuat Penerima Pinjaman tidak mampu memenuhi
                kewajiban-kewajibannya dalam Perjanjian ini.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.35pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:47.0pt;text-indent:-36.2pt;mso-line-height-alt:
                0pt;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">10.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">HUKUM
                YANG BERLAKU DAN PENYELESAIAN SENGKETA</span></b><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p><p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                114%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">10.1 Perjanjian ini dan pelaksanaanya ini diatur
                oleh dan ditafsirkan sesuai dengan hukum yang berlaku di Republik Indonesia.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:13.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:77.0pt;text-align:justify;text-indent:
                -28.2pt;line-height:117%;mso-list:l0 level2 lfo1;tab-stops:77.0pt">

                <span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial;
                mso-ansi-language:IN;mso-fareast-language:IN;mso-bidi-language:AR-SA">10.2&nbsp; Apabila&nbsp;
                terjadi&nbsp; perselisihan&nbsp; antara&nbsp;
                Para&nbsp; Pihak&nbsp; sehubungan&nbsp;
                dengan&nbsp; pelaksanaan&nbsp; Perjanjian Pinjaman ini, Para Pihak sepakat
                untuk menyelesaikannya secara musyawarah. Apabila cara musyawarah&nbsp; tidak&nbsp;
                tercapai,&nbsp; maka&nbsp; Para&nbsp;
                Pihak&nbsp; sepakat&nbsp; untuk&nbsp;
                menyerahkan&nbsp; penyelesaiannya</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;"><br></span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">melalui Arbitrase yang akan dilaksanakan di
                Jakarta, pada Kantor Badan Arbitrase Nasional Indonesia (“BANI”), oleh 3 (tiga)
                Arbitrator yang ditunjuk sesuai dengan ketentuan peraturan dan prosedur yang
                diberlakukan BANI. Keputusan arbiter adalah keputusan yang final, mengikat dan
                terhadapnya tidak diperbolehkan upaya hukum perlawanan, banding atau kasasi.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:47.0pt;text-indent:-36.2pt;mso-line-height-alt:
                0pt;mso-list:l0 level1 lfo1;tab-stops:47.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;">11.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">KETENTUAN
                LAIN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p></o:p></span></p><p class="MsoNormal" style="line-height:15.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-indent:-31.5pt;line-height:
                116%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">11.1 Setiap komunikasi yang akan dilakukan antara
                Para Pihak berdasarkan atau sehubungan dengan Perjanjian ini dapat dilakukan
                melalui surat elektronik atau media elektronik lainnya, apabila Para Pihak:<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.25pt;line-height:
                114%;mso-list:l0 level2 lfo1;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">a.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">menyetujui bahwa, kecuali dan
                sampai diberikan pemberitahuan yang bertentangan, surat elektronik atau media
                elektronik tersebut akan menjadi bentuk komunikasi yang diterima;<o:p></o:p></span></p><p class="MsoNormal" style="line-height:13.0pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:109.0pt;text-align:justify;text-indent:
                -29.95pt;line-height:116%;mso-list:l0 level2 lfo1;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">b.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:116%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">memberitahukan secara tertulis
                kepada satu sama lain alamat surat elektronik mereka dan/atau informasi lain
                apa pun yang diperlukan untuk memungkinkan pengiriman dan penerimaan informasi
                melalui media tersebut; dan<o:p></o:p></span></p><p class="MsoNormal" style="line-height:12.85pt;mso-line-height-rule:exactly"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:109.0pt;text-indent:-29.25pt;line-height:
                114%;mso-list:l0 level2 lfo1;tab-stops:109.0pt"><!--[if !supportLists]--><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:114%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;">c.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span><!--[endif]--><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">memberitahukan kepada satu sama
                lain setiap perubahan pada alamat surat elektronik (email) mereka atau
                informasi lain apa pun yang diserahkan oleh mereka.<o:p></o:p></span></p><p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;line-height:
                117%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:117%;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Setiap Pihak akan memberitahukan kepada Pihak lain segera
                setelah mengetahui bahwa sistem surat elektronik miliknya tidak berfungsi
                karena adanya kerusakan teknis (dan kerusakan tersebut akan berlanjut atau
                mungkin akan berlanjut selama lebih dari 24 jam). Setelah disampaikannya
                pemberitahuan tersebut, sampai Pihak tersebut memberitahukan kepada Pihak
                lainnya bahwa kerusakan teknis itu telah diperbaiki, semua pemberitahuan antara
                Para Pihak tersebut akan dikirimkan melalui faks atau surat sesuai dengan Pasal
                11.1 ini. Pemberitahuan dan komunikasi sehubungan dengan Perjanjian ini akan
                disampaikan kepada Para Pihak dengan alamat sebagai berikut:<o:p></o:p></span></p><p class="MsoNormal" style="line-height:13.65pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Pemberi Pinjaman:</span><span style="font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="font-size:11.5pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Penerima
                Pinjaman:<o:p></o:p></span></p><p class="MsoNormal" style="line-height:19.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">U.p: PT. SATUSTOP SOLUSI</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="font-size:11.5pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">U.p: <?php echo $data_bio[0]->bio_fullname;?><o:p></o:p></span></p><p class="MsoNormal" style="line-height:19.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Alamat Surat Elektronik:</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Alamat
                Surat Elektronik:<o:p></o:p></span></p><p class="MsoNormal" style="line-height:2.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><?php echo $data_contact[0]->contact_us_email; ?></span><span style="font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><?php echo $check_data[0]->register_email;?><o:p></o:p></span></p><p class="MsoNormal" style="line-height:19.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">No. Telp:</span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="font-size:11.5pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">No. Telp:<o:p></o:p></span></p><p class="MsoNormal" style="line-height:2.7pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">&nbsp;</span></p><p class="MsoNormal" style="margin-left:80.0pt;mso-line-height-alt:0pt;
                tab-stops:336.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><?php echo $data_contact[0]->contact_us_phone; ?></span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><?php echo $data_bio[0]->bio_phone;?><o:p></o:p></span></p><p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><br></p><p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;line-height:116%"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:116%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial"><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">11.2</span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="font-family: &quot;Times New Roman&quot;, serif; font-size: 12pt;">Setiap
                syarat atau ketentuan dari Perjanjian Pinjaman ini dapat dikesampingkan setiap
                saat oleh Pihak yang berhak atas manfaat daripadanya, tetapi pengesampingan
                tersebut tidak akan efektif kecuali dituangkan dalam bentuk tertulis yang dilaksanakan
                sebagaimana mestinya oleh atau atas nama Pihak yang mengesampingkan syarat atau
                ketentuan tersebut. Tidak ada pengesampingan oleh Pihak manapun akan syarat
                atau ketentuan apapun dalam Perjanjian Pinjaman ini, dalam satu atau lebih hal,
                harus dianggap atau ditafsirkan sebagai pengesampingan akan syarat dan
                ketentuan yang sama ataupun lain dari Perjanjian Pinjaman ini&nbsp;</span>pada setiap kesempatan di masa depan. Semua upaya hukum, baik berdasarkan
                Perjanjian Pinjaman ini atau oleh Hukum atau lainnya yang dapat diberikan, akan
                berlaku secara kumulatif dan bukan alternatif.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">11.3<span style="mso-tab-count:
                1">&nbsp;&nbsp; </span>Tidak ada perubahan, amandemen atau pengesampingan Perjanjian
                Pinjaman ini yang akan berlaku atau mengikat kecuali dibuat secara tertulis
                dan, dalam hal perubahan atau amandemen, ditandatangani oleh Para Pihak dan
                dalam hal pengesampingan, oleh Pihak yang mengesampingkan terhadap siapa
                pengesampingan akan dilakukan. Setiap pengesampingan oleh salah satu Pihak akan
                hak apapun dalam Perjanjian Pinjaman ini atau setiap pelanggaran Perjanjian
                Pinjaman ini oleh Pihak lain tidak dapat diartikan sebagai diabaikannya hak
                lainnya atau bentuk pelanggaran lainnya oleh Pihak lain tersebut, baik dengan
                sifat yang sama atau sifat berbeda daripadanya.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.95pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:79.0pt;text-align:justify;text-indent:
                -31.45pt;line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;
                mso-bidi-font-size:10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">11.4<span style="mso-tab-count:1">&nbsp;&nbsp; </span>Jika ketentuan apapun dalam Perjanjian
                Pinjaman ini dianggap ilegal, tidak sah atau tidak dapat dilaksanakan
                berdasarkan Hukum yang berlaku sekarang atau di masa depan, dan apabila hak-hak
                atau kewajiban dari tiap-tiap Pihak dari Perjanjian berdasarkan Perjanjian
                Pinjaman ini tidak akan terpengaruh secara material dan dengan demikian, (a)
                ketentuan tersebut akan sepenuhnya terpisah, (b) Perjanjian Pinjaman ini akan
                ditafsirkan dan dilaksanakan seolah-olah ketentuan yang ilegal, tidak sah atau
                tidak dapat dilaksanakan tersebut tidak pernah menjadi bagian dari Perjanjian
                Pinjaman ini dan (c) sisa ketentuan berdasarkan Perjanjian Pinjaman ini akan
                tetap berlaku dan tidak akan terpengaruh oleh ketentuan yang ilegal, tidak sah
                atau tidak dapat dilaksanakan tersebut.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">11.5<span style="mso-tab-count:
                1">&nbsp;&nbsp; </span>Kegagalan oleh masing-masing Pihak untuk melaksanakan sebagian
                atau seluruh hak-hak dalam Perjanjian Pinjaman ini, atau pelaksanaan sebagian
                dari hal itu, tidak dapat dianggap sebagai tindakan pelepasan atau
                pengesampingan terhadap hak-hak yang dimiliki tersebut atau secara umum tanpa
                harus menunda terjadinya atau terjadinya kembali peristiwa yang serupa atau
                peristiwa lain yang memunculkan hak tersebut.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:117%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:117%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">11.6<span style="mso-tab-count:
                1">&nbsp;&nbsp; </span>Perjanjian Pinjaman ini akan mengikat dan berlaku untuk keuntungan
                masing-masing Pihak dan berlaku untuk pewaris, penerus dan mereka yang
                ditunjuk. Perjanjian Pinjaman ini tidak memberi hak kepada orang atau badan
                hukum manapun yang bukan merupakan pihak berdasarkan Perjanjian Pinjaman ini,
                kecuali dinyatakan secara jelas dalam Perjanjian Pinjaman ini.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:12.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:114%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">11.7<span style="mso-tab-count:
                1">&nbsp;&nbsp; </span>Mengenai Perjanjian Pinjaman ini Penerima Pinjaman dan Pemberi
                Pinjaman sepakat untuk melepaskan ketentuan Pasal 1266 dari Kitab Undang-undang
                Hukum Perdata Indonesia.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:114%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">11.8<span style="mso-tab-count:
                1">&nbsp;&nbsp; </span>Masing-masing Pihak harus menanggung Pajak sehubungan dengan
                pelaksanaan Perjanjian sesuai dengan ketentuan hukum yang berlaku.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:13.05pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-top:0cm;margin-right:3.0pt;margin-bottom:0cm;
                margin-left:79.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-31.45pt;
                line-height:114%;tab-stops:78.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:114%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">11.9<span style="mso-tab-count:
                1">&nbsp;&nbsp; </span>Seluruh lampiran-lampiran, perubahan, penambahan dan/atau addendum
                dari Perjanjian Pinjaman ini merupakan satu kesatuan dan tidak dapat
                dipisahkan.&nbsp;<o:p></o:p></span></p>
                <br><p class="MsoNormal" style="margin-left:17.0pt;line-height:118%"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;line-height:118%;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
                &quot;Times New Roman&quot;;mso-bidi-font-family:Arial">DEMIKIAN</span></b><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;line-height:118%;font-family:
                &quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
                Arial">, Perjanjian Pinjaman ini ditandatangani dengan menggunakan tanda tangan
                elektronik<b style="mso-bidi-font-weight:normal"> </b>sebagaimana diatur dalam
                Undang-undang Republik Indonesia No.11 Tahun 2008 tentang Informasi dan Transaksi
                Elektronik oleh Para Pihak atau perwakilannya yang sah pada tanggal sebagaimana
                disebutkan di bagian awal Perjanjian Pinjaman ini dan akan mempunyai kekuatan
                hukum yang sama dengan Perjanjian yang dibuat dan ditandatangani secara basah.<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:14.4pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:94.0pt;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Untuk dan atas nama<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:13.9pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:88.0pt;mso-line-height-alt:0pt;
                tab-stops:345.0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">PEMBERI
                PINJAMAN</span></b><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b style="mso-bidi-font-weight:normal"><span style="font-size:11.5pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">PENERIMA PINJAMAN<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:17.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:79.0pt;mso-line-height-alt:0pt"><b style="mso-bidi-font-weight:normal"><span style="font-size:12.0pt;mso-bidi-font-size:
                10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">PT SATU STOP SOLUSI<o:p></o:p></span></b></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:10.0pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="line-height:17.2pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:35.0pt;mso-line-height-alt:0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">______________________________________<o:p></o:p><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">______________________________________<o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:1.0pt;mso-line-height-rule:exactly"><!--[if gte vml 1]><v:line
                 id="_x0000_s1026" style='position:absolute;z-index:-251660288' from="298.05pt,-.45pt"
                 to="526.05pt,-.45pt" o:userdrawn="t" strokeweight="1pt"/><![endif]--><!--[if !vml]--><span style="mso-ignore:vglayout;position:relative;z-index:251656190"><span style="position:absolute;left:396px;top:-2px;width:307px;height:3px"><img width="307" height="3" src="file:///C:/Users/MFIQRI~1/AppData/Local/Temp/msohtmlclip1/01/clip_image001.gif" v:shapes="_x0000_s1026"></span></span><!--[endif]--><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><o:p></o:p></span></p>

                <p class="MsoNormal" style="line-height:16.55pt;mso-line-height-rule:exactly"><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial"><o:p>&nbsp;</o:p></span></p>

                <p class="MsoNormal" style="margin-left:58.0pt;mso-line-height-alt:0pt;
                tab-stops:394.0pt"><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;
                font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
                mso-bidi-font-family:Arial">Nama : <?php echo $data_direk[0]->management_menu_person;?></span><span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial"><span style="mso-tab-count:1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style="font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
                mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Arial">Nama : <?php echo $data_bio[0]->bio_fullname;?><o:p></o:p></span></p>
          </div>
        
        
        <div class="modal-footer">
          <button type="submit" class="btn-danger btn-sm btn btnwdt" style="background-color: orange; height: 22px;width: 50px; text-align: center; line-height: 1.1 !important;margin-top: 2%;">I Agree</button>
                  
          <button type="button" class="btn btn-default" data-dismiss="modal" style="width: 60px;margin-top: 2%;">Close</button>
        </div>
        </form>
      </div>

    </div>
</div>
<script type="text/javascript">

function check_score(){

        var input_amount = $('#input_amount').val();
        var input_tenor = $('#input_tenor').val();

        var amount_valid = input_amount.replace(/\D/g,'');

        if (amount_valid >= 500000){  
          $("#min_invest_alert").hide();
          if (input_amount == ''){
              $("#input_amount_alert").show();
              $("#input_tenor_alert").hide();

                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          
                          document.getElementById('montly2').value = '';

              $("#post_button").hide();

          } else if (input_tenor == 0){
              $("#input_tenor_alert").show();
              $("#input_amount_alert").hide();

                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          
                          document.getElementById('montly2').value = '';

              $("#post_button").hide();

          } else {
              $("#input_deskripsi").show();
              $("#input_amount_alert").hide();
              $("#input_tenor_alert").hide();
              $.ajax({
                  url: <?php echo "'". site_url("Finance/F_borrower/check_score")."'";?>,
                  type: 'POST',
                  dataType: 'json',
                  data: {type_loan: 'Personal Loan', amount: input_amount, periode: input_tenor},
                  timeout: 180000,
                  beforeSend: function() {
                  },
                  success: function(data) {
                      //console.log(data);
                      if(data.alert_error_income==true){  
                          document.getElementById('modal_alert').innerHTML = data.alert_message_income;
                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('amount3').value = '';
                          document.getElementById('montly2').value = '';

                          $("#myModal").modal();
                          $("#post_button").hide();
                      } else if(data.alert_error==true){
                          document.getElementById('modal_alert').innerHTML = data.alert_message;                    
                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('amount3').value = '';
                          document.getElementById('montly2').value = '';

                          $("#myModal").modal();
                          $("#post_button").hide();
                      } else {
                          var rate = data.loan_rate/100;
                          var bunga = (data.loan_amount * rate) * (data.loan_tenor / 12);
                          //var bunga = data.loan_amount * rate;

                          // var t_pokok = Math.round(data.loan_amount / data.loan_tenor);
                          // var t_bunga = Math.round(bunga / data.loan_tenor);

                          var t_pokok =  data.loan_amount /  data.loan_tenor;
                          var t_bunga =  bunga /  data.loan_tenor;
                          
                          var pokok_bunga = parseFloat(t_pokok) + parseFloat(t_bunga);
                          var montly = pokok_bunga;
                          var montly2 = Math.round(pokok_bunga);
                          var t_pokok2 = Math.round(t_pokok);
                          var t_bunga2 = Math.round(t_bunga);
                          
                          document.getElementById('type_loan').value = data.loan_type;
                          document.getElementById('periode').value = data.loan_tenor;
                          document.getElementById('rating').value = data.loan_rating;
                          document.getElementById('rate').value = data.loan_rate;
                          document.getElementById('needs').value = data.loan_needs;
                          document.getElementById('periode2').value = data.loan_tenor;
                          document.getElementById('rating2').value = data.loan_rating;
                          document.getElementById('rate2').value = data.loan_rate;

                          document.getElementById('amount').value = data.loan_amount;
                          document.getElementById('principal').value = t_pokok;
                          document.getElementById('interest').value = t_bunga;
                          document.getElementById('principal2').value = "Rp. " + addCommas(t_pokok2);
                          document.getElementById('interest2').value = "Rp. " + addCommas(t_bunga2);
                          document.getElementById('montly').value = montly;
                          document.getElementById('amount2').value = "Rp. " + addCommas(data.loan_amount);
                          // document.getElementById('amount3').value = "Rp. " + addCommas(data.loan_amount);
                          document.getElementById('montly2').value = "Rp. " + addCommas(montly2);

                          document.getElementById("amount3").innerHTML = "Rp. " + addCommas(data.loan_amount);
                          document.getElementById("amount4").innerHTML = "Rp. " + addCommas(data.loan_amount);
                          document.getElementById("amount5").innerHTML = "Rp. " + addCommas(data.loan_amount);
                          document.getElementById('periode3').innerHTML = data.loan_tenor;
                          document.getElementById("output").innerHTML = terbilang(data.loan_amount);


                          $("#post_button").show();
                      }
                  },
                  error: function(x, t, m) {

                  }
              });
          }
        } else {
          $("#input_amount_alert").hide();
              $("#input_tenor_alert").hide();
              $("#min_invest_alert").show();

                          document.getElementById('type_loan').value = '';
                          document.getElementById('periode').value = '';
                          document.getElementById('rating').value = '';
                          document.getElementById('rate').value = '';
                          document.getElementById('needs').value = '';
                          document.getElementById('periode2').value = '';
                          document.getElementById('rating2').value = '';
                          document.getElementById('rate2').value = '';

                          document.getElementById('amount').value = '';
                          document.getElementById('principal').value = '';
                          document.getElementById('interest').value = '';
                          document.getElementById('principal2').value = '';
                          document.getElementById('interest2').value = '';
                          document.getElementById('montly').value = '';
                          document.getElementById('amount2').value = '';
                          document.getElementById('amount3').value = '';
                          document.getElementById('montly2').value = '';

          $("#post_button").hide();
        }
}

function terbilang(bilangan) {
 
 bilangan    = String(bilangan);
 var angka   = new Array('0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
 var kata    = new Array('','Satu','Dua','Tiga','Empat','Lima','Enam','Tujuh','Delapan','Sembilan');
 var tingkat = new Array('','Ribu','Juta','Milyar','Triliun');
 
 var panjang_bilangan = bilangan.length;
 
 /* pengujian panjang bilangan */
 if (panjang_bilangan > 15) {
   kaLimat = "Diluar Batas";
   return kaLimat;
 }
 
 /* mengambil angka-angka yang ada dalam bilangan, dimasukkan ke dalam array */
 for (i = 1; i <= panjang_bilangan; i++) {
   angka[i] = bilangan.substr(-(i),1);
 }
 
 i = 1;
 j = 0;
 kaLimat = "";
 
 
 /* mulai proses iterasi terhadap array angka */
 while (i <= panjang_bilangan) {
 
   subkaLimat = "";
   kata1 = "";
   kata2 = "";
   kata3 = "";
 
   /* untuk Ratusan */
   if (angka[i+2] != "0") {
     if (angka[i+2] == "1") {
       kata1 = "Seratus";
     } else {
       kata1 = kata[angka[i+2]] + " Ratus";
     }
   }
 
   /* untuk Puluhan atau Belasan */
   if (angka[i+1] != "0") {
     if (angka[i+1] == "1") {
       if (angka[i] == "0") {
         kata2 = "Sepuluh";
       } else if (angka[i] == "1") {
         kata2 = "Sebelas";
       } else {
         kata2 = kata[angka[i]] + " Belas";
       }
     } else {
       kata2 = kata[angka[i+1]] + " Puluh";
     }
   }
 
   /* untuk Satuan */
   if (angka[i] != "0") {
     if (angka[i+1] != "1") {
       kata3 = kata[angka[i]];
     }
   }
 
   /* pengujian angka apakah tidak nol semua, lalu ditambahkan tingkat */
   if ((angka[i] != "0") || (angka[i+1] != "0") || (angka[i+2] != "0")) {
     subkaLimat = kata1+" "+kata2+" "+kata3+" "+tingkat[j]+" ";
   }
 
   /* gabungkan variabe sub kaLimat (untuk Satu blok 3 angka) ke variabel kaLimat */
   kaLimat = subkaLimat + kaLimat;
   i = i + 3;
   j = j + 1;
 
 }
 
 /* mengganti Satu Ribu jadi Seribu jika diperlukan */
 if ((angka[5] == "0") && (angka[6] == "0")) {
   kaLimat = kaLimat.replace("Satu Ribu","Seribu");
 }
 
 return kaLimat;
}
  

function addCommas(nStr) {
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + '.' + '$2');
    }
    return x1 + x2;
}

function save_data()
{
    bootbox.confirm({
    title: "Are You Sure?",
    message: "The proposed loan can not be canceled. are you sure you want to apply for this loan?",
    buttons: {
        cancel: {
            label: '<i class="fa fa-times"></i> Cancel',
            className: 'btn_modal_ok btn-default'
        },
        confirm: {
            label: '<i class="fa fa-check"></i> Yes',
            className: 'btn_modal_ok btn-success'
        }
    },
    callback: function (result) {
        if (result == true){
            document.getElementById("myForm").submit();
        } 
    }
    });
}

</script>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Notice !!</h4>
      </div>
      <div class="modal-body">
        <div id="modal_alert"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Are you sure?</h4>
      </div>
      <div class="modal-body">
        <div id="modal_alert">The proposed loan can not be canceled. are you sure you want to apply for this loan?</div>
        
      </div>
      <div class="modal-footer">
        <button type="submit" id="submit" class="btn btn-danger" style="width: 60px;border-radius: 5px;">Yes</button><button type="button" class="btn btn-danger" data-dismiss="modal" style="width: 60px;border-radius: 5px;">Close</button>
      </div>
    </div>

  </div>
</div>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
  <style>
  /* The check_custom */
  .check_custom {
      position: relative;
      padding-left: 35px;
      margin-bottom: 12px;
      margin-right: 10px;
      cursor: pointer;
      font-size: 15px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  /* Hide the browser's default checkbox */
  .check_custom input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
  }

  /* Create a custom checkbox */
  .check_mark {
      position: absolute;
      top: 0;
      left: 0;
      height: 25px;
      width: 25px;
      background-color: #eee;
  }

  /* On mouse-over, add a grey background color */
  .check_custom:hover input ~ .check_mark {
      background-color: #ccc;
  }

  /* When the checkbox is checked, add a blue background */
  .check_custom input:checked ~ .check_mark {
      background-color: #ffd100;
  }

  /* Create the check_mark/indicator (hidden when not checked) */
  .check_mark:after {
      content: "";
      position: absolute;
      display: none;
      border-radius: 10%;
  }

  /* Show the check_mark when checked */
  .check_custom input:checked ~ .check_mark:after {
      display: block;
  }

  /* Style the check_mark/indicator */
  .check_custom .check_mark:after {
      left: 10px;
      top: 7px;
      width: 7px;
      height: 10px;
      border: solid white;
      border-width: 0 3px 3px 0;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
  }

  .nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus {
    color: orange;
    cursor: default;
    background-color: #fff;
    border: 1px solid #ddd;
    border-bottom-color: transparent;
}

.accordion {
    background-color: #dadada;
    color: #444;
    cursor: pointer;
    padding-left: 12px;
    padding-right: 18px;
    padding-top: 5px;
    padding-bottom: 5px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 15px;
    transition: 0.4s;
    font-family: FontAwesome;
}

.active_li, .accordion:hover {
    background-color: #ccc;
}

.accordion:before {
	content: "\f055";
    color: #777;
    font-weight: bold;
    float: right;
    margin-left: 15px;
}

.active_li:before {
   	content: "\f056";
}

.panel {
    padding: 0 18px;
    background-color: white;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
}

table, th, td {
        border: 1px solid #726f6f;
    }
</style>


<section class="container home" >
	<div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
		<div class="container div-feedback" >
		<div class="row" style="background-color: white; margin-bottom: 2%; padding: 20px;">
			 <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
            <?php } ?>
			<div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
				
				<h3><p><b> PAYMENT</b></p></h3>
				
			</div>
				<div class="col-md-7 col-sm-12 col-xs-12" style=" margin-bottom: 2%; margin-top: 10px;" >
                    <div class=" form-group" >
                        <label> Virtual Account </label>
                        <input type="text" placeholder=" Virtual Account " class=" form-control" disabled="">
                    </div>
					<div class=" form-group"  style="text-align: left;">
						<p>Several ways to Payment</p>
					
						  <ul class="nav nav-tabs ">
						    <li class="active"><a href="#InternetBank" data-toggle="tab">Internet Banking</a></li>
						    <li><a href="#atm" data-toggle="tab">ATM</a></li>
						    <li><a href="#bank" data-toggle="tab">Bank Teller</a></li>
						    <li><a href="#mobile" data-toggle="tab">Mobile Banking</a></li>
						    <li><a href="#other" data-toggle="tab">Other</a></li>
						  </ul>
					</div>

					<div class="tab-content">
             			  <div class="active tab-pane" id="InternetBank">
             			  	<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('Internet Banking');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>
             			 <div class="tab-pane" id="atm">
							<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('ATM');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>
					
             			<div class="tab-pane" id="bank">
							<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('Bank Teller');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>
					
             			<div class="tab-pane" id="mobile">
							<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('Mobile Banking');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>

						<div class="tab-pane" id="other">
							<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('Other');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>

					</div>

				</div>
							
				<div class="col-md-5 col-sm-12 col-xs-12" >
					<!-- <div class=" form-group"  style="text-align: center;">
						
							<P> &nbsp </P>
						<p>Your Bank Account Information</p>
					</div>
					<div class=" form-group" >
						<label> Amount </label>
						<input type="Number" placeholder="Amount" class=" form-control">
					</div>
					<div class=" form-group" >
						<label>Name</label>
						<input type="text" placeholder="Name" value="<?php echo @$data_code[0]->your_bank_name ; ?>"  class="form-control" readonly>
					</div>
					<div  class=" form-group">
						<label>Account Number</label>
						<input type="Number" placeholder="Account Number" value="<?php echo @$data_code[0]->bank_account; ?>" class=" form-control" readonly>
					</div>
					<div class=" form-group">
						<label> Bank Name </label>
						<input type="text" placeholder="Bank" value="<?php echo @$data_code[0]->bank_name;?>" class=" form-control" readonly>
					</div>
					<div class=" form-group">
						<label> Branch </label>
						<input type="text" placeholder="Branch" value="<?php echo @$data_code[0]->bank_branch; ?>" class=" form-control" readonly>
					</div>

					<div  class=" form-group">
								<label class="check_custom" style="font-weight: normal;"> Same information as virtual account
		                          <input type="checkbox" name="" >
		                          <span class="check_mark"></span>
		                        </label>
					</div>
					

					<div  class=" form-group">
						
						<button type="button" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; background-color: orange; width: 100%;height: 30px;" >Submit</button>	
					</div>
					<hr style="border: 1px solid; color: grey; " > -->
					<div class=" form-group"  style="text-align: left;">
						<p>Term :</p>
					</div>
					<?php 
						$this->load->model("crud_model");
	                    $data_setting = $this->crud_model->get_setting();
	                    $fee_pg   = $data_setting[0]->fee_pg;
	                    $fee_pg_ex = 1000000 + $fee_pg; 
						?>
					<div class=" form-group"  style="text-align: justify;">
						<p>All transfer fee will be your cost</p>
						<p>Installment payments are subject to a transaction fee Rp. <?php echo number_format($fee_pg,0,".",".");?></p>
						<p>Ex : If the installment payment of Rp 1.000.000 then the funds to be deposited is equal to  Rp. <?php echo number_format($fee_pg_ex,0,".",".");?></p>
						<p>Please Allow 1 X 24 hour for the balance to be update </p>
						<p>Please contact us if you have other questions </p>
					</div>
					   <div class=" form-group" >
                            <label> Email </label>
                            <input type="text" value="<?php echo $data_contact[0]->contact_us_email; ?>" class=" form-control" disabled="">
                        </div>
                        <div  class=" form-group">
                            <label> Phone </label>
                            <input type="text" value="<?php echo $data_contact[0]->contact_us_phone; ?>" class=" form-control" disabled="">
                        </div>
                        <div  class=" form-group">
                            <label> Whatsapp </label>
                            <input type="text" value="<?php echo $data_contact[0]->contact_us_phone; ?>" class=" form-control" disabled="">
                        </div>  

				</div>
						<hr style="border: 1px solid; color: grey; " >
			
			<!-- 	<div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 10px;">
					<div class=" form-group"  style="text-align: left;">
						<p>Term :</p>
					</div>
					
					<div class=" form-group"  style="text-align: left;">
						<p>All transfer fee will be your cost</p>
						<p>Please Allow 1 X 24 hour for the balance to be update </p>
						<p>Please contact us if you have other questions </p>
					</div>
					<div class=" form-group" >
						<label> Email </label>
						<input type="text" placeholder=" Email " class=" form-control">
					</div>
					<div  class=" form-group">
						<label> Phone </label>
						<input type="text" placeholder=" Phone " class=" form-control">
					</div>
					<div  class=" form-group">
						<label> Whatsapp </label>
						<input type="text" placeholder=" Whatsapp " class=" form-control">
					</div>
				</div> -->
				<div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px">
					<div class="form-group">
						<div class="table-responsive">
						<h3 style="text-align: center;">Payment History</h3>
						<table class="table" style="background-color: #cacaca; text-align: center;">
							 	 <!-- <tr style="background-color: grey; " >
								    <th style="text-align: center;">Date</th>
								    <th style=" text-align: center;">Amount</th> 
								    <th style="text-align: center;">Status</th>
								    <th style="text-align: center;">Note</th>
								</tr>
							    <tr>
								    <td>1</td>
								    <td>500000</td>
								    <td>Yes</td>
								    <td>Submit</td>
								</tr>
								 <tr  style="background-color: grey; ">
								    <th style="text-align: center;">Total</th>
								    <th></th>
								    <th></th>
								    <th></th>
								</tr> -->
								<thead>
									<tr style="background-color: #726f6f;color: white">
										<th style="width: 10px;">No</th>
										<th style="text-align: center;">Date</th>
	                                    <th style="text-align: center;">Amount</th>
										<th style="text-align: center;">Status</th>
										<th style="text-align: center;">Note</th>
									</tr>
								</thead>
								<tbody>
									<?php
								       	$this->load->model("crud_model");
					                    $data_setting = $this->crud_model->get_setting();
					                    $limit   = $data_setting[0]->setting_pagination;
								        $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;
										
										if(empty($page)){
								            $position  = 0;
								            $page = 1;
								        } else {
								            $position = ($page-1) * $limit;
								        }

								            $this->load->model('Front_Fintech/payment_model');
								            $data_code = $this->payment_model->get_payment_borrower($get_code,$limit,$position)->result();
								            $no = $position+1;
								            
								             if ($data_code != null) { 
								             	foreach ($data_code as $code_entry){ ?>

								                 	<tr style="background-color: whitesmoke;">
														<td><?php echo $no;?></td>
														<td><?php echo date('d/m/Y', strtotime ($code_entry->payment_date));?></td>
														<td align="right">Rp.<?php echo number_format($code_entry->payment_amount,0,".",".");?></td>
														<td><?php echo $code_entry->payment_status;?></td>
														<td></td>
													</tr>
												    <?php 
									                $no++;
									                }
									             } else { ?>
								                 	<tr style="background-color: whitesmoke;">
														<td>&nbsp;</td>
														<td></td>
														<td></td>
														<td></td>
														<td></td>
													</tr>
								          <?php  
								            } 
											?>
								</tbody>	
							</table>
						</div>
					</div>
						<?php
			                $data_rows = $this->payment_model->get_payment_borrower($get_code)->num_rows();
			                $all_page  = ceil($data_rows/$limit);
			            ?>
			                <center>
			                <ul class="pagination">
			                    <li>
			                        <?php
			                            if($page > 1){
			                                $prev = $page-1;
			                                echo "<a href='".base_url()."Finance/F_borrower/payment?page=$prev'>Previous</a>";
			                            }
			                        ?>
			                    </li>
			                    <li>
			                        <?php
			                            for($i=1;$i<=$all_page;$i++)
			                                if ($i != $page){
			                                    echo "<a href='".base_url()."Finance/F_borrower/payment?page=$i'>$i</a>";
			                                }
			                        ?>
			                        </li>
			                        <li>
			                        <?php
			                            if($page < $all_page){
			                                $next=$page+1;
			                                echo "<a href='".base_url()."Finance/F_borrower/payment?page=$next'>Next</a>";
			                            }
			                        ?>
			                    </li>
			                </ul>
			                </center>
					
					
				</div>
			</div>
		</div>
	</div>
</section>	

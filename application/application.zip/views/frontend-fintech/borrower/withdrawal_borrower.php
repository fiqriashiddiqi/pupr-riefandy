<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style type="text/css">
    table, th, td {
        border: 1px solid #726f6f;
    }
</style>
<section class="container home" >
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback" >
		<div class="row" style="background-color: white; margin-top: 3%; margin-bottom: 2%;">
			    <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
                <?php } ?>
				<div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center; color: black;">
					
					<br>
					<h4 ><label>Withdrawal</label>  </h4>
				</div>
							<div class="col-md-4 col-sm-12 col-xs-12" style="margin-top: 5%;">
							</div>
							<div class="col-md-4 col-sm-12 col-xs-12">
                            <div class=" form-group" align="center">
                                <h4>Available Fund</h4>
                                <label>Rp. <?php echo number_format(@$borrower_fund[0]->amount,0,".",".");?></label>
                            </div>

							<div class=" form-group">
								<label>Withdrawal Amount</label>
								<input type="text" placeholder="Amount" class=" form-control" value="Rp. <?php echo number_format(@$borrower_fund[0]->amount,0,".",".");?>" disabled>
							</div>
							<div class=" form-group" >
								<label>Name</label>
								<input type="text" placeholder="Name" value="<?php echo @$data_code[0]->your_bank_name ; ?>"  class="form-control" disabled>
							</div>
							<div  class=" form-group">
								<label>Account Number</label>
								<input type="Number" placeholder="Account Number" value="<?php echo @$data_code[0]->bank_account; ?>" class=" form-control" disabled>
							</div>
							<div class=" form-group">
								<label> Bank Name </label>
								<input type="text" placeholder="Bank" value="<?php echo @$data_code[0]->bank_name;?>" class=" form-control" disabled>
							</div>
							<div class=" form-group">
								<label> Branch </label>
								<input type="text" placeholder="Branch" value="<?php echo @$data_code[0]->bank_branch; ?>" class=" form-control" disabled>
							</div>
							<?php 
								$this->load->model("crud_model");
			                    $data_setting = $this->crud_model->get_setting();
			                    $fee_pg   = $data_setting[0]->fee_pg;
			                    $fee_pg_ex = 10000000 + $fee_pg; 
							?>
							<div class=" form-group">
								<p style="margin: 0">*Term</p>
								<p>Will be reduced by the transaction fee Rp. <?php echo number_format($fee_pg,0,".",".");?></p>
							</div>
							<div class="form-group" style="text-align: center">
								<a href="<?php echo $edit_url;?>" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; margin-top: 2%; background-color: orange; width: 100%; color: black;height: 30px;" ><b>Withdrawal</b></a>	
							</div>
							
								
							</div>
							<div class="col-md-4 col-sm-12 col-xs-12">

							</div>
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class=" form-group" style="text-align: center; ">
								<label> Withdrawal History</label>
								<div class="table-responsive">
								  	<table class="table">
								    	<thead>
										    <tr style="background-color: #726f6f;color: white">
										      <th style="text-align: center;" width="20px">No</th>
                                              <th style="text-align: center;">Date</th>
                                              <th style="text-align: center;">Bank</th>
                                              <th style="text-align: center;">Amount</th>
                                              <th style="text-align: center;">Status</th>
										    </tr>
										  </thead>
										  <tbody>
											<?php
										        $this->load->model("crud_model");
							                    $data_setting = $this->crud_model->get_setting();
							                    $limit   = $data_setting[0]->setting_pagination;
										        $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;
												
												if(empty($page)){
										            $position  = 0;
										            $page = 1;
										        } else {
										            $position = ($page-1) * $limit;
										        }

										            $this->load->model('Front_Fintech/bank_model');
										            $data_code = $this->bank_model->get_withdrawal_borrower($get_code,$limit,$position)->result();
										            $no = $position+1;
										         if ($data_code != null) {
										         	foreach ($data_code as $code_entry){
										                 
										    ?>
											<tr style="background-color: whitesmoke;">
                                                <th><?php echo $no;?></th>
                                                <td><?php echo date('d/m/Y', strtotime ($code_entry->withdrawal_date));?></td>
                                                <td><?php echo $code_entry->bank_name;?> : <?php echo $code_entry->bank_account;?></td>
                                                <td align="right">Rp. <?php echo number_format($code_entry->withdrawal_amount,0,".",".");?></td>
                                                <td><?php echo $code_entry->withdrawal_status;?></td>
                                            </tr>
												    <?php 
									                $no++;
									                }
									               } else {
									              ?>
									              	<tr style="background-color: whitesmoke;">
		                                                <th></th>
		                                                <td></td>
		                                                <td></td>
		                                                <td align="right"></td>
		                                                <td></td>
		                                            </tr>
									              <?php  
										            } 
												?>
										  </tbody>
										  
								  	</table>
								  	<?php
			                $data_rows = $this->bank_model->get_withdrawal_borrower($get_code)->num_rows();
			                $all_page  = ceil($data_rows/$limit);
			            ?>
			                <center>
			                <ul class="pagination">
			                    <li>
			                        <?php
			                            if($page > 1){
			                                $prev = $page-1;
			                                echo "<a href='".base_url()."Finance/F_borrower/withdrawal_borrower?page=$prev'>Previous</a>";
			                            }
			                        ?>
			                    </li>
			                    <li>
			                        <?php
			                            for($i=1;$i<=$all_page;$i++)
			                                if ($i != $page){
			                                    echo "<a href='".base_url()."Finance/F_borrower/withdrawal_borrower?page=$i'>$i</a>";
			                                }
			                        ?>
			                        </li>
			                        <li>
			                        <?php
			                            if($page < $all_page){
			                                $next=$page+1;
			                                echo "<a href='".base_url()."Finance/F_borrower/withdrawal_borrower?page=$next'>Next</a>";
			                            }
			                        ?>
			                    </li>
			                </ul>
			                </center>
								</div>
							</div>
							</div>

				</div>
			</div>
		</div>
	</div>
</section>
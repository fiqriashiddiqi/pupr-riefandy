<?php date_default_timezone_set("Asia/Jakarta"); ?>
<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-top: 3%; margin-bottom: 2%;">
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <a style="color:orange; " href="# ">
                            <h3>Personal Information</h3>
                        </a>
                    </div>
                    <div class="form-group " ">
                        <a style="color: <?php echo @$style_href;?>" href="
                        <?php echo site_url('Finance/F_borrower/data_bank_borrower') ?>">
                        <h3>Change Bank data</h3>
                        </a>
                    </div>
                    <div class="form-group" ">
                    <a style="color: <?php echo @$style_href;?>" href="
                        <?php echo site_url('Finance/F_borrower/change_password_borrower') ?>">
                        <h3>Change Password</h3>
                        </a>
                    </div>
                </div>

                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
                    <div class="col-md-4 col-sm-12 col-xs-12" id="left2">
                        <input type="hidden" value="<?php echo $get_code; ?>" name="register_code" />
                        <br>
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" placeholder=" Name" name="bio_fullname" value="<?php echo $data_code[0]->bio_fullname; ?>" class="form-control" required>
                        </div> 
						<div class="form-group">
                            <label> Birth Place</label>
                            <input type="text" placeholder=" Birth Place " name="bio_place_birth_date" value="<?php echo $data_code[0]->bio_place_birth_date; ?>" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label> Birthdate</label>
                            <input type="date" placeholder=" Birthdate " name="bio_birth_date" value="<?php echo $data_code[0]->bio_birth_date; ?>" class="form-control " required>
                        </div>
                        <div class="form-group">
                            <label> Gender</label>
                            <select class="form-control select2" name="bio_gender" style="width: 100%;" required>
                            <?php   if ($data_code[0]->bio_gender == 'Male') {
                                                $Male  = 'selected';
                                            } else if ($data_code[0]->bio_gender == 'Female') {
                                                $Female = 'selected';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?> >- Choose Statement -</option>
                              <option value="Male" <?php echo @$Male;?> >Male</option>
                              <option value="Female" <?php echo @$Female;?> >Female</option>          
                           </select>
                        </div>
                        <div class="form-group">
                            <label> Phone</label>
                            <input type="Number" placeholder="  Phone " name="bio_phone" value="<?php echo $data_code[0]->bio_phone; ?>" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Status</label>
                            <select id="borrower_status" required="required" class="form-control select2" name="bio_marriage_status" onchange="check_status_marriage_borrower_update();" style="width: 100%;">
                                        <?php   
                                            if ($data_code[0]->bio_marriage_status == 'Married') {
                                                    $Married  = 'selected';
                                                    $display = 'block';
                                                } else if ($data_code[0]->bio_marriage_status == 'Single') {
                                                    $Single = 'selected';
                                                    $display = 'none';
                                                } else {
                                                    $default  = 'selected';
                                                }
                                        ?>
                                  <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                                  <option value="Married" <?php echo @$Married;?>>Married</option>
                                  <option value="Single" <?php echo @$Single;?>>Single</option>  
                               
                            </select>
                        </div>
                        
                        <div class="form-group" id="spouse_name_borrower" style="display: <?php echo @$display;?>;">
                            <label>Spouse Name</label>
                            <input id="borrower_spouse_name" type="text" placeholder="Spouse Name" name="bio_spouse_name" value="<?php echo @$data_code[0]->bio_spouse_name; ?>" class="form-control" required>
                        </div>
                        <div class="form-group" id="spouse_phone_borrower" style="display: <?php echo @$display;?>;">
                            <label>Spouse Phone</label>
                            <input id="borrower_spouse_phone" type="number" placeholder="Spouse Phone" name="bio_spouse_phone" value="<?php echo @$data_code[0]->bio_spouse_phone; ?>" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Mothers Name</label>
                            <input type="text" placeholder=" Mothers Name " name="bio_mother_name" value="<?php echo $data_code[0]->bio_mother_name; ?>" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label> Last Education</label>
                            <select class="form-control select2" name="bio_last_education" style="width: 100%;" required>
                                    <?php   
                                        if ($data_code[0]->bio_last_education == 'SMP') {
                                                $SMP  = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'SMA') {
                                                $SMA = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'D3') {
                                                $D3 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S1') {
                                                $S1 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S2') {
                                                $S2 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S3') {
                                                $S3 = 'selected';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>

                              <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                              <option value="SMP"<?php echo @$SMP;?>>SMP</option>
                              <option value="SMA"<?php echo @$SMA;?>>SMA</option>
                              <option value="D3" <?php echo @$D3;?>>D3</option>
                              <option value="S1" <?php echo @$S1;?>>S1</option>
                              <option value="S2" <?php echo @$S2;?>>S2</option>
                              <option value="S3" <?php echo @$S3;?>>S3</option>
                                           
                             </select>
                        </div>
                        <div class="form-group">
                            <label> Occupation </label>
                            <select class="form-control select2" name="bio_occupation" id="Occupation" onChange="check_occupation();" required>
                            <?php   
                                        if ($data_code[0]->bio_occupation == 'Wiraswasta') {
                                                $Wiraswasta  = 'selected';
                                            } else if ($data_code[0]->bio_occupation == 'Karyawan Swasta') {
                                                $Karyawan  = 'selected';
                                                $display = "none";
                                            } else if ($data_code[0]->bio_occupation == 'Pegawai Negeri Sipil') {
                                                $PNS = 'selected';
                                                $display = "none";
                                            } else if ($data_code[0]->bio_occupation == 'TNI/POLRI') {
                                                $TNI_POLRI = 'selected';
                                                $display = "none";
                                            }else if ($data_code[0]->bio_occupation == 'Pensiunan') {
                                                $Pensiunan = 'selected';
                                                $display = "none";
                                            }else if ($data_code[0]->bio_occupation == '') {
                                                $default  = 'selected';
                                                $display = "none";
                                            }else {
                                                $Others = 'selected';
                                                $display = "block";
                                            }
                                    ?>
                              <option value="" >- Choose Occupation -</option>
                              <option value="Wiraswasta" <?php echo @$Wiraswasta;?>>Wiraswasta</option>
                              <option value="Karyawan Swasta"<?php echo @$Karyawan;?> >Karyawan Swasta</option>
                              <option value="Pegawai Negeri Sipil"<?php echo @$PNS;?> >Pegawai Negeri Sipil</option>
                              <option value="TNI/POLRI" <?php echo @$TNI_POLRI;?>>TNI/POLRI</option>
                              <option value="Pensiunan" <?php echo @$Pensiunan;?>>Pensiunan</option>
                              <option value="Others" <?php echo @$Others;?>>Others</option>
                          </select>
                            
                        </div>
                        <div class="form-group">
                            <input class="form-control select2" name="bio_occupation_others" value="<?php echo $data_code[0]->bio_occupation; ?>" placeholder="Write your Statement" type="text" id="dummyText" style="display: <?php echo $display;?>;" />
                        </div>
                        <div class="form-group hidden">
                            <label> Reference Code </label>
                            <input type="text" placeholder=" Reference Code " name="bio_reference_code" value="<?php echo $data_code[0]->bio_reference_code; ?>" class="form-control" required="true">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <br>
                        <div class="form-group">
                            <label> Citizenship </label>
                            <input type="hidden" name="bio_cityzenship" value="<?php echo @$data_code[0]->bio_cityzenship; ?>" class="form-control">
                            <input type="text" name="" value="<?php echo @$data_code[0]->bio_cityzenship; ?>" class="form-control" disabled>
                        </div>
                        <?php   
                            if ($data_code[0]->bio_cityzenship == 'WNI') {
                        ?>
                        <div class="form-group" id="ktp_group" style="">
                        <label>KTP/NIK</label>
                        <input id="ktp_nik_borrower" type="hidden" placeholder="KTP / NIK" name="bio_nik" value="<?php echo @$data_code[0]->bio_nik; ?>" class="form-control">
                        <input id="ktp_nik_borrower" type="Number" placeholder="KTP / NIK" name="bio_nik" value="<?php echo @$data_code[0]->bio_nik; ?>" class="form-control" disabled>

                        <br>
                        <img id="ktp_borrower" src="<?php echo base_url();?>uploads/Fintech/ktp_borrower/<?php echo @$data_code[0]->bio_upload_nik;?>" style="width: 100%; height: 150px; border: 1px solid;">
                        <br>

                        <input id="borrower_id_picture" type="file" onchange="preview_ktp_borrower()" placeholder="KTP Upload" name="bio_upload_nik" class="form-control">

                    </div>
                    <div class="form-group">
                        <label>Province</label>
                        
                        <select id="borrower_province_select" type="text" name="bio_province_select" class="form-control select2" required ="required">
                            <option value="">- Choose Province -</option>
                            <?php 
                           
                            $this->load->model('Front_Fintech/indonesia_model');
                            $province = $this->indonesia_model->get_province_by_id($data_code[0]->bio_province);



                                foreach ($data_indonesia as $province_entry) {

                                    if ($province[0]->id_indonesia_provinsi == $province_entry->id_indonesia_provinsi){
                                    echo "<option value='".$province_entry->id_indonesia_provinsi."' selected>".$province_entry->nama."</option>";

                                    } else {

                                    echo "<option value='".$province_entry->id_indonesia_provinsi."'>".$province_entry->nama."</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        
                        <select id="borrower_city_select" type="text" name="bio_city_select" class="form-control select2" required ="required">
                            <option value="">- Choose City -</option>
                            <?php
                                $id_indonesia_provinsi = $data_code[0]->bio_province;
                                $id_indonesia_kota_kab = $data_code[0]->bio_city;
                                $data = $this->indonesia_model->get_city($id_indonesia_provinsi);

                                foreach ($data as $data_entry){
                                    if($data_entry->id_indonesia_kota_kab == $id_indonesia_kota_kab){
                                        echo "<option value='".$data_entry->id_indonesia_kota_kab."' selected>".$data_entry->nama."</option>";
                                    } else {
                                        echo "<option value='".$data_entry->id_indonesia_kota_kab."'>".$data_entry->nama."</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>District</label>
                        
                        <select id="borrower_district_select" type="text" name="bio_district_select" class="form-control select2" required ="required">
                            <option value="">- Choose District -</option>
                            <?php
                                $id_indonesia_kota_kab = $data_code[0]->bio_city;
                                $id_indonesia_kec = $data_code[0]->bio_district;
                                $data = $this->indonesia_model->get_district($id_indonesia_kota_kab);

                                foreach ($data as $data_entry){
                                    if($data_entry->id_indonesia_kec == $id_indonesia_kec){
                                        echo "<option value='".$data_entry->id_indonesia_kec."' selected>".$data_entry->nama."</option>";
                                    } else {
                                        echo "<option value='".$data_entry->id_indonesia_kec."'>".$data_entry->nama."</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Village</label>
                        
                        <select id="borrower_village_select" type="text" name="bio_village_select" class="form-control select2" required ="required">
                            <option value="">- Choose Village -</option>
                            <?php
                                $id_indonesia_kec = $data_code[0]->bio_district;
                                $id_indonesia_kel_des = $data_code[0]->bio_village;
                                $data = $this->indonesia_model->get_village($id_indonesia_kec);

                                foreach ($data as $data_entry){
                                    if($data_entry->id_indonesia_kel_des == $id_indonesia_kel_des){
                                        echo "<option value='".$data_entry->id_indonesia_kel_des."' selected>".$data_entry->nama."</option>";
                                    } else {
                                        echo "<option value='".$data_entry->id_indonesia_kel_des."'>".$data_entry->nama."</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>
                        <?php 
                        } else { 
                        ?>
                        <div class="form-group" id="passport_group" style="">
                        <label>Passport Number</label>
                        <input id="passport_num_borrower" type="Number" placeholder="Passport" name="bio_passport" value="<?php echo @$data_code[0]->bio_passport; ?>" class="form-control">
                        <br>
                        <img id="passport_borrower" src="<?php echo base_url();?>uploads/Fintech/passport_borrower/<?php echo @$data_code[0]->bio_upload_passport;?>" style="width: 100%; height: 150px; border: 1px solid;">
                        <br>

                        <input id="borrower_id_passport" type="file" onchange="preview_passport_borrower()" placeholder="passport Upload" name="bio_upload_passport" class="form-control">

                        </div>
                        <div class="form-group">
                            <label>Country / State</label>
                            <input type="text" placeholder="Country / State" name="bio_country" value="<?php echo @$data_code[0]->bio_country; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Province</label>
                            <input type="text" placeholder="Province" name="bio_province" value="<?php echo @$data_code[0]->bio_province; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" placeholder="City" name="bio_city" value="<?php echo @$data_code[0]->bio_city; ?>" class="form-control">
                        </div>
                        <?php 
                        }
                        ?>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea placeholder="Enter Address Here.." rows="3" name="bio_address" value="" class="form-control" required="true"><?php echo $data_code[0]->bio_address; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label> Post Code </label>
                            <input type="Number" placeholder=" Post Code " name="bio_post_code" value="<?php echo $data_code[0]->bio_post_code; ?>" class="form-control" required="true">
                        </div>
                        <div class="form-group" style="text-align: center">
                            <a href="javascript:void(0);" onclick="$(this).closest('form').submit();" class="btn btn-warning btn-sm btn-block" style="background-color: orange; color: black;"><b>Update</b></a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
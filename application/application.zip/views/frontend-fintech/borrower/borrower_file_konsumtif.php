<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
    /* The check_custom */
      .check_custom {
          position: relative;
          padding-left: 35px;
          margin-bottom: 12px;
          margin-right: 10px;
          cursor: pointer;
          font-size: 15px;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
      }
    
      /* Hide the browser's default checkbox */
      .check_custom input {
          position: absolute;
          opacity: 0;
          cursor: pointer;
      }
    
      /* Create a custom checkbox */
      .check_mark {
          position: relative;
          top: 0;
          left: 0;
          height: 25px;
          width: 25px;
          background-color: #eee;
      }
    
      /* On mouse-over, add a grey background color */
      .check_custom:hover input ~ .check_mark {
          background-color: #ccc;
      }
    
      /* When the checkbox is checked, add a blue background */
      .check_custom input:checked ~ .check_mark {
          background-color: #ffd100;
      }
    
      /* Create the check_mark/indicator (hidden when not checked) */
      .check_mark:after {
          content: "";
          position: relative;
          display: none;
          border-radius: 10%;
      }
    
      /* Show the check_mark when checked */
      .check_custom input:checked ~ .check_mark:after {
          display: block;
      }
    
      /* Style the check_mark/indicator */
      .check_custom .check_mark:after {
          left: 10px;
          top: 7px;
          width: 7px;
          height: 10px;
          border: solid white;
          border-width: 0 3px 3px 0;
          -webkit-transform: rotate(45deg);
          -ms-transform: rotate(45deg);
          transform: rotate(45deg);
      }

       /*wizard*/
      .background-step {
          background-color: orange;
      }
      .stepwizard-step p {
          margin-top: 10px;
      }

      .stepwizard-row {
          display: table-row;
      }

      .stepwizard {
          display: table;
          width: 100%;
          position: relative;
      }

      .stepwizard-step button[disabled] {
          opacity: 1 !important;
          filter: alpha(opacity=100) !important;
      }

      .stepwizard-row:before {
          top: 14px;
          bottom: 0;
          position: absolute;
          content:" ";
          width: 100%;
          height: 1px;
          background-color: #ccc;
          z-order: 0;

      }

      .stepwizard-step {
          display: table-cell;
          text-align: center;
          position: relative;
      }

      .btn-circle {
        width: 64px;
        height: 34px;
        text-align: center;
        padding: 3px 0;
        font-size: 12px;
        line-height: 26px;
        border-radius: 8px;
      }
      .btn_modal_ok {
          height: 27px;
          width: 65px;
      }
      .btn_modal_cancel {
          height: 27px;
          width: 70px;
      }
</style>

<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-top: 2%; margin-bottom: 2%;">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class=" form-group" align="center">
                     <label><h2>Personal Loan File</h2></label>
                </div>
                     <div class="stepwizard">
                        <div class="stepwizard-row">
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_konsumtif" type="button" class="btn btn-default btn-circle">Step 1</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/borrower_file_konsumtif" type="button" class="btn btn-warning btn-circle">Step 2</a>
                            </div>
                            <div class="stepwizard-step">
                                <a href="<?php echo base_url(); ?>Finance/F_borrower/new_loan_consumtive" type="button" class="btn btn-default btn-circle">Step 3</a>
                            </div>
                        </div>
                    </div>
                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
                <div class="col-md-4 col-sm-12 col-xs-12">
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <br>
                    <br>
                      <input type="hidden" value="<?php echo $get_code; ?>" name="register_code"/>
                    <div class=" form-group">
                        <label> NPWP </label>
                         <input type="hidden" name="npwp" value="NPWP" >
                         <br>
                            <?php
                              if(@$data_npwp[0]->file_upload != ""){
                            ?>
                            <img src="<?php echo base_url();?>uploads/Fintech/file_borrower_consumtive/<?php echo @$data_npwp[0]->file_upload; ?>" style="width: 100%; height: 150px; border: 1px solid;">
                            <br>
                            <br>
                            <?php }?>
                        <input type="file" placeholder="" name="file_npwp" class="form-control" required="required">
                    </div>
                    <div class=" form-group">
                        <label> Certificate of Employment</label>
                        <input type="hidden" name="certificate" value="Certificate" required="true">
                        <br>
                            <?php
                              if(@$data_certificate[0]->file_upload != ""){
                            ?>
                            <img src="<?php echo base_url();?>uploads/Fintech/file_borrower_consumtive/<?php echo @$data_certificate[0]->file_upload; ?>" style="width: 100%; height: 150px; border:1px solid;">
                            <br>
                            <br>
                             <?php }?>
                        <input type="file" placeholder="" name="file_certificate"  class="form-control" required="required">
                    </div>
                    <div class=" form-group">
                        <label>Salary per month</label>
                        <input type="hidden" name="salary" value="Salary" required="true">
                        <br>
                            <?php
                              if(@$data_salary[0]->file_upload != ""){
                            ?>
                            <img src="<?php echo base_url();?>uploads/Fintech/file_borrower_consumtive/<?php echo @$data_salary[0]->file_upload; ?>" style="width: 100%; height: 150px; border:1px solid;">
                            <br>
                            <br>
                             <?php }?>
                        <input type="file" placeholder="" name="file_salary" class="form-control" required="required">
                    </div>
                    <div class=" form-group">
                        <label>Checking account/savings accounts last 3 months </label>
                        <input type="hidden" name="account" value="Account" required="true">
                         <br>
                            <?php
                              if(@$data_account[0]->file_upload != ""){
                            ?>
                            <img src="<?php echo base_url();?>uploads/Fintech/file_borrower_consumtive/<?php echo @$data_account[0]->file_upload; ?>" style="width: 100%; height: 150px; border: 1px solid;">
                            <br>
                            <br>
                             <?php }?>
                        <input type="file" placeholder="" name="file_account" class="form-control" required="required">
                    </div>
                    <div class=" form-group">
                        <label> Credit card bill last 3 months </label>
                        <input type="hidden" name="credit" value="Credit" >
                         <br>
                            <?php
                              if(@$data_credit[0]->file_upload != ""){
                            ?>
                            <img src="<?php echo base_url();?>uploads/Fintech/file_borrower_consumtive/<?php echo @$data_credit[0]->file_upload; ?>" style="width: 100%; height: 150px; border: 1px solid;">
                            <br>
                            <br>
                             <?php }?>
                        <input type="file" placeholder="" name="file_credit" class="form-control">
                    </div>

                    <div class="row" style="text-align: center;margin-bottom: 4%;">
                      <button type="submit" class="btn btn-warning btn-sm btnwdt" style=" margin-top: 4%;background-color: orange; width: 20%; color: white ;height: 30px;"><b>Update</b></button>
                      <?php

                            if (@$data_npwp[0]->file_upload == '' AND @$data_certificate[0]->file_upload == '' AND @$data_salary[0]->file_upload == '' AND @$data_account[0]->file_upload == '' AND @$data_credit[0]->file_upload == '') {
                             ?> 
                              <a class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: black; width: 20%; margin-top: 4%;" href="#" disabled>Next</a>
                              <br>
                              <span style="color: #dd4b39; font-size: 12px">*Please complete your data to proceed to the next step.</span>
                           <?php } else { 
                          ?>
                            <a class="btn btn-warning btn-sm btnwdt" style="color: white; background-color: orange; margin-top: 4%;width: 20%;" href="<?php echo site_url();?>Finance/F_borrower/new_loan_consumtive">Next</a>
                          <?php } ?>
                        

                    </div>
                </div>

                <div class="col-md-4 col-sm-12 col-xs-12">
                </div>
              </form>
            </div>
            </div>
        </div>
        <!-- -->
    </div>
</section>
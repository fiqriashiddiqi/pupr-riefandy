<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style type="text/css">
.modal {
  text-align: center;
}
@media screen and (min-width: 768px) { 
.modal:before {
    display: inline-block;
    vertical-align: middle;
    content: " ";
    height: 100%;
  }
}

.modal-dialog {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
}
</style>
<div class="showcase" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
    <div class="container" style="padding-top: 10px;padding-bottom: 5px;">
        <div class="row">
            <div class="hero">                                       
                <iframe width="100%" height="320" src="https://www.youtube.com/embed/<?php echo $data_video[0]->videos_url;?>?rel=0&controls=0&showinfo=0&autoplay=0" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen style="vertical-align: middle;"></iframe>
            </div>
        </div>
    </div>
</div>
	<div class="showcase showcase2" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png') !important; padding-bottom: 15px;">
        <div class="container" style="padding-top: 2%;border-top: 2px solid;">

            <div class="row">
                <div class="hero loading">
                    
                    <ul class="bxslider">
                        <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                                # code...
                        ?>
                        <li>
                            <img src="<?php echo base_url() ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%"/>
                            <div>
                                <br><br>
                                <h3><?php echo $slideshow_entry->slideshow_name;?></h3>
                                <p><small style="font-size:18px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

        </div>
    </div>
	<section class="container home" >
		<div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
			<div class="container div-feedback" >
			    <div class="row">
                    <div class="col-md-12">
                        <h3 class="title-feedback">TO GET STARTED :</h3>
                    </div>
                </div>
                <div class="row feedback">
                	<div class="col-md-12 col-sm-12 col-xs-12" >
				  			
				  			<div class="col-md-1 col-sm-12 col-xs-12" >
				  			</div>
				  			<div class="col-md-10 col-sm-12 col-xs-12" >

					  			<h4><p style="text-align: justify; width: 100%">1. Please make sure you have transfered the money to your virtual account and attach the proof of transfer to our deposit bar.</p></h4>
									<br>
								<h4><p style="text-align: justify; width: 100%">2. Browse the loan and you will see that all borrowers have been rated by our risk system. We have consider ... to rate the borrowers</p></h4><br>
									<img src="<?php echo base_url();?>uploads/base-img/HTGS1.PNG" style="width: 100%;">
									<br>
								<h4><p style="text-align: justify; width: 100%">3. We also provide borrowers fact for you.</p></h4><br>
								<h4><p style="text-align: justify; width: 100%">4. Choose which loan you want invest.</p></h4>
								<br>
								<h4><p style="text-align: justify; width: 100%">5. Get your return.</p></h4>
								<br>
				  			</div>

				  			<div class="col-md-1 col-sm-12 col-xs-12" >
				  			</div>
				  			
					
						</div>
                </div>
		
			</div>

		</div>
	</section>
    <div id="myModal" class="modal fade" role="dialog" >
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Notice !!</h4>
          </div>
          <div class="modal-body">
           <div class="from-group" style="width: 50%;margin-left: 25%;">
                <label>User</label>
                <input type="text" value="<?php echo $get_code; ?>" class="form-control" readonly>
            </div>
            <div class="from-group" style="width: 50%;margin-left: 25%;">
                <label>Escrow Account</label>
                <input type="text" value="0808-xxx-xxx" class="form-control" readonly>
            </div>
            <?php 
                $data_setting = $this->crud_model->get_setting();
                $comm_borrower   = $data_setting[0]->commision_borrower;
                $fee_pg = $data_setting[0]->fee_pg;
                $insurance = $data_setting[0]->insurance_rate;
            ?>
            <p style="text-align: justify;">Credit disbursement will be deducted from the commission fee <?php echo $comm_borrower;?>%, credit life insurance premium <?php echo $insurance;?>% and then transaction fee Rp <?php echo number_format($fee_pg,0,".",".");?>. Installment payments are subject to a transaction fee. </p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width: 65px">Close</button>
          </div>
        </div>

      </div>
    </div>


<script>
    $(document).ready(function() {
        if ($.cookie('pop') == null) {
            $('#myModal').modal('show');
            $.cookie('pop', '7');
        }
    });
</script>	 
	
    <!-- <script type="text/javascript">
        $(window).load(function(e){        
           $('#myModal').modal('show');
        });
    </script> -->
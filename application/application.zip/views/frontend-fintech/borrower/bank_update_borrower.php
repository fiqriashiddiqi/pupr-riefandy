<?php date_default_timezone_set("Asia/Jakarta"); ?>
<section class="container home" >
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback" >
		<div class="row" style="background-color: white; margin-bottom: 2%; padding: 20px;">
            
			<div class="col-md-3 col-sm-12 col-xs-12">
				<div class=" form-group" ">
					<a style="color: <?php echo @$style_href;?>" href="<?php echo site_url('Finance/F_borrower/personal_info_borrower') ?>"><h3>Personal Information</h3></a>
				</div>
				<div class=" form-group" ">
					<a style="color: orange;" href="<?php echo site_url('Finance/F_borrower/data_bank_borrower') ?>"><h3>Change Bank Data</h3></a>
				</div>
				<div class=" form-group" ">
					<a style="color: <?php echo @$style_href;?>" href="<?php echo site_url('Finance/F_borrower/change_password_borrower') ?>"><h3>Change Password</h3></a>
				</div>
			</div>
				<div class="col-md-9 col-sm-12 col-xs-12" id="left2">
					<br>
						<form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
							<div class="col-md-3 col-sm-12 col-xs-12">
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
							<div class=" form-group" >
								<label>Name</label>
								<input type="hidden" value="<?php echo $get_code; ?>" name="register_code"/>
								<input type="text" placeholder="Name" name="your_bank_name" value="<?php echo @$data_code[0]->your_bank_name ; ?>"  class="form-control" required>
							</div>
							<div  class=" form-group">
								<label>Account Number</label>
								<input type="Number" placeholder="Account Number" name="bank_account" value="<?php echo @$data_code[0]->bank_account; ?>" class=" form-control">
							</div>
							<div class=" form-group">
								<label>Bank Name</label>
								<input type="text" placeholder="Bank"  name="bank_name" value="<?php echo @$data_code[0]->bank_name; ?>" class=" form-control">
							</div>
							<div class=" form-group">
								<label>Branch</label>
								<input type="text" placeholder="Branch" name="bank_branch"  value="<?php echo @$data_code[0]->bank_branch; ?>" class=" form-control">
							</div>
							<div class="form-group" style="text-align: center">
                                <?php if (@$data_code[0]->your_bank_name == null){
                                ?>
								<a href="javascript:void(0);" onclick="$(this).closest('form').submit();" class="btn btn-warning btn-sm btn-block" style="background-color: orange; color: black;"><b>Save</b></a>
                                <?php } else {?>
                                <a href="javascript:void(0);" onclick="$(this).closest('form').submit();" class="btn btn-warning btn-sm btn-block" style="background-color: orange; color: black;"><b>Update</b></a>
                                <?php }?>

							</div>
								
							</div>
							<div class="col-md-3 col-sm-12 col-xs-12">

							</div>
						</form>
				</div>
			</div>
		</div>
	</div>
</section>
<aside class="cls_widget">
        <div class="side-menu">
            <div class="right-menu pull-right">
                <span class="lng left lng-id active"><a>INA</a></span>
                <span class="lng right lng-en"><a>ENG</a></span>
                <span class="halo-bca">SANDERS</span>
            </div>
            <ul id="mobile-accordion1" class="nav">
                <li class="accordion-menu"><a href="<?php echo site_url('Finance/F_borrower') ?>">How to Get Started</a></li>
                <li class="accordion-menu"><a href="<?php echo site_url('Finance/F_borrower/account_borrower') ?>">Account</a></li>
                <li class="accordion-menu"><a href="<?php echo site_url('Finance/F_borrower/browse_loan') ?>">Propose New Loan</a></li>
                <li class="accordion-menu"><a href="<?php echo site_url('Finance/F_borrower/payment') ?>">Payment</a></li>
                <li class="accordion-menu"><a href="<?php echo site_url('Finance/F_borrower/personal_info_borrower') ?>">Personal Information</a></li>
                <li class="accordion-menu"><a href="<?php echo site_url('Finance/F_borrower/withdrawal_borrower') ?>">Withdrawal</a></li>
                <li class="accordion-menu"><a href="#"><?php echo $bio_fullname[0]->bio_fullname;?></a>
                    <span class="glyphicon glyphicon-chevron-down pull-right collapse_btn"></span>
                    <div class="accordion-collapse collapse in collapse_toogle">
                        <div class="accordion-body">
                            <ul class="nav nav-lev2">
                                <li class="accordion-menu" style="background-color: white;padding: 2px 25px;"><b>Available Fund</b> Rp. <?php echo number_format(@$borrower_fund[0]->amount,0,".",".");?></li>
                                <li class="accordion-menu"><a href="<?php echo site_url('Finance/F_borrower/social_point_borrower') ?>">Connect & Point</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="accordion-menu"><a href="<?php echo site_url('Finance/F_login/signout') ?>">Logout</a></li>
            </ul>
        </div>

        <span class="glyphicon glyphicon-chevron-left" style="display:none"></span>
    </aside>

    <script>
        $(document).ready(function(){

            $(".collapse_btn").click(function(){
                $(".collapse_toogle").collapse('toggle');
            });
        });
    </script>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/5a5575a2d7591465c7069726/default';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
    <!--End of Tawk.to Script-->
</body>
</html>
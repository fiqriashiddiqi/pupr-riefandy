<body style="background-image:url('<?php echo base_url(); ?>uploads/base-img/img_home/bg.png');" class="desktopmode" id="home">

    <!-- begin header-->

    <header class="main-nav">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default navbar-header">
                    <div class="logo">
                        <a class="navbar-brand" href="<?php echo base_url();?>home">
                            <div class="logobcaheader">
                                <img class="img-responsive img-logo" src="<?php echo base_url() ?>uploads/base-img/img_home/logoSanders.jpg" style="height:50px;width:160px;margin-top:-5px">
                            </div>
                        </a>
                    </div>
                </nav>
            </div>
        </div>
    </header>
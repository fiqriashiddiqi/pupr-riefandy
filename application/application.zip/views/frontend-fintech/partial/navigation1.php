<body style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png');" class="desktopmode" id="home">
	<header class="main-nav">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default navbar-header navbar-top-1">
                    <div class="logo">
                        <a class="navbar-brand" href="<?php echo site_url('Finance/F_lender') ?>">
                            <div class="logobcaheader">
                                <img class="img-responsive img-logo" src="<?php echo base_url() ?>uploads/base-img/img_home/logoSanders.jpg" style="height:50px;width:160px;margin-top:-5px">
                            </div>
                        </a>
                    </div>
                    <ul class="nav navbar-nav">
                        <li style="height:50px" class="<?php echo @$htgs_active;?>">
                            <a href="<?php echo site_url('Finance/F_lender') ?> "><p style="font-size: 14px;line-height: 1;"> How to Get<br/> Started </p></a>
                        </li>
		                  
		                  <li class="<?php echo @$account_active;?>" ><a href="<?php echo site_url('Finance/F_lender/account') ?>"><p style="font-size: 14px;">Account</p></a></li>
		                  <li class="<?php echo @$portofolio_active;?>"><a href="<?php echo site_url('Finance/F_lender/portofolio_lender') ?>"><p style="font-size: 14px;">Portofolio</p></a></li>
		                  <li class="<?php echo @$browse_active;?>"><a href="<?php echo site_url('Finance/F_lender/browse') ?>"><p style="font-size: 14px;">Browse</p></a></li>
		                  <li class="<?php echo @$deposit_active;?>"><a href="<?php echo site_url('Finance/F_lender/deposit') ?>"><p style="font-size: 14px;">Deposit</p></a></li>
		                   <li class="<?php echo @$report_active;?>"><a href="<?php echo site_url('Finance/F_lender/report') ?>"><p style="font-size: 14px;">Report</p></a></li>
                    </ul>
                    <style>
                        .navbar_li {
                            overflow: hidden;
                            
                            font-family: Arial, Helvetica, sans-serif;

                        }

                        .navbar_li a {
                            float: left;
                            font-size: 13px;
                            color: #6d6d6d;
                            text-align: center;
                            padding: 14px 16px;
                            text-decoration: none;
                        }

                        .dropdown_li {
                            float: left;
                            overflow: hidden;
                        }

                        .dropdown_li .dropbtn {
                            font-size: 13px;    
                            border: none;
                            outline: none;
                            color: #6d6d6d;
                            padding: 14px 16px;
                            background-color: inherit;
                            font-family: inherit;
                            margin: 0;
                        }

                        .navbar_li a:hover, .dropdown_li:hover .dropbtn {
                            background-color: ;
                        }

                        .dropdown-content_li {
                            display: none;
                            position: absolute;
                            background-color: #f9f9f9;
                            min-width: 160px;
                            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                            z-index: 1;
                        }

                        .dropdown-content_li a {
                            float: none;
                            color: black;
                            padding: 3px 16px;
                            text-decoration: none;
                            display: block;
                            text-align: left;
                        }

                        .dropdown-content_li a:hover {
                            background-color: #ddd;
                        }

                        .dropdown_li:hover .dropdown-content_li {
                            display: block;
                        }

                        .divider_li {
                          
                          margin: 9px 0;
                          overflow: hidden;
                          background-color: #e5e5e5;
                          display: block;
                          height: 1px;
                        }

                       
                    </style>

                    <ul class="pull-right right-menu" style="top:13px">
                        <div class="navbar_li">
                          <div class="dropdown_li">
                            <button class="dropbtn"><?php echo $bio_fullname[0]->bio_fullname;?> 
                              <i class="glyphicon glyphicon-triangle-bottom" style="top:3px"></i>
                            </button>
                            <div class="dropdown-content_li">
                              <div style="text-align: left;padding: 0px 6px;font-size: 13px;">
                                  <p class="dropdown-divider"><b>Available Fund</b></p>
                                  <p class="dropdown-divider">Rp. <?php echo number_format(@$lender_fund[0]->amount,0,".",".");?></p>
                              </div>
                              <p class="divider_li" ></p>
                              <a href="<?php echo site_url('Finance/F_lender/personal_info_lender') ?>">Personal Information</a>
                              <a href="<?php echo site_url('Finance/F_lender/withdrawal_lender') ?>">Withdrawal</a>
                              <a href="<?php echo site_url('Finance/F_lender/social_point_lender') ?>">Connect & Point</a>
                              <p class="divider_li" ></p>
                              <a href="<?php echo site_url('Finance/F_login/signout') ?>">Logout</a>
                            </div>
                          </div> 
                        </div>
                       
                         <!-- <li class="dropdown" >
					          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="font-size: 14px">Ericsander <span class="caret"></span></a>
					         <ul class="dropdown-menu">
					         	<li readonly><label>Balance</label></li>
					          	 <li><a>Rp 20.0000.000</a></li>
					            <li><a href="<?php echo site_url('Finance/F_lender/personal_info_lender') ?>">Personal Information</a></li>
					            <li><a href="<?php echo site_url('Finance/F_lender/withdrawal_lender') ?>">Withdrawal</a></li>
					            <li><a href="<?php echo site_url('Finance/F_lender/social_point_lender') ?>">Connect & Point</a></li>
					            <li class="dropdown-divider"><a href="<?php echo site_url('Finance/F_login/login_lender') ?>">Logout</a></li>
			        	 	 </ul>
			        	  </li> --> 

                    </ul> 
                   
                <div class="pull-right">
                    <button style="margin-top: -8px;z-index: 1;" type="button" class="navbar-toggle">
                    <div class="sprites spritemobile"></div>
                    </button>
                </div>
            </nav>
        </div>
    </div>
</header>
		
		
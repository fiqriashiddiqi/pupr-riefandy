<body style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png');" class="desktopmode" id="home">
    <header class="main-nav">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default navbar-header navbar-top-1">
                    <div class="logo">
                        <a class="navbar-brand" href="<?php echo site_url('Finance/F_lender') ?>">
                            <div class="logobcaheader">
                                <img class="img-responsive img-logo" src="<?php echo base_url() ?>uploads/base-img/img_home/logoSanders.jpg" style="height:50px;width:160px;margin-top:-5px">
                            </div>
                        </a>
                    </div>
                    <ul class="nav navbar-nav">
                        <li style="height:50px" class="<?php echo @$htgs_active;?>">
                            <a href="<?php echo site_url('Finance/F_lender') ?> "><p style="font-size: 14px;line-height: 1;"> How to Get<br/> Started </p></a>
                        </li>
                          
                          <li class="<?php echo @$account_active;?>" ><a href="<?php echo site_url('Finance/F_lender/account') ?>"><p style="font-size: 14px;">Account</p></a></li>
                          <li class="<?php echo @$portofolio_active;?>"><a href="<?php echo site_url('Finance/F_lender/portofolio_lender') ?>"><p style="font-size: 14px;">Portofolio</p></a></li>
                          <li class="<?php echo @$browse_active;?>"><a href="<?php echo site_url('Finance/F_lender/browse') ?>"><p style="font-size: 14px;">Browse</p></a></li>
                          <li class="<?php echo @$deposit_active;?>"><a href="<?php echo site_url('Finance/F_lender/deposit') ?>"><p style="font-size: 14px;">Deposit</p></a></li>
                           <li class="<?php echo @$report_active;?>"><a href="<?php echo site_url('Finance/F_lender/report') ?>"><p style="font-size: 14px;">Report</p></a></li>
                    </ul>
                    <style>
                        .navbar_li {
                            overflow: hidden;
                            
                            font-family: Arial, Helvetica, sans-serif;

                        }

                        .navbar_li a {
                            float: left;
                            font-size: 13px;
                            color: #6d6d6d;
                            text-align: center;
                            padding: 14px 16px;
                            text-decoration: none;
                        }

                        .dropdown_li {
                            float: left;
                            overflow: hidden;
                        }

                        .dropdown_li .dropbtn {
                            font-size: 13px;    
                            border: none;
                            outline: none;
                            color: #6d6d6d;
                            padding: 14px 16px;
                            background-color: inherit;
                            font-family: inherit;
                            margin: 0;
                        }

                        .navbar_li a:hover, .dropdown_li:hover .dropbtn {
                            background-color: ;
                        }

                        .dropdown-content_li {
                            display: none;
                            position: absolute;
                            background-color: #f9f9f9;
                            min-width: 160px;
                            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                            z-index: 1;
                        }

                        .dropdown-content_li a {
                            float: none;
                            color: black;
                            padding: 3px 16px;
                            text-decoration: none;
                            display: block;
                            text-align: left;
                        }

                        .dropdown-content_li a:hover {
                            background-color: #ddd;
                        }

                        .dropdown_li:hover .dropdown-content_li {
                            display: block;
                        }

                        .divider_li {
                          
                          margin: 9px 0;
                          overflow: hidden;
                          background-color: #e5e5e5;
                          display: block;
                          height: 1px;
                        }

                    </style>

                    <ul class="pull-right right-menu" style="top:13px">
                        <div class="navbar_li">
                          <div class="dropdown_li">
                            <button class="dropbtn"><?php echo $bio_fullname[0]->bio_fullname;?>
                              <i class="fa fa-caret-down"></i>
                            </button>
                            <div class="dropdown-content_li">
                              <a href="#" class="dropdown-divider">Available Fund</a>
                              <a href="#" class="dropdown-divider">Rp. <?php echo number_format(@$lender_fund[0]->amount,0,".",".");?></a>
                              <p class="divider_li"></p>
                              <a href="<?php echo site_url('Finance/F_lender/personal_info_lender') ?>">Personal Information</a>
                              <a href="<?php echo site_url('Finance/F_lender/withdrawal_lender') ?>">Withdrawal</a>
                              <a href="<?php echo site_url('Finance/F_lender/social_point_lender') ?>">Connect & Point</a>
                              <p class="divider_li"></p>
                              <a href="<?php echo site_url('Finance/F_login/signout') ?>">Logout</a>
                            </div>
                          </div> 
                        </div>

                    </ul> 
                   
                <div class="pull-right">
                    <button style="margin-top: -8px;" type="button" class="navbar-toggle">
                    <div class="sprites spritemobile"></div>
                    </button>
                </div>
            </nav>
        </div>
    </div>
     <style type="text/css">
        .active_li{
            background: #ffc516;
        }
        .active_link{
            background: #ffc516;
            color: black;
        }
        .active_link:hover{
            color:  white;
        }
        .deactive_link{
            background: #6d6d6d;
            color: white;
        }

        </style>

        <div class="hidden-xs hidden-sm" style="background: #6d6d6d !important; text-align: center; float: none; width: 100%; height: 60px; z-index: 9;padding-bottom: 15px;">
            <div style="margin: 0 auto; max-width: 62.5rem; width: 100%;">
                <div style="width: 100%; position: relative; padding-left: 0.9375rem;padding-right: 0.9375rem; float: none;">
                    <ul style="display: inline-block; padding: 10px 28px;">
                                                                                          
                        <li class="<?php echo @$autopurchase_active;?>" style="display: inline-block; padding: 10px 28px;">
                            <a class="<?php echo @$autopurchase_active;?>" href="<?php echo base_url('Finance/F_lender/autopurchase');?> " style="color:white;">Auto Invest</a></li>
                        <li class="<?php echo @$manually_active;?>" style="display: inline-block; padding: 10px 28px;">
                            <a class="<?php echo @$manually_active;?>" href="<?php echo base_url('Finance/F_lender/manually') ?>" style="color:white;">Manually</a></li>                      
                    </ul>
                </div>
            </div>
        </div>
</header>
        
        

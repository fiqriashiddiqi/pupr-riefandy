<!DOCTYPE html>
<html class="no-js">
<head lang="en">
    <title>Sanders - One Stop Solution</title>

    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="tags" content="">
    <meta name="description" content="">
    <meta name="keywords" content="pinjaman usaha, suku bunga">

    <meta name="language" content="en">
    
    <meta name="msapplication-TileImage" content="<?php echo base_url();?>uploads/base-img/favicon/mstile-144x144.png">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/Sanders/css/bootstrap.min.css">
    <link defer href="<?php echo base_url() ?>assets/Sanders/styles/style.css" rel="stylesheet">
    <link defer href="<?php echo base_url() ?>assets/Sanders/styles/main.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/LTE/plugins/font-awesome/css/font-awesome.min.css">

    <script src="<?php echo base_url() ?>assets/Sanders/js/jquery-2.2.3.min.js"></script>
    <script src="<?php echo base_url() ?>assets/Sanders/scripts/libs/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" charset="utf-8" defer src="<?php echo base_url() ?>assets/Sanders/scripts/libs/css_browser_selector.js"></script>
    <script type="text/javascript" charset="utf-8" defer data-main="../assets/Sanders/scripts/main" src="<?php echo base_url() ?>assets/Sanders/scripts/libs/require.js"></script>

    <!-- Favicons-->
    <link rel='shortcut icon' href='<?php echo base_url();?>uploads/base-img/favicon/favicon-32x32.png' type='image/x-icon'>
    <link rel="icon" href="<?php echo base_url();?>uploads/base-img/favicon/favicon-32x32.png" type='image/x-icon' sizes="32x32">
    <link rel="apple-touch-icon-precomposed" href="<?php echo base_url();?>uploads/base-img/favicon/apple-touch-icon-152x152.png">

</head>


<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style type="text/css">
    .success_pass {
    color: green;
}

.error_pass {
    color: red;
}
</style>
<div class="showcase" style="background-image:url('<?php echo base_url(); ?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
        <div class="container" style="padding-top: 10px;">

            <div class="row">
                <div class="hero loading">
                    
                    <ul class="bxslider">
                        <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                                # code...
                        ?>
                        <li>
                            <img src="<?php echo base_url(); ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%"/>
                            <div>
                                <br><br>
                                <h3><?php echo $slideshow_entry->slideshow_name;?></h3>
                                <p><small style="font-size:18px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

        </div>
</div>

<section class="container home">
    <div class="row" style="margin-bottom: 15px;">
        <div class="container div-feedback">
            <div class="row">

                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>

				<div class="col-md-3 col-sm-12 col-xs-12" >
					<div class=" form-group">
						<a style="color: <?php echo @$style_login;?>;" href="<?php echo site_url();?>Finance/F_login/login"><h1>Login</h1></a>
					</div>
					<div class=" form-group">
						<a style="color: <?php echo @$style_register;?>" href="<?php echo site_url();?>Finance/F_register_lender/register_1"><h1>Register</h1></a>
					</div>
				</div>

				<div class="col-md-9 col-sm-12 col-xs-12">
					<br>
                    <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
					<div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 1%; margin-bottom: 4%; border-left: 2px solid; border-right: 2px solid;  border-color: gray;">
                        <div class="form-group" >
                            <input type="hidden" name="code" value="<?php echo $code;?>" required="required">
                        </div>
                        <div class="form-group" >
                            <label> New Password </label>
                            <input type="Password" placeholder=" New Password " id="error_pass" oninput="check_password()" name="reg_password" class="form-control" required="required">
                            <p style="color: black;">* Password must contain alpha numericals, min 8 character</p>
                            <p id="error_password"></p>
                        </div>
                        <div class="form-group" >
                            <label> Verify Password </label>
                            <input type="Password" placeholder=" Verify Password " id="error_pass_valid" oninput="check_password()" name="reg_password_verify" class="form-control" required="required">
                            <p id="error_html"></p>
                        </div>
						<div class="from-grup" style="text-align: center;" >
							<button type="submit" class="btn btn-warning btn-sm btnwdt" id="next_button" style="width: 100px;">Change</button>
						</div>	
					</div>
                    </form>
					<div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 1%; border-color: gray;">
							<H4> Back To Login?</H4>
						<div class=" form-group" ">
							<a style="color: #06bbf1;" href="<?php echo site_url();?>Finance/F_login/login"><h4><u>Click here</u></h4></a>
							<p>  </p>
							<p>  </p>
						</div>
					</div>
				</div>
			</div>
		</div>		
	</div>
</section>

<script type="text/javascript">

    var error_pass = "";
    var error_pass_valid =""; 
    var pass_next;

    function validate_next(pass){

        // console.log(pass, email);
        if(pass==true){
            document.getElementById('next_button').disabled = false;
            $('#next_button').removeClass('btn-default');
            $('#next_button').addClass('btn-warning');
            document.getElementById('alert_next').style.display = 'block';
        }else{
            document.getElementById('next_button').disabled = true;
            $('#next_button').removeClass('btn-warning');
            $('#next_button').addClass('btn-default');
             document.getElementById('alert_next').style.display = 'none';
            
        }


      // check_password(function(isValid){
             
      //   if (validate_test(email) && isValid){
      //   }else{
      //   }
      // });
    }
    
     function check_password(error_pass,error_pass_valid) {
     var error_pass = $("#error_pass").val();
     var error_pass_valid = $("#error_pass_valid").val();
     var str = document.getElementById('error_pass').value;
     
     letter_number = false;
        
     if (error_pass == error_pass_valid) {
         $("#error_group").removeClass("has-error");
         $("#error_html").addClass('success_pass');
         $("#error_html").removeClass('error_pass');
         document.getElementById('error_html').innerHTML = 'your password match.';
         

     } else {
         $("#error_group").addClass("has-error");
         $("#error_html").addClass('error_pass');
         $("#error_html").removeClass('success_pass');
         document.getElementById('error_html').innerHTML = 'your password does not match !!';
         
     }

     if (error_pass.length < 8) {
        $("#error_password").show();
            $("#error_password").addClass('error_pass');
            document.getElementById('error_password').innerHTML = 'your password too short.';
            
            
     } else if (error_pass.length > 50) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password too long.';
        
        
     } else if (error_pass.search(/\d/) == -1) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password no number content.';
        
     } else if (error_pass.search(/[a-zA-Z]/) == -1) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password no letter content.';
        
     } else {
     $("#error_password").hide();
     letter_number = true;
    
     }
     if(error_pass == error_pass_valid&&letter_number==true){
        pass_next = true;
     }else{
        pass_next = false;
     }
     validate_next(pass_next);
  }
</script>
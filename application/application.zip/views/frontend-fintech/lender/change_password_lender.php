<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
.success_pass {
    color: green;
}

.error_pass {
    color: red;
}
</style>
<section class="container home" >
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback" >
		<div class="row" style="background-color: white; margin-bottom: 2%; padding: 20px;">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
            <?php } ?>
			<div class="col-md-3 col-sm-12 col-xs-12" >
				<div class=" form-group">
					
					<a style="color: <?php echo @$style_href;?>" href="<?php echo site_url('Finance/F_lender/personal_info_lender') ?>"><h3>Personal Information</h3></a>
				</div>
				<div class=" form-group">
					<a style="color: <?php echo @$style_href;?>" href="<?php echo site_url('Finance/F_lender/data_bank_lender') ?>"><h3>Change Bank Data</h3></a>
				</div>
				<div class=" form-group">
					<a style="color: orange;" href="<?php echo site_url('Finance/F_lender/change_password_lender') ?>"><h3>Change Password</h3></a>
				</div>		
				</div>
				<form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
				<div class="col-md-9 col-sm-12 col-xs-12" id="left2">
					<br>
							<div class="col-md-3 col-sm-12 col-xs-12">
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
							<div class=" form-group" >
								<input type="hidden" value="<?php echo $get_code; ?>" name="register_code"/>
								<label> Email</label>
								<input type="text" placeholder=" Email " name="register_email" value="<?php echo $data_code[0]->register_email; ?>" class=" form-control" readonly>
							</div>
							<div  class=" form-group">
								<label>Old Password</label>
								<input type="Password" placeholder=" Password " name="old_register_password" class=" form-control" required="required">
							</div>
							 <div class="form-group">
                                <label class="control-label">Password</label>
                                <input type="Password" id="error_pass" minlength="8" oninput="check_password()" placeholder="Password" name="new_register_password" class="form-control" required="required">
                                <p id="error_password"></p>
                              </div>
                              <div class="form-group" id="error_group">
                                 <label class="control-label">Re-enter Password</label>
                                 <input type="Password" id="error_pass_valid" minlength="8" oninput="check_password()" placeholder="Re-enter Password" name="new_register_re_password" class="form-control" required="required">
                                 <p id="error_html"></p>
                                 <p style="color: black;">* Password must contain alpha numericals, min 8 character</p>
                              </div>

							<div class="form-group" style="text-align: center">
								<!-- <button type="button" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; margin-top: 2%; background-color: orange; width: 30%; color: black;height: 25px;" ><b>Edit</b></button>	 -->
								<button type="submit" class="btn btn-warning btn-sm btnwdt" id="next_button" style="margin-bottom: 4%; margin-top: 2%; width: 30%; color: black;height: 25px;" ><b>Update</b></button>
							</div>
							</div>
							<div class="col-md-3 col-sm-12 col-xs-12">
							</div>

				</div>
			</form>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">

    var error_pass = "";
    var error_pass_valid =""; 
    var pass_next;

    function validate_next(pass){

        // console.log(pass, email);
        if(pass==true){
            document.getElementById('next_button').disabled = false;
            $('#next_button').removeClass('btn-default');
            $('#next_button').addClass('btn-warning');
            document.getElementById('alert_next').style.display = 'block';
        }else{
            document.getElementById('next_button').disabled = true;
            $('#next_button').removeClass('btn-warning');
            $('#next_button').addClass('btn-default');
             document.getElementById('alert_next').style.display = 'none';
            
        }


      // check_password(function(isValid){
             
      //   if (validate_test(email) && isValid){
      //   }else{
      //   }
      // });
    }
    
     function check_password(error_pass,error_pass_valid) {
     var error_pass = $("#error_pass").val();
     var error_pass_valid = $("#error_pass_valid").val();
     var str = document.getElementById('error_pass').value;
     
     letter_number = false;
        
     if (error_pass == error_pass_valid) {
         $("#error_group").removeClass("has-error");
         $("#error_html").addClass('success_pass');
         $("#error_html").removeClass('error_pass');
         document.getElementById('error_html').innerHTML = 'your password match.';
         

     } else {
         $("#error_group").addClass("has-error");
         $("#error_html").addClass('error_pass');
         $("#error_html").removeClass('success_pass');
         document.getElementById('error_html').innerHTML = 'your password does not match !!';
         
     }

     if (error_pass.length < 8) {
        $("#error_password").show();
            $("#error_password").addClass('error_pass');
            document.getElementById('error_password').innerHTML = 'your password too short.';
            
            
     } else if (error_pass.length > 50) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password too long.';
        
        
     } else if (error_pass.search(/\d/) == -1) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password no number content.';
        
     } else if (error_pass.search(/[a-zA-Z]/) == -1) {
        $("#error_password").show();
        $("#error_password").addClass('error_pass');
        document.getElementById('error_password').innerHTML = 'your password no letter content.';
        
     } else {
     $("#error_password").hide();
     letter_number = true;
    
     }
     if(error_pass == error_pass_valid&&letter_number==true){
        pass_next = true;
     }else{
        pass_next = false;
     }
     validate_next(pass_next);
  }
</script>
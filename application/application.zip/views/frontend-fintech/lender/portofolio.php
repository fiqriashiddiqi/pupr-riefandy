<?php 
                    if(@$data_loan != null){
                ?>
                

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <br>
                    <h4><strong>Punctuality</strong></h4>
                    <div style="overflow-x: auto;">
                        
                        <?php
                        $no=0;
                        $saldo = 0;
                        $penalt = 0;

                        

                        foreach ($data_loan as $loan_entry){
                            $data_loan_period = $this->account_model->get_data_loan_period($lend_code,$loan_entry->id_borrower_loan);

                        $data_setting = $this->crud_model->get_setting();
                        $comm_borrower   = $data_setting[0]->commision_borrower;

                        $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);
                        

                        $amount = @$amount_invest[0]->amount_invest;
                        $flat_rate = $loan_entry->loan_rate;
                        $total_interest = $loan_entry->loan_interest;
                        $total_principal = $loan_entry->loan_principal;
                        $total_loan = $loan_entry->loan_amount;

                        //var_dump($total_interest);
                        $a = ($amount / $loan_entry->loan_amount) * ($total_interest * ($comm_borrower/100));
                        $b = ($amount * ($flat_rate/100)) + $amount;

                        //var_dump($a);
                        // $estimated = $b - ($a * $loan_entry->loan_tenor);

                        $x = (($amount/$total_loan) * $total_interest);
                        $y =  $x * ($comm_borrower/100);
                        $fee_interest = $x;

                        $p = (($amount/$total_loan) * $total_principal);
                        $s = $p *($comm_borrower/100);
                        $fee_principal = $p;
                        $total_penalty = $this->account_model->get_sum_penalty_lender($lend_code,$loan_entry->id_borrower_loan);
                        $pen = @$total_penalty[0]->total_pinalty_lender;
                        $penalty = $pen *($comm_borrower/100);
                        $fee_penalty = $pen * ($amount/$total_loan);
                        
                        
                        

                        $commision = ($fee_interest + $fee_principal) * ($comm_borrower/100);
                        $x = ($fee_interest + $fee_principal - $commision) * $loan_entry->loan_tenor;
                        $tot_pip = $x + $fee_penalty + $penalty;
                        
                        // var_dump($penalty);
                        // var_dump($pen);
                        // var_dump($fee_penalty);
                        // var_dump($commision);
                        $total_realization = $this->account_model->get_pay_realization_sum($lend_code,$loan_entry->id_borrower_loan);

                        $tot_real = $total_realization[0]->total_realization - $commision;
                        $estimated = $x;
                        
                        $no++;
                         
                        ?>
                            <table class="table table-bordered">
                                <thead style="background-color:lightgray;">
                                    <tr>
                                        <th rowspan="2" style="vertical-align: middle;text-align: center;">Loan ID</th>
                                        <th rowspan="2" style="vertical-align: middle;text-align: center;">Amount</th>
                                        <th rowspan="2" style="vertical-align: middle;text-align: center;">Period</th>
                                        <th rowspan="2" style="vertical-align: middle;text-align: center;">Rating</th>
                                        <th style="text-align: center">Rate</th>
                                        <th rowspan="2" style="vertical-align: middle;text-align: center;">Payment Estimate</th>
                                        <th rowspan="2" style="vertical-align: middle;text-align: center;">Payment Realization</th>
                                        <th rowspan="2" style="vertical-align: middle;text-align: center;">Loan Status</th>
                                        <th rowspan="2" style="vertical-align: middle;text-align: center;">Loan Start</th>
                                        <?php 
                                            $loan_tenor = $loan_entry->loan_tenor;
                                            for($i=1;$loan_tenor>=$i;$i++){
                                            }
                                        ?>
                                        <th colspan="<?php echo $i; ?>" style="text-align: center"><?php if($loan_entry->loan_start_date != "0000-00-00"){echo "Pembayaran ke:";} else { echo "Pembayaran ke:";} ?></th>
                                    </tr>
                                    <tr>
                                        <th style="width:10%">(Effective & Flat)</th>
                                        <?php 
                                            for($q=1;$loan_tenor>=$q;$q++){
                                                echo "<th style='text-align: center'>$q</th>";
                                            }
                                            $this->load->model('Front_Fintech/account_model');
                                            $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);
                                            
                                        ?>
                                    </tr>
                                </thead>

                                <tbody style="background-color: #e9e9e9;">
                                    <tr>
                                        <td rowspan="2" style="text-align: center;"><?php echo $loan_entry->id_borrower_loan; ?></td>
                                        <td rowspan="2" style="text-align: center;">Rp. <?php echo number_format(@$amount_invest[0]->amount_invest,0,".","."); ?></td>
                                        <td rowspan="2" style="text-align: center;"><?php echo $loan_entry->loan_tenor; ?> months</td>
                                        <td rowspan="2" style="text-align: center;"><?php echo $loan_entry->loan_rating; ?></td>
                                        <td style="text-align: center;"><?php echo $loan_entry->loan_flat_rate; ?> %</td>
                                        
                                        <td rowspan="2" style="text-align: center;">Rp. <?php echo number_format($estimated,0,".","."); ?></td>
                                        <td rowspan="2" style="text-align: center;">Rp. <?php echo number_format($total_realization[0]->total_realization,0,".","."); ?></td>
                                        <td rowspan="2" style="text-align: center;"><?php echo $loan_entry->loan_status; ?></td>
                                        <td rowspan="2" style="text-align: center;">
                                        <?php if($loan_entry->loan_start_date != "0000-00-00"){echo date('d/m/y', strtotime($loan_entry->loan_start_date));} else { echo "Proses";} ?></td>


                                        <?php 
                                            // for($w=1;$loan_tenor>=$w;$w++){

                                                $data_loan_period = $this->account_model->get_data_loan_period($lend_code,$loan_entry->id_borrower_loan);
                                                

                                                    foreach ($data_loan_period as $period_entry){
                                                        if ($period_entry->payment_periode_status_principal AND $period_entry->payment_periode_status_interest == "default") {
                                                                $status_color = 'whitesmoke';
                                                                $font_color = 'black';    
                                                            } else if ($period_entry->payment_periode_status_principal AND $period_entry->payment_periode_status_interest == "On Time") {
                                                                $status_color = 'green';
                                                                $font_color = 'white';
                                                            } else if ($period_entry->payment_periode_status_principal AND $period_entry->payment_periode_status_interest == "Late, Not Yet Paid") {
                                                                $status_color = 'orange';
                                                                $font_color = 'white';
                                                            } else if ($period_entry->payment_periode_status_principal AND $period_entry->payment_periode_status_interest == "Late, Already Paid") {
                                                                $status_color = 'yellow';
                                                            } else{
                                                                $status_color = '';
                                                            }

                                                        
                                                ?>

                                               
                                                    <td rowspan="2" style="text-align: center;background-color: <?php echo @$status_color; ?>"></td>
                                                
                                                    
                                                <?php
                                                }
                                            
                                        ?>
                                    </tr>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $loan_entry->loan_rate; ?> %</td>
                                    </tr>
                                </tbody>
                            </table>
                            <?php 
                            }
                            
                        ?>
                    </div>
                </div> 

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <br><br>
                    <h4><strong>Principal and Interest Report (Expected and Actual)</strong></h4>
                    <div style="overflow-x: auto;">
                        <table class='table' border="1" style="text-align: center;">

                            <tr style="font-weight: bold; background-color: lightgray;">
                                <td rowspan="2" colspan="2" style="text-align: center; vertical-align: middle;width:200px;"> # </td>
                                <?php
                                    foreach ($data_loan as $loan_entry){
                                        echo "<td colspan='2' style='width:200px;'>".$loan_entry->id_borrower_loan."</td>";

                                    }
                                ?>
                                <td colspan="2" style="width:200px;">Total</td>
                            </tr>

                            <tr style="font-weight: bold; background-color: lightgray;">

                                <?php
                                    $loan_jml = 0;
                                    foreach ($data_loan as $loan_entry){
                                        echo "<td style='width:100px;'>Expected</td>";
                                        echo "<td style='width:100px;'>Actual</td>";
                                    $loan_jml++;
                                    }
                                ?>

                                <td style="width:100px;">Expected</td>
                                <td style="width:100px;">Actual</td>
                            </tr>

                            <?php
                            
                            $min_date = $this->account_model->get_loan_min_date($lend_code,$id_borrower_loan);
                            $max_date = $this->account_model->get_loan_max_date($lend_code,$id_borrower_loan);

                            $start = new DateTime($min_date[0]->min_date);
                            $end   = new DateTime($max_date[0]->max_date);

                            for($i = $start; $i <= $end; $i->modify('+1 months')){

                            ?>
                            <tr>
                                <td style="width: 80px; text-align: center; vertical-align: middle;  background-color: lightgray; font-weight: bold;" rowspan="5">
                                    <?php echo $i->format("Y")."<br>".$i->format("F");?>
                                </td>
                                <td style="background-color: lightgray; font-weight: bold; width: 100px;">Principal</td>

                                <?php 
                                    $total_principal_side = 0;
                                    $total_principal_side_actual = 0;
                                    foreach ($data_loan as $loan_entry){
                                        $months_now = $i->format("Y-m-d");
                                        $data_loan_period = $this->account_model->get_data_loan_period_month($lend_code,$loan_entry->id_borrower_loan,$months_now);

                                        $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);

                                        $amount = @$amount_invest[0]->amount_invest;

                                        foreach ($data_loan_period as $entry_periode) {

                                            $months_payment = date("Y-m",strtotime($entry_periode->payment_periode_date));
                                            if ($months_payment == $i->format("Y-m")){
                                            $principal = $entry_periode->payment_periode_principal;
                                            $interest = $entry_periode->payment_periode_interest;
                                            $pinalty = $entry_periode->payment_periode_pinalty;

                                            $proposional_prin = ($amount/$loan_entry->loan_amount) * ($principal);
                                            $proposional_intr = ($amount/$loan_entry->loan_amount) * ($interest);
                                            $proposional_pin = ($amount/$loan_entry->loan_amount) * ($pinalty);

                                            $total_principal_side = $total_principal_side + $proposional_prin;
                                ?>
                                            <td><?php echo number_format($proposional_prin,0,".",".");?></td>
                                <?php
                                                if($entry_periode->payment_periode_status_principal == 'On Time' OR $entry_periode->payment_periode_status_principal == 'Late, Already Paid'){
                                                    echo"<td>".number_format($proposional_prin,0,".",".")."</td>";

                                                    $total_principal_side_actual = $total_principal_side_actual + $proposional_prin;
                                                } else {
                                                    echo"<td>0</td>";
                                                }
                                            }                                          
                                        }

                                        if(empty($data_loan_period)){
                                            echo"<td>0</td><td>0</td>";
                                        }
                                    }
                                ?>

                                <td><?php echo number_format($total_principal_side,0,".",".");?></td>
                                <td><?php echo number_format($total_principal_side_actual,0,".",".");?></td>
                            </tr>
                            
                            <tr>
                                <td style="background-color: lightgray; font-weight: bold;">Interest</td>

                                <?php 
                                    $total_interest_side = 0;
                                    $total_interest_side_actual = 0;
                                    foreach ($data_loan as $loan_entry){
                                        $months_now = $i->format("Y-m-d");
                                        $data_loan_period = $this->account_model->get_data_loan_period_month($lend_code,$loan_entry->id_borrower_loan,$months_now);
                                        $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);

                                        $amount = @$amount_invest[0]->amount_invest;
                                        
                                        foreach ($data_loan_period as $entry_periode) {

                                            $months_payment = date("Y-m",strtotime($entry_periode->payment_periode_date));
                                            if ($months_payment == $i->format("Y-m")){
                                            $principal = $entry_periode->payment_periode_principal;
                                            $interest = $entry_periode->payment_periode_interest;
                                            $pinalty = $entry_periode->payment_periode_pinalty;

                                            $proposional_prin = ($amount/$loan_entry->loan_amount) * ($principal);
                                            $proposional_intr = ($amount/$loan_entry->loan_amount) * ($interest);
                                            $proposional_pin = ($amount/$loan_entry->loan_amount) * ($pinalty);

                                            $total_interest_side = $total_interest_side + $proposional_intr;
                                ?>
                                            <td><?php echo number_format($proposional_intr,0,".",".");?></td>
                                <?php
                                                if($entry_periode->payment_periode_status_interest == 'On Time' OR $entry_periode->payment_periode_status_interest == 'Late, Already Paid'){
                                                    echo"<td>".number_format($proposional_intr,0,".",".")."</td>";

                                                    $total_interest_side_actual = $total_interest_side_actual + $proposional_intr;
                                                } else {
                                                    echo"<td>0</td>";
                                                }
                                            }                                        
                                        }

                                        if(empty($data_loan_period)){
                                            echo"<td>0</td><td>0</td>";
                                        }
                                    }
                                ?>
                                
                                <td><?php echo number_format($total_interest_side,0,".",".");?></td>
                                <td><?php echo number_format($total_interest_side_actual,0,".",".");?></td>
                            </tr>

                            <tr>
                                <td style="background-color: lightgray; font-weight: bold;">Penalty</td>

                                <?php 
                                    $total_pinalty_side = 0;
                                    $total_pinalty_side_actual = 0;
                                    foreach ($data_loan as $loan_entry){
                                        $months_now = $i->format("Y-m-d");
                                        $data_loan_period = $this->account_model->get_data_loan_period_month($lend_code,$loan_entry->id_borrower_loan,$months_now);
                                        $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);

                                        $amount = @$amount_invest[0]->amount_invest;

                                        foreach ($data_loan_period as $entry_periode) {

                                            $months_payment = date("Y-m",strtotime($entry_periode->payment_periode_date));
                                            if ($months_payment == $i->format("Y-m")){
                                            $principal = $entry_periode->payment_periode_principal;
                                            $interest = $entry_periode->payment_periode_interest;
                                            $pinalty = $entry_periode->payment_periode_pinalty;

                                            $proposional_prin = ($amount/$loan_entry->loan_amount) * ($principal);
                                            $proposional_intr = ($amount/$loan_entry->loan_amount) * ($interest);
                                            $proposional_pin = ($amount/$loan_entry->loan_amount) * ($pinalty);

                                            $total_pinalty_side = $total_pinalty_side + $proposional_pin;
                                ?>
                                            <td><?php echo number_format(0,0,".",".");?></td>
                                <?php
                                                if($entry_periode->payment_periode_status_pinalty == 'On Time' OR $entry_periode->payment_periode_status_pinalty == 'Late, Already Paid'){
                                                    echo"<td>".number_format($proposional_pin,0,".",".")."</td>";

                                                    $total_pinalty_side_actual = $total_pinalty_side_actual + $proposional_pin;
                                                } else {
                                                    echo"<td>0</td>";
                                                }
                                            }                                          
                                        }

                                        if(empty($data_loan_period)){
                                            echo"<td>0</td><td>0</td>";
                                        }
                                    }
                                ?>

                                <td><?php echo number_format(0,0,".",".");?></td>
                                <td><?php echo number_format($total_pinalty_side_actual,0,".",".");?></td>
                            </tr>

                            <tr>
                                <td style="background-color: lightgray; font-weight: bold;">(Commision)</td>

                                <?php 
                                    $total_commision_side = 0;
                                    $total_commision_side_actual = 0;
                                    foreach ($data_loan as $loan_entry){
                                        $months_now = $i->format("Y-m-d");
                                        $data_loan_period = $this->account_model->get_data_loan_period_month($lend_code,$loan_entry->id_borrower_loan,$months_now);
                                        $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);

                                        $amount = @$amount_invest[0]->amount_invest;

                                        foreach ($data_loan_period as $entry_periode) {

                                            $months_payment = date("Y-m",strtotime($entry_periode->payment_periode_date));
                                            if ($months_payment == $i->format("Y-m")){
                                            $principal = $entry_periode->payment_periode_principal;
                                            $interest = $entry_periode->payment_periode_interest;
                                            $pinalty = $entry_periode->payment_periode_pinalty;

                                            $proposional_prin = ($amount/$loan_entry->loan_amount) * ($principal);
                                            $proposional_intr = ($amount/$loan_entry->loan_amount) * ($interest);
                                            $proposional_pin = ($amount/$loan_entry->loan_amount) * ($pinalty);

                                            $data_setting = $this->crud_model->get_setting();
                                            $comm_borrower   = $data_setting[0]->commision_borrower;

                                            //$commision =  ($proposional_prin + $proposional_intr + $proposional_pin) * ($comm_borrower/100);

                                            $commision_ex =  ($proposional_prin + $proposional_intr) * ($comm_borrower/100);
                                            $commision =  ($proposional_prin + $proposional_intr + $proposional_pin) * ($comm_borrower/100);
                                            $total_ex = ($proposional_prin + $proposional_intr) - $commision_ex;
                                            $total = ($proposional_prin + $proposional_intr + $proposional_pin) - $commision;

                                            $total_commision_side = $total_commision_side + $commision_ex;
                                ?>
                                            <td><?php echo number_format($commision_ex,0,".",".");?></td>
                                <?php
                                                if($entry_periode->payment_periode_status_interest == 'On Time' OR $entry_periode->payment_periode_status_interest == 'Late, Already Paid'){
                                                    echo"<td>".number_format($commision,0,".",".")."</td>";

                                                    $total_commision_side_actual = $total_commision_side_actual + $commision;
                                                } else {
                                                    echo"<td>0</td>";
                                                }
                                            }                                          
                                        }

                                        if(empty($data_loan_period)){
                                            echo"<td>0</td><td>0</td>";
                                        }
                                    }
                                ?>
                                
                                <td><?php echo number_format($total_commision_side,0,".",".");?></td>
                                <td><?php echo number_format($total_commision_side_actual,0,".",".");?></td>
                            </tr>

                            <tr style="font-weight: bold;">
                                <td style="background-color: lightgray; font-weight: bold;">TOTAL</td>

                                <?php 
                                    $total_side = 0;
                                    $total_side_actual = 0;
                                    foreach ($data_loan as $loan_entry){
                                        $months_now = $i->format("Y-m-d");
                                        $data_loan_period = $this->account_model->get_data_loan_period_month($lend_code,$loan_entry->id_borrower_loan,$months_now);
                                        $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);

                                        $amount = @$amount_invest[0]->amount_invest;

                                        foreach ($data_loan_period as $entry_periode) {

                                            $months_payment = date("Y-m",strtotime($entry_periode->payment_periode_date));
                                            if ($months_payment == $i->format("Y-m")){

                                            $principal = $entry_periode->payment_periode_principal;
                                            $interest = $entry_periode->payment_periode_interest;
                                            $pinalty = $entry_periode->payment_periode_pinalty;

                                            if($entry_periode->payment_periode_status_principal == 'On Time' OR $entry_periode->payment_periode_status_principal == 'Late, Already Paid'){
                                                
                                                $proposional_prin_flex = ($amount/$loan_entry->loan_amount) * ($principal);
                                            } else {
                                                $proposional_prin_flex = 0;
                                            }

                                            $proposional_prin = ($amount/$loan_entry->loan_amount) * ($principal);
                                            $proposional_intr = ($amount/$loan_entry->loan_amount) * ($interest);
                                            $proposional_pin = ($amount/$loan_entry->loan_amount) * ($pinalty);

                                            $data_setting = $this->crud_model->get_setting();
                                            $comm_borrower   = $data_setting[0]->commision_borrower;

                                            $commision_ex =  ($proposional_prin + $proposional_intr) * ($comm_borrower/100);
                                            $commision =  ($proposional_prin + $proposional_intr + $proposional_pin) * ($comm_borrower/100);
                                            $total_ex = ($proposional_prin + $proposional_intr ) - $commision_ex;
                                            $total = ($proposional_prin_flex + $proposional_intr + $proposional_pin) - $commision;

                                            $total_side = $total_side + $total_ex;
                                ?>
                                            <td style='background-color: #e9e9e9;'><?php echo number_format($total_ex,0,".",".");?></td>
                                <?php
                                                if($entry_periode->payment_periode_status_interest == 'On Time' OR $entry_periode->payment_periode_status_interest == 'Late, Already Paid'){
                                                    echo"<td style='background-color: #e9e9e9;'>".number_format($total,0,".",".")."</td>";

                                                    $total_side_actual = $total_side_actual + $total;
                                                } else {
                                                    echo"<td style='background-color: #e9e9e9;'>0</td>";
                                                }
                                            }                                          
                                        }

                                        if(empty($data_loan_period)){
                                            echo"<td style='background-color: #e9e9e9;'>0</td><td style='background-color: #e9e9e9;'>0</td>";
                                        }
                                    }
                                ?>
                                
                                <td style='background-color: #e9e9e9;'><?php echo number_format($total_side,0,".",".");?></td>
                                <td style='background-color: #e9e9e9;'><?php echo number_format($total_side_actual,0,".",".");?></td>
                            </tr>
                            <?php
                                }
                            ?>
                            <tr style="font-weight: bold;">
                                <td colspan="2" style="background-color: lightgray; font-weight: bold;">GRAND TOTAL</td>

                                <?php 
                                    $grand_total_side = 0;
                                    $grand_total_side_actual = 0;
                                    foreach ($data_loan as $loan_entry){
                                        $data_loan_period = $this->account_model->get_data_loan_period($lend_code,$loan_entry->id_borrower_loan);
                                        $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);

                                        $amount = @$amount_invest[0]->amount_invest;

                                        $total_down_per_loan_ex = 0;
                                        $total_down_per_loan = 0;
                                        foreach ($data_loan_period as $entry_periode) {

                                            $principal = $entry_periode->payment_periode_principal;
                                            $interest = $entry_periode->payment_periode_interest;
                                            $pinalty = $entry_periode->payment_periode_pinalty;

                                            if($entry_periode->payment_periode_status_principal == 'On Time' OR $entry_periode->payment_periode_status_principal == 'Late, Already Paid'){
                                                
                                                $proposional_prin_flex = ($amount/$loan_entry->loan_amount) * ($principal);
                                            } else {
                                                $proposional_prin_flex = 0;
                                            }

                                            $proposional_prin = ($amount/$loan_entry->loan_amount) * ($principal);
                                            $proposional_intr = ($amount/$loan_entry->loan_amount) * ($interest);
                                            $proposional_pin = ($amount/$loan_entry->loan_amount) * ($pinalty);

                                            $data_setting = $this->crud_model->get_setting();
                                            $comm_borrower   = $data_setting[0]->commision_borrower;

                                            $commision_ex =  ($proposional_prin + $proposional_intr) * ($comm_borrower/100);
                                            $commision =  ($proposional_prin + $proposional_intr + $proposional_pin) * ($comm_borrower/100);
                                            $total_ex = ($proposional_prin + $proposional_intr) - $commision_ex;

                                            $total = ($proposional_prin_flex + $proposional_intr + $proposional_pin) - $commision;



                                            $grand_total_side = $grand_total_side + $total_ex;
                                            $total_down_per_loan_ex = $total_down_per_loan_ex + $total_ex;

                                            if($entry_periode->payment_periode_status_interest == 'On Time' OR $entry_periode->payment_periode_status_interest == 'Late, Already Paid'){
                                                
                                                $grand_total_side_actual = $grand_total_side_actual + $total;
                                                $total_down_per_loan = $total_down_per_loan + $total;
                                            } 
                                        }

                                        echo"<td style='background-color: lightgray;'>".number_format($total_down_per_loan_ex,0,".",".")."</td>";
                                        echo"<td style='background-color: lightgray;'>".number_format(@$total_down_per_loan,0,".",".")."</td>";                                     
                                    }
                                ?>
                                
                                <td style='background-color: lightgray;'><?php echo number_format($grand_total_side,0,".",".");?></td>
                                <td style='background-color: lightgray;'><?php echo number_format(@$grand_total_side_actual,0,".",".");?></td>
                            </tr>
                            
                        </table>
                    </div>
                </div>
                <?php 
                }   
                ?>
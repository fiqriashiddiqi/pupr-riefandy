<?php date_default_timezone_set("Asia/Jakarta"); ?>
<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; margin-bottom: 2%; padding: 20px;">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
                <?php } ?>
                <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="form-group">
                    <a style="color:orange;" href="<?php echo site_url('Finance/F_lender/personal_info_lender') ?>"><h3>Personal Information</h3></a>
                </div>
                <div class="form-group">
                        <a style="color: <?php echo @$style_href;?>" href="<?php echo site_url('Finance/F_lender/data_bank_lender') ?>">
                            <h3>Change Bank Data</h3>
                        </a>
                    </div>
                    <div class="form-group">
                    <a style="color: <?php echo @$style_href;?>" href="
                        <?php echo site_url('Finance/F_lender/change_password_lender') ?>">
                        <h3>Change Password</h3>
                        </a>
                    </div>
                </div>

                <div class="col-md-4 col-sm-12 col-xs-12" id="left3"> 
                    <br>
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_fullname; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Birth Place</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_place_birth_date; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Birthdate</label>
                        <input type="date" value="<?php echo $data_code[0]->bio_birth_date; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Gender</label>
                        <select class="form-control" style="width: 100%;" disabled>
                            <?php   if ($data_code[0]->bio_gender == 'Male') {
                                                $Male  = 'selected';
                                            } else if ($data_code[0]->bio_gender == 'Female') {
                                                $Female = 'selected';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?> >- Choose Statement -</option>
                              <option value="Male" <?php echo @$Male;?> >Male</option>
                              <option value="Female" <?php echo @$Female;?> >Female</option>          
                           </select>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_phone; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" style="width: 100%;" disabled>
                                    <?php   
                                        if ($data_code[0]->bio_marriage_status == 'Married') {
                                                $Married  = 'selected';
                                            } else if ($data_code[0]->bio_marriage_status == 'Single') {
                                                $Single = 'selected';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                              <option value="Married" <?php echo @$Married;?>>Married</option>
                              <option value="Single" <?php echo @$Single;?>>Single</option>  
                           
                           </select>
                    </div>
                    <?php
                    if ($data_code[0]->bio_marriage_status == 'Married'){
                    ?>
                    <div class="form-group">
                        <label>Spouse Name</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_spouse_name; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Spouse Phone</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_spouse_phone; ?>" class="form-control" readonly>
                    </div>
                    <?php
                    }
                    ?>
                    <div class="form-group">
                        <label>Last Education</label>
                        <select class="form-control" style="width: 100%;" disabled>
                                    <?php   
                                        if ($data_code[0]->bio_last_education == 'SMP') {
                                                $SMP  = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'SMA') {
                                                $SMA = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'D3') {
                                                $D3 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S1') {
                                                $S1 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S2') {
                                                $S2 = 'selected';
                                            } else if ($data_code[0]->bio_last_education == 'S3') {
                                                $S3 = 'selected';
                                            } else {
                                                $default  = 'selected';
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?>>- Choose Statement -</option>
                              <option value="SMP"<?php echo @$SMP;?>>SMP</option>
                              <option value="SMA"<?php echo @$SMA;?>>SMA</option>
                              <option value="D3" <?php echo @$D3;?>>D3</option>
                              <option value="S1" <?php echo @$S1;?>>S1</option>
                              <option value="S2" <?php echo @$S2;?>>S2</option>
                              <option value="S3" <?php echo @$S3;?>>S3</option>
                                           
                             </select>
                    </div>
                    <div class="form-group">
                        <label>Occupation</label>
                        <select class="form-control" disabled>
                                    <?php   
                                        if ($data_code[0]->bio_occupation == 'Wiraswasta') {
                                                $Wiraswasta  = 'selected';
                                            } else if ($data_code[0]->bio_occupation == 'Karyawan Swasta') {
                                                $Karyawan  = 'selected';
                                                $display = "none";
                                            } else if ($data_code[0]->bio_occupation == 'Pegawai Negeri Sipil') {
                                                $PNS = 'selected';
                                                $display = "none";
                                            } else if ($data_code[0]->bio_occupation == 'TNI/POLRI') {
                                                $TNI_POLRI = 'selected';
                                                $display = "none";
                                            }else if ($data_code[0]->bio_occupation == 'Pensiunan') {
                                                $Pensiunan = 'selected';
                                                $display = "none";
                                            }else if ($data_code[0]->bio_occupation == '') {
                                                $default  = 'selected';
                                                $display = "none";
                                            }else {
                                                $Others = 'selected';
                                                $display = "block";
                                            }
                                    ?>
                              <option value="" <?php echo @$default;?>>- Choose Occupation -</option>
                              <option value="Wiraswasta" <?php echo @$Wiraswasta;?>>Wiraswasta</option>
                              <option value="Karyawan Swasta"<?php echo @$Karyawan;?> >Karyawan Swasta</option>
                              <option value="Pegawai Negeri Sipil"<?php echo @$PNS;?> >Pegawai Negeri Sipil</option>
                              <option value="TNI/POLRI" <?php echo @$TNI_POLRI;?>>TNI/POLRI</option>
                              <option value="Pensiunan" <?php echo @$Pensiunan;?>>Pensiunan</option>
                              <option value="Others" <?php echo @$Others;?>>Others</option>
                          </select>
                        
                    </div>
                    <div class="form-group">
                        <input class="form-control select2" name="bio_occupation_others" value="<?php echo $data_code[0]->bio_occupation; ?>" placeholder="Write your Statement" type="text" id="dummyText" style="display: <?php echo @$display ?>;" disabled>
                    </div>
                    <div class="form-group">
                        <label>Reference Code</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_reference_code; ?>" class="form-control" readonly>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <br>
                    <div class="form-group">
                        <label>Citizenship</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_cityzenship; ?>" class="form-control" readonly>
                    </div>

                    <?php 
                    if($data_code[0]->bio_cityzenship == "WNI"){
                    ?>
                    <div class="form-group">
                        <label>KTP / NIK</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_nik; ?>" class="form-control" readonly>
                        <br>
                     
                         <img id="ktp_lender" src="<?php echo base_url();?>uploads/Fintech/ktp_lender/<?php echo @$data_code[0]->bio_upload_nik;?>" style="width: 100%; height: 150px; border: 1px solid;">
                      
                    </div>
                    <div class="form-group hidden">
                        <label>Country / State</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_country; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Province</label>
                        <input type="text" value="<?php echo $data_province[0]->nama; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" value="<?php echo $data_city[0]->nama; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>District</label>
                        <input type="text" value="<?php echo $data_district[0]->nama; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Village</label>
                        <input type="text" value="<?php echo $data_village[0]->nama; ?>" class="form-control" readonly>
                    </div>
                    <?php 
                    } else {
                    ?>
                    <div class="form-group">
                        <label>Passport Number</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_passport; ?>" class="form-control" readonly>
                        <br>
                        <?php 
                            if($data_code[0]->bio_upload_passport == "-"){
                                $passport_lender = "noimage.jpg";
                            } else {
                                $passport_lender = $data_code[0]->bio_upload_passport;
                            }
                        ?>
                        <img src="<?php echo base_url();?>uploads/Fintech/passport_lender/<?php echo $passport_lender; ?>" style="width: 100%; height: 150px; border: 1px solid;">

                    </div>
                    <div class="form-group">
                        <label>Country / State</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_country; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Province</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_province; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_city; ?>" class="form-control" readonly>
                    </div>
                    <?php 
                    }
                    ?>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <textarea rows="3" value="" class="form-control" readonly><?php echo $data_code[0]->bio_address; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Post Code</label>
                        <input type="text" value="<?php echo $data_code[0]->bio_post_code; ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group" style="text-align: center">
                        <a href="<?php echo $edit_url;?>" class="btn btn-warning btn-sm btn-block" style="background-color: orange;  color: black;">Edit</a>
                    </div>        
                </div>
            </div>
        </div>
    </div>

</section>
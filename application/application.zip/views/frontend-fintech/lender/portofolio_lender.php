<?php date_default_timezone_set("Asia/Jakarta"); 
$this->load->model('Front_Fintech/account_model');
$this->load->model('Front_Fintech/portofolio_model');
$this->load->model("crud_model");
?>
<?php 
$rating_ap = $this->portofolio_model->get_rating($lend_code,'A+');
$rating_a = $this->portofolio_model->get_rating($lend_code,'A');
$rating_bp = $this->portofolio_model->get_rating($lend_code,'B+');
$rating_b = $this->portofolio_model->get_rating($lend_code,'B');
$rating_cp = $this->portofolio_model->get_rating($lend_code,'C+');
$rating_c = $this->portofolio_model->get_rating($lend_code,'C');
$rating_dp = $this->portofolio_model->get_rating($lend_code,'D+');
$rating_d = $this->portofolio_model->get_rating($lend_code,'D');

$type_consumptive = $this->portofolio_model->get_loan_type($lend_code,'Personal Loan');
$type_commercial_fix = $this->portofolio_model->get_loan_type($lend_code,'Fixed Loan');
$type_commercial_flex = $this->portofolio_model->get_loan_type($lend_code,'Flexible Loan');
$a = $type_commercial_fix[0]->total_type;
$b = $type_commercial_flex[0]->total_type;
$commer = $a + $b;
        
?>
<script type="text/javascript" src="<?php echo base_url();?>assets/Sanders/js/amcharts.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/pie.js"></script>

<style>
    .tool_tip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }
    
    .tool_tip .tool_tiptext {
        visibility: hidden;
        width: 180px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 0px;
        padding: 5px 0;
    
        /* Position the tool_tip */
        position: absolute;
        z-index: 1;
    }
    
    .tool_tip:hover .tool_tiptext {
        visibility: visible;
    }
</style>
<style>
    .dropbtn {
        background-color: whitesmoke;
        color: black;
        padding: 6px;
        font-size: 16px;
        border: none;
        cursor: pointer;
    }

    .dropbtn:hover, .dropbtn:focus {
        background-color: #ccc;
    }

    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f1f1f1;
        min-width: 160px;
        overflow: auto;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown a:hover {background-color: #ddd}

    .show {display:block;}
</style>
<!-- amCharts javascript code -->
<script type="text/javascript">
    AmCharts.makeChart("chartdiv",
        {
            "type": "pie",
            "balloonText": "[[category]]([[value]])<br></span>",
            "gradientType": "linear",
            "labelRadius": 0,
            "labelText": "",
            "titleField": "category",
            "valueField": "column-1",
            "colorField": "color",
            "labelColorField": "color",
            "theme": "default",
            "allLabels": [],
            "balloon": {},
            "legend": {
                "enabled": true,
                "accessibleLabel": "",
                "align": "center",
                "equalWidths": false,
                "markerSize": 22,
                "valueText": ""
            },
            "titles": [],
            "dataProvider": [
                {
                    "category": "A+",
                    "column-1": "<?php echo $rating_ap[0]->total_rating ;?>",
                    "color" : "#0D8ECF"
                },
                {
                    "category": "A",
                    "column-1": "<?php echo $rating_a[0]->total_rating ;?>",
                    "color" : "#04D215"
                },
                {
                    "category": "B+",
                    "column-1": "<?php echo $rating_bp[0]->total_rating ;?>",
                    "color" : "#B0DE09"
                },
                {
                    "category": "B",
                    "column-1": "<?php echo $rating_b[0]->total_rating ;?>",
                    "color" : "#F8FF01"
                },
                {
                    "category": "C+",
                    "column-1": "<?php echo $rating_cp[0]->total_rating ;?>",
                    "color" : "#FCD202"
                },
                {
                    "category": "C",
                    "column-1": "<?php echo $rating_c[0]->total_rating ;?>",
                    "color" : "#FF9E01"
                },
                {
                    "category": "D+",
                    "column-1": "<?php echo $rating_dp[0]->total_rating ;?>",
                    "color" : "#FF6600"
                },
                {
                    "category": "D",
                    "column-1": "<?php echo $rating_d[0]->total_rating ;?>",
                    "color" : "#FF0F00"
                }
            ]
        }
    );
    

    AmCharts.makeChart("chartdiv1",
        {
            "type": "pie",
            "balloonText": "[[title]]<br></span>",
            "gradientType": "linear",
            "labelRadius": 0,
            "labelText": "",
            "titleField": "category",
            "valueField": "column-1",
            "theme": "default",
            "colorField": "color",
            "labelColorField": "color",
            "allLabels": [],
            "balloon": {

            },
            "legend": {
                "enabled": true,
                "accessibleLabel": "",
                "align": "right",
                "position":"right",
                "equalWidths": false,
                "markerSize": 20,
                "valueText": ""
            },
            "titles": [],
            "dataProvider": [
                {
                    "category": "Personal(<?php echo $type_consumptive[0]->total_type;?>)",
                    "column-1": "<?php echo $type_consumptive[0]->total_type;?>",
                    "color" : "#0D8ECF"
                },
                {
                    "category": "Commercial(<?php echo $commer;?>)",
                    "column-1": "<?php echo $commer;?>",
                    "color" : "#04D215"
                }
                
            ]
        }
    );

    AmCharts.makeChart("chartdiv2",
        {
            "type": "pie",
            "balloonText": "[[title]]<br></span>",
            "gradientType": "linear",
            "labelRadius": 0,
            "labelText": "",
            "titleField": "category",
            "valueField": "column-1",
            "theme": "default",
            "colorField": "color",
            "labelColorField": "color",
            "allLabels": [],
            "balloon": {},
            "legend": {
                "enabled": true,
                "accessibleLabel": "",
                "align": "right",
                "position":"right",
                "equalWidths": false,
                "markerSize": 20,
                "valueText": ""
            },
            "titles": [],
            "dataProvider": [
                {
                    "category": "Personal Loan(<?php echo $type_consumptive[0]->total_type ;?>)",
                    "column-1": "<?php echo $type_consumptive[0]->total_type ;?>",
                    "color" : "#0D8ECF"
                },
                {
                    "category": "Fixed Loan(<?php echo $type_commercial_fix[0]->total_type ;?>)",
                    "column-1": "<?php echo $type_commercial_fix[0]->total_type ;?>",
                    "color" : "#04D215"
                },
                {
                    "category": "Flexible Loan(<?php echo $type_commercial_flex[0]->total_type ;?>)",
                    "column-1": "<?php echo $type_commercial_flex[0]->total_type ;?>",
                    "color" : "#B0DE09"
                }
                
            ]
        }
    );

    // AmCharts.makeChart("chartdiv3",
    //     {
    //         "type": "pie",
    //         "balloonText": "[[title]]<br></span>",
    //         "gradientType": "linear",
    //         "labelRadius": 0,
    //         "labelText": "",
    //         "titleField": "category",
    //         "valueField": "column-1",
    //         "theme": "default",
    //         "allLabels": [],
    //         "balloon": {},
    //         "legend": {
    //             "enabled": true,
    //             "accessibleLabel": "",
    //             "align": "right",
    //             "position":"right",
    //             "equalWidths": false,
    //             "markerSize": 15,
    //             "valueText": ""
    //         },
    //         "titles": [],
    //         "dataProvider": [
    //             {
    //                 "category": "Education",
    //                 "column-1": "1"
    //             },
    //             {
    //                 "category": "Health",
    //                 "column-1": "1"
    //             }
                
    //         ]
    //     }
    // );
</script>

<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row" style="background-color: white; padding: 20px;">

                <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 2%;">
                    <div class="col-md-6 col-sm-12 col-xs-12" style="text-align: right" ;>
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="form-group" style="text-align: right;">
                            <label>Average Rate</label>

                            <?php 

                            $tot_invest = $this->account_model->get_invest_by_id_nreg($lend_code,@$data_loan[0]->id_borrower_loan);
                            $total_inv = @$total_funding[0]->total_funding;
                            $avg_rate=0;
                            foreach($data_loan as $loan_entry){
                                $flat_rate = $loan_entry->loan_rate;
                                $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);

                                $amount = @$amount_invest[0]->amount_invest;

                                $a = $flat_rate * ($amount/$total_inv);
                                $avg_rate = $avg_rate + $a;
                                
                                
                            }
                            

                            ?>
                            <input type="text" class="form-horizontal" value="<?php echo number_format($avg_rate,2); ?> %" placeholder="" style="width: 80px; text-align: center; color: black;" disabled>

                        </div>
                    </div>



                </div>

                <div class="col-md-6 col-sm-12 col-xs-12">


                    <?php
                            $total_invest = @$total_invest[0]->total_invest;
                            $total_reserve = @$total_reserved[0]->total_reserved;
                            $total_funding = @$total_funding[0]->total_funding;
                            $available_fund = @$lender_fund[0]->amount;

                            $total_value = $total_invest + $total_reserve + $available_fund;

                            $number_loan = $this->portofolio_model->get_count_loan($lend_code,@$data_loan[0]->id_borrower_loan);
                            $number_going_loan = @$number_loan[0]->total_loan;
                            // echo "<pre>";
                            // var_dump($number_going_loan);
                        ?>
                        <div class="form-group">
                            <label style="text-align: left;">Total Funding (Total Invested)</label><a href="#" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                            <input type="text" class="form-control" value="Rp. <?php echo number_format($total_funding,0,".","."); ?>" placeholder="" disabled>
                        </div>
                        <div class="form-group">
                            <label style="text-align: left;">Disbursed (Total Invested)</label><a href="#" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                            <input type="text" class="form-control" value="Rp. <?php echo number_format($total_invest,0,".","."); ?>" placeholder="" disabled>
                        </div>
                        <div class="form-group">
                            <label style="text-align: left;">Not yet disbursed (Reserve Fund)</label><a href="#" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                            <input type="text" class="form-control" value="Rp. <?php echo number_format($total_reserve,0,".","."); ?>" placeholder="" disabled>
                        </div>
                        <div class="form-group">
                            <label style="text-align: left;">Number of ongoing loan</label><a href="#" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
                            <input type="text" class="form-control" value="<?php echo number_format($number_going_loan,0,".","."); ?>" placeholder="" disabled>
                        </div>
                        <div class="form-group">
                            <label style="text-align: left;">Interest payment this month (estimated)</label><a href="#" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>

                            <?php 
                            $id_borrower_loan = isset($_REQUEST['id_borrower_loan']) ? $_REQUEST['id_borrower_loan'] : null;
                            $date = date('Y-m-d');
                            $jumlah = 0;
                            $jumlah_interest = 0;
                            foreach ($data_loan as $loan_entry){

                            
                            $data_loan_period = $this->account_model->get_data_loan_period($lend_code,$loan_entry->id_borrower_loan);
                            foreach ($data_loan_period as $loan_period_test) {
                                $data_setting = $this->crud_model->get_setting();
                                $comm_borrower   = $data_setting[0]->commision_borrower;

                                $amount_invest = $this->account_model->get_invest_by_id_nreg($lend_code,$loan_entry->id_borrower_loan);

                                $amount = @$amount_invest[0]->amount_invest;
                                // $flat_rate = $loan_entry->loan_rate;
                                $total_interest = $loan_period_test->payment_periode_interest;
                                $jumlah_interest = $jumlah_interest + $total_interest;
                                
                                $a = (($amount / $loan_entry->loan_amount) * $total_interest );
                                $b = ($a * ($comm_borrower/100));
                                $c = $a - $b;


                                if (date('Y m',strtotime(@$loan_period_test->payment_periode_date)) == date('Y m',strtotime($date)) AND $loan_period_test->payment_periode_status_interest == "default" ) {

                               $jumlah = $jumlah + $a;
                                
                             }
                            }
                             
                            
                            }

                            // var_dump($b);
                            ?>
                            <input type="text" class="form-control" value="Rp. <?php echo number_format($jumlah,0,".","."); ?>" placeholder="" disabled>
                            
                        </div>
                </div>

                <div class="col-md-3 col-sm-12 col-xs-12">

                    <div class="form-group" >
                        <div id="chartdiv" style="border: 1px solid;height: 331px; width: 100%;"></div>
                    </div>

                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">

                    <div class="form-group">
                        <div id="chartdiv1" style="border: 1px solid;height: 157px; width: 100%;"></div>
                    </div>
                    <div class="form-group">
                        <div id="chartdiv2" style="border: 1px solid;height: 157px; width: 100%;"></div>
                    </div>
                    <!-- <div class="form-group">
                        <div id="chartdiv3" style="border: 1px solid;height: 100px; width: 100%;"></div>
                    </div> -->

                </div>


                <div class="col-md-12 col-sm-12 col-xs-12">
                    <HR style="display: block; border-width: 2px; border-color: gray;">
                </div>

                <?php 
                    if(@$data_loan != null){
                ?>

                <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px">
                    
                    <div class="form-group">
                        
                        <div class="col-sm-6 " style="margin-bottom: 20px;">
                            <label class="control-label">Sort by:</label>
                            
                            <div class="">
                                
                                  <form>
                                  <select class="form-control select2" name="id_borrower_loan" id="id_borrower_loan" style="width: 150px ; ">
                                        <option value="all">ID Borrower Loan</option>
                                        <?php foreach ($data_loan as $loan_entry) { ?>
                                            <option value="<?php echo $loan_entry->id_borrower_loan;?>"><?php echo $loan_entry->id_borrower_loan;?></option>
                                        <?php } ?>
                                        
                                                     
                                  </select>
                                  </form>

                            </div>
                        </div>
                        <div class="col-sm-3">
                            <i class="fa fa-circle" style="font-size: 18px;color: green;"></i>
                            <label class="control-label">On time</label>
                        </div>
                        <div class="col-sm-3" >
                            <i class="fa fa-circle" style="font-size: 18px;color: yellow;"></i>
                            <label class="control-label">Late, already paid</label>
                        </div>
                        <div class="col-sm-3">
                            <i class="fa fa-circle" style="font-size: 18px;color: orange;"></i>
                            <label class="control-label">Late, not yet paid</label>
                        </div>
                        <div class="col-sm-3">
                            <i class="fa fa-circle" style="font-size: 18px;color: red;"></i>
                            <label class="control-label">Default</label>
                        </div>
                        <!-- <div class="col-sm-2">
                            <i class="fa fa-circle" style="font-size: 20px;color: red; width: 16%"></i>
                            <label class="control-label">Penalty</label>
                        </div> -->
                    </div>
                </div>
                <div class="order-data"></div>
                
                <?php 
                }   
                ?>

            </div>
        </div>
    </div>
</section>
<script>
    /* When the user clicks on the button, 
    toggle between hiding and showing the dropdown content */
    function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
      if (!event.target.matches('.dropbtn')) {

        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('show')) {
            openDropdown.classList.remove('show');
          }
        }
      }
    }
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $.ajax({
                type : 'get',
                url : 'portofolio/',
                
                success : function(data){
                $('.order-data').html(data);//menampilkan data ke dalam modal

                
                }
            });
        $('#id_borrower_loan').click(function () {
            var id_borrower_loan = document.getElementById('id_borrower_loan').value;
            if(id_borrower_loan == "all"){
                $.ajax({
                type : 'get',
                url : 'portofolio/',
                
                success : function(data){
                $('.order-data').html(data);//menampilkan data ke dalam modal

                
                }
            });
            }else{
            
            console.log(id_borrower_loan);
            //menggunakan fungsi ajax untuk pengambilan data
            $.ajax({
                type : 'get',
                url : 'portofolio/'+id_borrower_loan,
                data:"id="+id_borrower_loan,
                success : function(data){
                $('.order-data').html(data);//menampilkan data ke dalam modal

                
                }
            });
            }
         });
    });
</script>
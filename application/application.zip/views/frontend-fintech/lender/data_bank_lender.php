<?php date_default_timezone_set("Asia/Jakarta"); ?>
<section class="container home" >
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback" >
		<div class="row" style="background-color: white; margin-bottom: 2%; padding: 20px;">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
            <?php } ?>
            
			<div class="col-md-3 col-sm-12 col-xs-12">
				<div class=" form-group" ">
					<a style="color: <?php echo @$style_href;?>" href="<?php echo site_url('Finance/F_lender/personal_info_lender') ?>"><h3>Personal Information</h3></a>
				</div>
				<div class=" form-group" ">
					<a style="color: orange;" href="#"><h3>Change Bank Data</h3></a>
				</div>
				<div class=" form-group" ">
					<a style="color: <?php echo @$style_href;?>" href="<?php echo site_url('Finance/F_lender/change_password_lender') ?>"><h3>Change Password</h3></a>
				</div>
			</div>
				<div class="col-md-9 col-sm-12 col-xs-12" id="left2">
					<br>
						
							<div class="col-md-3 col-sm-12 col-xs-12">
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
							<div class=" form-group" >
								<label>Name</label>
								<input type="text" placeholder="Name" value="<?php echo @$data_code[0]->your_bank_name ; ?>"  class="form-control" readonly>
							</div>
							<div  class=" form-group">
								<label>Account Number</label>
								<input type="Number" placeholder="Account Number" value="<?php echo @$data_code[0]->bank_account; ?>" class=" form-control" readonly>
							</div>
							<div class=" form-group">
								<label> Bank Name </label>
								<input type="text" placeholder="Bank" value="<?php echo @$data_code[0]->bank_name;?>" class=" form-control" readonly>
							</div>
							<div class=" form-group">
								<label> Branch </label>
								<input type="text" placeholder="Branch" value="<?php echo @$data_code[0]->bank_branch; ?>" class=" form-control" readonly>
							</div>
							<div class="form-group" style="text-align: center">
								 <a href="<?php echo $edit_url;?>" class="btn btn-warning btn-sm btn-block" >Edit</a>
							<!-- 	<button type="submit" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; margin-top: 2%; background-color: orange; width: 30%; color: black	" ><b>Edit</b></button>	 -->
								<!-- <button type="button" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; margin-top: 2%; background-color: orange; width: 30%; color: black" ><b>Update</b></button> -->
							</div>
								
							</div>
							<div class="col-md-3 col-sm-12 col-xs-12">

							</div>

				</div>
			</div>
		</div>
	</div>
</section>
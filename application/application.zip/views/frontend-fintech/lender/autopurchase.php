<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
    /* The check_custom */
      .check_custom {
          position: relative;
          padding-left: 35px;
          margin-bottom: 12px;
          margin-right: 10px;
          cursor: pointer;
          font-size: 15px;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
      }
    
      /* Hide the browser's default checkbox */
      .check_custom input {
          position: absolute;
          opacity: 0;
          cursor: pointer;
      }
    
      /* Create a custom checkbox */
      .check_mark {
          position: absolute;
          top: 0;
          left: 0;
          height: 25px;
          width: 25px;
          background-color: #eee;
      }
    
      /* On mouse-over, add a grey background color */
      .check_custom:hover input ~ .check_mark {
          background-color: #ccc;
      }
    
      /* When the checkbox is checked, add a blue background */
      .check_custom input:checked ~ .check_mark {
          background-color: #ffd100;
      }
    
      /* Create the check_mark/indicator (hidden when not checked) */
      .check_mark:after {
          content: "";
          position: absolute;
          display: none;
          border-radius: 10%;
      }
    
      /* Show the check_mark when checked */
      .check_custom input:checked ~ .check_mark:after {
          display: block;
      }
    
      /* Style the check_mark/indicator */
      .check_custom .check_mark:after {
          left: 10px;
          top: 7px;
          width: 7px;
          height: 10px;
          border: solid white;
          border-width: 0 3px 3px 0;
          -webkit-transform: rotate(45deg);
          -ms-transform: rotate(45deg);
          transform: rotate(45deg);
      }
</style>

<style>
    .switch {
      position: absolute;
      display: inline-block;
      width: 83px;
      height: 26px;
      right: 23px;
    }
    
    .switch input {display:none;}
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: -2px;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      -webkit-transition: .4s;
      transition: .4s;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 20px;
      width: 20px;
      left: 4px;
      bottom: 4px;
      background-color: white;
      -webkit-transition: .4s;
      transition: .4s;

    }

    .slider:after
    {
     content:'OFF';
     color: white;
     display: block;
     position: absolute;
     transform: translate(-50%,-50%);
     top: 50%;
     left: 50%;
     font-size: 13px;
     font-family: Verdana, sans-serif;
    }

    input:checked + .slider:after
    {  
      content:'ON';
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:focus + .slider {
      box-shadow: 0 0 1px #2196F3;
    }
    
    input:checked + .slider:before {
      -webkit-transform: translateX(26px);
      -ms-transform: translateX(26px);
      transform: translateX(55px);
    }
    
    /* Rounded sliders */
    .slider.round {
      border-radius: 12px;
    }
    
    .slider.round:before {
      border-radius: 50%;
    }
</style>
<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="row">
                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <br>
                        <?php if ($this->session->flashdata('alert_success')) { ?>
                        <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                                <?php echo $this->session->flashdata('alert_success'); ?>
                            </p>
                        </div>
                        <?php } ?>

                        <?php if ($this->session->flashdata('alert_error')) { ?>
                        <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                                <?php echo $this->session->flashdata('alert_error'); ?>
                            </p>
                        </div>
                        <?php } ?>
                    </div>
                    <div class="col-md-4 col-sm-3 col-xs-3">
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-6">

                        <div class=" form-group" style="text-align: center;">
                            <input type="hidden" value="<?php echo $get_code; ?>" name="register_code" required>
                            <br>
                            <label>Available Fund</label><br><br>
                            <input type="text" value="Rp. <?php echo number_format(@$lender_fund[0]->amount,0,".",".");?>" class="form-control" disabled="true" style="text-align: center;">
                        </div>

                    </div>
                    <div class="col-md-4 col-sm-3 col-xs-3">
                    </div>

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <br>
                    </div>

                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <div class="container div-register " style="text-align: ; width: 100%; background-color:#eaeaea; ">
                            <h4><b> Active Auto Invest </b></h4>
                            <br>
                            <?php 
                            $no = 0;
                            foreach ($auto as $auto_entry) {
                            $no++;
                            ?>

                            <div class="form-group">
                                <label></label>
                                <label><a href="#" onclick="get_data_modal('<?php echo $auto_entry->id_lender_automation; ?>','<?php echo $auto_entry->automation_name; ?>','<?php echo $auto_entry->automation_amount; ?>');"><?php echo $no; ?>. &nbsp;&nbsp; <?php echo $auto_entry->automation_name; ?></a>
                                </label>
                                <label class="checkbox-inline switch">
                                  <?php                     
                                    if ($auto_entry->automation_status == "Activated"){
                                  ?>
                                      <input type="checkbox" name="automation_status" style="border-radius:20px;" onchange="loaddata(<?php echo $auto_entry->id_lender_automation; ?>)" checked data-toggle="toggle" value="">
                                      <span class="slider round"></span>
                                  <?php
                                    } else {
                                  ?>
                                      <input type="hidden" name="id_lender_automation" value="<?php echo $auto_entry->id_lender_automation; ?>">
                                      <input type="checkbox" name="automation_status" data-toggle="toggle" style="border-radius:20px;" onchange="loaddata(<?php echo $auto_entry->id_lender_automation; ?>)"  value="">
                                      <span class="slider round"></span> 

                                  <?php
                                    }
                                  ?>
                                    <!-- <input type="checkbox" data-toggle="toggle" style="border-radius:20px;">
                                    <span class="slider round"></span> -->
                                </label>
                            </div>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="col-md-8 col-sm-12 col-xs-12" style="border-left: 1px; border-color: gray; border-left-style: solid; margin-bottom: 2%; margin-top: 19px;">

                        <div class="col-md-12 col-sm-12 col-xs-12" align="center">
                            <h4><label> Add Auto Invest</label></h4>
                        </div>

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class=" form-group">
                                <h5><label>Auto Invest Name</label></h5>
                                <input type="text" placeholder=" Auto Invest Name" name="automation_name" class=" form-control" style="width: 65%;" required="true">
                            </div>
                        </div>

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class=" form-group">
                                <h5><label> Amount per loan</label></h5>
                                <input type="text" placeholder=" Amount per loan" name="automation_amount" class="form-control dengan-rupiah" style="width: 65%;" required="true">
                            </div>
                        </div>

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <h5><label>Loan Term</label></h5>
                        </div>

                        <?php
                            foreach ($data_periode as $periode_entry){
                        ?>

                            <div class="col-md-3 col-sm-3 col-xs-4">
                                <div class=" form-group">
                                    <label class="check_custom" style="font-weight: normal;"> <?php echo $periode_entry->periode; ?> Month
                                <input type="checkbox" name="automation_loan_term[]" value="<?php echo $periode_entry->periode; ?>" >
                                <span class="check_mark"></span>
                                </label>
                                </div>
                            </div>

                            <?php
                            }
                        ?>

                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <h5><label> Rating</label></h5>
                                </div>

                                <div class="col-md-3 col-sm-3 col-xs-4">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title="12"> A+
                                  <input type="checkbox" name="automation_rating[]" value="APlus" >
                                  <span class="check_mark"></span>
                                </label>
                                    </div>

                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-4">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> A
                                  <input type="checkbox" name="automation_rating[]" value="A" >
                                  <span class="check_mark"></span>
                                </label>
                                    </div>

                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-4">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> B+
                                  <input type="checkbox" name="automation_rating[]" value="BPlus" >
                                  <span class="check_mark"></span>
                                </label>
                                    </div>

                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-4">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> B
                                          <input type="checkbox" name="automation_rating[]" value="B" >
                                          <span class="check_mark"></span>
                                        </label>
                                    </div>

                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-4">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> C+
                                          <input type="checkbox" name="automation_rating[]" value="CPlus" >
                                          <span class="check_mark"></span>
                                        </label>
                                    </div>

                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-4">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> C
                                          <input type="checkbox" name="automation_rating[]" value="C" >
                                          <span class="check_mark"></span>
                                        </label>
                                    </div>

                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-4">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> D+
                                          <input type="checkbox" name="automation_rating[]" value="DPlus" >
                                          <span class="check_mark"></span>
                                        </label>
                                    </div>

                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-4">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> D
                                          <input type="checkbox" name="automation_rating[]" value="D" >
                                          <span class="check_mark"></span>
                                        </label>
                                    </div>

                                </div>
                                

                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <h5><label> Type Of Loan</label></h5>
                                </div>

                                <div class="col-md-6 col-sm-6 col-xs-6">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;"> Personal Loan
                                          <input type="checkbox" name="automation_type_loan[]" value="Personal_Loan">
                                          <span class="check_mark"></span>
                                        </label>
                                    </div>

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;"> Fixed Loan
                                          <input type="checkbox" name="automation_type_loan[]" value="Fixed_Loan">
                                          <span class="check_mark"></span>
                                        </label>
                                    </div>

                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-6">

                                    <div class=" form-group">
                                        <label class="check_custom" style="font-weight: normal;"> Flexible Loan
                                          <input type="checkbox" name="automation_type_loan[]" value="Flexible_Loan">
                                          <span class="check_mark"></span>
                                        </label>
                                    </div>
                                    <br>

                                </div>


                                <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
                                    <br><br>
                                    <button type="submit" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; background-color: orange; width: 100px;height:30px; ">Add Auto Invest</button>

                                </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
  function loaddata(id_lender_automation)
  {
    var id_lender_automation = id_lender_automation;

    $.ajax({
          type: 'POST',
          url: "<?php echo base_url(); ?>Finance/F_lender/access_status_exchange",
          data: {
            id_lender_automation : id_lender_automation
          },
          success: function() {
             //alert('DONE' + id_blog);
     
          }
    });

    event.preventDefault();

  }

</script>
<script type="text/javascript">
    function get_data_modal(id,name,amount){
            
        var id = id;
        var name = name;
        var amount = amount;

        var amount_stored = "Rp. " + addCommas(amount);

        $(".modal2 #id_auto").val( id );
        $(".modal2 #name").val( name );
        $(".modal2 #amount").val( amount_stored );

        $.ajax({
            url: <?php echo "'". site_url("Finance/F_lender/check_automation_update")."'";?>,
            type: 'POST',
            dataType: 'json',
            data: {id_lender_automation: id},
            timeout: 180000,
            beforeSend: function() {
            },
            success: function(data) {
                //console.log(data);
                $.each(data, function(index) {

                    document.getElementById('id'+data[index]).checked = true;

                });

            },
            error: function(x, t, m) {

            }
        });
        
        $("#myModal").modal();          
    }
</script>
<script type="text/javascript">
    function addCommas(nStr) {
        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
                x1 = x1.replace(rgx, '$1' + '.' + '$2');
        }
        return x1 + x2;
    }
</script>


<div class="modal fade col-md-12" id="myModal" role="dialog" aria-labelledby="title_plus" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3 class="modal-title" id="title_plus">Edit Auto Invest</h3>
            </div>
            <form action="<?php echo $update_url; ?>" method="post" enctype="multipart/form-data">
            <div class="modal-body modal2">
                <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class=" form-group">
                        <h5><label>Auto Invest Name</label></h5>
                        <input type="hidden" name="id_lender_automation" id="id_auto" required="true">
                        <input type="text" placeholder=" Autopurchase Name" name="automation_name" id="name" class=" form-control" style="width: 65%;" required="true">
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class=" form-group">
                        <h5><label> Amount per loan</label></h5>
                        <input type="text" placeholder=" Amount per loan" name="automation_amount" id="amount" class="form-control dengan-rupiah" style="width: 65%;" required="true">
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <h5><label>Loan Term</label></h5>
                </div>

                <?php
                    foreach ($data_periode as $periode_entry){
                ?>

                    <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class=" form-group">
                            <label class="check_custom" style="font-weight: normal;"> <?php echo $periode_entry->periode; ?> Month
                                <input type="checkbox" name="automation_loan_term[]" id="id<?php echo $periode_entry->periode; ?>" value="<?php echo $periode_entry->periode; ?>" >
                                <span class="check_mark"></span>
                                </label>
                        </div>
                    </div>

                <?php
                    }
                ?>

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <h5><label> Rating</label></h5>
                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-4">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title="12"> A+
                                  <input type="checkbox" name="automation_rating[]" id="idAPlus" value="APlus" >
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-4">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> A
                                  <input type="checkbox" name="automation_rating[]" id="idA" value="A" >
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-4">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> B+
                                  <input type="checkbox" name="automation_rating[]" id="idBPlus" value="BPlus" >
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-4">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> B
                                  <input type="checkbox" name="automation_rating[]" id="idB" value="B" >
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-4">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> C+
                                  <input type="checkbox" name="automation_rating[]" id="idCPlus" value="CPlus" >
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-4">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> C
                                  <input type="checkbox" name="automation_rating[]" id="idC" value="C" >
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-4">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> D+
                                  <input type="checkbox" name="automation_rating[]" id="idDPlus" value="DPlus" >
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-4">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;" data-toggle="tooltip" data-placement="top" title=""> D
                                  <input type="checkbox" name="automation_rating[]" id="idD" value="D" >
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <h5><label> Type Of Loan</label></h5>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-6">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;"> Personal Loan
                                  <input type="checkbox" name="automation_type_loan[]" value="Personal_Loan" id="idPersonal_Loan">
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;"> Fixed Loan
                                  <input type="checkbox" name="automation_type_loan[]" value="Fixed_Loan" id="idFixed_Loan">
                                  <span class="check_mark"></span>
                                </label>
                            </div>

                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-6">

                            <div class=" form-group">
                                <label class="check_custom" style="font-weight: normal;"> Flexible Loan
                                  <input type="checkbox" name="automation_type_loan[]" value="Flexible_Loan" id="idFlexible_Loan">
                                  <span class="check_mark"></span>
                                </label>
                            </div>
                            <br>

                        </div>
            </div>
            </div>
            </div>
            <div class="modal-footer">
              <!-- <a href="#" id="delete" onclick="delete_data(<?php echo @$data['auto'][0]->id_lender_automation; ?>)" class="btn-danger btn-sm btn btnwdt" >Delete</a> -->
                <button type="button" id="delete" class="btn btn-danger btn-sm btnwdt" onclick="delete_data(<?php echo @$auto[0]->id_lender_automation; ?>)" style="margin-bottom: 4%;background-color: #dc1b1b; margin-top: 2%; width: 15%;height:30px; ">Delete</button>
                <button type="button" class="btn btn-danger btn-sm btnwdt" data-dismiss="modal" style="margin-bottom: 4%; margin-top: 2%; background-color: #dc1b1b; width: 15%;height:30px; ">Close</button>
                <button type="submit" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; margin-top: 2%; background-color: orange; width: 30%;height:30px; ">Update Auto Invest</button>
            </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
  function delete_data(id_lender_automation)
{
    bootbox.confirm({
    title: "Deleting Data?",
    message: "Do you want to delete this data?",
    buttons: {
        cancel: {
            label: '<i class="fa fa-times"></i> Cancel',
            className: 'btn-default'
        },
        confirm: {
            label: '<i class="fa fa-check"></i> Delete',
            className: 'btn-danger'
        }
    },
    callback: function (result) {
        if (result == true){
            window.location = "<?php echo $delete_url; ?>/" + id_lender_automation;
        } else {
            event.preventDefault();
        }
    }
    });
}
</script>
</script>>
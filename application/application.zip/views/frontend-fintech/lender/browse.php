<?php date_default_timezone_set("Asia/Jakarta"); ?>
<section class="container home" >
	<div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
		<div class="container div-feedback" >
		
					  <!-- Wrapper for slides -->
			<div class="row feedback" style="background-color: white; margin-top: 0%; margin-bottom: 2%;">
			<div class="col-md-12 col-sm-12 col-xs-12" >
				<br><br>
				
			</div>
			
				<div class="col-md-6 col-sm-12 col-xs-12" style="margin-bottom: 2%;" >

						<div class="form-group">
							
								<div class="col-md-4" style="text-align: center; width: 100%;">
									<a href="<?php echo site_url('Finance/F_lender/autopurchase');?>" class="btn btn-warning btn-lg" style="width:100%;height: 70px; background-color: #ffc516"><h3 style="color:#6d6d6d;line-height: 1.8">Auto Invest</h3></a>
									<br>
								<br>
								</div>	
								
								<div class="col-md-4 col-xs-12 " style=" width: 100%; padding-left: 0px;padding-right: 0px">
									<h5><p style="text-align: justify; width: 100%">1. You just need to set up the perimeter such as you preference in rating, period, type of loan, etc</p></h5>
								
									<h5><p style="text-align: justify; width: 100%">2. Once its done, you just sit back and our system will invest automatically as your requirment.</p></h5>
								
								
									<h5><p style="text-align: justify; width: 100%">3. You just need monitor and enjoy good return on your invesment.</p></h5>
								</div>	

								
						</div>
					
				</div>
							
				<div class="col-md-6 col-sm-12 col-xs-12" id="left1">

					<div class="form-group">
							
								<div class="col-md-4" style="text-align: center; width: 100%;">
                                    <a href="<?php echo site_url('Finance/F_lender/manually');?>" class="btn btn-warning btn-lg" style="width:100%;height: 70px; background-color: #ffc516"><h3 style="color:#6d6d6d;line-height: 1.8">Browse Manually</h3></a>
                                    <br>
                                <br>
                                </div>

								<div class="col-md-4 col-xs-12" style="text-align: left; width: 100%; padding-left: 0px;padding-right: 0px">
									<h5><p style="text-align: justify; width: 100%">1. Choose the type of loan you want to invest</p></h5>
								
									<h5><p style="text-align: justify; width: 100%">2. You will have a list  of available loan to invest and you can review then one by one by reading the fact sheets we provides.</p></h5>
								
								
									<h5><p style="text-align: justify; width: 100%">3. Once you are firm with your choices, you fill the amount of money you want to invest and submit.</p></h5>

									<h5><p style="text-align: justify; width: 100%">4. The next step is to monitor and enjoy good return on your investment.</p></h5>
									<br>
									<br>
								</div>	
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
	

		
			
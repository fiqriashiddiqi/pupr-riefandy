<?php date_default_timezone_set("Asia/Jakarta"); ?>
<section class="container home" >
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback" >
		    <div class="row" style="background-color: white; margin-top: 2%; margin-bottom: 2%;">
			
				<div class="col-md-12 col-sm-12 col-xs-12" >
				<br>
				<h3 style="text-align: center;"><p><b>REPORT </b></p></h3>
							<div class="col-md-3 col-sm-12 col-xs-12">
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
							
                            <div class="form-group">
                                <label for="feedback_postdate">Start Date</label>
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" name="start_date" class="form-control pull-right datepicker" value <?php echo date('d-m-y');?> placeholder="Start Date" id="start_date">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="feedback_postdate">End Date</label>
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" name="end_date" class="form-control pull-right datepicker" value <?php echo date('d-m-y');?> placeholder="End Date" id="end_date">
                                </div>
                            </div>

							<div  class=" form-group">
								<label> Report Type</label>
					                <select class="form-control select2" name="whereuknow" required="true" id="lender_report" onchange="check_report();">
					                  
					                  <option value="Cashflow">Cash Flow</option>
					                  <option value="OrderHistory">Order history</option>
               						</select>
                            </div>
                            <div  class=" form-group" align="right" >

                                <button type="button" class="btn btn-info btn-sm" id="Cashflow" data-toggle="modal" data-target="#myModal" style="width:15%;height: 25px;background-color: #ffc516;border-color: #ffc516;display: ">View</button>
                                <button type="button" class="btn btn-info btn-sm" id="OrderHistory" data-toggle="modal" data-target="#myModal1" style="width:15%;height: 25px;background-color: #ffc516;border-color: #ffc516;display: none;">View</button>
                                <!-- <button type="button" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="Download Pdf" style="width:15%;height: 25px;background-color: #ffc516;border-color: #ffc516;"><i class="fa fa-file-pdf-o" style="padding:0;width:10px;margin: 0;"></i></button>
                                <button type="button" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="Download Excel" style="width:15%;height: 25px;background-color: #ffc516;border-color: #ffc516;"><i class="fa fa-file-excel-o" style="padding:0;width:10px;margin: 0;"></i></button> -->
                                 
          				      
							</div>
                           
						<div class="col-md-3 col-sm-12 col-xs-12">
						</div>

					</div>
				</div>
			</div>
		</div>
    </div>
</section>


<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg" style="width: 1100px">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <!-- <h4 class="modal-title" style="text-align: right;">PT One Stop</h4> -->
                <div class="container">
                <div class="row">
                  <div class="col-md-3 col-sm-4 col-xs-12">
                  
                    <!-- Brand and toggle get grouped for better mobile display -->
                    
                  </div>

                      <div class="col-md-9 col-sm-8 col-xs-12">
                        
                          <!-- Collect the nav links, forms, and other content for toggling -->
                          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <div class="clearfix"> </div>
                                        
                          </div><!-- /.navbar-collapse -->
                      </div>

                    </div> <!-- .row -->
                    </div><!-- /.container-fluid -->
                 
            </div>
            <div class="modal-body" style="margin-top: 7%;">
                <div class="fetched-data">
                  
                </div>    
            </div>
        
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal" style="width: 70px;height: 30px;">Close</button>
            <a id="linkPdf"  class="btn btn-primary" style="width: 70px;height: 30px;"><i class="fa fa-download"></i>&nbsp;PDF</a>
          </div>
        </div>

    </div>
</div>

<div id="myModal1" class="modal fade" role="dialog">
      <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <!-- <h4 class="modal-title" style="text-align: right;">PT One Stop</h4> -->
                <div class="container">
                <div class="row">
                  <div class="col-md-3 col-sm-4 col-xs-12">
                  
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                    <ul class="nav nav-pills">
                      <a class="navbar-brand" href="<?php echo base_url();?>home">
                        <img alt="Brand" class="img-responsive img-logo" src="<?php echo base_url();?>uploads/base-img/logoSanders.png">
                      </a>

                    </ul>
                    </div>
                  </div>

                      <div class="col-md-9 col-sm-8 col-xs-12">
                        
                          <!-- Collect the nav links, forms, and other content for toggling -->
                          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <div class="clearfix"> </div>
                                        
                          </div><!-- /.navbar-collapse -->
                      </div>

                    </div> <!-- .row -->
                    </div><!-- /.container-fluid -->
                 
            </div>
          <div class="modal-body" style="margin-top: 7%;">
              <div class="order-data"></div>
        </div>
        
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal" style="width: 70px;height: 30px;">Close</button>
            <a id="linkPdforder"  class="btn btn-primary" style="width: 70px;height: 30px;"><i class="fa fa-download"></i>&nbsp;PDF</a>
          </div>
        </div>

      </div>
</div>

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
        $('#myModal').on('show.bs.modal', function (e) {
            var start_date = document.getElementById('start_date').value;
            var end_date = document.getElementById('end_date').value;
            console.log('cashflow');
            //menggunakan fungsi ajax untuk pengambilan data
            $.ajax({
                type : 'get',
                url : 'cashflow?start_date='+start_date+'&end_date='+end_date,
                success : function(data){
                $('.fetched-data').html(data);//menampilkan data ke dalam modal
                $('#linkPdf').attr('href', "<?php echo site_url('Export_Pdf/pdf_cashflow/'); ?>?"+'start_date='+start_date+'&end_date='+end_date);
                }
            });
         });
    });
  </script>
  <script type="text/javascript">
    $(document).ready(function(){
        $('#myModal1').on('show.bs.modal', function (e) {
            var start_date = document.getElementById('start_date').value;
            var end_date = document.getElementById('end_date').value;
            console.log('order_history');
            //menggunakan fungsi ajax untuk pengambilan data
            $.ajax({
                type : 'get',
                url : 'order_history?start_date='+start_date+'&end_date='+end_date,
                success : function(data){
                $('.order-data').html(data);//menampilkan data ke dalam modal
                $('#linkPdforder').attr('href', "<?php echo site_url('Export_Pdf/pdf_order_history/'); ?>?"+'start_date='+start_date+'&end_date='+end_date);
                }
            });
         });
    });
  </script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
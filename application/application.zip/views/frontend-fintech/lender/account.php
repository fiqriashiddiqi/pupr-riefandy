<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
    .tool_tip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }
    
    .tool_tip .tool_tiptext {
        visibility: hidden;
        width: 180px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 0px;
        padding: 5px 0;
    
        /* Position the tool_tip */
        position: absolute;
        z-index: 1;
    }
    
    .tool_tip:hover .tool_tiptext {
        visibility: visible;
    }


</style>
<section class="container home" >
		<div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
			<div class="container div-feedback" >
			    
                <div class="row feedback" style="margin-top: 2%">
                	<div class="col-md-6 col-sm-12 col-xs-12" style="border-right: 1px; border-color: gray; border-right-style: solid; margin-bottom: 2%;" >
                		<input type="hidden" value="<?php echo $get_code; ?>" name="register_code"/>
						<div class=" form-group" >
							<label> Name</label>
							<input type="text" placeholder=" Name " class=" form-control" name="bio_fullname" value="<?php echo $data_code[0]->bio_fullname; ?>" required="true" readonly>
						</div>
						<div class=" form-group" >
							<label> Investor ID</label>
							<input type="text" placeholder=" Investor ID " class=" form-control" name="register_code" value="<?php echo $data_code[0]->register_code; ?>" required="true" readonly>
						</div>
						<div class=" form-group" >
							<label> Virtual Account</label>
							<input type="text" placeholder="0980-xxxx-xxx" class=" form-control" name="virtual_account" value="" required="true" readonly>
						</div>
						<hr style="border: 1px solid; color: black; " >
		
						<div class="col-sm-4" style="text-align: left; width: 100%; border: 2px solid; margin-top: 1%; margin-bottom: 1%">
							<h5>Total Invested + &nbsp  Reserve Fund +  &nbsp Available Funds = &nbsp Total Value</h5>


						</div>	
						<hr style="border: 1px solid ; color: black; " >
						<br>
						<?php
	                        $total_invest = @$total_invest[0]->total_invest;
	                        $total_reserve = @$total_reserved[0]->total_reserved;
	                        $available_fund = @$lender_fund[0]->amount;
                            $point = 0;
                            $total_cash_point = $available_fund + $point;
	                        $total_value = $total_invest + $total_reserve + $available_fund;



	                    ?>
						<div class=" form-group" >
							<label> Total Invested</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<input type="text" value="Rp. <?php echo  number_format($total_invest,0,".","."); ?>" class=" form-control" disabled="true">
						</div>
							<div class=" form-group" >
							<label> Reserve Fund</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<input type="text" value="Rp. <?php echo number_format($total_reserve,0,".","."); ?>" placeholder=" Reserve Fund " class=" form-control" disabled="true">
						</div>
						<div class=" form-group" >
							<label> Available Funds</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<input type="text" value="Rp. <?php echo number_format($available_fund,0,".","."); ?>" placeholder=" Available Fund " class=" form-control" disabled="true">
						</div>
							<div class=" form-group" >
							<label> Total Value</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<input type="text" value="Rp. <?php echo number_format($total_value,0,".","."); ?>" placeholder=" Total Value " class=" form-control" disabled="true">
						</div>
						<hr style="border: 1px solid; color: black; " >
                        <br>
						<div class=" form-group" >
							<label> Cash</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<input type="text" value="Rp. <?php echo number_format($available_fund,0,".","."); ?>" placeholder=" Cash " class=" form-control" disabled="true">
						</div>
						<div class=" form-group" >
							<label> Point</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<input type="text" value="Rp. <?php echo number_format($point,0,".","."); ?>" placeholder=" Point " class=" form-control" disabled="true">
						</div>
						<div class=" form-group" >
							<label> Total </label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<input type="text" value="Rp. <?php echo number_format($total_cash_point,0,".","."); ?>" placeholder=" Total" class=" form-control" disabled="true">
						</div>
						
					</div>
					<div class="col-md-6 col-sm-12 col-xs-12" >

						<div class=" form-group" >
							<?php 

                            $tot_invest = $this->account_model->get_invest_by_id_nreg($get_code,@$data_loan[0]->id_borrower_loan);
                            $total_inv = @$total_funding[0]->total_funding;
                            $avg_rate=0;
                            foreach($data_loan as $loan_entry){
                                $flat_rate = $loan_entry->loan_rate;
                                $amount_invest = $this->account_model->get_invest_by_id_nreg($get_code,$loan_entry->id_borrower_loan);

                                $amount = @$amount_invest[0]->amount_invest;

                                $a = $flat_rate * ($amount/$total_inv);
                                $avg_rate = $avg_rate + $a;
                                
                                
                            }
                            
                            ?>
							<label> Average Return</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<input type="text" value="<?php echo number_format($avg_rate,2,".","."); ?>%" placeholder=" Average Return " class=" form-control"  disabled="true">
						</div>
						<div  class=" form-group">
							<label> Interest Paid To Date</label><a href="javascript:void(0);" class="tool_tip"><i class="fa fa-info-circle" style="margin-left: 4px"></i><span class="tool_tiptext">Information</span></a>
							<?php 
                            
                            foreach ($data_loan as $loan_entry){
                            
                            @$total_interest_payment = $this->account_model->get_sum_interest_lender($get_code);
                            
                            }
                            
                            ?>
							<input type="text" value="Rp. <?php echo number_format(@$total_interest_payment[0]->total_interest_lender,0,".","."); ?>" placeholder=" Interest Paid to date " class=" form-control" disabled="true">
						</div>
						<div class="form-group" style="text-align: center">
							
							<input type="button" value="Agreement Doc" class="btn btn-warning btn-lg form-control" style="line-height: 5px;width:50%;background-color: #ffc516;color:#6d6d6d;" data-toggle="modal" data-id="<?php echo $data_code[0]->register_code; ?>" data-target="#myModal">
						</div>
						<br>
							
						<div class=" form-group">
							<h4 style="text-align: center;"> Start Invest by :</h4>
								<div class="col-md-4" style="text-align: center; width: 100%; margin-top: 18px">
									<a href="<?php echo site_url('Finance/F_lender/autopurchase');?>" class="btn btn-warning btn-lg" style="width: 280px;height: 60px; margin-left: -10px;background-color: #ffc516"><h3 style="color:#6d6d6d;line-height: 1.3">Auto Invest</h3></a>
								</div>
						</div>
						<div class="form-group">
							
							<div class="col-md-4" style="text-align: center; width: 100%; margin-top: 18px">
								<a href="<?php echo site_url('Finance/F_lender/manually') ?>" class="btn btn-warning btn-lg" style="width: 280px;height: 60px; margin-left: -10px;background-color: #ffc516"><h3 style="color:#6d6d6d;line-height: 1.3">Manually</h3></a>
							</div>
						</div>
						
					</div>
                </div>
		
			</div>

		</div>
	</section>
	<div id="myModal" class="modal fade" role="dialog">
	  <div class="modal-dialog modal-lg" style="width: 62%;">

	      <!-- Modal content-->
	      <div class="modal-content">
	        <div class="modal-header">
	          <button type="button" class="close" data-dismiss="modal">&times;</button>
	          <!-- <h4 class="modal-title" style="text-align: right;">PT One Stop</h4> -->
	              <div class="container">
	              <div class="row">
	                <div class="col-md-3 col-sm-4 col-xs-12">
	                
	                  <!-- Brand and toggle get grouped for better mobile display -->
	                  <div class="navbar-header">
	                  <ul class="nav nav-pills">
	                    

	                  </ul>
	                  
	                  </div>
	                </div>

	                    <div class="col-md-9 col-sm-8 col-xs-12">
	                      
	                        <!-- Collect the nav links, forms, and other content for toggling -->
	                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	                          <div class="clearfix"> </div>
	                                      
	                        </div><!-- /.navbar-collapse -->
	                    </div>

	                  </div> <!-- .row -->
	                  </div><!-- /.container-fluid -->
	                  <br>
	               <h2 style="text-align: center;">TERMS AND CONDITIONS</h2>
	          </div>
	        <div class="modal-body">
	          <div class="col-md-12 col-sm-12 col-xs-12" style="overflow-y: auto;overflow-x: hidden;height: 400px;text-align: justify;">
	          	<div class="data-term"></div>
	          </div>
	        </div>
	      
	        <div class="modal-footer">
	                  
	          <button type="button" class="btn btn-default" data-dismiss="modal" style="width: 60px;margin-top: 2%;">Close</button>
	          <a id="Pdf_term" class="btn btn-primary" style="width: 70px;height: 30px;"><i class="fa fa-download"></i>&nbsp;PDF</a>
	        </div>
	      </div>

	   </div>
	</div>
	
  <script type="text/javascript">
    $(document).ready(function(){
        $('#myModal').on('show.bs.modal', function (e) {
            var id_bor = $(e.relatedTarget).data('id');
            console.log(id_bor);
            //menggunakan fungsi ajax untuk pengambilan data
            $.ajax({
                type : 'get',
                url : 'term_lender/'+id_bor,
                success : function(data){
                $('.data-term').html(data);//menampilkan data ke dalam modal
                $('#Pdf_term').attr('href', "<?php echo site_url('Export_Pdf/pdf_term_lender/'); ?>" + id_bor);
                }
            });
         });
    });
  </script>

		
			
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Fact Sheet</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/LTE/dist/css/AdminLTE.min.css">
  <!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/LTE/bootstrap/css/bootstrap.min.css"> -->
  <link defer href="<?php echo base_url() ?>assets/Sanders/custom/custom.css" rel="stylesheet">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <!-- <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css"> -->

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style type="text/css">
    table, th, td {
        border: 1px solid #726f6f;
    }

    @page { margin: 100px 50px; }
    #header { position: fixed; left: 0px; top: -80px; right: 0px; height: 10px;text-align: left; }
    #footer { position: fixed; left: 0px; bottom: -100px; right: 0px; height: 40px;}
    #footer .page:after { content: counter(page, upper-roman); }
  </style>
</head>
<body>

<div class="table-responsive" style="margin-top: -2%;" >
                        <div class="col-md-4 col-sm-12 col-xs-12">
                            <p style="text-align: left;">Cash Flow Statement</p>
                            <p style="text-align: left;"><?php echo date('F Y');?></p>
                        </div>  
                        <div class="col-md-4 col-sm-12 col-xs-12">
                        </div>  
                        <div class="col-md-4 col-sm-12 col-xs-12">
                            <p style="text-align: right;"><?php echo $bio_fullname[0]->bio_fullname;?></p>
                            <p style="text-align: right;"><?php echo $get_code ;?></p>
                        </div>  
                    
                    <table id="table-test" class="table" style="margin-top: 2%;width: 90%; text-align: center;width: 100%">
                     <tr style="background-color: #726f6f;color: white; " >
                        <th style="text-align: center;">Date</th>
                        <th style=" text-align: center;">Beginning</th> 
                        <th style="text-align: center;">Pokok<br>(+) </th>
                        <th style="text-align: center;">Interest<br>(+)</th>
                        <th style="text-align: center;">Tax<br>(-)</th>
                        <th style="text-align: center;">Invest<br>(-)</th>
                        <th style="text-align: center;">Withdrawal<br>(-)</th>
                        <th style="text-align: center;">Deposit<br>(+)</th>
                        <th style="text-align: center;">Ending</th>
                        <th style="text-align: center;">Note</th>

                    </tr>
                    <?php
                      
                      $data_report = array();
                      $i = 0;

                        foreach ($data_cashflow as $cashflow_entry) {
                          
                          $entry = new \stdClass;

                          $beginning = $cashflow_entry->beginning_amount;
                          $entry->tot_beginning = $beginning;

                          $pokok = $cashflow_entry->payment_pokok;
                          $entry->tot_pokok = $pokok;

                          $interest = $cashflow_entry->payment_interest;
                          $entry->tot_interest = $interest;

                          $tax = $cashflow_entry->payment_tax;
                          $entry->tot_tax = $tax;

                          $invest = $cashflow_entry->invest_amount;
                          $entry->tot_invest = $invest;

                          $withdrawal = $cashflow_entry->withdrawal_amount;
                          $entry->tot_withdrawal = $withdrawal;

                          $deposit = $cashflow_entry->deposit_amount;
                          $entry->tot_deposit = $deposit;

                          $ending = $cashflow_entry->total_amount;
                          $entry->tot_ending = $ending;
                          $data_report[$i]=$entry;
                          $i++;
                          // var_dump($withdrawal);
                          // die();
                    ?>
                    <tr style="background-color: whitesmoke; ">
                        <td><?php echo  date('d-m-Y',strtotime($cashflow_entry->cashflow_date)); ?></td>
                        <td><?php echo number_format($cashflow_entry->beginning_amount,0,".","."); ?></td>
                        <td><?php echo number_format($cashflow_entry->payment_pokok,0,".","."); ?></td>
                        <td><?php echo number_format($cashflow_entry->payment_tax,0,".","."); ?></td>
                        <td><?php echo number_format($cashflow_entry->payment_interest,0,".","."); ?></td>
                        <td><?php echo number_format($cashflow_entry->invest_amount,0,".","."); ?></td>
                        <td><?php echo number_format($cashflow_entry->withdrawal_amount,0,".","."); ?></td>
                        <td><?php echo number_format($cashflow_entry->deposit_amount,0,".","."); ?></td>
                        <td><?php echo number_format($cashflow_entry->total_amount,0,".","."); ?></td>
                        <td><?php echo $cashflow_entry->cashflow_status ;?></td>
                    </tr>
                    <?php 
                    }
                    ?>
                     <!-- <tr  style="background-color: #726f6f;color: white;  "> -->
                        <!-- <?php 
                              $tot_beginning = 0;
                              $tot_pokok = 0;
                              $tot_interest = 0;
                              $tot_tax = 0;
                              $tot_invest = 0;
                              $tot_withdrawal = 0;
                              $tot_deposit = 0;
                              $tot_ending = 0;
                              foreach ($data_report as $report_entry) {
                                $tot_beginning += $report_entry->tot_beginning;
                                $tot_pokok += $report_entry->tot_pokok;
                                $tot_interest += $report_entry->tot_interest;
                                $tot_tax += $report_entry->tot_tax;
                                $tot_invest += $report_entry->tot_invest;
                                $tot_withdrawal += $report_entry->tot_withdrawal;
                                $tot_deposit += $report_entry->tot_deposit;
                                $tot_ending += $report_entry->tot_ending;
                                // var_dump($tot_beginning);
                               }
                        ?> -->
                          <!-- <td style="text-align: center;">Total</td>
                          <td><?php echo number_format($tot_beginning,0,".","."); ?></td>
                          <td><?php echo number_format($tot_pokok,0,".","."); ?></td>
                          <td><?php echo number_format($tot_tax,0,".","."); ?></td>
                          <td><?php echo number_format($tot_interest,0,".","."); ?></td>
                          <td><?php echo number_format($tot_invest,0,".","."); ?></td>
                          <td><?php echo number_format($tot_withdrawal,0,".","."); ?></td>
                          <td><?php echo number_format($tot_deposit,0,".","."); ?></td>
                          <td><?php echo number_format($tot_ending,0,".","."); ?></td>
                          <td></td>

                    </tr> -->
                    </table>
                </div>
            </body>
            </html>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style>
  /* The check_custom */
  .check_custom {
      position: relative;
      padding-left: 35px;
      margin-bottom: 12px;
      margin-right: 10px;
      cursor: pointer;
      font-size: 15px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  /* Hide the browser's default checkbox */
  .check_custom input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
  }

  /* Create a custom checkbox */
  .check_mark {
      position: absolute;
      top: 0;
      left: 0;
      height: 25px;
      width: 25px;
      background-color: #eee;
  }

  /* On mouse-over, add a grey background color */
  .check_custom:hover input ~ .check_mark {
      background-color: #ccc;
  }

  /* When the checkbox is checked, add a blue background */
  .check_custom input:checked ~ .check_mark {
      background-color: #ffd100;
  }

  /* Create the check_mark/indicator (hidden when not checked) */
  .check_mark:after {
      content: "";
      position: absolute;
      display: none;
      border-radius: 10%;
  }

  /* Show the check_mark when checked */
  .check_custom input:checked ~ .check_mark:after {
      display: block;
  }

  /* Style the check_mark/indicator */
  .check_custom .check_mark:after {
      left: 10px;
      top: 7px;
      width: 7px;
      height: 10px;
      border: solid white;
      border-width: 0 3px 3px 0;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
  }
  </style>
<section class="container home" >
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback" >	
		<div class="row" style="background-color: white; margin-top: 3%; margin-bottom: 3%;">
			
				<div class="col-md-12 col-sm-12 col-xs-12" style="border-top-color: transparent; text-align: center; " >
					<br>
					<h3 ><b>Withdrawal</b>  </h3>
					<br>
					
				</div>	
						<div class="col-md-4 col-sm-12 col-xs-12" style="margin-top: 5%;">
						</div>
						<div class="col-md-4 col-sm-12 col-xs-12">
                            <div class=" form-group" align="center">
                                <h4>Available Fund</h4>
                                <label>Rp. <?php echo number_format(@$lender_fund[0]->amount,0,".",".");?></label>
                            </div> 

                            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
							<div class=" form-group">
								<label>Withdrawal Amount</label>
								<input type="text" placeholder="Amount" name="withdrawal_amount" class=" form-control dengan-rupiah" id="withdrawal_amount" required="true">
							</div>
							
							<div class=" form-group">
								<label>Reason to withdraw</label>
								<input type="text" placeholder="Reason to withdraw" name="withdrawal_reason" class=" form-control" id="withdrawal_reason" required="true">
							</div>
						  <div class=" form-group" >
								<label>Name</label>
								<input type="text" placeholder="Name" name="your_bank_name" value="<?php echo @$data_code[0]->your_bank_name ; ?>"  class="form-control" id="your_bank_name" required="true">
							</div>
							<div  class=" form-group">
								<label>Account Number</label>
								<input type="Number" placeholder="Account Number" name="bank_account" value="<?php echo @$data_code[0]->bank_account; ?>" class=" form-control" id="bank_account" required="true">
							</div>
							<div class=" form-group">
								<label>Bank Name</label>
								<input type="text" placeholder="Bank" name="bank_name" value="<?php echo @$data_code[0]->bank_name;?>" class=" form-control" id="bank_name" required="true">
							</div>
							<div class=" form-group">
								<label>Branch</label>
								<input type="text" placeholder="Branch" name="bank_branch" value="<?php echo @$data_code[0]->bank_branch; ?>" class=" form-control" id="bank_branch" required="true">
							</div>
              <?php 
                $this->load->model("crud_model");
                          $data_setting = $this->crud_model->get_setting();
                          $fee_pg   = $data_setting[0]->fee_pg;
                          $fee_pg_ex = 10000000 + $fee_pg; 
              ?>
              <div class=" form-group">
                <p style="margin: 0">*Term</p>
                <p>Will be reduced by the transaction fee Rp. <?php echo number_format($fee_pg,0,".",".");?></p>
              </div>
							<div  class=" form-group">
								
								<label class="check_custom" style="font-weight: normal;"> Same information as virtual account
                  <input type="checkbox" onchange="checkedData()" id="data_bank">
                  <span class="check_mark"></span>
                </label>
							</div>
							<div class="form-group" style="text-align: center">
								<button type="submit" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%; margin-top: 2%; background-color: orange; width: 100%; color: black;height: 30px;" ><b>Proses Withdrawal</b></button>	
							</div>
                            </form>
								
						</div>
							<div class="col-md-4 col-sm-12 col-xs-12">

							</div>
				</div>
			</div>
		</div>
	</div>
</section>

<script type="text/javascript">
  var i=0;
    function checkedData(){
      if(i%2==0){
        // console.log('');
        $.ajax({
            url: <?php echo "'". site_url("Finance/F_lender/withdrawal_prosses_get_same_data")."'";?>,
            type: 'POST',
            dataType: 'json',
            data: $('#data_bank').serialize(),
            timeout: 180000,

            success: function(data) {
                console.log(data);
                $('#your_bank_name').val(data.your_bank_name);
                $('#bank_name').val(data.bank_name);
                $('#bank_account').val(data.bank_account);
                $('#bank_branch').val(data.bank_branch);

                $('#your_bank_name').attr('readonly',true);
                $('#bank_name').attr('readonly', true);
                $('#bank_account').attr('readonly', true);
                $('#bank_branch').attr('readonly', true);

               
            },
            error: function(x, t, m) {

            }
        });
      }else{
        $('#your_bank_name').val('');
        $('#bank_name').val('');
        $('#bank_account').val('');
        $('#bank_branch').val('');

        $('#your_bank_name').removeAttr('readonly',true);
        $('#bank_name').removeAttr('readonly', true);
        $('#bank_account').removeAttr('readonly', true);
        $('#bank_branch').removeAttr('readonly', true);   
      }
      i++;
    }
    
</script>
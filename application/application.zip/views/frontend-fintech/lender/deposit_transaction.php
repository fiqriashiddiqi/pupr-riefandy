 <?php date_default_timezone_set("Asia/Jakarta"); ?>
  <style>
  /* The check_custom */
  .check_custom {
      position: relative;
      padding-left: 35px;
      margin-bottom: 12px;
      margin-right: 10px;
      cursor: pointer;
      font-size: 15px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
  }

  /* Hide the browser's default checkbox */
  .check_custom input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
  }

  /* Create a custom checkbox */
  .check_mark {
      position: absolute;
      top: 0;
      left: 0;
      height: 25px;
      width: 25px;
      background-color: #eee;
  }

  /* On mouse-over, add a grey background color */
  .check_custom:hover input ~ .check_mark {
      background-color: #ccc;
  }

  /* When the checkbox is checked, add a blue background */
  .check_custom input:checked ~ .check_mark {
      background-color: #ffd100;
  }

  /* Create the check_mark/indicator (hidden when not checked) */
  .check_mark:after {
      content: "";
      position: absolute;
      display: none;
      border-radius: 10%;
  }

  /* Show the check_mark when checked */
  .check_custom input:checked ~ .check_mark:after {
      display: block;
  }

  /* Style the check_mark/indicator */
  .check_custom .check_mark:after {
      left: 10px;
      top: 7px;
      width: 7px;
      height: 10px;
      border: solid white;
      border-width: 0 3px 3px 0;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
  }

  .nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus {
    color: orange;
    cursor: default;
    background-color: #fff;
    border: 1px solid #ddd;
    border-bottom-color: transparent;
}

.accordion {
    background-color: #dadada;
    color: #444;
    cursor: pointer;
    padding-left: 12px;
    padding-right: 18px;
    padding-top: 5px;
    padding-bottom: 5px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 15px;
    transition: 0.4s;
    font-family: FontAwesome;
}

.active_li, .accordion:hover {
    background-color: #ccc;
}

.accordion:before {
	content: "\f055";
    color: #777;
    font-weight: bold;
    float: right;
    margin-left: 15px;
}

.active_li:before {
   	content: "\f056";
}

.panel {
    padding: 0 18px;
    background-color: white;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
}
  </style>
	
<section class="container home" >
	<div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
		<div class="container div-feedback" >
			<div class="row" style="background-color: white; margin-bottom: 2%; padding: 20px;">
				<div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
					<br>
					<h3><p><b>TOP-UP BALANCE </b></p></h3>
					
				</div>
				<div class="col-md-7 col-sm-12 col-xs-12" style=" margin-bottom: 2%; margin-top: 10px;" >
					<div class=" form-group"  style="text-align: left;">
						<p>Several ways to deposit</p>
					
						  <ul class="nav nav-tabs ">
						    <li class="active"><a href="#InternetBank" data-toggle="tab">Internet Banking</a></li>
						    <li><a href="#atm" data-toggle="tab">ATM</a></li>
						    <li><a href="#bank" data-toggle="tab">Bank Teller</a></li>
						    <li><a href="#mobile" data-toggle="tab">Mobile Banking</a></li>
						    <li><a href="#other" data-toggle="tab">Other</a></li>
						  </ul>
					</div>

					<div class="tab-content">
             			  <div class="active tab-pane" id="InternetBank">
             			  	<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('Internet Banking');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>
             			 <div class="tab-pane" id="atm">
							<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('ATM');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>
					
             			<div class="tab-pane" id="bank">
							<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('Bank Teller');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>
					
             			<div class="tab-pane" id="mobile">
							<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('Mobile Banking');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>

						<div class="tab-pane" id="other">
							<?php
             			  		@$data_faq = $this->parameter_all_model->get_faq_by_category('Other');

             			  		foreach ($data_faq as $faq_entry) {
             			  			
             			  	?>
							<div class="panel-group "  role="tablist" aria-multiselectable="true">
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_entry->question_faq;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_entry->answer_faq;?></p>
									</div>
						        
							</div>
							<?php 
								}
							?>
						</div>

					</div>

				</div>
			
				<!-- <div class="col-md-6 col-sm-12 col-xs-12" style="margin-bottom: 2%; " >
					<div class=" form-group"  style="text-align: center;">
						<P>Virtual Account</P>
						<p>Please deposit to this account</p>
					</div>
					<div class=" form-group" >
						<label> Name</label>
						<input type="text" placeholder=" Name " name="name" class=" form-control">
					</div>
					<div class=" form-group" >
						<label> Virtual Account Number</label>
						<input type="text" placeholder="  Virtual Account " name="virual_account" class=" form-control">
					</div>
					<hr style="border: 1px solid; color: black; " > 
					
					<div class=" form-group" >
						<label> Bank Name</label>
						<input type="text" placeholder=" Total Invested " class=" form-control">
					</div>
						<div class=" form-group" >
						<label> Branch </label>
						<input type="text" placeholder=" Reserve Fund " class=" form-control">
					</div>
					<div class=" form-group" >
						<label> Reference Code</label>
						<input type="text" placeholder=" Available Fund " class=" form-control">
					</div>
						
					
				</div> -->
							
				<div class="col-md-5 col-sm-12 col-xs-12" >
                    <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
					<div class=" form-group"  style="text-align: center;">
						
					<P> &nbsp </P>
					<p>Your Bank Account Information</p>
                    <input type="hidden" placeholder="Amount" name="register_code" value="<?php echo $get_code;?>" class="form-control" required="required">
					</div>
					<div class=" form-group" >
						<label> Amount </label>
						<input type="text" class="form-control dengan-rupiah" placeholder="Amount" name="deposit_amount"  required="required">
					</div>
					<div class=" form-group" >
						<label>Name</label>
						<input type="text" class="form-control" placeholder="Name" name="deposit_name" value="<?php echo @$data_code[0]->your_bank_name ; ?>"  required="required">
					</div>
					<div  class=" form-group">
						<label>Account Number</label>
						<input type="number" class="form-control" placeholder="Account Number" name="deposit_account" value="<?php echo @$data_code[0]->bank_account; ?>" required="required">
					</div>
					<div class=" form-group">
						<label> Bank Name </label>
						<input type="text" class="form-control" placeholder="Bank" name="deposit_bank_name" value="<?php echo @$data_code[0]->bank_name;?>" required="required">
					</div>
					<div class=" form-group">
						<label> Branch </label>
						<input type="text" class="form-control" name="deposit_branch" value="<?php echo @$data_code[0]->bank_branch; ?>" required="required">
					</div>

					<!-- <div  class=" form-group">
								<label class="check_custom" style="font-weight: normal;"> Same information as virtual account
		                          <input type="checkbox" name="" >
		                          <span class="check_mark"></span>
		                        </label>
					</div> -->
					<div class="form-group" style="text-align: center;" >
						
						<button type="submit" class="btn btn-warning btn-sm btnwdt" style="margin-bottom: 4%;background-color: orange;width: 100%;height: 30px;" >Transaction</button>	
					</div>
                    </form>
                    <hr style="border: 1px solid; color: grey; " >
                    <div class=" form-group"  style="text-align: left;">
							<p>Term :</p>
						</div>
						<div class=" form-group"  style="text-align: left;">
							<p>All transfer fee will be your cost</p>
						</div>
						<div class=" form-group"  style="text-align: left;">
							<p>Please Allow 1 X 24 hour for the balance to be update </p>
						</div>
						<div class=" form-group"  style="text-align: left;">
							<p>Please contact us if you have other questions </p>
						</div>

						<div class=" form-group" >
							<label> Email </label>
							<input type="text" value="<?php echo $data_contact[0]->contact_us_email; ?>" class=" form-control" disabled="">
						</div>
						<div  class=" form-group">
							<label> Phone </label>
							<input type="text" value="<?php echo $data_contact[0]->contact_us_phone; ?>" class=" form-control" disabled="">
						</div>
						<div  class=" form-group">
							<label> Whatsapp </label>
							<input type="text" value="<?php echo $data_contact[0]->contact_us_phone; ?>" class=" form-control" disabled="">
						</div>	

				</div>
						<hr style="border: 1px solid; color: grey; " >
				
						<!-- 		
					<div class="col-md-6 col-sm-12 col-xs-12" >
						
						
					</div> -->
					<div class="col-md-12 col-sm-12 col-xs-12">
                        <br>
							<div class=" form-group" style="text-align: center; ">
								<label> Deposit History</label>
								<div class="table-responsive">
								  	<table class="table table-bordered">
								    	<thead>
										    <tr style="background-color: #726f6f;color: white">
										      <th style="width: 10px;">No</th>
										      <th style="text-align: center;width: 200px;">Date</th>
                                              <th style="text-align: center;width: 170px;">Bank</th>
										      <th style="text-align: center;">Amount</th>
										      <th style="text-align: center;width: 150px;">Status</th>
										    </tr>
										  </thead>
										  <tbody>
										  	<?php
								                $this->load->model("crud_model");
							                    $data_setting = $this->crud_model->get_setting();
							                    $limit   = $data_setting[0]->setting_pagination;
								                $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

								                
								                if(empty($page)){
								                    $position  = 0;
								                    $page = 1;
								                } else {
								                    $position = ($page-1) * $limit;
								                }

								                $this->load->model('Front_Fintech/bank_model');
								                $data_code = $this->bank_model->get_bank_deposit($get_code,$limit,$position)->result();
								                $no = $position+1;
								                   foreach ($data_code as $code_entry){
								                 
								            ?>
										    <tr style="background-color: aliceblue;">
										      <th><?php echo $no;?></th>
										      <td><?php echo $code_entry->deposit_date;?></td>
                                              <td><?php echo $code_entry->deposit_bank_name;?></td>
										      <td align="right"><?php echo number_format($code_entry->deposit_amount,0,".",".");?></td>
										      <td><?php echo $code_entry->deposit_status;?></td>
										    </tr>
										    <?php 
							                $no++;
							                }?>
										  </tbody>

								  	</table>
									<?php
						            $data_rows = $this->bank_model->get_bank_deposit($get_code)->num_rows();
						            $all_page  = ceil($data_rows/$limit);
						            ?>
						            <center>
						                <ul class="pagination">
						                    <li>
						                        <?php
						                            if($page > 1){
						                                $prev = $page-1;
						                                echo "<a href='".base_url()."Finance/F_lender/deposit?page=$prev'>Previous</a>";
						                            }
						                        ?>
						                    </li>
						                    <li>
						                        <?php
						                            for($i=1;$i<=$all_page;$i++)
						                                if ($i != $page){
						                                    echo "<a href='".base_url()."Finance/F_lender/deposit?page=$i'>$i</a>";
						                                }
						                        ?>
						                        </li>
						                        <li>
						                        <?php
						                            if($page < $all_page){
						                                $next=$page+1;
						                                echo "<a href='".base_url()."Finance/F_lender/depositpage=$next'>Next</a>";
						                            }
						                        ?>
						                    </li>
						                </ul>
						            </center>
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
	
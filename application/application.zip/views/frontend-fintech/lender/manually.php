<?php date_default_timezone_set("Asia/Jakarta"); ?>
<style type="text/css">
    table, th, td {
        border: 1px solid #726f6f;
    }
</style>
<style>
    .tool_tip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }
    
    .tool_tip .tool_tiptext {
        visibility: hidden;
        width: 180px;
        background-color: black;
        color: #fff;
        text-align: center;
        border-radius: 0px;
        padding: 5px 0;
    
        /* Position the tool_tip */
        position: absolute;
        z-index: 1;
    }
    
    .tool_tip:hover .tool_tiptext {
        visibility: visible;
    }


</style>
<section class="container home">
    <div class="row" style="margin-top: 5%;  margin-bottom: 5%;">
        <div class="container div-feedback">
            <div class="col-md-12">
                <br>
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible" style="background-color: #11a7119c !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible" style="background-color: #ff6b6bba !important; border-radius: 0px !important;padding-right: 35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban" style="font-size: 20px;"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
                <?php } ?>
            </div>

            <!-- Table Space -->
            <div class="col-md-12 col-sm-12 col-xs-12" style=" margin-bottom: 2%;">

                <div>
                    <center>
                        <br>
                        <h3 style="text-align: center;">
                            <p><b>Browse Loan Type </b></p>
                        </h3>
                        <br>
                        <div class="form-group">
                            <select class="form-control select2" name="" id="lender_manually" onchange="check_browse_manually();" style="width: 140px ; ">
                                        <option value="all">ALL</option>
                                        <option value="personal_loan">Personal Loan</option>
                                        <option value="fixed_loan">Fixed Loan</option>
                                        <option value="flexible_loan">Flexible Loan</option>                
                            </select>
                        </div>
                    </center>
                    <br>
                    <br>

                    <div class="tab-content">
                        <div class="active tab-pane" id="all">
                            <div class="table-responsive" style="margin-top: -2%;">
                                <table class="table">
                                    <tr style="background-color: lightgrey !important; ">
                                        <td style="text-align: center;">No</td>
                                        <td style="text-align: center;width: 100px;">Amount</td>
                                        <td style="text-align: center;">Loan ID</td>
                                        <td style="text-align: center;">Date</td>
                                        <td style="text-align: center;">Loan Purpose</td>
                                        <td style="text-align: center;">Rating</td>
                                        <td style="text-align: center; width: 89px">Effective Flat Rate</td>
                                        <td style="text-align: center;">Loan Amount</td>
                                        <td style="text-align: center;">Period</td>
                                        <td style="text-align: center; width: 95px;">Amount & Time Left</td>
                                        <td style="text-align: center;">Action</td>
                                    </tr>
                                    <tr>

                                        <?php

                                        $this->load->model("crud_model");
                                          $data_setting = $this->crud_model->get_setting();
                                          $limit   = $data_setting[0]->setting_pagination;
                                          $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

                                          
                                          if(empty($page)){
                                              $position  = 0;
                                              $page = 1;
                                          } else {
                                              $position = ($page-1) * $limit;
                                          }

                                          $this->load->model('Front_Fintech/manually_model');
                                          $data_manually = $this->manually_model->get_manually($limit,$position)->result();
                                          

                                  if ($data_manually != null) {
                                    $this->load->model('Front_Fintech/manually_model');

                                     $no = $position+1;
                                     $no = 0;
                                    
                                    foreach ($data_manually as $manually_entry){
                                     $no++;
                                     @$check_manually = $this->manually_model->check_manually_invest($manually_entry->id_borrower_loan,$lend_code)->result();

                                  ?>
                                            <tr style="text-align: center;">
                                                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data" onsubmit="return confirm('The proposed loan can not be canceled. are you sure you want to apply for this loan?')">
                                                    <input type="hidden" name="loan_code" value="<?php echo $manually_entry->id_borrower_loan; ?>" style="height: 20px;" required="true">
                                                    <td>
                                                        <?php echo $no; ?>
                                                    </td>
                                                    <?php
                                                    if ($manually_entry->amount_left == 0){
                                                    ?>
                                                    <td>Rp. <?php echo number_format(@$check_manually[0]->amount_invest,0,".","."); ?></td>
                                                    <?php 
                                                    $display = 'none';
                                                    $displays = 'block';
                                                    } else if (@$check_manually[0]->id_borrower_loan != @$manually_entry->id_borrower_loan){
                                                    ?>
                                                    <td><input type="text" name="amount_invest" class="form-control" style="height: 20px;" required="true"></td>
                                                    <?php
                                                    $display = 'block';
                                                    $displays = 'none';
                                                    } else {
                                                    $display = 'none';
                                                    $displays = 'block'; ?>
                                                    <td>Rp. <?php echo number_format(@$check_manually[0]->amount_invest,0,".","."); ?></td>
                                                    <?php
                                                    }
                                                    ?>
                                                    <td><a href="<?php echo $manually_entry->id_borrower_loan;?>" data-toggle="modal" data-id="<?php echo $manually_entry->id_borrower_loan;?>" data-target="#myModal" class="tool_tip"><?php echo $manually_entry->id_borrower_loan; ?><span class="tool_tiptext">Click For Detail Information</span><span class="tool_tiptext">Click For Detail Information</span></a></td>
                                                    <td style="text-align: center;"><?php echo date('d/m/y', strtotime($manually_entry->loan_date)); ?></td>
                                                    <td>
                                                        <?php echo $manually_entry->loan_type; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $manually_entry->loan_rating ?>
                                                    </td>
                                                    <td>
                                                        <?php echo number_format($manually_entry->loan_flat_rate,2,".","."); ?>% <br>
                                                        <?php echo number_format($manually_entry->loan_rate,2,".","."); ?>%</td>
                                                    <td>Rp.
                                                        <?php echo number_format($manually_entry->loan_amount,0,".","."); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $manually_entry->loan_tenor; ?> mo</td>
                                                    <td>Rp.
                                                        <?php echo number_format($manually_entry->amount_left,0,".","."); ?><br>
                                                        <?php if ($manually_entry->amount_left > 0){ ?>
                                                        <input type="hidden" id="val<?php echo $no;?>" value="<?php echo $manually_entry->time_left;?>" style="text-align: center;">
                                                        <input type="hidden" id="ln<?php echo $no;?>" value="<?php echo $manually_entry->id_borrower_loan;?>" style="text-align: center;">
                                                        <input type="text" name="counter" id="<?php echo $no;?>" style="text-align: center;width: 70px; border:0px;" readonly>
                                                        <?php } ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <button type="submit" class="btn btn-info btn-sm btnwdt" style="width: 100%;height:30px;background-color: #ffc516;border-color: #ffc516;display: <?php echo @$display;?>">Invest</button>
                                                        <a href="javascript:void(0);" data-toggle="tooltip" title="This loan has been fulfilled!" data-placement="bottom" style="display: <?php echo @$displays;?>"><i class="fa fa-info-circle" style="margin-left: 4px"></i></a>
                                                        
                                                    </td>
                                                </form>
                                            </tr>

                                            <?php
                                     
                                 }
                                 
                                 } else {
                                ?>
                                                <tr style="background-color: whitesmoke;">
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <?php 
                                 } 
                                ?>
                                </table>
                                <?php
                                    $data_rows = $this->manually_model->get_manually()->num_rows();
                                    $all_page  = ceil($data_rows/$limit);
                                    ?>
                                    <center>
                                    <ul class="pagination">
                                        <li>
                                            <?php
                                                if($page > 1){
                                                    $prev = $page-1;
                                                    echo "<a href='".base_url()."Finance/F_lender/manually?page=$prev'>Previous</a>";
                                                }
                                            ?>
                                        </li>
                                        <li>
                                            <?php
                                                for($i=1;$i<=$all_page;$i++)
                                                    if ($i != $page){
                                                        echo "<a href='".base_url()."Finance/F_lender/manually?page=$i'>$i</a>";
                                                    }
                                            ?>
                                            </li>
                                            <li>
                                            <?php
                                                if($page < $all_page){
                                                    $next=$page+1;
                                                    echo "<a href='".base_url()."Finance/F_lender/manually?page=$next'>Next</a>";
                                                }
                                            ?>
                                        </li>
                                    </ul>
                                    </center>
                            </div>
                        </div>

                        <div class="tab-pane" id="personal_loan" style="display: none;">
                            <div class="table-responsive" style="margin-top: -2%;">
                                <table class="table">
                                    <tr style="background-color: lightgrey !important; ">
                                        <td style="text-align: center;">No</td>
                                        <td style="text-align: center;width: 100px;">Amount</td>
                                        <td style="text-align: center;">Loan ID</td>
                                        <td style="text-align: center;">Loan Purpose</td>
                                        <td style="text-align: center;">Rating</td>
                                        <td style="text-align: center; width: 89px">Effective Flat Rate</td>
                                        <td style="text-align: center;">Loan Amount</td>
                                        <td style="text-align: center;">Period</td>
                                        <td style="text-align: center; width: 95px;">Amount & Time Left</td>
                                        <td style="text-align: center;">Action</td>

                                        <tr>
                                            <?php

                                  $this->load->model("crud_model");
                                  $data_setting = $this->crud_model->get_setting();
                                  $limit   = $data_setting[0]->setting_pagination;
                                  $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

                                  
                                  if(empty($page)){
                                      $position  = 0;
                                      $page = 1;
                                  } else {
                                      $position = ($page-1) * $limit;
                                  }

                                  $this->load->model('Front_Fintech/manually_model');
                                  $data_consumtive = $this->manually_model->get_consumtive($limit,$position)->result();

                                 if ($data_consumtive != null) {
                                    $no = $position+1;                               
                                    $no=0;
                                    foreach ($data_consumtive as $consumtive_entry){
                                     $no++;
                                     @$check_manually = $this->manually_model->check_manually_invest($consumtive_entry->id_borrower_loan,$lend_code)->result();

                                  ?>
                                                <tr style="text-align: center;">
                                                    <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data" onsubmit="return confirm('The proposed loan can not be canceled. are you sure you want to apply for this loan?')">
                                                        <input type="hidden" name="loan_code" value="<?php echo $consumtive_entry->id_borrower_loan; ?>" style="height: 20px;" required="true">
                                                        <td>
                                                            <?php echo $no; ?>
                                                        </td>
                                                        <?php
                                                        if ($consumtive_entry->amount_left == 0){
                                                        ?>
                                                        <td>Rp. <?php echo number_format(@$check_manually[0]->amount_invest,0,".","."); ?></td>
                                                        <?php 
                                                        $display = 'none';
                                                        $displays = 'block';
                                                        } else if (@$check_manually[0]->id_borrower_loan != @$manually_entry->id_borrower_loan){
                                                        ?>
                                                        <td><input type="text" name="amount_invest" class="form-control" style="height: 20px;" required="true"></td>
                                                        <?php 
                                                        $display = 'block';
                                                        $displays = 'none';
                                                        } else {
                                                        $display = 'none';
                                                        $displays = 'block' ?>
                                                        <td>Rp. <?php echo number_format(@$check_manually[0]->amount_invest,0,".","."); ?></td>
                                                        <?php
                                                        }
                                                        ?>
                                                        <td><a href="javascript:void(0);" class="tool_tip" data-toggle="modal" data-id="<?php echo $consumtive_entry->id_borrower_loan;?>" data-target="#myModal"><?php echo $consumtive_entry->id_borrower_loan; ?><span class="tool_tiptext">Click For Detail Information</span></a></td>
                                                        <td>
                                                            <?php echo $consumtive_entry->loan_type; ?>
                                                        </td>
                                                        <td>
                                                            <?php echo $consumtive_entry->loan_rating ?>
                                                        </td>
                                                        <td>
                                                            <?php echo number_format($consumtive_entry->loan_flat_rate,2,".","."); ?>%<br>
                                                            <?php echo number_format($consumtive_entry->loan_rate,2,".","."); ?>%</td>
                                                        <td>Rp.
                                                            <?php echo number_format($consumtive_entry->loan_amount,0,".","."); ?>
                                                        </td>
                                                        <td>
                                                            <?php echo $consumtive_entry->loan_tenor; ?> months</td>
                                                        <td>Rp.
                                                            <?php echo number_format($consumtive_entry->amount_left,0,".","."); ?><br>
                                                        <?php if ($consumtive_entry->amount_left > 0){ ?>
                                                        <input type="hidden" id="val<?php echo $no;?>" value="<?php echo $consumtive_entry->time_left;?>" style="text-align: center;">
                                                        <input type="hidden" id="ln<?php echo $no;?>" value="<?php echo $consumtive_entry->id_borrower_loan;?>" style="text-align: center;">
                                                        <input type="text" name="counter" id="<?php echo $no;?>" style="text-align: center;width: 70px; border:0px;" readonly>

                                                        
                                                        <?php } ?>
                                                        </td>
                                                        <td class="text-center">
                                                            <button type="submit" class="btn btn-info btn-sm btnwdt" style="width: 100%;height:30px;background-color: #ffc516;border-color: #ffc516;display: <?php echo @$display;?>">Invest</button>
                                                            <a href="javascript:void(0);" data-toggle="tooltip" title="This loan has been fulfilled!" data-placement="bottom" style="display: <?php echo @$displays;?>"><i class="fa fa-info-circle" style="margin-left: 4px"></i></a>
                                                        </td>
                                                    </form>
                                                </tr>

                                                <?php
                                    }
                                   } else {
                                ?>
                                                    <tr style="background-color: whitesmoke;">
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <?php
                                   }
                                ?>

                                </table>
                                <?php
                                    $data_rows = $this->manually_model->get_consumtive()->num_rows();
                                    $all_page  = ceil($data_rows/$limit);
                                    ?>
                                    <center>
                                    <ul class="pagination">
                                        <li>
                                            <?php
                                                if($page > 1){
                                                    $prev = $page-1;
                                                    echo "<a href='".base_url()."Finance/F_lender/manually?page=$prev'>Previous</a>";
                                                }
                                            ?>
                                        </li>
                                        <li>
                                            <?php
                                                for($i=1;$i<=$all_page;$i++)
                                                    if ($i != $page){
                                                        echo "<a href='".base_url()."Finance/F_lender/manually?page=$i'>$i</a>";
                                                    }
                                            ?>
                                            </li>
                                            <li>
                                            <?php
                                                if($page < $all_page){
                                                    $next=$page+1;
                                                    echo "<a href='".base_url()."Finance/F_lender/manually?page=$next'>Next</a>";
                                                }
                                            ?>
                                        </li>
                                    </ul>
                                    </center>
                            </div>
                        </div>

                        <div class="tab-pane" id="fixed_loan" style="display: none;">
                            <div class="table-responsive" style="margin-top: -2%;">
                                <table class="table">
                                    <tr style="background-color: lightgrey !important; ">
                                        <td style="text-align: center;">No</td>
                                        <td style="text-align: center;width: 100px;">Amount</td>
                                        <td style="text-align: center;">Loan ID</td>
                                        <td style="text-align: center;">Loan Purpose</td>
                                        <td style="text-align: center;">Rating</td>
                                        <td style="text-align: center; width: 89px">Effective Flat Rate</td>
                                        <td style="text-align: center;">Loan Amount</td>
                                        <td style="text-align: center;">Period</td>
                                        <td style="text-align: center; width: 95px;">Amount & Time Left</td>
                                        <td style="text-align: center;">Action</td>
                                    </tr>
                                    <tr>
                                        <?php
                                          $this->load->model("crud_model");
                                          $data_setting = $this->crud_model->get_setting();
                                          $limit   = $data_setting[0]->setting_pagination;
                                          $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

                                          
                                          if(empty($page)){
                                              $position  = 0;
                                              $page = 1;
                                          } else {
                                              $position = ($page-1) * $limit;
                                          }

                                          $this->load->model('Front_Fintech/manually_model');
                                          $data_commercial_principal = $this->manually_model->get_commercial_principal($limit,$position)->result();
                                    if ($data_commercial_principal != null) {
                                    $no=$position+1;
                                    $no=0;
                                    foreach ($data_commercial_principal as $commercial_principal_entry){
                                     $no++;
                                     @$check_manually = $this->manually_model->check_manually_invest($commercial_principal_entry->id_borrower_loan,$lend_code)->result();

                                  ?>
                                            <tr>
                                                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data" onsubmit="return confirm('The proposed loan can not be canceled. are you sure you want to apply for this loan?')">
                                                    <input type="hidden" name="loan_code" value="<?php echo $commercial_principal_entry->id_borrower_loan; ?>" style="height: 20px;" required="true">
                                                    <td>
                                                        <?php echo $no; ?>
                                                    </td>
                                                    <?php
                                                    if ($commercial_principal_entry->amount_left == 0){
                                                    ?>
                                                    <td>Rp. <?php echo number_format(@$check_manually[0]->amount_invest,0,".","."); ?></td>
                                                    <?php 
                                                    $display = 'none';
                                                    $displays = 'block';
                                                    } else if (@$check_manually[0]->id_borrower_loan != @$manually_entry->id_borrower_loan){
                                                    ?>
                                                    <td><input type="text" name="amount_invest" class="form-control" style="height: 20px;" required="true"></td>
                                                    <?php 
                                                    $display = 'block';
                                                    $displays = 'none';
                                                    } else {
                                                    $display = 'none';
                                                    $displays = 'block' ?>
                                                    <td>Rp. <?php echo number_format(@$check_manually[0]->amount_invest,0,".","."); ?></td>
                                                    <?php
                                                    }
                                                    ?>
                                                    <td><a href="#" class="tool_tip" data-toggle="modal" data-id="<?php echo $commercial_principal_entry->id_borrower_loan;?>" data-target="#myModal"><?php echo $commercial_principal_entry->id_borrower_loan; ?><span class="tool_tiptext">Click For Detail Information</span></a></td>
                                                    <td>
                                                        <?php echo $commercial_principal_entry->loan_type; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $commercial_principal_entry->loan_rating ?>
                                                    </td>
                                                    <td>
                                                        <?php echo number_format($commercial_principal_entry->loan_flat_rate,2,".","."); ?>%<br>
                                                        <?php echo number_format($commercial_principal_entry->loan_rate,2,".","."); ?>%</td>
                                                    <td>Rp.
                                                        <?php echo number_format($commercial_principal_entry->loan_amount,0,".","."); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $commercial_principal_entry->loan_tenor; ?> months</td>
                                                    <td>Rp.
                                                        <?php echo number_format($commercial_principal_entry->amount_left,0,".","."); ?><br>
                                                        <?php if ($commercial_principal_entry->amount_left > 0){ ?>
                                                        
                                                        <input type="hidden" id="val<?php echo $no;?>" value="<?php echo $commercial_principal_entry->time_left;?>" style="text-align: center;">
                                                        <input type="hidden" id="ln<?php echo $no;?>" value="<?php echo $commercial_principal_entry->id_borrower_loan;?>" style="text-align: center;">
                                                        <input type="text" name="counter" id="<?php echo $no;?>" style="text-align: center;width: 70px; border:0px;" readonly>
                                                        <?php } ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <button type="submit" class="btn btn-info btn-sm btnwdt" style="width: 100%;height:30px;background-color: #ffc516;border-color: #ffc516;display: <?php echo @$display;?>">Invest</button>
                                                        <a href="javascript:void(0);" data-toggle="tooltip" title="This loan has been fulfilled!" data-placement="bottom" style="display: <?php echo @$displays;?>"><i class="fa fa-info-circle" style="margin-left: 4px"></i></a>
                                                    </td>
                                                </form>
                                            </tr>

                                            <?php
                                       }
                                    } else {
                                ?>
                                    <tr style="background-color: whitesmoke;">
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php
                                   }
                                ?>
                                    </tr>

                                </table>
                                <?php
                                    $data_rows = $this->manually_model->get_commercial_principal()->num_rows();
                                    $all_page  = ceil($data_rows/$limit);
                                    ?>
                                    <center>
                                    <ul class="pagination">
                                        <li>
                                            <?php
                                                if($page > 1){
                                                    $prev = $page-1;
                                                    echo "<a href='".base_url()."Finance/F_lender/manually?page=$prev'>Previous</a>";
                                                }
                                            ?>
                                        </li>
                                        <li>
                                            <?php
                                                for($i=1;$i<=$all_page;$i++)
                                                    if ($i != $page){
                                                        echo "<a href='".base_url()."Finance/F_lender/manually?page=$i'>$i</a>";
                                                    }
                                            ?>
                                            </li>
                                            <li>
                                            <?php
                                                if($page < $all_page){
                                                    $next=$page+1;
                                                    echo "<a href='".base_url()."Finance/F_lender/manually?page=$next'>Next</a>";
                                                }
                                            ?>
                                        </li>
                                    </ul>
                                    </center>
                            </div>
                        </div>

                        <div class="tab-pane" id="flexible_loan" style="display: none;">
                            <div class="table-responsive" style="margin-top: -2%;">
                                <table class="table">
                                    <tr style="background-color: lightgrey !important; ">
                                        <td style="text-align: center;">No</td>
                                        <td style="text-align: center;width: 100px;">Amount</td>
                                        <td style="text-align: center;">Loan ID</td>
                                        <td style="text-align: center;">Loan Purpose</td>
                                        <td style="text-align: center;">Rating</td>
                                        <td style="text-align: center; width: 89px">Effective Flat Rate</td>
                                        <td style="text-align: center;">Loan Amount</td>
                                        <td style="text-align: center;">Period</td>
                                        <td style="text-align: center; width: 95px;">Amount & Time Left</td>
                                        <td style="text-align: center;">Action</td>
                                    </tr>
                                    <tr>
                                        <?php

                                          $this->load->model("crud_model");
                                          $data_setting = $this->crud_model->get_setting();
                                          $limit   = $data_setting[0]->setting_pagination;
                                          $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

                                          
                                          if(empty($page)){
                                              $position  = 0;
                                              $page = 1;
                                          } else {
                                              $position = ($page-1) * $limit;
                                          }

                                          $this->load->model('Front_Fintech/manually_model');
                                          $data_commercial_revolver = $this->manually_model->get_commercial_revolver($limit,$position)->result();

                                    if ($data_commercial_revolver != null) {
                                    $no=0;
                                    foreach ($data_commercial_revolver as $commercial_revolver_entry){
                                     $no++;
                                     @$check_manually = $this->manually_model->check_manually_invest($commercial_revolver_entry->id_borrower_loan,$lend_code)->result();

                                  ?>
                                            <tr style="text-align: center;">
                                                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data" onsubmit="return confirm('The proposed loan can not be canceled. are you sure you want to apply for this loan?')">
                                                    <input type="hidden" name="loan_code" value="<?php echo $commercial_revolver_entry->id_borrower_loan; ?>" style="height: 20px;" required="true">
                                                    <td>
                                                        <?php echo $no; ?>
                                                    </td>
                                                    <?php
                                                    if ($commercial_revolver_entry->amount_left == 0){
                                                    ?>
                                                    <td>Rp. <?php echo number_format(@$check_manually[0]->amount_invest,0,".","."); ?></td>
                                                    <?php 
                                                    $display = 'none';
                                                    $displays = 'block';
                                                    } else if (@$check_manually[0]->id_borrower_loan != @$manually_entry->id_borrower_loan){
                                                    ?>
                                                    <td><input type="text" name="amount_invest" class="form-control" style="height: 20px;" required="true"></td>
                                                    <?php 
                                                    $display = 'block';
                                                    $displays = 'none';
                                                    } else {
                                                    $display = 'none';
                                                    $displays = 'block' ?>
                                                    <td>Rp. <?php echo number_format(@$check_manually[0]->amount_invest,0,".","."); ?></td>
                                                    <?php
                                                    }
                                                    ?>
                                                    <td><a href="#" class="tool_tip" data-toggle="modal" data-id="<?php echo $commercial_revolver_entry->id_borrower_loan;?>" data-target="#myModal"><?php echo $commercial_revolver_entry->id_borrower_loan; ?><span class="tool_tiptext">Click For Detail Information</span></a></td>
                                                    <td>
                                                        <?php echo $commercial_revolver_entry->loan_type; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $commercial_revolver_entry->loan_rating ?>
                                                    </td>
                                                    <td>
                                                        <?php echo number_format($commercial_revolver_entry->loan_flat_rate,2,".","."); ?>%<br>
                                                        <?php echo number_format($commercial_revolver_entry->loan_rate,2,".","."); ?>%</td>
                                                    <td>Rp.
                                                        <?php echo number_format($commercial_revolver_entry->loan_amount,0,".","."); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $commercial_revolver_entry->loan_tenor; ?> months</td>
                                                    <td>Rp.
                                                        <?php echo number_format($commercial_revolver_entry->amount_left,0,".","."); ?><br>
                                                        <?php if ($commercial_revolver_entry->amount_left > 0){ ?>
                                                        <input type="hidden" id="val<?php echo $no;?>" value="<?php echo $commercial_revolver_entry->time_left;?>" style="text-align: center;">
                                                        <input type="hidden" id="ln<?php echo $no;?>" value="<?php echo $commercial_revolver_entry->id_borrower_loan;?>" style="text-align: center;">
                                                        <input type="text" name="counter" id="<?php echo $no;?>" style="text-align: center;width: 70px; border:0px;" readonly>
                                                        <?php } ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <button type="submit" class="btn btn-info btn-sm btnwdt" style="width: 100%;height:30px;background-color: #ffc516;border-color: #ffc516;display: <?php echo @$display;?>">Invest</button>
                                                        <a href="javascript:void(0);" data-toggle="tooltip" title="This loan has been fulfilled!" data-placement="bottom" style="display: <?php echo @$displays;?>"><i class="fa fa-info-circle" style="margin-left: 4px"></i></a>
                                                    </td>
                                                </form>
                                            </tr>

                                <?php
                                   }
                                  } else {
                                ?>
                                                <tr style="background-color: whitesmoke;">
                                                    <td></td>
                                                    <td></td>
                                                    <!-- <td><?php echo $manually_entry->register_code ?></td> -->
                                                    <td></td>
                                                    <td></td>
                                                    <!-- <td><?php echo $manually_entry->loan_date; ?></td> -->
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>

                                                    <td></td>

                                                    <td></td>
                                                </tr>
                                <?php
                                   }
                                 
                                ?>
                                    </tr>

                                </table>
                                <?php
                                    $data_rows = $this->manually_model->get_commercial_revolver()->num_rows();
                                    $all_page  = ceil($data_rows/$limit);
                                    ?>
                                    <center>
                                    <ul class="pagination">
                                        <li>
                                            <?php
                                                if($page > 1){
                                                    $prev = $page-1;
                                                    echo "<a href='".base_url()."Finance/F_lender/manually?page=$prev'>Previous</a>";
                                                }
                                            ?>
                                        </li>
                                        <li>
                                            <?php
                                                for($i=1;$i<=$all_page;$i++)
                                                    if ($i != $page){
                                                        echo "<a href='".base_url()."Finance/F_lender/manually?page=$i'>$i</a>";
                                                    }
                                            ?>
                                            </li>
                                            <li>
                                            <?php
                                                if($page < $all_page){
                                                    $next=$page+1;
                                                    echo "<a href='".base_url()."Finance/F_lender/manually?page=$next'>Next</a>";
                                                }
                                            ?>
                                        </li>
                                    </ul>
                                    </center>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- end of table-->
            <!-- Wrapper for slides -->

            <div class="col-sm-12 col-xs-12 col-md-12">
                <h3><strong>On Going Investment</strong></h3>

                <div class="table-responsive" style="margin-top: 0%;">
                    <table class="table">
                        <tr style="background-color: lightgrey !important; ">
                            <td style="text-align: center;width: 8px;">No</td>
                            <td style="text-align: center;">Amount</td>
                            <td style="text-align: center;width: 90px;">Loan ID</td>
                            <td style="text-align: center;width: 45px;">Date</td>
                            <td style="text-align: center;width: 90px;">Loan Purpose</td>
                            <td style="text-align: center;width: 30px;">Rating</td>
                            <td style="text-align: center;width: 80px">Effective Flat Rate</td>
                            <td style="text-align: center;width: 110px;"">Loan Amount</td>
                            <td style="text-align: center;width: 30px;">Period</td>
                            <td style="text-align: center;width: 110px;">Amount & Time Left</td>
                        </tr>
                        <tr>

                            <?php
                            $this->load->model("crud_model");
                              $data_setting = $this->crud_model->get_setting();
                              $limit   = $data_setting[0]->setting_pagination;
                              $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

                              
                              if(empty($page)){
                                  $position  = 0;
                                  $page = 1;
                              } else {
                                  $position = ($page-1) * $limit;
                              }

                              $this->load->model('Front_Fintech/manually_model');
                              $data_manually_dis = $this->manually_model->get_manually_dis($limit,$position)->result();
                              $no = $position;
                               // var_dump($no);
                              // die();

                            // $this->load->model('Front_Fintech/manually_model');
                            
                            foreach ($data_manually_dis as $manually_entry){
                             
                             @$check_manually = $this->manually_model->check_manually_invest($manually_entry->id_borrower_loan,$lend_code)->result();

                             if (@$check_manually[0]->id_borrower_loan == @$manually_entry->id_borrower_loan){
                                
                            ?>
                                <tr style="text-align: center;">
                                        <td>
                                            <?php echo $no; ?>
                                        </td>
                                        <td>Rp.
                                            <?php echo number_format($check_manually[0]->amount_invest,0,".","."); ?></td>
                                        <td><a href="javascript:void(0);" class="tool_tip" data-toggle="modal" data-id="<?php echo $manually_entry->id_borrower_loan;?>" data-target="#myModal"><?php echo $manually_entry->id_borrower_loan; ?><span class="tool_tiptext">Click For Detail Information</span><span class="tool_tiptext">Click For Detail Information</span></a></td>
                                        <td style="text-align: center;"><?php echo date('d/m/y', strtotime($manually_entry->loan_date)); ?></td>
                                        <td>
                                            <?php echo $manually_entry->loan_type; ?>
                                        </td>
                                        <td>
                                            <?php echo $manually_entry->loan_rating ?>
                                        </td>
                                        <td>
                                            <?php echo number_format($manually_entry->loan_flat_rate,2,".","."); ?>% <br>
                                            <?php echo number_format($manually_entry->loan_rate,2,".","."); ?>%</td>
                                        <td>Rp.
                                            <?php echo number_format($manually_entry->loan_amount,0,".","."); ?>
                                        </td>
                                        <td>
                                            <?php echo $manually_entry->loan_tenor; ?> mo</td>
                                        <td>Rp.
                                            <?php echo number_format($manually_entry->amount_left,0,".","."); ?>
                                            <br>
                                            <?php if ($manually_entry->amount_left > 0){ ?>
                                            <input type="hidden" id="val<?php echo $no;?>a" value="<?php echo $manually_entry->time_left;?>" style="text-align: center;">
                                            <input type="hidden" id="ln<?php echo $no;?>a" value="<?php echo $manually_entry->id_borrower_loan;?>" style="text-align: center;">
                                            <input type="text" name="counter" id="<?php echo $no;?>a" style="text-align: center;width: 70px; border:0px;" readonly>
                                            <?php } ?>
                                        </td>
                                </tr>

                                <?php
                             }
                             $no++;
                         }  
                         
                         if ($no==0){
                        ?>
                                    <tr style="background-color: whitesmoke;">
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php 
                         } 
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg" style="width:1100px;">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">

            <div class="fetched-data"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="width: 70px;height: 30px;">Close</button>
                <a id="linkPdf"  class="btn btn-primary" style="width: 70px;height: 30px;"><i class="fa fa-download"></i>&nbsp;PDF</a>
            </div>
        </div>

    </div>
</div>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
        $('#myModal').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            // console.log(rowid);
            //menggunakan fungsi ajax untuk pengambilan data
            $.ajax({
                type : 'get',
                url : 'fact_sheet/'+rowid,
                success : function(data){
                $('.fetched-data').html(data);//menampilkan data ke dalam modal
                $('#linkPdf').attr('href', "<?php echo site_url('Export_Pdf/pdf_fact_sheet/'); ?>" + rowid);
                }
            });
         });
    });
  </script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
 
  <!-- Script Timer -->
<script type="text/javascript">
$(document).ready(function() {

    $('input[name=counter]').each(function () {

        var $this = $(this);
        var id = $this.attr("id");
        var val_time = document.getElementById('val'+id).value;
        var loan_code = document.getElementById('ln'+id).value;

        var hour = val_time.substr(0, 2);
        var minute = val_time.substr(3, 2);
        var second = val_time.substr(6, 2);

        /** Membuat Waktu Mulai Hitung Mundur Dengan 
        * var detik = 0,
        * var menit = 1,
        * var jam = 1
        */
        var detik = second;
        var menit = minute;
        var jam   = hour;
          
        /**
        * Membuat function hitung() sebagai Penghitungan Waktu
        */
        function hitung() {
            /** setTimout(hitung, 1000) digunakan untuk 
                * mengulang atau merefresh halaman selama 1000 (1 detik) 
            */
           setTimeout(hitung,1000);

           if(jam == 6 && menit == 0 && detik == 0){
                 //kirim email
                 console.log('MAIL');
           };

           // if(jam == 0 && menit == 0 && detik == 0){
           //       var jam = 0;
           //       var menit = 0;
           //       var detik = 0;
           // };
           //console.log(loan_code);
           /** Menampilkan Waktu Timer pada Tag #Timer di HTML yang tersedia */
            document.getElementById(id).value = (jam + ':' + menit + ':' + detik);

            var time_left = jam + ':' + menit + ':' + detik;

            // console.log(time_left);

            $.ajax({
                url: <?php echo "'". site_url("Finance/F_lender/time_left")."'";?>,
                type: 'POST',
                dataType: 'json',
                data: {time_left: time_left, id_borrower_loan: loan_code},
                timeout: 180000,
                beforeSend: function() {
                },
                success: function(data) {
                  //console.log(data);
                },
                error: function(x, t, m) {

                }
            });
            /** Melakukan Hitung Mundur dengan Mengurangi variabel detik - 1 */
            detik --;

            /** Jika var detik < 0
                * var detik akan dikembalikan ke 59
                * Menit akan Berkurang 1
            */
            if(detik < 0) {
                detik = 59;
                menit --;

                /** Jika menit < 0
                    * Maka menit akan dikembali ke 59
                    * Jam akan Berkurang 1
                */
                if(menit < 0) {
                    menit = 59;
                    jam --;

                    /** Jika var jam < 0
                        * clearInterval() Memberhentikan Interval dan submit secara otomatis
                    */
                    if(jam < 0) {                                                                 
                        clearInterval();  
                    } 
                } 
            } 

        }           

        /** Menjalankan Function Hitung Waktu Mundur */
        hitung();

    });
}); 
</script>
<script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip(); 
    });
</script>
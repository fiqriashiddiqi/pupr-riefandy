<style type="text/css">
    table, th, td {
        border: 1px solid #726f6f;
    }
</style>

<div class="table-responsive" style="margin-top: -2%;" >
        <div class="col-md-4 col-sm-12 col-xs-12">
            <p style="text-align: left;">Order History</p>
            <p style="text-align: left;"><?php echo date('F Y');?></p>
        </div>  
        <div class="col-md-4 col-sm-12 col-xs-12">
        </div>  
        <div class="col-md-4 col-sm-12 col-xs-12">
            <p style="text-align: right;"><?php echo $bio_fullname[0]->bio_fullname;?></p>
            <p style="text-align: right;"><?php echo $get_code;?></p>
        </div>  
    
    <table id="table-test" class="table" style="margin-top: 2%; background-color:#726f6f; text-align: center; width: 100%">
     <tr style="background-color: grey;color: white;" >
        <th style="text-align: center;">Order</th>
        <th style=" text-align: center;">Date</th> 
        <th style="text-align: center;">Amount </th>
        <th style="text-align: center;">Rating</th>
        <th style="text-align: center;">Rates</th>
        <th style="text-align: center;">Purpose</th>
        <th style="text-align: center;">Status</th>
    </tr>
    <?php foreach ($data_loan as $loan_entry) {?>
    <tr style="background-color: whitesmoke">
        <td><?php echo $loan_entry->id_borrower_loan ;?></td>
        <td><?php echo date('d-m-y', strtotime($loan_entry->loan_start_date));?></td>
        <td>Rp. <?php echo number_format($loan_entry->loan_amount,0,".","."); ?></td>
        <td><?php echo $loan_entry->loan_rating; ?></td>
        <td><?php echo $loan_entry->loan_rate; ?></td>
        <td><?php echo $loan_entry->loan_type; ?></td>
        <td><?php echo $loan_entry->loan_status; ?></td>
    </tr>
    <?php 
    } 
    ?>
    
     
    </table>
</div>
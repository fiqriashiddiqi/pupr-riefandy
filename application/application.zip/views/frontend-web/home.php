
<div class="compitable" style="display:none; background-color:#cf9b6f; text-align:center;padding:10px;color:white;font-weight:bold;font-size:16px">Website ini terbaik dilihat dengan browser Internet Explorer 11, Google Chrome 48, Mozilla Firefox 43, atau yang terbaru.</div>

    <!-- begin showcase-->
    <div class="showcase" style="padding-bottom: 15px;">
        <div class="container div-banner1" >
            <div class="row banner1">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="padding-left: 0;padding-right: 0">
                    <iframe width="100%" height="276" src="https://www.youtube.com/embed/<?php echo $data_video[0]->videos_url;?>?rel=0&controls=0&showinfo=0&autoplay=0" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen style="vertical-align: middle;"></iframe>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="title">
                        <?php echo $data_video[0]->videos_name;?>
                    </div>
                        
                    <div class="describe">
                        <?php echo $data_video[0]->videos_description;?>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- end showcase-->

    <div class="showcase showcase2" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png') !important; padding-bottom: 15px;">
        <div class="container" style="padding-top: 2%;border-top: 2px solid;">

            <div class="row">
                <div class="hero loading">
                    
                    <ul class="bxslider">
                        <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                                # code...
                        ?>
                        <li>
                            <img src="<?php echo base_url() ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%"/>
                            <div>
                                <br><br>
                                <h3 align="right"><?php echo $slideshow_entry->slideshow_name;?></h3>
                                <p align="justify"><small style="font-size:17px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

        </div>
    </div>

    <div class="showcase showcase2" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png') !important; padding-bottom: 15px;">
        <div class="wrap-register">
            <div class="container div-register">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="title-register"><a href="<?php echo site_url();?>Finance/f_login/login">REGISTER NOW ></a></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="showcase showcase2" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png') !important; padding-bottom: 15px;">
        <div class="container">   
                <div class="row">
                    <?php 
                        foreach ($data_artikel as $artikel_entry) {
                    ?>
                    <div class="col-md-4 col-sm-6 col-xs-12" >

                        <?php 
                            if ($artikel_entry->blog_media_status == "Picture"){
                        ?>
                        <div class="cont" style="padding-bottom: 10px;">
                            <img class="image" src="<?php echo base_url();?>uploads/Website/artikel/<?php echo $artikel_entry->blog_picture_url;?>" style="width: 100%;height: 180px;">
                            <div class="overlay">
                            <div class="title-box"><a href="<?php echo site_url('blog') ?>?blog=<?php echo $artikel_entry->id_website_blog;?>"><?php echo $artikel_entry->blog_name;?></a></div>
                            <div class="desc-box"><?php echo $artikel_entry->blog_description;?></div>
                            </div>
                        </div>
                        <?php 
                            } else {
                        ?>
                        <div class="cont" style="padding-bottom: 10px;">
                            <iframe class="videos" width="100%" height="180px" src="https://www.youtube.com/embed/<?php echo $artikel_entry->blog_video_url;?>?rel=0&controls=0&showinfo=0&autoplay=0" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen style="vertical-align: middle;"></iframe>
                            <div class="overlay">
                            <div class="title-box"><a href="<?php echo site_url('blog') ?>?blog=<?php echo $artikel_entry->id_website_blog;?>"><?php echo $artikel_entry->blog_name;?></a></div>
                            <div class="desc-box"><?php echo $artikel_entry->blog_description;?></div>
                            </div>
                        </div>
                        <?php
                            }
                        ?>

                    </div>
                    <?php
                        }
                    ?>
                </div>
        </div>
    </div>

    <section class="container home">
        <div class="row" style="background-color: white; margin-bottom: 15px;">
            <div class="container div-feedback">
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="title-feedback">Customers Feedback</h3>
                    </div>
                </div>
                <div class="row feedback">
                <?php 
                    foreach ($data_feedback as $feedback_entry) {
                ?>
                    <div class="col-md-4 col-sm-6 col-xs-12" align="center">
                        <div class="gallery">
                            <img src="<?php echo base_url();?>uploads/Website/feedback/<?php echo $feedback_entry->feedback_picture_url;?>" alt="Forest" width="300" height="200" style="border-radius: 50%;width: 160px;height: 160px;">
                            <div class="desc"><?php echo $feedback_entry->feedback_name;?></div>
                            <div class="desc2">"<?php echo $feedback_entry->feedback_description;?>"</div>
                        </div>
                    </div>
                <?php
                    }
                ?>  
                </div>
            </div>
        </div>
    </section>
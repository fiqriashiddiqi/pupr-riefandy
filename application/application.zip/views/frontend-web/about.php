		<?php
			$id_website_about_menu = isset($_REQUEST['pages']) ? $_REQUEST['pages'] : NULL;
			$this->load->model('about_model');
			$about_menu = $this->about_model->get_aboutmenu_by_id($id_website_about_menu);
			if (empty($id_website_about_menu)){

		?>

		<div class="showcase" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
        <div class="container" style="padding-top: 10px;">

            <div class="row">
                <div class="hero loading">
                    
                    <ul class="bxslider">
                        <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                                # code...
                        ?>
                        <li>
                            <img src="<?php echo base_url() ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%"/>
                            <div>
                            	<br><br>
                                <h3 align="right"><?php echo $slideshow_entry->slideshow_name;?></h3>
                                <p align="justify"><small style="font-size:17px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

        </div>
    	</div>

    	<?php
    		}
		?>

		<div class="showcase" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
				 <div class="container" style="padding-top: 10px;padding-bottom: 5px;">

				<div class="row">
				<?php
    			if (!empty($id_website_about_menu)){
				?>
					<div class="hero loading">
					  <ul class="bxslider">
					  	<?php 
								
				            	if ($about_menu[0]->about_menu_media_status == "Picture"){
				            		foreach ($data_slideshow_product as $slideshow_product_entry) {
				            ?>
						    	<li>
				                	<img src="<?php echo base_url();?>uploads/Website/slideshow/<?php echo $slideshow_product_entry->slideshow_url;?>" width=100%/>
				                    	<div align="justify">
				                    		<br><br>
				                        	<h3><?php echo $slideshow_product_entry->slideshow_name;?></h3>
				                            <p style="text-align:justify;"><small style="font-size:17px;"><?php echo substr($slideshow_product_entry->slideshow_description,0,210) ;?></small></p>
				                        	<div class="control-wrap"></div>
				                         </div>
				                </li>
				                	<?php 
				                        }
				                        } else {
				                        ?>
				                        <iframe width="100%" height="320" src="https://www.youtube.com/embed/<?php echo $about_menu[0]->about_menu_video_url;?>?rel=0&controls=0&showinfo=0&autoplay=0" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen style="vertical-align: middle;"></iframe>
				            <?php
				                }
				            ?>
				                        
					  	</ul>  
					</div>

				<?php
				}
					if (empty($id_website_about_menu)){
				?>
  				
				<div class="hot-product-feed hidden-xs hidden-sm" style="padding-right: 0; padding-left: 0;">

					<?php
						
						foreach ($data_aboutmenu as $aboutmenu_entry) {
							# code...
					?>
					<div class="col-md-4 col-sm-12 col-xs-12" style="margin-bottom: -28px;">
						<div class="cont">
							<a href="<?php echo site_url('about');?>?pages=<?php echo $aboutmenu_entry->id_website_about_menu; ?>">
							<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"><h4><strong><?php echo $aboutmenu_entry->about_menu_name; ?></strong></h4></div>
						  	<img class="image" src="<?php echo base_url();?>uploads/base-img/bgorange.jpg" style="width: 100%;height: 110px;">
						  	</a>
						</div>
					</div>
					<?php
 						}
					?>

					<div class="col-md-4 col-sm-12 col-xs-12" style="margin-bottom: -28px;">
						<div class="cont">
							<a href="<?php echo site_url('management');?>">
							<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"><h4><strong>Management</strong></h4></div>
						  	<img class="image" src="<?php echo base_url();?>uploads/base-img/bgorange.jpg" style="width: 100%;height: 110px;">
						  	</a>
						</div>
					</div>
				</div>
				<?php
					}
				?>
				</div>
			</div>
			  
		</div>

		<section class="container home">
		    <div class="row" style="background-color: white; margin-bottom: 15px;">
		        <div class="container div-feedback">
		            <div align="justify" class="row feedback" style="margin-left: 10px; margin-top: 10px; margin-right: 10px;">
		                <?php 
							if (empty($id_website_about_menu)){
								?><br><h2><center><b>SANDERS ONE STOP SOLUTION</b></center></h2><br><?php
								echo @$data_about[0]->about_description;
							} 
							if ($id_website_about_menu == 9){
								?><br><h2><center><b>Vision & Mission</b></center></h2><br><?php
								echo @$about_menu[0]->about_menu_description;
							}	
							if ($id_website_about_menu == 10){
								?><br><h2><center><b>Product & Service</b></center></h2><br><?php
								echo @$about_menu[0]->about_menu_description;	
							}
						?>
		            </div>
		        </div>
		    </div>
    	</section>

		<div class="showcase showcase2" style="background-image:url('uploads/base-img/img_home/bg.png') !important; padding-bottom: 15px;">
	        <div class="wrap-register">
	            <div class="container div-register">
	                <div class="row">
	                    <div class="col-md-12">
	                        <h2 class="title-register"><a href="<?php echo site_url();?>Finance/f_login/login">JOIN NOW AND GROW TOGETHER WITH US ></a></h2>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
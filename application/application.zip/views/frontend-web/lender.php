<div class="compitable" style="display:none; background-color:#cf9b6f; text-align:center;padding:10px;color:white;font-weight:bold;font-size:16px">Website ini terbaik dilihat dengan browser Internet Explorer 11, Google Chrome 48, Mozilla Firefox 43, atau yang terbaru.</div>

    <div class="showcase" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
        <div class="container" style="padding-top: 10px;padding-bottom: 5px;">

            <div class="row">
                <div class="hero">
                    
                    <ul class="bxslider">
                        <?php 
                            if (@$data_artikel[0]->blog_media_status == "Picture"){
                        ?>
                        <li>
                            <img src="<?php echo base_url();?>uploads/Website/artikel/<?php echo $data_artikel[0]->blog_picture_url;?>" width="100%"/>
                            <div>
                                
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                        <?php 
                            } else {
                        ?>
                            <iframe width="100%" height="320" src="https://www.youtube.com/embed/<?php echo $data_artikel[0]->blog_video_url;?>?rel=0&controls=0&showinfo=0&autoplay=0" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen style="vertical-align: middle;"></iframe>
                        <?php
                            }
                        ?>
                        

                    </ul>

                </div>
            </div>

        </div>
    </div>

    <section class="container home">
        <div class="row" style="background-color: white; margin-bottom: 15px;">
            <div class="container div-feedback">
                <br><h2><center><b>Investor (Pemberi Pinjaman)</b></center></h2>
                <div align="justify" class="row feedback" style="margin-left: 10px; margin-top: 10px; margin-right: 10px;">
                <?php 
                        echo @$data_artikel[0]->blog_description;
                    ?> 
                </div>
            </div>
        </div>
    </section>

    <div class="showcase showcase2" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png') !important; padding-bottom: 15px;">
        <div class="wrap-register">
            <div class="container div-register">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="title-register"><a href="<?php echo site_url();?>Finance/f_login/login">JOIN NOW AND GROW TOGETHER WITH US ></a></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
			
		<div class="showcase" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bghead.png') !important; padding-bottom: 15px;">
			<div class="container" style="padding-top: 10px;padding-bottom: 5px;">
				<div class="row">

				<?php
					$id_website_about_menu = isset($_REQUEST['pages']) ? $_REQUEST['pages'] : NULL;

					if (empty($id_website_about_menu)){

				?>

					<div class="hero">
					  <!-- Indicators -->
					  <ul class="bxslider">
					  	<?php 
				        	$id_website_about_menu = isset($_REQUEST['pages']) ? $_REQUEST['pages'] : NULL;
							$this->load->model('about_model');
							$about_menu = $this->about_model->get_aboutmenu_by_id($id_website_about_menu);

				            if (@$data_aboutmenu[0]->about_menu_media_status == "Picture"){
				            ?>
						    	<li>
				                	<img src="<?php echo base_url();?>uploads/Website/about_menu/<?php echo $data_aboutmenu[0]->about_menu_picture_url;?>" />
				                    	<div>
				                    		<br><br>
				                        	<h3><?php echo $data_aboutmenu[0]->about_menu_name;?></h3>
				                            <p><small style="font-size:17px;"><?php echo substr($data_aboutmenu[0]->about_menu_description,0,210) ;?></small></p>
				                        	<div class="control-wrap"></div>
				                         </div>
				                </li>
				                	<?php 
				                        } else {
				                        ?>
				                        <iframe width="100%" height="320" src="https://www.youtube.com/embed/<?php echo $data_aboutmenu[0]->about_menu_video_url;?>?rel=0&controls=0&showinfo=0&autoplay=0" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen style="vertical-align: middle;"></iframe>
				                        <?php
				                            }
				                        ?>
				                        
					  	</ul>
					  	<?php
				                            }
				                        ?>
					  <!-- Wrapper for slides -->
					  
					</div>
				
				</div>
		</div>   
	</div>
<section class="container home">
	<div class="row" style="background-color: white; margin-bottom: 15px;">
		<div class="container div-feedback">
			<br><h2><center><b>Management</b></center></h2>
			<div class="row ">
				<div align="justify" class="col-md-12 col-sm-12 col-xs-12">

					<p style="text-align: justify;">
						<?php echo $data_management[0]->management_description;?>
					</p>
				</div>
			</div>
			<div class="row ">
				<div class="col-md-4 col-sm-4 col-xs-12">
					<?php
							
					foreach ($data_managementmenu as $management_menu_entry) {
						$managementmenu_name = isset($_REQUEST['managementmenu_name']) ? $_REQUEST['managementmenu_name'] : NULL;

						if(empty($managementmenu_name)){
						$managementmenu_name = $data_managementmenu[0]->management_menu_name;
						}

						if ($managementmenu_name == $management_menu_entry->management_menu_name){
							$style_href = "orange";
						} else {
							$style_href = "black";
						}

						?>
						<a style="color: <?php echo @$style_href;?>" href="<?php echo site_url('management'); ?>?managementmenu_name=<?php echo $management_menu_entry->management_menu_name;?>"><h3><?php echo $management_menu_entry->management_menu_name;?></h3></a>
					<?php
						}
					?>
				</div>
				<div class="col-md-8 col-sm-8 col-xs-12">
						<?php
						$managementmenu_name = isset($_REQUEST['managementmenu_name']) ? $_REQUEST['managementmenu_name'] : NULL;

						if (empty($managementmenu_name)){
							$managementmenu_name = $data_managementmenu[0]->management_menu_name;
						} 

						$this->load->model('management_model');
						$managementmenu_data = $this->management_model->get_managementmenu_by_name($managementmenu_name);

						foreach ($managementmenu_data as $managementmenu_data_entry) {
						?>
						<div class="col-md-6 col-sm-12 col-xs-12" align="center">
						<div class="gallery">
							<br>
							<img src="<?php echo base_url();?>uploads/Website/management_menu/<?php echo $managementmenu_data_entry->management_menu_picture_url;?>" alt="Forest" width="300" height="200" style="border-radius: 50%;width: 160px;height: 160px;">
							<div class="desc"><?php echo $managementmenu_data_entry->management_menu_position;?><br><?php echo $managementmenu_data_entry->management_menu_person;?></div>
							<div class="desc2">"<?php echo $managementmenu_data_entry->management_menu_description;?>"</div>
						</div>
						</div>

						<?php
						} ?>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="showcase showcase2" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png') !important; padding-bottom: 15px;">
        <div class="wrap-register">
            <div class="container div-register">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="title-register"><a href="<?php echo site_url();?>Finance/f_login/login">JOIN NOW AND GROW TOGETHER WITH US ></a></h2>
                    </div>
                </div>
            </div>
        </div>
</div>
<body style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png');" class="desktopmode" id="home">

    <!-- begin header-->

    <header class="main-nav">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default navbar-header">
                    <div class="logo">
                        <a class="navbar-brand" href="<?php echo base_url();?>home">
                            <div class="logobcaheader">
                                <img class="img-responsive img-logo" src="<?php echo base_url() ?>uploads/base-img/img_home/logoSanders.png" style="height:50px;width:160px;margin-top:-5px">
                            </div>
                        </a>
                    </div>
                    <ul class="nav navbar-nav" style="font-size:17px;">
                        <li class="<?php echo @$lender_active;?>"><a href="<?php echo site_url('lender') ?> ">Investor</a></li>
                        <li class="<?php echo @$borrower_active;?>"><a href="<?php echo site_url('borrower') ?> ">Borrower</a></li>
                        <li class="<?php echo @$about_active;?>"><a href="<?php echo site_url('about') ?>">About</a></li>
                        <li class="<?php echo @$faq_active;?>"><a href="<?php echo site_url('faq') ?>">FAQ</a></li>
                    </ul>
                    <ul class="pull-right right-menu" style="margin-top: 22px;">
                        <li class="search">
                            <div class="sprites loopsprite"></div>
                        </li>

                        <li class="lng left lng-id"><a>INA</a></li>
                        <li class="lng right lng-en active"><a>ENG</a></li>

                        <li></li>

                    </ul>
                    <div class="pull-right">
                        <button style="margin-top: -8px;" type="button" class="navbar-toggle">
                        <div class="sprites spritemobile"></div>
                    </button>
                    </div>
                </nav>
            </div>
        </div>

        <style type="text/css">
        .active_li{
            background: #ffc516;
        }
        .active_link{
            background: #ffc516;
            color: black;
        }
        .active_link:hover{
            color:  white;
        }
        .deactive_link{
            background: #6d6d6d;
            color: white;
        }

        .href {
            color: white;
        }

        .href > a:hover{
            color:orange;
        }

        </style>

        <div class="hidden-xs hidden-sm" style="background: #6d6d6d !important; text-align: center; float: none; width: 100%; height: 60px; z-index: 9;padding-bottom: 15px;">
        <div style="margin: 0 auto; width: 100%;">
          <div style="width: 100%; position: relative; padding-left: 0.9375rem;padding-right: 0.9375rem; float: none;">
           
            <ul style="display: inline-block; padding: 10px 28px;">
                    <?php
                        
                        foreach ($data_aboutmenu as $aboutmenu_entry) {
                
                        $id_website_about_menu = isset($_REQUEST['pages']) ? $_REQUEST['pages'] : NULL;

                            if($id_website_about_menu == $aboutmenu_entry->id_website_about_menu){
                                $menu_li_active =  'class="active_li"';
                                $menu_a_active =  'active_link';

                            } else {
                                $menu_li_active =  '';
                                $menu_a_active =  'deactive_link';
                            }
                    ?>
                    <li <?php echo @$menu_li_active;?> class="href" style="display: inline-block; padding: 10px 28px;">
                            <a class="<?php echo @$menu_a_active;?>" href="<?php echo site_url('about');?>?pages=<?php echo $aboutmenu_entry->id_website_about_menu; ?>"><?php echo $aboutmenu_entry->about_menu_name; ?></a></li>
                    <?php
                        }
                    ?>

                    <li <?php echo @$managemen_li_active;?> style="display: inline-block; padding: 10px 28px;">
                            <a class="<?php echo @$managemen_a_active;?>" href="<?php echo base_url() ?>management">Management</a></li>        
                
            </ul>
          </div>
        </div>
      </div>
    </header>
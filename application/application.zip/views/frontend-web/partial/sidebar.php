<style type="text/css">
    .fa1 {
  font-size: 20px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
  border-radius: 50%;
}

.fa2 {
  font-size: 20px;
  text-align: center;
  text-decoration: none;
  
}

.fa {
  padding: 10px;
  font-size: 35px;
  width: 60px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-file-archive-o {
  background: #726f6f;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google-plus {
  background: #dd4b39;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-whatsapp {
  background: #25d366;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

.fa-pinterest {
  background: #cb2027;
  color: white;
}

.fa-snapchat-ghost {
  background: #fffc00;
  color: white;
  text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;
}

.fa-skype {
  background: #00aff0;
  color: white;
}

.fa-android {
  background: #a4c639;
  color: white;
}

.fa-dribbble {
  background: #ea4c89;
  color: white;
}

.fa-vimeo {
  background: #45bbff;
  color: white;
}

.fa-tumblr {
  background: #2c4762;
  color: white;
}

.fa-vine {
  background: #00b489;
  color: white;
}

.fa-foursquare {
  background: #45bbff;
  color: white;
}

.fa-stumbleupon {
  background: #eb4924;
  color: white;
}

.fa-flickr {
  background: #f40083;
  color: white;
}

.fa-yahoo {
  background: #430297;
  color: white;
}

.fa-envelope {
  background: #430297;
  color: white;
}

.fa-soundcloud {
  background: #ff5500;
  color: white;
}

.fa-reddit {
  background: #ff5700;
  color: white;
}

.fa-rss {
  background: #ff6600;
  color: white;
}

.href a, a:hover, a:focus {
    color: inherit;
    text-decoration: none;
    transition: all 0.3s;
}
</style>
<aside class="cls_widget">
        <div class="side-menu">
            <div class="right-menu pull-right">
                <span class="lng left lng-id active"><a>INA</a></span>
                <span class="lng right lng-en"><a>ENG</a></span>
                <span class="halo-bca">SANDERS</span>
            </div>
            <ul id="mobile-accordion1" class="nav">
                <li class="accordion-menu"><a href="<?php echo site_url('lender') ?> ">Investor</a></li>
                <li class="accordion-menu"><a href="<?php echo site_url('borrower') ?> ">Borrower</a></li>
                <li class="accordion-menu"><a href="<?php echo site_url('about') ?> ">About</a>
                    <span class="glyphicon glyphicon-chevron-down pull-right collapse_btn"></span>
                    <div class="accordion-collapse collapse in collapse_toogle">
                        <div class="accordion-body">
                            <ul class="nav nav-lev2">
                                
                                <?php
                        
                                    foreach ($data_aboutmenu as $aboutmenu_entry) {
                            
                                    $id_website_about_menu = isset($_REQUEST['pages']) ? $_REQUEST['pages'] : NULL;

                                       
                                ?>
                                <li class="accordion-menu">
                                        <a href="<?php echo site_url('about');?>?pages=<?php echo $aboutmenu_entry->id_website_about_menu; ?>"><?php echo $aboutmenu_entry->about_menu_name; ?></a></li>
                                <?php
                                    }
                                ?>

                                <li class="accordion-menu">
                                        <a href="<?php echo base_url() ?>management">Management</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="accordion-menu"><a href="<?php echo site_url('faq') ?> ">FAQ</a></li>
            </ul>
        </div>



        <div class="side-widget-wraper">
            <span class="glyphicon glyphicon-remove" style="display:none"></span>
            <ul class="side-widget">
                <li class="text-center menu">

                <a href="<?php echo base_url() ?>Finance/f_login/login">
                    <span><strong>Register</strong></span>
                    <div class="sidebarspr" style="display: inline-block;">
                        <img src="<?php echo base_url() ?>uploads/base-img/img_home/kontak.png" class="img-responsive" >
                    </div>
                </a>
                </li>
                <li class="text-center menu">
                    <a>
                    <span><strong>Contact</strong></span>
                    <div class="sidebarspr" style="display: inline-block;">
                        <img src="<?php echo base_url() ?>uploads/base-img/img_home/phone.png" class="img-responsive" >
                    </div>
                </a>
                    <div class="widget-content" id="widget-content-kursBCA" style="overflow:auto;">
                        <h3 style="color:black">Contact</h3>
                        
                            <img src="<?php echo base_url() ?>uploads/base-img/img_home/phone.png" class="img-responsive" style="width: 10%;margin-bottom: 10px" >
                            
                            <div class="description" style="color: black; font-size:16px;"><?php echo $data_contact[0]->contact_us_description; ?></div>
                            <!-- <div class="sub-headline" style="color: black;">Headquarter</div>
                            <div class="description" style="color: black;"><?php echo $data_contact[0]->contact_us_headquarter; ?></div> -->
                            <div class="description" style="color: black; font-size:16px;">Telepon&emsp; :&emsp; <?php echo $data_contact[0]->contact_us_phone; ?></div> 
                            <div class="description" style="color: black; font-size:16px;">Fax&emsp;&emsp;&emsp;:&emsp; <?php echo $data_contact[0]->contact_us_fax; ?></div>
                        
                    </div>
                </li>
                <li class="text-center menu">

                    <a>
                    <span><strong>Email</strong></span>
                    <div class="sidebarspr" style="display: inline-block;">
                        <img src="<?php echo base_url() ?>uploads/base-img/img_home/email.png" class="img-responsive" >
                    </div>
                </a>
                    <div class="widget-content" style="overflow:auto;">
                        <h3 style="color:black">Email</h3>
                        
                            <img src="<?php echo base_url() ?>uploads/base-img/img_home/email.png" class="img-responsive" style="width: 10%; margin-bottom: 10px">
                        
                            
                            <p style="color:black; font-size:16px;">Untuk informasi dan pertanyaan, silakan ajukan kepada kami melalui e-mail : <?php echo $data_contact[0]->contact_us_email; ?></p>
                        
                        
                        <div class="clearfix"></div>
                       
                    </div>
                </li>
                <li class="text-center menu">
                    <a>
                    <span><strong>Location</strong></span>
                    <div class="sidebarspr" style="display: inline-block;">
                        <img src="<?php echo base_url() ?>uploads/base-img/img_home/map.png" class="img-responsive" >
                    </div>
                </a>
                    <div style="overflow: auto;height:200px" class="widget-content scroll">
                            <h3 style="color:black">Location</h3>
                        
                            <img src="<?php echo base_url() ?>uploads/base-img/img_home/map.png" class="img-responsive" style="width: 10%;margin-bottom: 10px">
                        
                            
                            <p style="color:black; font-size:16px;"><?php echo $data_contact[0]->contact_us_address; ?></p>
                    </div>
                </li>
                <li class="text-center menu">
                    <a>
                    <span><strong>Share</strong></span>
                    <div class="sidebarspr" style="display: inline-block;">
                        <img src="<?php echo base_url() ?>uploads/base-img/img_home/share.png" class="img-responsive" >
                    </div>
                </a>
                    <div class="widget-content">
                        <h3>Share</h3>
                        <img src="<?php echo base_url() ?>uploads/base-img/img_home/share.png" class="img-responsive" style="width: 10%;margin-bottom: 10px">
                        
                        <div class="share-bca">
                            <div class="col-md-12">
                                <a href="facebook.com/<?php echo $data_contact[0]->contact_us_facebook; ?>" class="fa fa-facebook" style="font-size:35px;"></a>
                                <a href="twitter.com/<?php echo $data_contact[0]->contact_us_twitter; ?>" class="fa fa-twitter" style="font-size:35px;"></a>
                                <a href="<?php echo $data_contact[0]->contact_us_google_plus; ?>" class="fa fa-google-plus" style="font-size:35px;"></a>
                                <a href="<?php echo $data_contact[0]->contact_us_linkedin; ?>" class="fa fa-linkedin" style="font-size:35px;"></a>
                                
                            </div>
                            <div class="col-md-12">
                                <a href="<?php echo $data_contact[0]->contact_us_whatsapp; ?>" class="fa fa-whatsapp" style="font-size:35px;"></a>
                                <a href="<?php echo $data_contact[0]->contact_us_instagram; ?>" class="fa fa-instagram" style="font-size:35px;"></a>
                                <a href="mailto:<?php echo $data_contact[0]->contact_us_email; ?>" class="fa fa-envelope" style="font-size:35px;"></a>
                                <a href="#" class="fa fa-android" style="font-size:35px;"></a>
                            </div>

                          
                        </div>
                    </div>
                </li>
                <li class="text-center menu menu-hide"><i class="glyphicon glyphicon-chevron-down"></i></li>
            </ul>
            <div class="scroll-to-top text-center">
                <button class="bubble-icon bubble-blue-icon">
                <span><strong>UP</strong></span>
            </button>
            </div>
        </div>

        <span class="glyphicon glyphicon-chevron-left" style="display:none"></span>
    </aside>

    <script>
        $(document).ready(function(){

            $(".collapse_btn").click(function(){
                $(".collapse_toogle").collapse('toggle');
            });
        });
    </script>
    <script type="text/javascript">
    // $(document).bind("contextmenu",function(e) {
    //  e.preventDefault();
    // });

    // $(document).keydown(function(e){
    // if(e.which === 123){
    //    return false;
    // }
    // });


    </script>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/5a5575a2d7591465c7069726/default';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
    <!--End of Tawk.to Script-->
</body>
</html>
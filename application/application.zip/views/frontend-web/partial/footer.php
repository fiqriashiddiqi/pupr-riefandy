<footer>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="margin-top: 10px; margin-bottom: 10px;padding-left: 0;">
                <div class="contact-channel">
                    <div class="col-md-6 col-sm-12">
                        <div class="headline">Contact Us</div>
                        <div class="description"><?php echo $data_contact[0]->contact_us_description; ?></div>
                        <div class="sub-headline">Headquarter</div>
                        <div class="description"><?php echo $data_contact[0]->contact_us_headquarter; ?></div>
                        <br>
                        <div class="description">Telepon&emsp; :&emsp; <?php echo $data_contact[0]->contact_us_phone; ?></div> 
                        <div class="description">Fax&emsp;&emsp;&emsp;:&emsp; <?php echo $data_contact[0]->contact_us_fax; ?></div>
                        <div class="icon-link">
                            <ul class="nav navbar-nav">

                                <li class="col-md-3 text-center">
                                    <a href="javascript:void(Tawk_API.toggle())"> 
                                    <img src="<?php echo base_url() ?>uploads/base-img/img_home/logo-chat.png" alt="Chat Sanders">
                                    <p style="text-align: center;">Live Chat</p>
                                    </a>
                                </li>

                                <li class="col-md-3 text-center">
                                    <a href="mailto:<?php echo $data_contact[0]->contact_us_email; ?>">
                                    <img src="<?php echo base_url() ?>uploads/base-img/img_home/logo-email.png" alt="Mail to Sanders">
                                    <p style="text-align: center;">Email</p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <div class="col-md-6 col-sm-12"></div>
                    </div>

                    
                </div>
                </div>
            </div>

            <div class="row">
                <div class="footer">
                    <div class="text-link-pipped">
                        <ul class="nav navbar-nav">
                            <li><a href="<?php echo base_url() ?>Finance/f_login/login" style="font-size:11px">Register</a></li>
                            <li><a href="<?php echo site_url('simulation') ?> " style="font-size:11px">Simulation</a></li>
                            <li><a href="<?php echo site_url('feelimit') ?> " style="font-size:11px">Fee &amp; Limit</a></li>
                            <!-- <li><a href="<?php echo site_url('privacy') ?> " style="font-size:11px">Privacy</a></li> -->
                            <li><a href="<?php echo site_url('term') ?> " style="font-size:11px">Term & Condition</a></li>
                        </ul>
                    </div>

                    <div class="logo-link pn">
                        <div>
                            <div class="sprites ojksprite"></div>
                            <span style="color:#ffc516;"> Registered With & Supervised By OJK </span>
                            <div class="copyright pull-right" style="font-size:11px;margin-top:4px;">
                                Copyright (C) 2018 , All Rights Reserved
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    
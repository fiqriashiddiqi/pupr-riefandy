<body style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png');" class="desktopmode" id="home">

    <!-- begin header-->

    <header class="main-nav">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default navbar-header">
                    <div class="logo">
                        <a class="navbar-brand" href="<?php echo base_url();?>home">
                            <div class="logobcaheader">
                                <img class="img-responsive img-logo" src="<?php echo base_url() ?>uploads/base-img/img_home/logoSanders.jpg" style="height:50px;width:160px;margin-top:-5px">
                            </div>
                        </a>
                    </div>
                    <ul class="nav navbar-nav" style="font-size:17px;">
                        <li class="<?php echo @$lender_active;?>"><a href="<?php echo site_url('lender') ?> ">Investor</a></li>
                        <li class="<?php echo @$borrower_active;?>"><a href="<?php echo site_url('borrower') ?> ">Borrower</a></li>
                        <li class="<?php echo @$about_active;?>"><a href="<?php echo site_url('about') ?>">About</a></li>
                        <li class="<?php echo @$faq_active;?>"><a href="<?php echo site_url('faq') ?>">FAQ</a></li>
                    </ul>
                    <ul class="pull-right right-menu" style="margin-top: 22px;">
                        <li class="search">
                            <div class="sprites loopsprite"></div>
                        </li>

                        <li class="lng left lng-id"><a>INA</a></li>
                        <li class="lng right lng-en active"><a>ENG</a></li>

                        <li>
                        </li>

                    </ul>
                    <div class="pull-right">
                        <a href="javascript:void(Tawk_API.toggle())" class="visible-xs visible-sm hidden-md hidden-lg navbar-toggle" style="z-index: 2"> 
                                    <img src="<?php echo base_url() ?>uploads/base-img/img_home/logo-chat.jpg" alt="Chat Sanders" style="width: 30px;height: 30px;margin-top: -5px;margin-bottom: 0px;margin-left: 0px;margin-right: 48px;">
                        </a>
                        <button style="margin-top: -8px;z-index: 1;" type="button" class="navbar-toggle">
                        <div class="sprites spritemobile"></div>
                        </button>
                    </div>
                </nav>
            </div>
        </div>
    </header>
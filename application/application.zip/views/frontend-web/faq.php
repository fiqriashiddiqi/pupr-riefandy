<style>
.accordion {
    background-color: #dadada;
    color: #444;
    cursor: pointer;
    padding-left: 12px;
    padding-right: 18px;
    padding-top: 5px;
    padding-bottom: 5px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 15px;
    transition: 0.4s;
    font-family: FontAwesome;
}

.active_li, .accordion:hover {
    background-color: #ccc;
}

.accordion:before {
	content: "\f055";
    color: #777;
    font-weight: bold;
    float: right;
    margin-left: 15px;
}

.active_li:before {
   	content: "\f056";
}

.panel {
    padding: 0 18px;
    background-color: white;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
}
</style>	
	<div class="showcase " style=" padding-bottom: 15px;">
        <div class="container" style="padding-top: 2%;">

            <div class="row">
                <div class="hero loading">
                    
                    <ul class="bxslider">
                        <?php
                            foreach ($data_slideshow as $slideshow_entry) {
                                # code...
                        ?>
                        <li>
                            <img src="<?php echo base_url() ?>uploads/Website/slideshow/<?php echo $slideshow_entry->slideshow_url;?>" width="100%"/>
                            <div>
                            	<br><br>
                                <h3 align="right"><?php echo $slideshow_entry->slideshow_name;?></h3>
                                <p align="justify"><small style="font-size:17px;"><?php echo $slideshow_entry->slideshow_description;?></small></p>
                                <div class="control-wrap">

                                </div>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

        </div>
    </div>
		
	
	<section class="container home">
		<div class="row" style="margin-bottom: 15px;">
			<div class="container div-feedback">
					<div class="col-md-3 col-sm-12 col-xs-12" style="margin-top: 5%" >
						<h3><strong>You Are :</strong></h3>
						<hr style="padding-bottom: 10px; border-width: 2px; border-color: gray;">

						<?php
							$this->load->model('Website/faq_model');
							$data_faq_category = $this->faq_model->get_dropdown_faq_category();

							foreach ($data_faq_category as $faq_category_entry) {

							$faq_category = isset($_REQUEST['faq_category']) ? $_REQUEST['faq_category'] : NULL;

							if (empty($faq_category)){
							$faq_category = $data_faq_category[0]->faq_category;
							} 


								if ($faq_category == $faq_category_entry->faq_category){
									$style_href = "orange";
								} else {
									$style_href = "black";
								}
						?>

						<a style="color: <?php echo @$style_href;?> !important" href="<?php echo site_url('faq'); ?>?faq_category=<?php echo $faq_category_entry->faq_category;?>"><h3><?php echo $faq_category_entry->faq_category;?></h3></a>
						<?php
							}
						?>
					</div>
					
					<div class="col-md-9 col-sm-12 col-xs-12" style="margin-top: 4%" >
						
						<?php
						$faq_category = isset($_REQUEST['faq_category']) ? $_REQUEST['faq_category'] : NULL;

						if (empty($faq_category)){
							$faq_category = $data_faq_category[0]->faq_category;
						} 

						$data_faq_by_category = $this->faq_model->get_faq_by_category($faq_category);
						$i=0;
						foreach ($data_faq_by_category as $faq_by_category_entry) {
					
							$data_faq_by_subcategory = $this->faq_model->get_faq_by_subcategory($faq_category, $faq_by_category_entry->faq_subcategory);
						?>
					
						<h4><strong><?php echo $faq_by_category_entry->faq_subcategory;?></strong></h4>
							<?php
											
								foreach ($data_faq_by_subcategory as $faq_by_subcategory_entry) {
								$i++;
								?>
							

							<div class="panel-group "  role="tablist" aria-multiselectable="true">
								
						        <button class="accordion" style="text-align: justify;font-weight: bold;"><?php echo $faq_by_subcategory_entry->faq_question;?></button>
						            <div class="panel">
									  <p style="padding-top: 5px; text-align: justify;"><?php echo $faq_by_subcategory_entry->faq_answer;?></p>
									</div>
						        
							</div>
						<?php
								}
						} ?>
						
					</div>
				</div>
			</div>
			
		</section>
		<div class="showcase showcase2" style="background-image:url('<?php echo base_url();?>uploads/base-img/img_home/bg.png') !important; padding-bottom: 15px;">
	        <div class="wrap-register">
	            <div class="container div-register">
	                <div class="row">
	                    <div class="col-md-12">
	                        <h2 class="title-register"><a href="<?php echo site_url();?>Finance/f_login/login">JOIN NOW AND GROW TOGETHER WITH US ></a></h2>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	    <script>
			var acc = document.getElementsByClassName("accordion");
			var i;

			for (i = 0; i < acc.length; i++) {
			  acc[i].addEventListener("click", function() {
			    this.classList.toggle("active_li");
			    var panel = this.nextElementSibling;
			    if (panel.style.maxHeight){
			      panel.style.maxHeight = null;
			    } else {
			      panel.style.maxHeight = panel.scrollHeight + "px";
			    } 
			  });
			}
			</script>
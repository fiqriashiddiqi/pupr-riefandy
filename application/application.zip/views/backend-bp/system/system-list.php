<style type="text/css">
    .table_c, .th_c, .td_c {
        border: 1px solid #726f6f;
        padding: 7px;
    }
</style>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
            <!-- /.box-header -->
            <!-- form start -->
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
                  <div class="col-lg-12 col-xs-12">

                  </div>
              </div>
            </div>
          
          <div class="box-body">
            <div class="row">
                <div class="col-lg-12 col-xs-12">
              <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
                  <div class="col-md-4 col-lg-4">
                   <div class="form-group">
                      <label >Cost System Cloud</label>
                      <input type="number" class="form-control" name="cost_system_cloud" value="<?php echo @$get_cost[0]->cost_system_cloud;?>"  placeholder="Cloud" required="true">
                   </div>
                </div>   
                  <div class="col-md-4 col-lg-4">
                   <div class="form-group">
                      <label >Cost System Firewall</label>
                      <input type="number" class="form-control" name="cost_system_firewall" value="<?php echo @$get_cost[0]->cost_system_firewall;?>"  placeholder="Firewall" required="true">
                   </div>
                </div>   

                <div class="col-md-4 col-lg-4">
                   <div class="form-group">
                      <label >Cost System Maintenance</label>
                      <input type="number" class="form-control" name="cost_system_maintenance" value="<?php echo @$get_cost[0]->cost_system_maintenance;?>"  placeholder="Maintenance" required="true">
                   </div>
                </div>   

               <div class="col-md-12 col-lg-12 text-right">
                  <button type="submit" name="submit"  class="btn btn-warning btnbig">Update</button>
              </div>
            </form>
                </div>
            </div>
            <div class="col-xs-12 col-lg-12"  style="padding-top: 15px; width:100%; ">
                  <table class="table_c" style="width: 100%;">
                      <tr style=" background-color: lightgrey;">
                        <th class="th_c" rowspan="2" style="text-align: center; padding: 20px;" width: 20%;">Revenue</th>
                        <th class="th_c" colspan="12" style="text-align: center;">2018</th> 
                      </tr>
                      <tr style=" background-color: lightgrey;">
                        <th class="th_c">Per Month</th>
                        <th class="th_c">Per Year</th>
                      </tr>
                      <tr>
                        <td class="td_c">Cloud</td>
                        <td class="td_c"><?php echo $get_cost[0]->cost_system_cloud; ?></td>
                        <td class="td_c"><?php echo $get_cost[0]->cost_system_cloud * 12; ?></td> 
                      </tr>
                      <tr>
                        <td class="td_c">Firewall</td>
                        <td class="td_c"><?php echo $get_cost[0]->cost_system_firewall; ?></td>
                        <td class="td_c"><?php echo $get_cost[0]->cost_system_firewall * 12; ?></td> 
                      </tr>
                      <tr>
                        <td class="td_c">Maintenance</td>
                        <td class="td_c"><?php echo $get_cost[0]->cost_system_maintenance; ?></td>
                        <td class="td_c"><?php echo $get_cost[0]->cost_system_maintenance * 12; ?></td> 
                      </tr> 
                      <tr>
                        <th class="td_c">Total</td>
                        <th class="td_c"><?php echo $get_cost[0]->cost_system_cloud + $get_cost[0]->cost_system_firewall + $get_cost[0]->cost_system_maintenance; ?></td>
                        <th class="td_c"><?php echo ($get_cost[0]->cost_system_cloud * 12) + ($get_cost[0]->cost_system_firewall * 12) + ($get_cost[0]->cost_system_maintenance * 12); ?></td> 
                      </tr> 
                   </table>
            </div>
            </div>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
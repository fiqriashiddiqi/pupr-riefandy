<style type="text/css">
    .table_c, .th_c, .td_c {
        border: 1px solid #726f6f;
        padding: 7px;
    }
</style>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <?php echo $title; ?>
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
                <?php } ?>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="row">
                            <div class="col-lg-12 col-xs-12">

                            </div>
                        </div>
                    </div>

                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="col-xs-6 col-md-6 col-lg-6">
                 <div class="form-group">
                    <label >Other </label>
                    <input type="number" class="form-control" name="cost_other" value="<?php echo @$get_cost[0]->cost_other; ?>"  placeholder="other " required="true">
                 </div>
              </div> 

            <div class="col-lg-12 col-xs-12 text-right" style="margin-right: 2%;">
                <button type="submit" name="submit"  class="btn btn-warning btnbig">Update</button> 
            </div>
            </form>
                            </div>
                        </div>
            <div class="col-xs-12 col-lg-12" style="padding-top: 15px; width:100%; ">
                <table class="table_c" style="width: 100%;">
                    <?php
                    $revenue_borrower = ($get_target[0]->asumption_commission_borrower * $get_target[0]->asumption_new_loan) / 100;

                    $sales = ($get_target[0]->asumption_new_loan * (1 + ($get_target[0]->asumption_interest_percent / 100))) / 12;
                    for ($x = 1; $x <= 24; $x++) {
                        $total[$x] = 0;
                    }

                    for ($i = 1; $i <= 12; $i++) {
                        for ($j = 1; $j <= 24; $j++) {
                            if ($j >= $get_target[0]->asumption_start_month && $i >= $get_target[0]->asumption_start_month && $i <= $j && $j <= $i + 11) {
                                $total[$j] += number_format($sales);
                            }
                        }
                    }

                    $total_revenue = array();
                    $total_rev_borrower = 0;
                    $total_rev_investor = 0;
                    $grand_total_rev = 0;
                    for ($i = 1; $i <= 12; $i++) {
                        if ($i >= $get_target[0]->asumption_start_month) {
                            $total_rev_borrower += $revenue_borrower;
                            $revenue_investor = ($total[$i] * $get_target[0]->asumption_commission_investor) / 100;
                            $total_revenue[$i] = $revenue_borrower + $revenue_investor;
                            $total_rev_investor += $revenue_investor;
                            $grand_total_rev += $total_revenue[$i];
                        } else {
                            $total_revenue[$i] = 0;
                        }
                    }
                    ?>
                    <tr>
                        <td class="th_c"><?php echo $get_target[0]->asumption_loan_year; ?></td>
                        <td class="th_c"><?php echo round((($get_cost[0]->cost_other * $grand_total_rev) / 100), 0, PHP_ROUND_HALF_UP) ?></td>
                    </tr>
                        
                </table>
            </div>
            </div>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
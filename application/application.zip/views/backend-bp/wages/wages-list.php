<style type="text/css">
    .table_c, .th_c, .td_c {
        border: 1px solid #726f6f;
        padding: 7px;
    }
</style>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
            <!-- /.box-header -->
            <!-- form start -->
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
                  <div class="col-lg-12 col-xs-12">

                  </div>
              </div>
            </div>
          
          <div class="box-body">
            <div class="row">
                <div class="col-lg-12 col-xs-12 col-md-12">
              <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
                                <div class="col-lg-6 col-xs-12 col-md-6">
                                    <div class="form-group">
                                        <label>Bonus Amount</label>
                                        <input type="number" class="form-control" name="asumption_bonus" placeholder="Bonus Amount" required="true" value="<?php echo $get_target[0]->asumption_bonus; ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-xs-12 col-md-6">
                                    
                                
                                    <div class="form-group text-right">
                                        <button type="submit" name="submit" class="btn btn-warning btnbig">Update</button>
                                    </div>
                                </div>
                            </form>

                            <!-- <div class="col-xs-12 col-md-12 col-lg-12">&nbsp;</div> -->

                            <!-- <form action="<?php echo $create_url; ?>" method="post" enctype="multipart/form-data">
                                <div class="col-lg-6 col-xs-12 col-md-6">
                                    <div class="form-group">
                                        <label>Position</label>
                                        <input type="text" class="form-control" name="wages_name" placeholder="Position" required="true" maxlength="200">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-xs-12 col-md-6">
                                    <div class="form-group">
                                        <label>People</label>
                                        <input type="number" class="form-control" name="wages_people" placeholder="People" required="true">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-xs-12 col-md-6">
                                    <div class="form-group">
                                        <label>Salary</label>
                                        <input type="number" class="form-control" name="wages_pay_check" placeholder="Salary" required="true">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-xs-12 col-md-6">
                                    <div class="form-group">
                                        <label>Bonus</label>
                                        <select class="form-control" name="wages_bonus_status" required="true">
                                            <option value="No">NO</option>
                                            <option value="Yes">YES</option>
                                        </select>
                                    </div>
                                </div>
                        
                            <div class="col-lg-12 col-xs-12 col-md-12 text-right">
                                <div class="form-group">
                                    <button type="submit" name="submit" class="btn btn-primary btnbig">Add Wages</button>
                                </div>
                            </div>
                            </form> -->
                </div>
            </div>
            <div class="col-xs-12 col-lg-12"  style="padding-top: 15px; width:100%; ">
                  <table class="table_c" style="width: 100%;">
                                    <tr style="background-color: lightgray; ">
                                        <th class="th_c text-center" width="180px">Position</th>
                                        <th class="th_c text-center" width="180px">People</th>
                                        <th class="th_c text-center" width="200px">Salary</th>
                                        <th class="th_c text-center" width="200px">Per Month</th>
                                        <th class="th_c text-center" width="200px">Per Year</th>
                                        <th class="th_c text-center" width="200px">Bonus</th>
                                        <th class="th_c text-center" width="200px">Total wages</th>
                                        <th class="th_c text-center" width="100px">Action</th>
                                    </tr>
                                    <?php 
                                        foreach ($get_wages as $wages_entry) {
                                        
                                        $mon = $wages_entry->wages_people * $wages_entry->wages_pay_check;
                                        $year = ($wages_entry->wages_people * $wages_entry->wages_pay_check) * 13;
                                            
                                            if ($wages_entry->wages_bonus_status == 'Yes'){
                                                $bonus = $wages_entry->wages_people * $wages_entry->wages_pay_check * $get_target[0]->asumption_bonus;
                                            } else {
                                                $bonus = 0;
                                            } 

                                        $total = $year + $bonus;
                                    ?>
                                    <tr>
                                        <td class="td_c"><strong><?php echo $wages_entry->wages_name;?></strong></td>
                                        <td class="td_c text-right"><?php echo number_format($wages_entry->wages_people);?></td>
                                        <td class="td_c text-right"><?php echo number_format($wages_entry->wages_pay_check);?></td>
                                        <td class="td_c text-right"><?php echo number_format($mon);?></td>
                                        <td class="td_c text-right"><?php echo number_format($year);?></td>
                                        <td class="td_c text-right"><?php echo number_format($bonus);?></td>
                                        <td class="td_c text-right"><?php echo number_format($total);?></td>
                                        <td class="td_c text-center" width="100px">
                                            <button type="button" name="button" class="btn btn-warning">Update</button>
                                        </td>
                                    </tr>
                                    <?php 
                                        }
                                    ?>
                                </table>
            </div>
            </div>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
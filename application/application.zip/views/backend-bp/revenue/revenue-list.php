<style type="text/css">
    .table_c, .th_c, .td_c {
        border: 1px solid #726f6f;
        padding: 7px;
    }
</style>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
            <!-- /.box-header -->
            <!-- form start -->
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
                  <div class="col-lg-12 col-xs-12">

                  </div>
              </div>
            </div>
          
          <div class="box-body">
            <div class="row">
              <div class="col-xs-12 col-lg-12 col-md-12">
              <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <input type="hidden" name="id_asumption" class="form-control " required="true" value="<?php echo $data_revenue[0]->id_asumption  ?>" placeholder="Loan year" >
              
              <div class="col-6-12 col-lg-4">
                  <label>Loan Year</label>
                  <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="asumption_loan_year" class="form-control pull-right datepicker" required="true" value="<?php echo $data_revenue[0]->asumption_loan_year;?>" placeholder="Loan year" readonly >
                  </div>
              </div>
              <div class="col-4-12 col-lg-4">
                  <div class="form-group">
                    <label >Commision Investor</label>
                    <input type="text" class="form-control" name="asumption_commission_investor" value="<?php echo $data_revenue[0]->asumption_commission_investor ?>" placeholder="Commision Investor" required="true">
                  </div>
              </div>
              <div class="col-4-12 col-lg-4">
                  <div class="form-group">
                    <label >Commision Borrower</label>
                    <input type="text" class="form-control" name="asumption_commission_borrower" value="<?php echo $data_revenue[0]->asumption_commission_borrower ?>" placeholder="Commision Borrower" required="true">
                  </div>
              </div> 
            
            <div class="col-xs-12 col-lg-12 col-md-12 text-right">
                <button type="submit" name="submit"  class="btn btn-warning btnbig">Update</button>        
            </div>
              </form>
            </div>
            </div>
            <div class="col-xs-12 col-lg-12"  style="padding-top: 15px; width:100%; ">
                  <table  class="table_c" style="width: 100%;">
                      <tr style="background-color: lightgray;">
                        <th class="th_c" rowspan="2" style="text-align: center; padding: 20px;" width: 20%;">Revenue</th>
                        <th class="th_c" colspan="12" style="text-align: center;"><?php echo $data_revenue[0]->asumption_loan_year; ?></th>
                        <th class="th_c" rowspan="2" style="text-align: center;">Total</th>
                        <th class="th_c" rowspan="2" style="text-align: center;">#</th>
                      </tr>
                      <tr style="background-color: lightgray;">
                        <th class="th_c">1</td>
                        <th class="th_c">2</th>
                        <th class="th_c">3</th>
                        <th class="th_c">4</th>
                        <th class="th_c">5</th>
                        <th class="th_c">6</th>
                        <th class="th_c">7</th>
                        <th class="th_c">8</th>
                        <th class="th_c">9</th>
                        <th class="th_c">10</th>
                        <th class="th_c">11</th>
                        <th class="th_c">12</th>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">Revenue Borrower</td>
                        <?php
                        $total_rev_borrower = 0;
                        $revenue_borrower = ($data_revenue[0]->asumption_commission_borrower * $data_revenue[0]->asumption_new_loan) / 100;
                        for ($i=1; $i <= 12; $i++) {
                          if ($i >= $data_revenue[0]->asumption_start_month) {
                            $total_rev_borrower += $revenue_borrower;
                        ?>
                        <td class="th_c"><?php echo $revenue_borrower; ?></td>
                        <?php
                          } else {
                        ?>
                        <td class="th_c">-</td>
                        <?php
                          }
                        }
                        ?>
                        <td class="th_c"><?php echo $total_rev_borrower; ?></td>
                        <td class="th_c"></td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">Revenue Investor</td>
                        <?php
                        $sales = ($data_revenue[0]->asumption_new_loan * (1 + ($data_revenue[0]->asumption_interest_percent / 100))) / 12;
                        for ($x = 1; $x <= 24; $x++) {
                          $total[$x] = 0;
                        }

                        for ($i = 1; $i <= 12; $i++) {
                          for ($j = 1; $j <= 24; $j++) {
                            if ($j >= $data_revenue[0]->asumption_start_month && $i >= $data_revenue[0]->asumption_start_month && $i <= $j && $j <= $i + 11) {
                              $total[$j] += number_format($sales);
                            }
                          }
                        }

                        $total_revenue = array();
                        $total_rev_investor = 0;
                        for ($i=1; $i <= 12; $i++) { 
                          if ($i >= $data_revenue[0]->asumption_start_month) {
                            $revenue_investor = ($total[$i] * $data_revenue[0]->asumption_commission_investor) / 100;
                            $total_revenue[$i] = $revenue_borrower + $revenue_investor;
                            $total_rev_investor += $revenue_investor;
                        ?>
                        <td class="th_c"><?php echo round($revenue_investor, 0, PHP_ROUND_HALF_UP); ?></td>
                        <?php
                          } else {
                            $total_revenue[$i] = 0;
                        ?>
                        <td class="th_c">-</td>
                        <?php
                          }
                        }
                        ?>
                        <td class="th_c"><?php echo round($total_rev_investor, 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"></td>
                      </tr>
                      <tr style="text-align: center;">
                        <th class="th_c" style="text-align: left;">Total</td>
                        <?php
                        $grand_total_rev = 0;
                        for ($i=1; $i <= 12; $i++) {
                          $grand_total_rev += $total_revenue[$i];
                        ?>
                        <td class="th_c"><?php echo ($total_revenue[$i] > 0) ? round($total_revenue[$i], 0, PHP_ROUND_HALF_UP) : '-' ?></td>
                        <?php
                        }
                        ?>
                        <td class="th_c"><?php echo round($grand_total_rev, 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo ($grand_total_rev / $grand_total_rev) * 100 . "%"; ?></td>
                      </tr>
                      <tr>
                        <td class="th_c" colspan="15"></td>
                      </tr>
                      <tr>
                        <th class="th_c">Sales & Marketing Expenses</th>
                        <?php
                          for ($i = 1; $i <= 12; $i++) {
                        ?>
                        <td class="th_c"></td>
                        <?php
                          }
                        ?>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">Wages</td>
                        <?php
													$wages_total = 0;
													foreach ($get_wages as $wages) {
														$year = ($wages->wages_people * $wages->wages_pay_check) * 13;
														if ($wages->wages_bonus_status == 'Yes') {
															$bonus = $wages->wages_people * $wages->wages_pay_check * $get_target[0]->asumption_bonus;
														} else {
															$bonus = 0;
														}
														$total = $year + $bonus;
														$wages_total += $total;
													}

													$total_wages = array();
                          for ($i = 1; $i <= 12; $i++) {
														if ($i >= $data_revenue[0]->asumption_start_month) {
															$total_wages[$i] = $wages_total / (13 - $data_revenue[0]->asumption_start_month);
												?>
												<td class="th_c"><?php echo number_format(($wages_total / (13 - $data_revenue[0]->asumption_start_month)), 0) ?></td>
												<?php
														} else {
															$total_wages[$i] = 0;
												?>
												<td class="th_c">-</td>
												<?php
														}
                          }
                        ?>
                        <td class="th_c"><?php echo number_format($wages_total, 0) ?></td>
                        <td class="th_c"><?php echo round((($wages_total / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">A&P</td>
                        <?php
													$total_ap = array();
                          for ($i = 1; $i <= 12; $i++) {
														if ($i >= $data_revenue[0]->asumption_start_month) {
															$total_ap[$i] = ((($get_cost[0]->cost_ap * $grand_total_rev) / 100) / (13 - $data_revenue[0]->asumption_start_month));
												?>
												<td class="th_c"><?php echo round($total_ap[$i], 0, PHP_ROUND_HALF_UP); ?></td>
												<?php
														} else {
															$total_ap[$i] = 0;
												?>
												<td class="th_c">-</td>
												<?php
														}
                          }
                        ?>
                        <td class="th_c"><?php echo round(array_sum($total_ap), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_ap) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">Other Selling Cost</td>
                        <?php
													$total_other_selling = array();
                          for ($i = 1; $i <= 12; $i++) {
														if ($i >= $data_revenue[0]->asumption_start_month) {
															$total_other_selling[$i] = ((($get_cost[0]->cost_other_selling * $grand_total_rev) / 100) / (13 - $data_revenue[0]->asumption_start_month));
												?>
												<td class="th_c"><?php echo round($total_other_selling[$i], 0, PHP_ROUND_HALF_UP); ?></td>
												<?php
														} else {
															$total_other_selling[$i] = 0;
												?>
												<td class="th_c">-</td>
												<?php
														}
                          }
                        ?>
                        <td class="th_c"><?php echo round(array_sum($total_other_selling), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_other_selling) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <th class="th_c" style="text-align: left;">Total Sales & Marketing Expenses</th>
                        <?php
													$total_sm_expense = array();
                          for ($i = 1; $i <= 12; $i++) {
														$total_sm_expense[$i] = $total_wages[$i] + $total_ap[$i] + $total_other_selling[$i];
                        ?>
                        <td class="th_c"><?php echo ($total_sm_expense[$i] > 0) ? round($total_sm_expense[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
                          }
                        ?>
                        <td class="th_c"><?php echo round(array_sum($total_sm_expense), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_sm_expense) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                      </tr>
                      <tr>
												<th class="th_c" style="text-align: left;">Operating profit</th>
												<?php
													$total_profit = array();
													for ($i = 1; $i <= 12; $i++) {
														$total_profit[$i] = $total_revenue[$i] - $total_sm_expense[$i];
												?>
                        <td class="th_c"><?php echo ($total_profit[$i] != 0) ? round($total_profit[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo round(array_sum($total_profit), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_profit) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                      </tr>
											
                      <tr>
                        <th class="th_c">General & Administration Expenses</th>
                        <?php
													for ($i = 1; $i <= 12; $i++) {
												?>
                        <td class="th_c"></td>
                        <?php
													}
												?>
                        <td class="th_c"></td>
                        <td class="th_c"></td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">Wages</td>
                        <?php
													$gx_wages_total = 0;
													foreach ($get_wages_gx as $wages) {
														$year = ($wages->wages_people * $wages->wages_pay_check) * 13;
														if ($wages->wages_bonus_status == 'Yes') {
															$bonus = $wages->wages_people * $wages->wages_pay_check * $get_target[0]->asumption_bonus;
														} else {
															$bonus = 0;
														}
														$total = $year + $bonus;
														$gx_wages_total += $total;
													}

													$total_wages_gx = array();
													for ($i = 1; $i <= 12; $i++) {
														if ($i >= $data_revenue[0]->asumption_start_month) {
															$total_wages_gx[$i] = $gx_wages_total / (13 - $data_revenue[0]->asumption_start_month);
												?>
												<td class="th_c"><?php echo round($total_wages_gx[$i], 0, PHP_ROUND_HALF_UP); ?></td>
												<?php
														} else {
															$total_wages_gx[$i] = 0;
												?>
												<td class="th_c">-</td>
												<?php
														}
													}
												?>
                        <td class="th_c"><?php echo round(array_sum($total_wages_gx), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_wages_gx) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP) ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">G&A Cost</td>
                        <?php
													$total_rent = array();
													$total_sys_maint = array();
													$total_amortization = array();
													$total_depreciation = array();
													$total_others = array();
													$total_ga_cost = array();
													for ($i = 1; $i <= 12; $i++) {
														if ($i >= $data_revenue[0]->asumption_start_month) {
															$total_rent[$i] = round(($get_cost[0]->cost_office_rent / 24), 0, PHP_ROUND_HALF_UP);
															$total_sys_maint[$i] = (($get_cost[0]->cost_system_cloud + $get_cost[0]->cost_system_firewall + $get_cost[0]->cost_system_maintenance) * 12) / (13 - $data_revenue[0]->asumption_start_month);
															$total_amortization[$i] = ($get_cost[0]->cost_amortization_system / $get_cost[0]->cost_amortization_period) / (13 - $data_revenue[0]->asumption_start_month);
															$total_depreciation[$i] = round(($get_cost[0]->cost_depreciation_assets / $get_cost[0]->cost_depreciation_period), 0, PHP_ROUND_HALF_UP);
															$total_others[$i] = (($get_cost[0]->cost_other * $grand_total_rev) / 100) / (13 - $data_revenue[0]->asumption_start_month);
														} else {
															$total_rent[$i] = 0;
															$total_sys_maint[$i] = 0;
															$total_amortization[$i] = 0;
															$total_depreciation[$i] = 0;
															$total_others[$i] = 0;
														}
														$total_ga_cost[$i] = $total_rent[$i] + $total_sys_maint[$i] + $total_amortization[$i] + $total_depreciation[$i] + $total_others[$i];
												?>
                        <td class="th_c"><?php echo ($total_ga_cost[$i] > 0) ? round($total_ga_cost[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo round(array_sum($total_ga_cost), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_ga_cost) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="padding-left: 15px; text-align: left;"><i>Office Rental</i></td>
                        <?php
													for ($i = 1; $i <= 12; $i++) {
												?>
                        <td class="th_c"><?php echo ($total_rent[$i] > 0) ? $total_rent[$i] : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo array_sum($total_rent); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_rent) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="padding-left: 15px; text-align: left;"><i>System & Maintenance</i></td>
                        <?php
													for ($i = 1; $i <= 12; $i++) {
												?>
                        <td class="th_c"><?php echo ($total_sys_maint[$i] > 0) ? round($total_sys_maint[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo array_sum($total_sys_maint); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_sys_maint) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="padding-left: 15px; text-align: left;"><i>Amortization</i></td>
                        <?php
													for ($i = 1; $i <= 12; $i++) {
												?>
                        <td class="th_c"><?php echo ($total_amortization[$i] > 0) ? round($total_amortization[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo array_sum($total_amortization); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_amortization) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="padding-left: 15px; text-align: left;"><i>Depreciation</i></td>
                        <?php
													for ($i = 1; $i <= 12; $i++) {
												?>
                        <td class="th_c"><?php echo ($total_depreciation[$i] > 0) ? $total_depreciation[$i] : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo array_sum($total_depreciation); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_depreciation) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="padding-left: 15px; text-align: left;"><i>Others</i></td>
                        <?php
													for ($i = 1; $i <= 12; $i++) {
												?>
                        <td class="th_c"><?php echo ($total_others[$i] > 0) ? round($total_others[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo round(array_sum($total_others)); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_others) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">Miscellaneous</td>
                        <?php
													$total_misc = array();
													for ($i = 1; $i <= 12; $i++) {
														$total_misc[$i] = 0;
												?>
                        <td class="th_c"><?php echo ($total_misc[$i] > 0) ? $total_misc[$i] : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo array_sum($total_misc); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_misc) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr style="text-align: center;">
                        <th class="th_c" style="text-align: left;">Total General & Administration Expenses</th>
                        <?php
													$total_ga_expense = array();
													for ($i = 1; $i <= 12; $i++) {
														$total_ga_expense[$i] = $total_wages_gx[$i] + $total_ga_cost[$i] + $total_misc[$i];
												?>
                        <td class="th_c"><?php echo ($total_ga_expense[$i] > 0) ? round($total_ga_expense[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo round(array_sum($total_ga_expense), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_ga_expense) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr>
                        <td class="th_c" colspan="15"></td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">EBT</td>
                        <?php
													$total_ebt = array();
													for ($i = 1; $i <= 12; $i++) {
														$total_ebt[$i] = $total_profit[$i] - $total_ga_expense[$i];
												?>
                        <td class="th_c"><?php echo ($total_ebt[$i] != 0) ? round($total_ebt[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo round(array_sum($total_ebt), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_ebt) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                      <tr>
                        <td class="th_c" colspan="15"></td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">Corporate Tax</td>
                        <?php
													$total_tax = array();
													for ($i = 1; $i <= 12; $i++) {
														$total_tax[$i] = (25 / 100) * $total_ebt[$i];
												?>
                        <td class="th_c"><?php echo ($total_tax[$i] != 0) ? round($total_tax[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo round(array_sum($total_tax), 0, PHP_ROUND_HALF_UP); ?></td>
                      </tr>
                      <tr>
                        <td class="th_c" colspan="15"></td>
                      </tr>
                      <tr style="text-align: center;">
                        <td class="th_c" style="text-align: left;">Net income</td>
                        <?php
													$total_income = array();
													for ($i = 1; $i <= 12; $i++) {
														$total_income[$i] = $total_ebt[$i] - $total_tax[$i];
												?>
                        <td class="th_c"><?php echo ($total_income[$i] != 0) ? round($total_income[$i], 0, PHP_ROUND_HALF_UP) : '-' ?></td>
                        <?php
													}
												?>
                        <td class="th_c"><?php echo round(array_sum($total_income), 0, PHP_ROUND_HALF_UP); ?></td>
                        <td class="th_c"><?php echo round(((array_sum($total_income) / $grand_total_rev) * 100), 0, PHP_ROUND_HALF_UP); ?>%</td>
                      </tr>
                  </table>
            </div>
            </div>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
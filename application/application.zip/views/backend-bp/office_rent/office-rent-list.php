<style type="text/css">
    .table_c, .th_c, .td_c {
        border: 1px solid #726f6f;
        padding: 7px;
    }
</style>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <?php echo $title; ?>
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php 
            } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
                <?php 
            } ?>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="row">
                            <div class="col-lg-12 col-xs-12">

                            </div>
                        </div>
                    </div>

                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
                <div class="col-md-4 col-xs-12 col-lg-4">
                  <!-- <label>Loan Year</label>
                  <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="date" name="asumption_loan_year" class="form-control pull-right datepicker" required="true" value="<?php echo date('Y-m-d'); ?>" placeholder="Loan year" >
                  </div> -->
                </div>

              <div class="col-md-6 col-xs-12 col-lg-4">
                 <div class="form-group">
                    <label >Office Rent</label>

                    <input type="number" class="form-control" name="cost_office_rent" value="<?php echo @$get_cost[0]->cost_office_rent; ?>"  placeholder=" " required="true">
                 </div>
               </div>   
                <div class="form-group col-md-4 col-xs-12 col-lg-4">
                    <!-- <label >Asumption start Month</label>
                    <select class="form-control" name="asumption_start_month" required="true" >
                        <option selected >-Month-</option>
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">July</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select> -->
                 </div>

               <div class="col-lg-12 col-xs-12 text-right" style="margin-right: 2%;">

                <button type="submit" name="submit"  class="btn btn-warning btnbig">Update</button>
                
              </div>

            </form>
                            </div>
                        </div>
                        <div class="col-xs-12 col-lg-12" style="padding-top: 15px; width:100%; ">
                            <table class="table_c" style="width: 100%;">
                     <tr style="background-color: lightgray;">
                        <th class="th_c" colspan="3" rowspan="5" style="padding: 50px; width: 15%;">Office Rent</th>
                        <th class="th_c" colspan="12" style="text-align: center;">2018</th>
                        <th class="th_c" colspan="12" style="text-align: center;">2019</th>
                        <th class="th_c" rowspan="2" style="text-align: center;">Total</th>
                        
                      </tr>
                      <tr style="background-color: lightgray;">
                        <th class="th_c">1</th>
                        <th class="th_c">2</th>
                        <th class="th_c">3</th>
                        <th class="th_c">4</th>
                        <th class="th_c">5</th>
                        <th class="th_c">6</th>
                        <th class="th_c">7</th>
                        <th class="th_c">8</th>
                        <th class="th_c">9</th>
                        <th class="th_c">10</th>
                        <th class="th_c">11</th>
                        <th class="th_c">12</th>
                        <th class="th_c">1</th>
                        <th class="th_c">2</th>
                        <th class="th_c">3</th>
                        <th class="th_c">4</th>
                        <th class="th_c">5</th>
                        <th class="th_c">6</th>
                        <th class="th_c">7</th>
                        <th class="th_c">8</th>
                        <th class="th_c">9</th>
                        <th class="th_c">10</th>
                        <th class="th_c">11</th>
                        <th class="th_c">12</th>
                      </tr>
                    <tr>
                        <?php
                            $total_rent = 0;
                            for ($i = 1; $i <= 24; $i++) {
                                $total_rent += ($get_cost[0]->cost_office_rent / 24);
                        ?>
                        <td class="td_c"><?php echo round(($get_cost[0]->cost_office_rent / 24), 0, PHP_ROUND_HALF_UP); ?></td>
                        <?php
                            }
                        ?>
                        <td class="td_c"><?php echo round($total_rent, 0, PHP_ROUND_HALF_UP) ?></td>
                    </tr>
                        
                </table>
            </div>
            </div>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
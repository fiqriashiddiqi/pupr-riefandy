<style type="text/css">
    .table_c, .th_c, .td_c {
        border: 1px solid #726f6f;
        padding: 7px;
    }
</style>
<?php date_default_timezone_set("Asia/Jakarta"); $date = date('Y-m-d');?>

<!-- Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <?php echo $title; ?>
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
                <?php } ?>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="row">
                            <div class="col-lg-12 col-xs-12">
                            </div>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-12 col-lg-12 col-md-12">
                            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
                                <div class="col-sm-6 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <label>Interest %</label>
                                        <input type="number" class="form-control" min="0" step="1" max="100" name="asumption_interest_percent" placeholder="Interest %" value="<?php echo $get_sales[0]->asumption_interest_percent;?>" required="true">
                                    </div>
                                </div>

                                <div class="col-sm-6 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        &nbsp;
                                    </div>
                                </div>

                                <div class="col-sm-6 col-lg-6 col-md-6 text-right"">
                                    <div class="form-group">
                                        <button type="submit" name="submit" class="btn btn-warning btnbig">Update</button>
                                    </div>
                                </div>
                            </form>

                            <div class="col-xs-12 col-lg-12 double-scroll" style="padding-top: 15px; overflow-x: auto;">
                                <table class="table_c">
                                    <tr style="background-color: lightgray;">
                                        <th class="th_c" rowspan="15" style="text-align: center; width: 10%;">Total Repayment</th>
                                        <th class="th_c" colspan="12" style="text-align: center;"><?php echo $get_sales[0]->asumption_loan_year; ?></th>
                                        <th class="th_c" colspan="12" style="text-align: center;"><?php echo $get_sales[0]->asumption_loan_year + 1; ?></th>
                                        
                                    </tr>
                                    <tr>
                                        <th class="th_c text-center" width="100px">1</th>
                                        <th class="th_c text-center" width="100px">2</th>
                                        <th class="th_c text-center" width="100px">3</th>
                                        <th class="th_c text-center" width="100px">4</th>
                                        <th class="th_c text-center" width="100px">5</th>
                                        <th class="th_c text-center" width="100px">6</th>
                                        <th class="th_c text-center" width="100px">7</th>
                                        <th class="th_c text-center" width="100px">8</th>
                                        <th class="th_c text-center" width="100px">9</th>
                                        <th class="th_c text-center" width="100px">10</th>
                                        <th class="th_c text-center" width="100px">11</th>
                                        <th class="th_c text-center" width="100px">12</th>

                                        <th class="th_c text-center" width="100px">1</th>
                                        <th class="th_c text-center" width="100px">2</th>
                                        <th class="th_c text-center" width="100px">3</th>
                                        <th class="th_c text-center" width="100px">4</th>
                                        <th class="th_c text-center" width="100px">5</th>
                                        <th class="th_c text-center" width="100px">6</th>
                                        <th class="th_c text-center" width="100px">7</th>
                                        <th class="th_c text-center" width="100px">8</th>
                                        <th class="th_c text-center" width="100px">9</th>
                                        <th class="th_c text-center" width="100px">10</th>
                                        <th class="th_c text-center" width="100px">11</th>
                                        <th class="th_c text-center" width="100px">12</th>
                                    </tr>

                                    <?php
                                        $sales = ($get_sales[0]->asumption_new_loan * (1 + ($get_sales[0]->asumption_interest_percent / 100))) / 12;
                                        for ($x=1; $x <= 24; $x++) { 
                                            $total[$x] = 0;
                                        }

                                        for ($i=1; $i <= 12; $i++) {
                                    ?>
                                    <tr style="text-align: center;">
                                    <?php
                                            for ($j = 1; $j <= 24; $j++) {
                                                if ($j >= $get_sales[0]->asumption_start_month && $i >= $get_sales[0]->asumption_start_month && $i <= $j && $j <= $i+11) {
                                                    $total[$j] += number_format($sales);
                                    ?>
                                        <td class="td_c"><?php echo number_format($sales); ?></td>
                                    <?php
                                                } else {
                                    ?>
                                        <td class="td_c">-</td>
                                    <?php
                                                }
                                            }
                                    ?>
                                    </tr>
                                    <?php
                                        }
                                    ?>
                                    <tr>
                                    <?php
                                        for ($i=1; $i <= 24; $i++) { 
                                    ?>
                                        <th class="th_c text-center" width="100px"><?php echo ($total[$i] > 0) ? $total[$i] : '-'; ?></th>
                                    <?php
                                        }
                                    ?>
                                    </tr>
                                </table>
                            </div>

                            <div class="col-xs-12 col-lg-12" style="padding-top: 15px;  ">
                                <table class="table_c" style="width: 100%;">
                                    <tr style="background-color: lightgray;">
                                        <th class="th_c" rowspan="15" style="text-align: center; width: 10%;">Principal Repayment</th>
                                        <th class="th_c" colspan="12" style="text-align: center;"><?php echo $get_sales[0]->asumption_loan_year; ?></th>
                                        <th class="th_c" colspan="12" style="text-align: center;"><?php echo $get_sales[0]->asumption_loan_year + 1; ?></th>

                                    </tr>
                                    <tr>
                                        <th class="th_c text-center" width="100px">1</th>
                                        <th class="th_c text-center" width="100px">2</th>
                                        <th class="th_c text-center" width="100px">3</th>
                                        <th class="th_c text-center" width="100px">4</th>
                                        <th class="th_c text-center" width="100px">5</th>
                                        <th class="th_c text-center" width="100px">6</th>
                                        <th class="th_c text-center" width="100px">7</th>
                                        <th class="th_c text-center" width="100px">8</th>
                                        <th class="th_c text-center" width="100px">9</th>
                                        <th class="th_c text-center" width="100px">10</th>
                                        <th class="th_c text-center" width="100px">11</th>
                                        <th class="th_c text-center" width="100px">12</th>

                                        <th class="th_c text-center" width="100px">1</th>
                                        <th class="th_c text-center" width="100px">2</th>
                                        <th class="th_c text-center" width="100px">3</th>
                                        <th class="th_c text-center" width="100px">4</th>
                                        <th class="th_c text-center" width="100px">5</th>
                                        <th class="th_c text-center" width="100px">6</th>
                                        <th class="th_c text-center" width="100px">7</th>
                                        <th class="th_c text-center" width="100px">8</th>
                                        <th class="th_c text-center" width="100px">9</th>
                                        <th class="th_c text-center" width="100px">10</th>
                                        <th class="th_c text-center" width="100px">11</th>
                                        <th class="th_c text-center" width="100px">12</th>
                                    </tr>

                                    <?php
                                        $sales_2 = $get_sales[0]->asumption_new_loan / 12;
                                        for ($x = 1; $x <= 24; $x++) {
                                            $total[$x] = 0;
                                        }

                                        for ($i = 1; $i <= 12; $i++) {
                                    ?>
                                    <tr style="text-align: center;">
                                    <?php
                                        for ($j = 1; $j <= 24; $j++) {
                                            if ($j >= $get_sales[0]->asumption_start_month && $i >= $get_sales[0]->asumption_start_month && $i <= $j && $j <= $i + 11) {
                                                $total[$j] += $sales_2;
                                    ?>
                                        <td class="td_c"><?php echo number_format($sales_2); ?></td>
                                    <?php

                                            } else {
                                    ?>
                                        <td class="td_c">-</td>
                                    <?php
                                            }
                                        }
                                    ?>
                                    </tr>
                                    <?php
                                        }
                                    ?>
                                    <tr>
                                    <?php
                                        for ($i = 1; $i <= 24; $i++) {
                                    ?>
                                        <th class="th_c text-center" width="100px"><?php echo ($total[$i] > 0) ? round($total[$i], 0, PHP_ROUND_HALF_UP) : '-'; ?></th>
                                    <?php
                                        }
                                    ?>
                                    </tr>
                                </table>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- /.content -->
</div>
<!-- end content-wrapper -->
<style type="text/css">
    .table_c, .th_c, .td_c {
        border: 1px solid #726f6f;
        padding: 7px;
    }
</style>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <?php echo $title; ?>
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-check"></i>
                        <?php echo $this->session->flashdata('alert_success'); ?>
                    </p>
                </div>
                <?php 
            } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <p><i class="icon fa fa-ban"></i>
                        <?php echo $this->session->flashdata('alert_error'); ?>
                    </p>
                </div>
                <?php 
            } ?>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="row">
                            <div class="col-lg-12 col-xs-12">

                            </div>
                        </div>
                    </div>

                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="col-md-6 col-lg-6">
                 <div class="form-group">
                    <label> Depreciation Assets</label>
                    <input type="number" class="form-control" name="cost_depreciation_assets" value="<?php echo @$get_cost[0]->cost_depreciation_assets; ?>" placeholder="Depreciation Assets" required="true">
                 </div>
              </div>   
              <div class="col-md-6 col-lg-6">
                 <div class="form-group">
                    <label> Depreciation Period</label>
                    <input type="number" class="form-control" name="cost_depreciation_period" value="<?php echo @$get_cost[0]->cost_depreciation_period; ?>" placeholder="Depreciation Period" required="true">
                 </div>
              </div>
              <div class="col-lg-12 col-xs-12 text-right" style="margin-right: 2%;">
                <button type="submit" name="submit"  class="btn btn-warning btnbig">Update</button>
              </div>
            </form>
                            </div>
                        </div>
                        <div class="col-xs-12 col-lg-12" style="padding-top: 15px; width:100%; ">
                    <table  class="table_c" style="width: 100%;">
                        <tr>
                            <td class="td_c">Depreciation Per Year</td>
                            <td class="td_c"><?php echo round(($get_cost[0]->cost_depreciation_assets / $get_cost[0]->cost_depreciation_period), 0, PHP_ROUND_HALF_UP) ?></td>
                        </tr>    
                    </table>
            </div>
            </div>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<div class="content-wrapper">
  <section class="content-header">
	<h1>
	  <?php echo $title; ?>
	  <small>
	  </small>
	</h1>
	<ol class="breadcrumb">
	  <li class="active">
		<a href="<?php echo $brd_title_url; ?>">
		  <i class="fa fa-dashboard">
		  </i> 
		  <?php echo $title; ?>
		</a>
	  </li>
	</ol>
  </section>
  <section class="content">
	<div class="panel-body" >
	  <?php if ($this->session->flashdata('alert_success')) { ?>
	  <div class="alert alert-success alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
		</button>
		<p>
		  <i class="icon fa fa-check">
		  </i> Welcome : 
		  <?php echo $this->session->flashdata('alert_success'); ?>
		</p>
	  </div>
	  <?php } ?>
	  <?php if ($this->session->flashdata('alert_error')) { ?>
	  <div class="alert alert-danger alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
		</button>
		<p>
		  <i class="icon fa fa-ban">
		  </i> Warning ! :
		  <?php echo $this->session->flashdata('alert_error'); ?>
		</p>
	  </div>
	  <?php } ?>
	  <center>
		<!--            <img src="<?php echo base_url(); ?>uploads/base-img/logosa.png" width="350" height="220" style="margin-top: 25px;">
<br><br>
<p style="font-weight: bold; font-size: 20px;">
<?php echo $this->config->item('backend_full_title') ?><br>Selamat Datang</p>
<p style="font-size: 16px;">
<?php echo $users_name; ?><br><?php echo $groups_name; ?></p>
<p style="font-size: 16px;"> Tanggal Login: 
<?php echo $users_last_signin; ?></p>
<br>
-->
		<!--            <iframe width="100%" height="600px" src="https://dashboard.tawk.to/#/dashboard">
</iframe> -->
	  </center>        
	</div>
  </section>
</div>

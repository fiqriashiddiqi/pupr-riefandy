<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
        <div class="box" id="">
            <div class="box-header with-border">
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
              <div class="form-group">
                <div class="box-body">
              <div class="form-group">
                <label for="contact_us_phone">ID Loan </label>
                <input type="text" class="form-control" placeholder="ID Loan" value="<?php echo @$data_loan[0]->id_borrower_loan; ?>"  name="id_borrower_loan" disabled >
                
              </div>
              <div class="form-group">
                  <label for="contact_us_fax">Fullname</label>
                  <input type="text" class="form-control" id="contact_us_fax" name="bio_fullname" value="<?php echo @$bio_fullname[0]->bio_fullname;?>" placeholder="FAX" disabled>
              </div>
              <div class="form-group">
                  <label for="contact_us_email">Proposed Date</label>
                  <input type="text" class="form-control" id="contact_us_email" name="propose_date" value="<?php echo @$data_loan[0]->loan_date; ?>" placeholder="Alamat Email" disabled>
              </div>
              <div class="form-group">
                  <label for="contact_us_livechat">Amount</label>
                  <input type="text" class="form-control" id="contact_us_livechat" name="loan_amount" value="<?php echo number_format(@$data_loan[0]->loan_amount,2) ; ?>" placeholder="Live Chat" disabled>
              </div>
              <div class="form-group">
                  <label for="contact_us_facebook">Rating</label>
                  <input type="text" class="form-control" id="contact_us_facebook" name="loan_rating" value="<?php echo @$data_loan[0]->loan_rating; ?>" placeholder="Facebook" disabled>
              </div>
              <div class="form-group">
                  <label for="contact_us_facebook">Rate</label>
                  <input type="text" class="form-control" id="contact_us_facebook" name="loan_rate" value="<?php echo @$data_loan[0]->loan_rate; ?>%" placeholder="Facebook" disabled>
              </div>
              <div class="form-group">
                  <label for="contact_us_facebook">Needs</label>
                  <input type="text" class="form-control" id="contact_us_facebook" name="loan_needs" value="<?php echo @$data_loan[0]->loan_needs; ?>" placeholder="Facebook" disabled>
              </div>
             <div class="form-group">
                  <label for="contact_us_livechat">Note</label>
                  <input type="text" class="form-control" id="contact_us_livechat" name="loan_note" value="<?php echo @$data_loan[0]->loan_note; ?>" placeholder="Live Chat" disabled>
              </div>

              </div>
              <!-- /.box-body -->
              <div class="box-footer text-right">
                <a href="<?php echo $back_url; ?>" id="info" class="btn btn-warning btn-sm btnwdt">Back</a>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>


        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->

<script src="<?php echo base_url() ?>assets/Sanders/js/jquery-1.4.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$('#contact_us_description').keyup(function() {
var len = this.value.length;
if (len >= 200) {
this.value = this.value.substring(0, 200);
}
$('#hitung').text(200 - len);
});
});
</script>


<script type="text/javascript">
$(document).ready(function() {
$('#contact_us_headquarter').keyup(function() {
var len = this.value.length;
if (len >= 300) {
this.value = this.value.substring(0, 300);
}
$('#hitung2').text(300 - len);
});
});
</script>


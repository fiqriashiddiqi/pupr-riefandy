<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } 
          ?>
          <div class="box">
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12" >
              <div class="col-xs-12 col-lg-12" style="overflow-y: auto;">
              <table id="" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>ID</th>
                  <th>Proposed Date</th>
                  <th>Type of Loan</th>
                  <th>Amount</th>
                  <th>Rating</th>
                  <th width="180" style="text-align: center;">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $this->load->model("crud_model");
                $data_setting = $this->crud_model->get_setting();
                $limit   = $data_setting[0]->setting_pagination;
                $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

                
                if(empty($page)){
                    $position  = 0;
                    $page = 1;
                } else {
                    $position = ($page-1) * $limit;
                }

                $this->load->model('Front_Fintech/loan_model');
                $data_loan = $this->loan_model->get_ongoing_list($limit,$position)->result();
                

                $no = $position+1;
                   foreach ($data_loan as $loan_entry){
                
                ?>   
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $loan_entry->id_borrower_loan; ?></td>
                  <td><?php echo $loan_entry->loan_date;?></td> 
                  <td><?php echo $loan_entry->loan_type; ?></td>
                  <td><?php echo number_format ($loan_entry->loan_amount,2); ?></td>
                  <td><?php echo $loan_entry->loan_rating; ?></td>

                  <td class="text-center">
                      <a href="<?php echo $info_url; ?>/<?php echo $loan_entry->id_borrower_loan; ?>" id="info" class="btn btn-info btn-sm btnwdt">Detail</a>
                  </td>
                </tr>
                <?php
                    $no++;
                 } 
                ?>
                </tbody>
              </table>
               <?php
                $data_rows = $this->register_model->get_borrower_list()->num_rows();
                $all_page  = ceil($data_rows/$limit);
                ?>
                <center>
                <ul class="pagination">
                    <li>
                        <?php
                            if($page > 1){
                                $prev = $page-1;
                                echo "<a href='".base_url()."Fintech_Site/B_borrower?page=$prev'>Previous</a>";
                            }
                        ?>
                    </li>
                    <li>
                        <?php
                            for($i=1;$i<=$all_page;$i++)
                                if ($i != $page){
                                    echo "<a href='".base_url()."Fintech_Site/B_borrower?page=$i'>$i</a>";
                                }
                        ?>
                        </li>
                        <li>
                        <?php
                            if($page < $all_page){
                                $next=$page+1;
                                echo "<a href='".base_url()."Fintech_Site/B_borrower?page=$next'>Next</a>";
                            }
                        ?>
                    </li>
                </ul>
                </center>
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->

<script type="text/javascript">
  function loaddata(register_code)
  {
    var register_code = register_code;

    $.ajax({
          type: 'POST',
          url: "<?php echo base_url(); ?>Fintech_Site/B_borrower/access_status_exchange",
          data: {
           register_code : register_code
          },

          success: function() {
             //alert('DONE' + id_aboutmenu);
     
          }
    });

    event.preventDefault();

  }
  </script>

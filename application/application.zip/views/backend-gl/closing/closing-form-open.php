<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

<style>
.ui-datepicker-calendar {
    display: none;
    }
</style>
      <div class="row">
        <div class="col-xs-12">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
      
            <!-- /.box-header -->
            <!-- form start -->
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
              <div class="col-lg-6 col-xs-12">
                <h3>Journal Posting</h3>
              </div>
              <div class="col-lg-6 col-xs-12 text-right">
                <a href="<?php echo $open_url; ?>" class="btn-warning btn-sm btn btnbig2">Open This Periode</a>
              </div>
              </div>
            </div>
          
            <div class="box-body">
                <div class="row">
                    <div class="col-lg-12 col-xs-12">
                        <table id="table-test" class="table table-bordered table-striped" width="100%">
                            <thead>
                            <tr>
                                 <th>No</th>
                                 <th >Number Journal</th>
                                 <th >Title</th>
                                 <th >Date Entry</th>
                                 <th >Date Posting</th>
                                 <th text-align: center;">Action</th>                 
                            </tr>
                            </thead>
                            <tbody>
                           <?php
                            $no=0;
                            $saldo = 0;
                               foreach ($data_journal as $journal_entry){
                            $no++;
                            ?>
                            <tr>
                              <td><?php echo $no; ?></td>
                              <td><?php echo $journal_entry->journal_no; ?></td>
                              <td><?php echo $journal_entry->journal_description; ?></td>
                              <td><?php echo $journal_entry->journal_entry; ?></td>
                              <td><?php echo $journal_entry->journal_date; ?></td>
                              <td style="text-align: center;">
                                  <a href="<?php echo $info_url; ?>/<?php echo $journal_entry->id_journal; ?>" id="info" class="btn btn-info btn-sm btnwdt">Detail</a>
                              </td>
                            </tr>
                            <?php 
                            // $no++;
                            } 
                            ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
          </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
<script type="text/javascript">
$(function() {
    $('.date-picker').datepicker( {
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,
        dateFormat: 'MM yy',
        onClose: function(dateText, inst) { 
            $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
        }
    });
});
</script>
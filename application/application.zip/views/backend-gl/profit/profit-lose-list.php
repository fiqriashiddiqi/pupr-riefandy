<?php date_default_timezone_set("Asia/Jakarta"); ?>

<style type="text/css">
#overflow_1, #overflow_2{width: 300px; border: none 0px RED;
overflow-x: scroll; overflow-y:hidden;}
#overflow_1{height: 20px; }
#overflow_2{height: 100px; }
#div1 {width:1000px; height: 20px; }
#div2 {width:1000px; height: 100px; background-color: #88FF88;
overflow: auto;}
</style>
<!-- Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title;?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
              <div class="col-lg-12 col-xs-12">
               <form method="get" action=""> 
                  <div class="col-lg-6 col-xs-12">
                     <?php 
                      $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : null;
                      $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
                      $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');
                    ?>
                    <div class="form-group">
                    <label for="">Start Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="start_date" class="form-control pull-right datepicker"  value="<?php echo @$start_date;?>" placeholder="Start Date" id="start_date">
       
                    </div>
                  </div>
                  </div>
                  <div class="col-lg-6 col-xs-12">
                    <div class="form-group">
                    <label for="">End Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="end_date" class="form-control pull-right datepicker"  value="<?php echo @$end_date;?>" placeholder="End Date" id="end_date">
       
                    </div>
                    </div>
                  </div>
                  <div class="col-lg-12 col-xs-12" align="right">
                    <button type="submit" class="btn btn-warning">Search !</button>
                  </div>
              </form>
              </div>
              </div>
            </div>
          
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                  <div class="col-lg-6 col-xs-12">
             
                </div>
                <div class="col-lg-6 col-xs-12 text-right">
              
                 <a href="<?php echo $excel_url; ?>?start_date=<?php echo @$start_date;?>&end_date=<?php echo @$end_date;?>" class="btn-success btn-sm btn btnbig2">Export Excel</a>
                </div>
              <div class="col-xs-12 col-lg-12">
              <div class="col-xs-12 col-lg-12" style="padding-top: 15px;">
                  <table class="table table-bordered table-striped" width="100%" cellpadding="10" cellspacing="0" border="1px">
                    <tr>
                         <td style="width: 60%;text-align: center;"><h4><strong>Description</strong></h4></td>
                         <td style="width: 20%;text-align: center;"><h4><strong>Amount</strong></h4></td>
                         <td style="width: 20%;text-align: center;"><h4><strong>Budget</strong></h4></td>
                    </tr>
                   <?php

                    $this->load->model('General_Ledger/journal_model');
                    $data_coa_a = $this->journal_model->get_coa_a();
                    // print_r($data_coa_a);
                    foreach ($data_coa_a as $coa_a_entry){
                    if ($coa_a_entry->coa_name_a == "REVENUE" OR $coa_a_entry->coa_name_a == "EXPENSES" OR $coa_a_entry->coa_name_a == "OTHER INCOME / EXPENSE"){
                    $total_coa_a = 0;
                     $total_coa_revenue = 0;
                    // $temp_total_a = 0;

                    ?>
                    <tr>
                      <td colspan="2" style="background-color: #b7b7b7;">&nbsp;&nbsp;&nbsp;<strong><?php echo $coa_a_entry->coa_name_a; ?></strong></td>
                       <td colspan="2" style="background-color: #b7b7b7;">&nbsp;&nbsp;&nbsp;<strong></strong></td>

                    </tr>
                    <?php
                        $data_coa_b = $this->journal_model->get_dropdown_coa_b($coa_a_entry->id_param_coa_a);
                        foreach ($data_coa_b as $coa_b_entry) {
                        $total_coa_b = 0;
                        $total_coa_b_revenue = 0;
                    ?>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo $coa_b_entry->coa_name_b; ?></strong></td>
                      <td></td>
                       <td></td>

                    </tr>
                    <?php
                            $data_coa_c = $this->journal_model->get_dropdown_coa_c($coa_b_entry->id_param_coa_b);
                            foreach ($data_coa_c as $coa_c_entry) {
                    ?>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo $coa_c_entry->coa_name_c; ?></strong></td>
                      <td></td>
                       <td></td>

                    </tr>
                    <?php
                            $data_coa_d = $this->journal_model->get_dropdown_coa_d($coa_c_entry->id_param_coa_c);
                            foreach ($data_coa_d as $coa_d_entry) {
                    ?>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo $coa_d_entry->coa_name_d; ?></strong></td>
                      <td></td>
                       <td></td>

                    </tr>
                    <?php
                            $data_coa_e = $this->journal_model->get_dropdown_coa_e($coa_d_entry->id_param_coa_d);
                            foreach ($data_coa_e as $key => $coa_e_entry) {
                              

                            $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : null;
                            $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : null;

                            $sum_data = $this->journal_model->sum_journal_by_coa_e($coa_e_entry->id_param_coa_e,$start_date,$end_date);

                            // $sum_amount = $sum_data[0]->debit-$sum_data[0]->credit;
                            $sum_amount = 0;
                            $sum_revenue = 0;
                            
                           
                            // if($sum_data[0]->debit==$sum_data[0]->credit){
                            //   $sum_amount = $sum_data[0]->debit;
                            // }else{
                            $sum_revenue = $sum_data[0]->debit-$sum_data[0]->credit;
                            $sum_amount = $sum_data[0]->debit-$sum_data[0]->credit;
                            // }
                            
                            $total_coa_b_revenue = $total_coa_b_revenue + $sum_revenue;
                            $total_coa_revenue = $total_coa_revenue + $sum_revenue;

                            $total_coa_a = $total_coa_a + $sum_amount;
                            $total_coa_b = $total_coa_b + $sum_amount;
                          

                            if ($total_coa_a > 0) {
                              
                              $total_coa_a=$total_coa_a;
                              $total_coa_b=$total_coa_b;
                              // $stor_kredit=0;
                            }else{
                              // $stor_debit=0;
                              $total_coa_a=$total_coa_a  ;
                              $total_coa_b=$total_coa_b ;

                            }
                             if ($total_coa_revenue > 0) {
                              
                              $total_coa_revenue=$total_coa_revenue;
                              $total_coa_b_revenue=$total_coa_b_revenue;
                              // $stor_kredit=0;
                            }else{
                              // $stor_debit=0;
                              $total_coa_revenue=$total_coa_revenue ;
                              $total_coa_b_revenue=$total_coa_b_revenue ;
                            }
                            // var_dump($total_coa_b_revenue);

                    ?>      
                    <tr>    
                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - <?php echo $coa_e_entry->coa_name_e; ?></td>
                            <?php
                             if($coa_a_entry->coa_name_a=="REVENUE"){
                              ?>
                              <td align="right"><?php echo number_format($sum_revenue,0,".","."); ?></td>
                              <td></td>

                              <?php
                            }else if($coa_a_entry->coa_name_a=="EXPENSES" OR $coa_a_entry->coa_name_a=="OTHER INCOME / EXPENSE"){
                              ?>
                              <td align="right"><?php echo number_format($sum_amount
                                ,0,".","."); ?></td>
                              <td></td>


                              <?php
                            }
                            ?>
                            
                    </tr>
                    <?php
                                    }
                    ?>
                    <tr>
                            <td>&nbsp;</td>
                            <td align="right">&nbsp;</td>
                            <td align="right">&nbsp;</td>
                    </tr>
                    <?php
                                }
                            }
                    ?>
                    <tr>
                            <td align="center" style="background-color: lightgray;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>TOTAL <?php echo $coa_b_entry->coa_name_b; ?></strong></td>

                             <?php
                             if($coa_a_entry->coa_name_a=="REVENUE"){
                              ?>
                              <td align="right" style="background-color: lightgrey;"><?php echo number_format($total_coa_b_revenue
                                ,0,".","."); ?></td>
                              <td align="right" style="background-color: lightgrey;"><?php echo number_format($total_coa_b_revenue
                                ,0,".","."); ?></td>



                              <?php
                            }else if($coa_a_entry->coa_name_a=="EXPENSES" OR $coa_a_entry->coa_name_a=="OTHER INCOME / EXPENSE"){
                              ?>
                              <td align="right" style="background-color: lightgray;"><?php echo number_format($total_coa_b
                                ,0,".","."); ?></td>
                                <td align="right" style="background-color: lightgray;"><?php echo number_format($total_coa_b
                                ,0,".","."); ?></td>
                              


                              <?php
                            }
                            ?>
                          <!-- <td align="right" style="background-color: lightgray;"><strong><?php echo number_format($total_coa_b,0,".","."); ?></strong></td> -->
                    </tr>

                    <?php
                        }
                    ?>
                    <tr>
                            <td align="center" style="background-color: #b7b7b7;">&nbsp;&nbsp;&nbsp;<strong>TOTAL <?php echo $coa_a_entry->coa_name_a; ?></strong></td>
                            <td align="right" style="background-color: #b7b7b7;">
                              <strong>
                              <span value=<?php echo $total_coa_a;?>  
                            <?php
                             if($coa_a_entry->coa_name_a=="REVENUE"){
                            ?> 
                              <td align="right"><?php echo number_format($total_coa_revenue
                                ,0,".","."); ?></td>
                           <td align="center" style="background-color: #b7b7b7;">&nbsp;&nbsp;&nbsp;<strong></strong></td>
                            



                              <?php
                            }else if($coa_a_entry->coa_name_a=="EXPENSES" OR $coa_a_entry->coa_name_a=="OTHER INCOME / EXPENSE"){
                              ?>
                              <td align="right" ><?php echo number_format($total_coa_a
                                ,0,".","."); ?></td>
                             <td align="center" style="background-color: #b7b7b7;">&nbsp;&nbsp;&nbsp;<strong></strong></td>


                              <?php
                            }
                            ?>

                              <?php 
                                if($coa_a_entry->coa_name_a=="REVENUE"){
                                  $end_total_revenue = $total_coa_revenue;
                                }else if($coa_a_entry->coa_name_a=="EXPENSES" OR $coa_a_entry->coa_name_a=="OTHER INCOME / EXPENSE"){
                                  $end_total_expense = $total_coa_a;
                                }
                              ?>

                              </span></strong></td>
                    </tr>
                    <tr>
                            <td>&nbsp;</td>

                            <td align="right">
                             
                            </td>

                    </tr>
                    <?php
                    }
                    } ?>

                     <tr>
                            <td style="text-align: center;"><strong>TOTAL PROFIT LOSS </strong></td>
                            <td align="right">
                              <?php
                                $netto = $end_total_revenue - $end_total_expense;
                                echo number_format($netto,0,".",".");

                              ?>
                            </td>
                              <td></td>

                    </tr>
                  
                   </table>

                   
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>

        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<script type="text/javascript">

// var overflow_1 = document.getElementById('overflow_1');
// var overflow_2 = document.getElementById('overflow_2');
// overflow_1.onscroll = function() {
//   overflow_2.scrollLeft = overflow_1.scrollLeft;
// };
// overflow_2.onscroll = function() {
//   overflow_1.scrollLeft = overflow_2.scrollLeft;
// };


</script>



<!-- jQuery 2.2.3 -->
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <!-- <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li> -->
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
      
        <div class="box" id="">
            <div class="box-header with-border">
              <div class="row">
              <div class="col-lg-12 col-xs-12">
               <form method="get" action="#"> 
                  <div class="col-lg-6 col-xs-12">
                    <?php 
                      $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : null;
                      $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
                      $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');
                    ?>
                    <div class="form-group">
                    <label for="">Start Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="start_date" class="form-control pull-right datepicker" value="<?php echo $start_date;?>" placeholder="Start Date" id="start_date">
       
                    </div>
                  </div>
                <div  class="form-group" ">
                  <label>Parent Account </label>
                  <select class="form-control select2" name="id_param_coa_e" style="width: 100%;">
                  <option value="">- Get All Data -</option>

                  <?php
                   

                        foreach ($dropdown_coa_e as $journal_entry) {
                                                                       
                  ?>
                        <option value="<?php echo $journal_entry->id_param_coa_e;  ?>" <?php if($id_param_coa_e==$journal_entry->id_param_coa_e){ echo"selected='selected'"; }?> ><?php echo $journal_entry->coa_code_e; ?> | <?php echo $journal_entry->coa_name_e; ?></option>


                  <?php
                // }
                        }
                  ?>

                </select>
                
              </div>
                  </div>
                  <div class="col-lg-6 col-xs-12">
                    <div class="form-group">
                    <label for="">End Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="end_date" class="form-control pull-right datepicker" value="<?php echo $end_date; ?>" placeholder="End Date" id="end_date">
       
                    </div>
                    </div>
                  </div>

                 <!--   <div class="col-lg-6 col-xs-12">
                    <div class="col-lg-6 col-xs-12">
                      <div class="form-group">
                      <label for="">Month</label>
                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-calendar"></i>
                        </div>
                         <input type="text" name="dateYearMonth" class="form-control pull-right monthPicker" value="" placeholder="Month" id="dateYearMonth">
                    
                      </div>
                      </div>
                    </div>
                  </div> -->

                  <div class="col-lg-12 col-xs-12" align="right">
                    <button type="submit" class="btn btn-warning">Search !</button>
                  </div>
              </form>
              </div>
              </div>               
               
            
            </div>
            <!-- /.box-header -->
            <!-- form start -->
           
          </div>


          <div class="box">
            <div class="box-header with-border">
              <div class="row">
              <div class="col-lg-6 col-xs-12">
              <!-- <h3><strong>General Ledger</strong></h3> -->
              </div>
              <!-- ?start_date=<?php echo @$start_date ?>?end_date=<?php echo @$end_date ?> -->
              <div class="col-lg-6 col-xs-12 text-right">
                <a href="<?php echo $excel_url; ?>?id_param_coa_e=<?php echo @$id_param_coa_e ?>&start_date=<?php echo @$start_date;?>&end_date=<?php echo @$end_date;?>" class="btn-success btn-sm btn btnbig2">Export Excel</a>
              </div>
              </div>
            </div>
          
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12">
              <div class="col-xs-12 col-lg-12"  style="padding-top: 15px;">


                <?php 
                $this->load->model('General_Ledger/journal_model');

                $data_table = $this->journal_model->get_tableledger($id_param_coa_e, $start_date, $end_date);
                foreach ($data_table as $table_entry) {
               
                $data_saldo_akhir = $this->journal_model->get_saldo_akhir($table_entry->id_param_coa_e,$start_date);

                $saldo_akhir = 0;
                foreach ($data_saldo_akhir as $saldo_akhir_entry) {
                  $saldo_akhir = ($saldo_akhir + $saldo_akhir_entry->journal_debit) - $saldo_akhir_entry->journal_kredit;
                }

                ?>


                <div style="background-color: whitesmoke; height:35px;margin-bottom: 2px; ">
                <h4><b style="line-height: 2; margin-left: 8px;"><?php echo $table_entry->coa_code_e; ?> || <?php echo $table_entry->coa_name_e; ?></b></h4>
                </div>
                  <table id="" class="table table-bordered table-striped" width="100%">
                    <thead>
                       <tr style="background-color: whitesmoke;">
                          <td><strong>Saldo Awal :</strong></td>
                          <td><?php echo number_format($saldo_akhir); ?></td>
                          <td></td>
                          <td align="center"></td>
                          <td align="center"></td>
                          <td align="center"></td>
                          <td align="center"></td>
                      </tr> 
                    <tr>
                         <th style="display: none;">No</th>
                         <th style="width: 10%;">Date</th>
                         <th style="width: 25%;">Account</th>
                         <th style="width: 8%;"">Number Journal</th>
                         <th style="width: 25%;">Description</th>
                         <th style="text-align: center;width: 10%;">Debit</th>
                         <th style="text-align: center;width: 10%;">Credit</th>
                         <th style="text-align: center;width: 10%;">Saldo</th>
                         <!-- <th   text-align: center;">Action</th> -->
                         
                        
                    </tr>
                    </thead>
                    <tbody>
                       <?php
                      
                        $data_journal = $this->journal_model->get_ledger($table_entry->id_param_coa_e,$start_date, $end_date);

                        $no=0;
                        $saldo = $saldo_akhir;
                        $saldodebit = 0;
                        $saldokredit = 0;
                           foreach ($data_journal as $journal_entry){
                        $no++;
                                $saldo = ($saldo + $journal_entry->journal_debit) - $journal_entry->journal_kredit;
                                $saldodebit = $saldodebit + $journal_entry->journal_debit;
                                $saldokredit = $saldokredit + $journal_entry->journal_kredit;

                     
                        ?>  
                        <tr>
                          <td style="display: none;"><?php echo $no; ?></td>
                          <td><?php echo date('d/m/Y', strtotime($journal_entry->journal_date)); ?> </td> 
                          <td><?php echo $journal_entry->coa_code_e; ?> || <?php echo $journal_entry->coa_name_e; ?> </td>
                          <td><?php echo $journal_entry->journal_no; ?> </td>
                          <td><?php echo $journal_entry->journal_description; ?> </td>
                          <td align="center"><?php echo number_format($journal_entry->journal_debit,0,".","."); ?> </td>
                          <td align="center"><?php echo number_format($journal_entry->journal_kredit,0,".","."); ?> </td>
                          <td align="center"><?php echo number_format($saldo,0,".","."); ?> </td>
                        </tr>
                        <?php 
                        // $no++;
                        } 
                        ?>
                    </tbody>
                      <tr>
                          <td></td>
                          <td></td>
                          <td></td>
                          <td align="center"><strong>TOTAL</strong></td>
                          <td align="center"><?php echo number_format($saldodebit,0,".","."); ?> </td>
                          <td align="center"><?php echo number_format($saldokredit,0,".","."); ?> </td>
                          <td align="center"> </td>
                          <!-- <td align="center"><?php echo number_format($saldo); ?> </td> -->
                      </tr> 
                      <tr style="background-color: whitesmoke;">
                        <span>
                          <td><strong>Saldo Akhir : </strong></td>
                          <td><?php echo number_format($saldo,0,".","."); ?></td>
                          <td></td>
                          <td align="center"></td>
                          <td align="center"> </td>
                          <td align="center"> </td>
                          <td align="center"> </td>
                          </span>
                      </tr> 
                   </table>

               <?php } ?>
               
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>



        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
<script type="text/javascript"> 
    

    function change_journal() {
        var journal_status = $("#journal_status").val();

        if(journal_status == "Debit") {
            document.getElementById('debit').required = true;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = false;
            document.getElementById('credit').disabled = true;
            document.getElementById("credit").value = parseInt(0);

        } else if(journal_status == "Credit") {
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = true;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = false;
            document.getElementById("debit").value = parseInt(0);

        } else {
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = true;
            document.getElementById("debit").value = parseInt(0);
            document.getElementById("credit").value = parseInt(0);
        }
    }

    // $( "#dateFormat" ).datepicker({dateFormat: 'yy'});
    // console.log($("#dateFormat").val());
     // $( "#dateYearMonth" ).datepicker({dateFormat: 'yymm'}); 
      console.log($( "#dateYearMonth" ).val());
     // $('#dateYearMonth').datepicker( {
     //         changeMonth: true,
     //         changeYear: true,
     //         showButtonPanel: true,
     //         dateFormat: 'MM yy',
     //         onClose: function(dateText, inst) { 
     //             var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
     //             var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
     //             $(this).datepicker('setDate', new Date(year, month, 1));
     //         }
     //     });
     $(".monthPicker").datepicker({
             dateFormat: 'MM yy',
             changeMonth: true,
             changeYear: true,
             showButtonPanel: true,

             onClose: function(dateText, inst) {
                 var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
                 var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
                 $(this).val($.datepicker.formatDate('yy-mm', new Date(year, month, 1)));
             }
         });

         $(".monthPicker").focus(function () {
             $(".ui-datepicker-calendar").hide();
             $("#ui-datepicker-div").position({
                 my: "center top",
                 at: "center bottom",
                 of: $(this)
             });
         });
</script>

<style type="text/css">
  .ui-datepicker-calendar {
     display: none;
  }
</style>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
       <!-- <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>  -->
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>

          <div class="box">
            <div class="box-header with-border">
              <div class="row">
              <div class="col-lg-6 col-xs-12">
              <!-- <h3><strong>General Journal</strong></h3> -->
               <?php 
                   $journal_no = isset($_REQUEST['journal_no']) ? $_REQUEST['journal_no'] : NULL;
                ?>
              </div>
              <div class="col-lg-6 col-xs-12 text-right">
                <!-- <a href="<?php echo $create_url; ?>" class="btn-primary btn-sm btn btnbig2">Add Option</a> -->
                 <a href="<?php echo $excel_url; ?>?journal_no="<?php echo @$journal_no; ?>" class="btn-success btn-sm btn btnbig2">Export Excel</a>
              </div>
              </div>
            </div>
          
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12">
              <div class="col-xs-12 col-lg-12"  style="padding-top: 15px;">
                  <table id="" class="table table-bordered table-striped" width="100%">
                    <thead>
                    <tr>
                         <th>No</th>
                         <th >Date</th>
                         <th >Account</th>
                         <!-- <th >Description</th> -->
                         <th style=  "text-align: center;">Debit</th>
                         <th style= " text-align: center;">Credit</th>
                         <!-- <th style="  text-align: center;">Saldo</th> -->
                         <!-- <th   text-align: center;">Action</th> -->
                         
                        
                    </tr>
                    </thead>
                    <tbody>
                   <?php

                    $this->load->model('General_Ledger/journal_model');
                    $data_journal = $this->journal_model->get_journal();

                    $no=0;
                    $saldo = 0;
                   $saldodebit = 0;
                   $saldokredit = 0;
                       foreach ($data_journal as $journal_entry){
                         $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : null;
                            $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : null;

                            // $sum_data = $this->journal_model->sum_journal_by_coa_e($coa_e_entry->id_param_coa_e,$start_date,$end_date);
                    $no++;
                            $saldo = ($saldo + $journal_entry->journal_debit) - $journal_entry->journal_kredit;
                            $saldodebit = $saldodebit + $journal_entry->journal_debit;
                            $saldokredit = $saldokredit + $journal_entry->journal_kredit;
                    ?>  
                    <tr>
                      <td><?php echo $no; ?></td>
                      <td><?php echo date('d/m/Y', strtotime($journal_entry->journal_date)); ?> </td> 
                      <td><?php echo $journal_entry->coa_code_e; ?> || <?php echo $journal_entry->coa_name_e; ?> </td>
                      <!-- <td><?php echo $journal_entry->journal_description_form; ?> </td> -->
                      <td align="center"><?php echo number_format($journal_entry->journal_debit); ?> </td>
                      <td align="center"><?php echo number_format($journal_entry->journal_kredit); ?> </td>
                      <!-- <td align="center"><?php echo number_format($saldo); ?> </td> -->
                      
                    </tr>

                       
                    <?php 
                    // $no++;
                    } 
                    ?>
                    

                    </tbody>
                        <tr>
                            <!-- <td></td> -->
                            <td></td>
                            <td></td>
                            <td align="center"><strong>TOTAL</strong></td>
                            <td align="center"><?php echo number_format($saldodebit); ?> </td>
                            <td align="center"><?php echo number_format($saldokredit); ?> </td>
                    
                            <td></td>
                        </tr>
                   </table>
             <!--  <?php
                $data_rows = $this->journal_model->get_journal_list()->num_rows();
                $all_page  = ceil($data_rows/$limit);
                ?>
                <center>
                <ul class="pagination">
                    <li>
                        <?php
                            if($page > 1){
                                $prev = $page-1;
                                echo "<a href='".base_url()."General_Ledger/b_journal?page=$prev'>Previous</a>";
                            }
                        ?>
                    </li>
                    <li>
                        <?php
                            for($i=1;$i<=$all_page;$i++)
                                if ($i != $page){
                                    echo "<a href='".base_url()."General_Ledger/b_journal?page=$i'>$i</a>";
                                }
                        ?>
                        </li>
                        <li>
                        <?php
                            if($page < $all_page){
                                $next=$page+1;
                                echo "<a href='".base_url()."General_Ledger/b_journal?page=$next'>Next</a>";
                            }
                        ?>
                    </li>
                </ul>
                </center>  -->
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>



        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
<script type="text/javascript"> 
    window.addEventListener('load', function() {
        var data_debit = <?php echo $data_journal[0]->journal_debit; ?>;
        var data_credit = <?php echo $data_journal[0]->journal_kredit; ?>;

        if (data_debit > 0){
            document.getElementById('debit').required = true;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = false;
            document.getElementById('credit').disabled = true;
            document.getElementById("credit").value = parseInt(0);
        } else if(data_credit > 0){
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = true;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = false;
            document.getElementById("debit").value = parseInt(0);

        } else {
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = true;
        }

    });

    function change_journal() {
        var journal_status = $("#journal_status").val();

        if(journal_status == "Debit") {
            document.getElementById('debit').required = true;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = false;
            document.getElementById('credit').disabled = true;
            document.getElementById("credit").value = parseInt(0);

        } else if(journal_status == "Credit") {
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = true;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = false;
            document.getElementById("debit").value = parseInt(0);

        } else {
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = true;
            document.getElementById("debit").value = parseInt(0);
            document.getElementById("credit").value = parseInt(0);
        }
    }
</script>
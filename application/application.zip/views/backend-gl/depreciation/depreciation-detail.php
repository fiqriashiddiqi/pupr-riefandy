<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <!-- <?php echo $title; ?> -->
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <!-- <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li> -->
        <!-- <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li> -->
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
      
        <div class="box" id="">
        
            <div class="box-header with-border">
               
               
            
            </div>
            <!-- /.box-header -->
            <!-- form start -->
           
          </div>

          <div class="box">
            <div class="box-header with-border">
              <div class="row">
              <div class="col-lg-6 col-xs-12">
              <h3><strong>Assets</strong></h3>
              </div>
              <div class="col-lg-6 col-xs-12 text-right">
                <!-- <a href="<?php echo $create_url; ?>" class="btn-primary btn-sm btn btnbig2">Add assets</a> -->
              </div>
              </div>
            </div>
          
            <div class="box-body">
              <div class="row">
              <div class="col-xs-12 col-lg-12">
              <div class="col-xs-12 col-lg-12"  style="padding-top: 15px;">
                  <table id="" class="table table-bordered table-striped" width="100%">
                    <thead>
                    <tr>
                         <th>No</th>
                         <th>Purchase Assets Date</th>
                         <th>Assets Number</th>
                         <th>Assets Remark </th>
                         <th>Assets Class</th>
                         <th>Assets Name</th>
                         <th>Assets/Year</th>
                         <th>Assets Price</th>
                         <th>Assets Location</th>
                         <th>Assets Despreciation</th>

                        <!--  <th style= "text-align: center;">Debit</th>
                         <th style= " text-align: center;">Credit</th> -->
                         <!-- <th style="  text-align: center;">Saldo</th> -->
                         <!-- <th   text-align: center;">Action</th> -->
                         
                        
                    </tr>
                    </thead>
                    <tbody>
                   <?php

                    $this->load->model('General_Ledger/journal_model');
                    $id_assets = $this->uri->segment(4);
                    $data_assets = $this->journal_model->get_assets_detail($id_assets);
                    // print_r($id_assets);

                    $no=0;
                    $saldoassets = 0;
                    $assets = 0;
                       foreach ($data_assets as $assets_entry){
                        // print_r($assets_entry->assets_name);
                    $no++;
                            $assets =  ($assets_entry->assets_price / $assets_entry->assets_age)/12;
                             $assetsyear =  ($assets_entry->assets_price / $assets_entry->assets_age);
                            $saldoassets = $assets_entry->assets_price - $assets;

                            // print_r($depretiation);
                            // print_r($saldodepretiation);
                            // die();
                          //   if ($saldo > 0) {
                          //     $stor_debit=$saldo;
                          //     $stor_kredit=0;
                          //   }else{
                          //     $stor_debit=0;
                          //     $saldo=$saldo*-1;

                          //     $stor_kredit=$saldo;

                          //   }

                          // $saldokredit=$saldokredit+$stor_kredit;
                          // $saldodebit=$saldodebit+$stor_debit;

                    ?>  
                    <tr>
                      
                      <td><?php echo $no; ?></td>
                      <td><?php echo date('d/m/Y', strtotime($assets_entry->assets_date)); ?> </td>
                      <!-- <td><?php echo $assets_entry->coa_code_e; ?> || <?php echo $assets_entry->coa_name_e; ?> </td>  -->
                       <td><?php echo $assets_entry->assets_no; ?> </td>
                      <td><?php echo $assets_entry->assets_remark; ?> </td>
                      <td><?php echo $assets_entry->assets_class; ?> </td>
                      <td><?php echo $assets_entry->assets_name; ?> </td>
                      <td><?php echo $assets_entry->assets_age; ?> </td>
                      <td><?php echo number_format($assets_entry->assets_price,2); ?> </td>
                      <td><?php echo $assets_entry->assets_loc; ?> </td>
                    
                      <td align="center"><?php echo number_format($assets ,2); ?> </td>
                      <!-- <td align="center"><?php echo number_format($assetsyear,2); ?> </td> -->
                      <!-- <td align="center"><?php echo number_format($saldodepretiation,2); ?> </td> -->
                      
                    </tr>

                       
                    <?php 
                    // $no++;
                    } 
                    ?>
                    

                    </tbody>
                        <!-- <tr>
                            <td></td>
                   
                            <td align="center"><strong>TOTAL</strong></td>
                            <td align="center"><?php echo number_format($saldodebit,2); ?> </td>
                            <td align="center"><?php echo number_format($saldokredit,2); ?> </td>
                    
                            <td></td>
                        </tr> -->
                   </table>
            
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>



        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->

<?php date_default_timezone_set("Asia/Jakarta"); ?>

<style type="text/css">
#overflow_1, #overflow_2{width: 300px; border: none 0px RED;
overflow-x: scroll; overflow-y:hidden;}
#overflow_1{height: 20px; }
#overflow_2{height: 100px; }
#div1 {width:1000px; height: 20px; }
#div2 {width:1000px; height: 100px; background-color: #88FF88;
overflow: auto;}
</style>
<!-- Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title;?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
              <div class="col-lg-12 col-xs-12">
               <form method="get" action=""> 
                  <div class="col-lg-6 col-xs-12">
                    <?php 
                      $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : null;
                      $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
                      $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');
                    ?>
                    <div class="form-group">
                    <label for="">Start Date </label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="start_date" class="form-control pull-right datepicker" value="<?php echo @$start_date; ?>" placeholder="Start Date" id="start_date">
       
                    </div>
                  </div>
                  </div>
                  <div class="col-lg-6 col-xs-12">
                    <div class="form-group">
                    <label for="">End Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="end_date" class="form-control pull-right datepicker" value="<?php echo @$end_date; ?>" placeholder="End Date" id="end_date">
       
                    </div>
                    </div>
                  </div>
                  <div class="col-lg-12 col-xs-12" align="right">
                    <button type="submit" class="btn btn-warning">Search !</button>
                  </div>
              </form>
              </div>
              </div>
            </div>
          
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                 <div class="col-lg-6 col-xs-12">
                 <?php 
                   $id_journal = isset($_REQUEST['id_journal']) ? $_REQUEST['id_journal'] : NULL;
                    $ending_balance=0;
                    $begening_balance=0;

                   @$data_begening = $this->journal_model->get_cashflow_begining(null,$start_date);

                   @$begening_balance= $data_begening[0]->debit-$data_begening[0]->kredit;


                ?>
                </div>
                <div class="col-lg-6 col-xs-12 text-right">
              
                 <a href="<?php echo $excel_url; ?>?start_date=<?php echo @$start_date;?>&end_date=<?php echo @$end_date;?>" class="btn-success btn-sm btn btnbig2">Export Excel</a>
                </div>
              <div class="col-xs-12 col-lg-12">
              <div class="col-xs-12 col-lg-12" style="padding-top: 15px;">
                  <table class="table table-bordered table-striped" width="100%" cellpadding="10" cellspacing="0" border="1px">
                    <tr  >
                         <td style="width: 35%;text-align: center;"><h4><strong>Description</strong></h4></td>
                         <td style="width: 15%;text-align: center;"><h4><strong>Amount</strong></h4></td>
                         <td style="width: 35%;text-align: center;"><h4><strong>Description</strong></h4></td>
                         <td style="width: 15%;text-align: center;"><h4><strong>Amount</strong></h4></td>
                    </tr>
                    <tr>
                      <th colspan="4">Begining Balance : &nbsp;Rp.<?php echo number_format(@$begening_balance); ?></th>            
                    </tr>
                    <tr style="background-color: #ffd100;">
                      <th colspan="2">CASH INFLOW</th>
                      <th colspan="2">CASH OUTFLOW</th>

                    </tr>
                    <?php
                    // $year_temp = isset($_REQUEST['start_date']) ? (date("Y",strtotime($_REQUEST['start_date'])) - 1) : date('Y');
                    // $month_temp = isset($_REQUEST['start_date']) ? (date("m",strtotime($_REQUEST['start_date'])) - 1) : date('m');

                    // $month_temp = ($month_temp<10) ? '0'.$month_temp : $month_temp;

                    // $begining_date_start = $year_temp.'-'.$month_temp.'-01'; 
                    // $begining_date_end  = date("Y-m-t", strtotime($begining_date_start));

                    // echo $begining_date_start.'====='.$begining_date_end;

                 
                      //Tarik data Cash Inflow
                      @$data_ID = $this->journal_model->get_cashflow('ID',$start_date,$end_date);
                      @$data_LR = $this->journal_model->get_cashflow('LR',$start_date,$end_date);
                      @$data_LIP = $this->journal_model->get_cashflow('LIP',$start_date,$end_date);
                      @$data_PEN = $this->journal_model->get_cashflow('PEN',$start_date,$end_date);
                      @$data_IP = $this->journal_model->get_cashflow('IP',$start_date,$end_date);
                      @$data_TF = $this->journal_model->get_cashflow('TF',$start_date,$end_date);
                      @$data_II = $this->journal_model->get_cashflow('II',$start_date,$end_date);
                      @$data_PUC = $this->journal_model->get_cashflow('PUC',$start_date,$end_date);
                      @$data_SH = $this->journal_model->get_cashflow('SH',$start_date,$end_date);
                      @$data_OTD = $this->journal_model->get_cashflow('OTD',$start_date,$end_date);

                      //Cash data Outflow
                      @$data_LD = $this->journal_model->get_cashflow('LD',$start_date,$end_date);
                      @$data_WD = $this->journal_model->get_cashflow('WD',$start_date,$end_date);
                      @$data_SB = $this->journal_model->get_cashflow('SB',$start_date,$end_date);
                      @$data_ME = $this->journal_model->get_cashflow('ME',$start_date,$end_date);
                      @$data_INS = $this->journal_model->get_cashflow('INS',$start_date,$end_date);
                      @$data_TE = $this->journal_model->get_cashflow('TE',$start_date,$end_date);
                      @$data_OOE = $this->journal_model->get_cashflow('OOE',$start_date,$end_date);
                      @$data_FAA = $this->journal_model->get_cashflow('FAA',$start_date,$end_date);
                      @$data_SH = $this->journal_model->get_cashflow('SHR',$start_date,$end_date);
                      @$data_OTC = $this->journal_model->get_cashflow('OTC',$start_date,$end_date);

                   
                         // var_dump($data_cashflowloanrepayment);
                      $Total_cash_in= $data_ID[0]->debit+$data_LR[0]->debit+$data_LIP[0]->debit+$data_PEN[0]->debit+$data_IP[0]->debit+$data_TF[0]->debit+$data_II[0]->debit+$data_PUC[0]->debit+$data_SH[0]->debit+$data_OTD[0]->debit;

                      $Total_cash_out= $data_LD[0]->kredit+$data_WD[0]->kredit+$data_SB[0]->kredit+$data_ME[0]->kredit+$data_INS[0]->kredit+$data_TE[0]->kredit+$data_OOE[0]->kredit+$data_FAA[0]->kredit+$data_SH[0]->kredit+$data_OTC[0]->kredit;

                      $ending_balance=$begening_balance+ $Total_cash_in-$Total_cash_out;
                     ?>
                    <tr >
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Investor Deposit</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_ID[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Loan Disbursement</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_LD[0]->kredit,0,".","."); ?></td>
                    </tr>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Loan Repayment</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_LR[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Withdrawal</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_WD[0]->kredit,0,".","."); ?></td>
                    </tr>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Loan Interest Payment</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_LIP[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Salary & Benefit</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_SB[0]->kredit,0,".","."); ?></td>
                    </tr>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Penalty</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_PEN[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Marketing Expenses</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_ME[0]->kredit,0,".","."); ?></td>
                    </tr>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Insurance Payment</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_IP[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Insurance</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_INS[0]->kredit,0,".","."); ?></td>
                    </tr>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Transaction Fee</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_TF[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Transaction Expenses</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_TE[0]->kredit,0,".","."); ?></td>
                    </tr>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Investment Income</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_II[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Other Operating Expenses</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_OOE[0]->kredit,0,".","."); ?></td>
                    </tr>
                    <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Paid Up Capital</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_PUC[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fix Assets Acquisition</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_FAA[0]->kredit,0,".","."); ?></td>
                    </tr>
                     <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Share Holder</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_SH[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Share Holder Loan Repayment</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_SHR[0]->kredit,0,".","."); ?></td>
                    </tr>
                     <tr>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Others</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_OTD[0]->debit,0,".","."); ?></td>
                      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Others</td>
                      <td style="text-align: right;"><?php echo number_format(@$data_OTC[0]->kredit,0,".","."); ?></td>
                    </tr>
                     <tr>
                      <th> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total Cash Inflow </th>
                      <th style="text-align: right;">Rp.<?php echo number_format(@$Total_cash_in,0,".","."); ?></th>
                      <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total Cash Outflow </th>
                      <th style="text-align: right;">Rp.<?php echo number_format(@$Total_cash_out,0,".","."); ?></th>
                    </tr>

                    <tr>
                      <th colspan="2">Ending Balance : &nbsp;Rp.<?php echo number_format(@$ending_balance,0,".","."); ?></th>
                      <th colspan="2" style="text-align: center;"></th>
                    </tr>

             
                   </table>

                   
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>

        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<script type="text/javascript">



</script>


<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         <?php echo $title; ?>
      </h1>
      <ol class="breadcrumb">
       <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <!-- <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li> -->
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
            <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>
      
        <div class="box" id="">
        
            <div class="box-header with-border">
               
              <div class="row">
              <div class="col-lg-12 col-xs-12">
               <form method="get" action="#"> 
                  <div class="col-lg-6 col-xs-12">
                    <?php 
                      $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : null;
                      $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
                      $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');
                    ?>
                    <div class="form-group">
                    <label for="">Start Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="start_date" class="form-control pull-right datepicker" value="<?php echo @$start_date;?>" placeholder="Start Date" id="start_date">
       
                    </div>
                  </div>
               
                  </div>
                  <div class="col-lg-6 col-xs-12">
                    <div class="form-group">
                    <label for="">End Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="end_date" class="form-control pull-right datepicker" value="<?php echo @$end_date; ?>" placeholder="End Date" id="end_date">
       
                    </div>
                    </div>
                  </div>

                  <div class="col-lg-12 col-xs-12" align="right">
                    <button type="submit" class="btn btn-warning">Search !</button>
                  </div>
              </form>
              </div>
              </div>               
               
            
            </div>
               
            
            </div>
            <!-- /.box-header -->
            <!-- form start -->
          <div class="box">
            <div class="box-header with-border">
              <div class="row">
                  <div class="col-lg-6 col-xs-12">
                 <?php 
                   $id_journal = isset($_REQUEST['id_journal']) ? $_REQUEST['id_journal'] : NULL;
                ?>
                </div>
                <div class="col-lg-6 col-xs-12 text-right">
              
                  <a href="<?php echo $excel_url; ?>?start_date=<?php echo @$start_date;?>&end_date=<?php echo @$end_date;?>" class="btn-success btn-sm btn btnbig2">Export Excel</a>
                </div>
              <div class="col-lg-6 col-xs-12">
              <!-- <h3><strong>Trial Balance</strong></h3> -->
              </div>
              <div class="col-lg-6 col-xs-12 text-right">
                <!-- <a href="<?php echo $create_url; ?>" class="btn-primary btn-sm btn btnbig2">Add Option</a> -->
              </div>
              </div>
            </div>
          
            <div class="box-body">
              <div class="row">

               <?php 
                $this->load->model('General_Ledger/journal_model');
               
                //  $data_saldo_akhir = $this->journal_model->get_saldo_akhir($id_param_coa_e,@$start_date);

                // // print_r($start_date);
                // // print_r($end_date);
                // $saldo_akhir = 0;
                // foreach ($data_saldo_akhir as $saldo_akhir_entry) {
                //   $saldo_akhir = ($saldo_akhir + $saldo_akhir_entry->journal_debit) - $saldo_akhir_entry->journal_kredit;
                // }

                ?>
              <div class="col-xs-12 col-lg-12">
              <div class="col-xs-12 col-lg-12"  style="padding-top: 15px;">
                  <table id="" class="table table-bordered table-striped" width="100%" border=1 fixed;>
                    <thead>

                    <tr>
                        <th style="text-align: center; padding-bottom: 25px;" rowspan='2' >Account</th>
                        <th style="text-align: center; padding-bottom: 25px;" rowspan='2'>Beginning Balance</th>
                        <th style="text-align: center;" colspan='2'>Movement</th>
                        <th style="text-align: center; padding-bottom: 25px;" rowspan='2'>Ending Balance</th>
                    </tr>
              
                    <tr>
                   
                         <th style= "text-align: center;">Debit</th>
                         <th style= " text-align: center;">Credit</th>
                        
                         <!-- <th style="  text-align: center;">Saldo</th> -->
                         <!-- <th   text-align: center;">Action</th> --> 
                    </tr>
                    <tr>
                        

                    </tr>
                    
                    </thead>
                    <tbody>
                   <?php
                    

                    $data_journal = $this->journal_model->get_trialbalance($id_param_coa_e,null,@$start_date,@$end_date);

                    $no=0;
                    $total_endsaldo= 0;
                    $total_begining= 0;
                    $saldodebit = 0;
                    $saldokredit = 0;
                    $saldo_mutasi_debit=0;
                    $saldo_mutasi_kredit=0;
                    $endsaldo=0;
                    $saldobegening=0;
                    // var_dump($data_journal); die();
                       foreach ($data_journal as $journal_entry){
                    $no++;
                            $data_saldo_akhir = $this->journal_model->get_saldo_akhir_trial($journal_entry->id_param_coa_e,@$start_date,@$end_date);

                            $isExists = $this->journal_model->get_journaldate_status(@$start_date,@$end_date);

                            if($isExists != "0"){
                              // echo "a";

                                $saldobegening=  @$data_saldo_akhir[0]->debit - @$data_saldo_akhir[0]->kredit;
                                $saldo =  $journal_entry->debit - $journal_entry->kredit;
                                $endsaldo= $saldobegening;

                                // $saldo_mutasi_kredit = $journal_entry->kredit;
                                // $saldo_mutasi_debit = $journal_entry->debit;
             

                                $total_endsaldo = $total_endsaldo + $endsaldo;
                                $total_begining = $total_begining + $saldobegening;

                                $saldokredit=$saldokredit+$saldo_mutasi_kredit;
                                $saldodebit=$saldodebit+$saldo_mutasi_debit;

                            }else{

                                $saldobegening=  @$data_saldo_akhir[0]->debit - @$data_saldo_akhir[0]->kredit;

                                $saldo_mutasi_kredit = $journal_entry->kredit;
                                $saldo_mutasi_debit = $journal_entry->debit;
                                $saldo =  $journal_entry->debit - $journal_entry->kredit;

         
                                $endsaldo= $saldobegening + $journal_entry->debit -  $journal_entry->kredit;
                                $total_endsaldo = $total_endsaldo + $endsaldo;
                                $total_begining = $total_begining + $saldobegening;
                         

                                $saldokredit=$saldokredit+$saldo_mutasi_kredit;
                                $saldodebit=$saldodebit+$saldo_mutasi_debit;
                          }

                    ?>  
                    <tr>
                     <!--  <td><?php echo $no; ?></td>
                      <td><?php echo date('d/m/Y', strtotime($journal_entry->journal_date)); ?> </td>  -->
                      <td><?php echo $journal_entry->coa_code_e; ?> || <?php echo $journal_entry->coa_name_e; ?> </td>
                      <td align="center"><?php echo number_format($saldobegening,0,".","."); ?></td>
                      <td align="center"><?php echo number_format($saldo_mutasi_debit,0,".","."); ?> </td>
                      <td align="center"><?php echo number_format($saldo_mutasi_kredit,0,".","."); ?> </td>
                       <td align="center"><?php echo number_format($endsaldo,0,".","."); ?></td>
                      
                    </tr>    
                    <?php 
                    } 
                    ?>
                    </tbody>
                        <tr>
                            <!-- <td></td> -->
                   
                            <td align="center"><strong>TOTAL</strong></td>
                            <td align="center"><?php echo number_format($total_begining,0,".","."); ?></td>
                            <td align="center"><?php echo number_format($saldodebit,0,".","."); ?> </td>
                            <td align="center"><?php echo number_format($saldokredit,0,".","."); ?> </td>
                            <td align="center"><?php echo number_format($total_endsaldo,0,".","."); ?></td>
                    
                         
                        </tr>
                   </table>
                <!-- <?php  ?> -->
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>



        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- end content-wrapper -->
<script type="text/javascript"> 
    window.addEventListener('load', function() {

      //disabled month
/*
      function() {
        alert("a");
       $("#start_date").datepicker().focus(function() {
        alert("tes");
        $(".ui-datepicker-prev, .ui-datepicker-next").remove();
      });
     }*/

        var data_debit = <?php echo $data_journal[0]->journal_debit; ?>;
        var data_credit = <?php echo $data_journal[0]->journal_kredit; ?>;

        if (data_debit > 0){
            document.getElementById('debit').required = true;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = false;
            document.getElementById('credit').disabled = true;
            document.getElementById("credit").value = parseInt(0);
        } else if(data_credit > 0){
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = true;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = false;
            document.getElementById("debit").value = parseInt(0);

        } else {
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = true;
        }

    });

    function change_journal() {
        var journal_status = $("#journal_status").val();

        if(journal_status == "Debit") {
            document.getElementById('debit').required = true;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = false;
            document.getElementById('credit').disabled = true;
            document.getElementById("credit").value = parseInt(0);

        } else if(journal_status == "Credit") {
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = true;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = false;
            document.getElementById("debit").value = parseInt(0);

        } else {
            document.getElementById('debit').required = false;
            document.getElementById('credit').required = false;
            document.getElementById('debit').disabled = true;
            document.getElementById('credit').disabled = true;
            document.getElementById("debit").value = parseInt(0);
            document.getElementById("credit").value = parseInt(0);
        }
    }
</script>
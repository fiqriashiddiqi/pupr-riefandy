<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
       <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
      <div class="row">
        <div class="col-xs-12">
        <div class="box" id="">  
            <div class="box-header with-border">
            </div>
              <div class="box-body">
                <div class="form-group" style="width: 50%";>
                  <label for="journal_entry">Journal Entry</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <input type="hidden"  class="form-control" name="id_temp_journal" value="<?php echo @$data_journal[0]->id_temp_journal;?>" > 
                     <input type="text" class="form-control pull-right" name="journal_entry" value="<?php echo date('d-m-Y', strtotime(@$data_journal[0]->journal_entry));?>" disabled>
                  </div>
                </div> 
           
                <div class="form-group" style="width: 50%";>
                  <label for="journal_date">Journal Date</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                     <input type="text" class="form-control pull-right" name="journal_date" value="<?php echo date('d-m-Y', strtotime(@$data_journal[0]->journal_date));?>" >
                  </div>
                </div> 

                <div class="form-group" style="width: 50%;">
                  <label>No Journal </label>
                  <input type="hidden" name="journal_del" value="<?php echo @$data_journal[0]->journal_no; ?>" required="true" >
                  <input type="hidden" name="journal_no" value="<?php echo @$newID;?>" required="true" >
                  <input type="hidden" name="journal_no_temp" value="<?php echo @$newID2;?>" required="true" >
                  <input type="text"  class="form-control" name="journal_no" value="<?php echo @$newID; ?>" disabled> 
                </div>

                <div class="form-group" >
                    <label>Journal Title</label>
                    <input type="text" name="journal_description" class="form-control" value="<?php echo @$data_journal[0]->journal_description; ?>"  > 
                </div>  

                <input type="hidden" id="idf" name="idf" value="1" required="true">
                            <?php
                                $sl_coa="<select name=id_param_coa_e[] class=form-control select2 style=width: 100%; required>";
                                $sl_coa.="<option value=>- Choose Account -</option>";

                                $this->load->model('General_Ledger/journal_model'); 
                                $dropdown_coa_a = $this->journal_model->get_coa_a();
                                foreach ($dropdown_coa_a as $coa_entry_a) {
                                    $coa_name_a = $coa_entry_a->coa_name_a;
                                    $sl_coa.="<optgroup label=$coa_name_a>";

                                        $dropdown_coa_b = $this->journal_model->get_dropdown_coa_b($coa_entry_a->id_param_coa_a);
                                        foreach ($dropdown_coa_b as $coa_entry_b) {

                                            $dropdown_coa_c = $this->journal_model->get_dropdown_coa_c($coa_entry_b->id_param_coa_b);
                                            foreach ($dropdown_coa_c as $coa_entry_c) {

                                                $dropdown_coa_d = $this->journal_model->get_dropdown_coa_d($coa_entry_c->id_param_coa_c);
                                                foreach ($dropdown_coa_d as $coa_entry_d) {

                                                    $dropdown_coa_e = $this->journal_model->get_dropdown_coa_e($coa_entry_d->id_param_coa_d);
                                                    foreach ($dropdown_coa_e as $coa_entry) {
                                                       $id_param_coa_e = $coa_entry->id_param_coa_e;
                                                       $sl_coa.="<option value=$id_param_coa_e>".$coa_entry->coa_code_e." - ".$coa_entry->coa_name_e."</option>";

                                                    }
                                    
                                                }
                                            }
                                        }  
                                    $sl_coa.="</optgroup>";  
                                }
                                $sl_coa.="</select>";
                            ?>

                             <!-- <input type="hidden" id="idf" name="idf" value="1" required="true"> -->
                            <?php
                                $this->load->model('General_Ledger/journal_model'); 
                                $cd_coa="<select name=cashflow_code_status[] class=form-control select2 style=width: 100%; required>";
                                $cd_coa.="<option value style= background-color:orange;>- Choose Code -</option>";
                                $cd_coa.="<option value=0>0 || Empty Code</option>";
                                $cd_coa.="<option value style= background-color:orange;>- CASH INFLOW -</option>";
                                $cd_coa.="<option value=ID>ID  || Investor Deposit</option>";
                                $cd_coa.="<option value=LR>LR  || Loan Repayment</option>";
                                $cd_coa.="<option value=LIP>LIP || Loan Interest Payment</option>";
                                $cd_coa.="<option value=PEN>PEN || Penalty</option>";
                                $cd_coa.="<option value=IP>IP  || Insurance Payment</option>";
                                $cd_coa.="<option value=TF>TF  || Transaction Fee</option>";
                                $cd_coa.="<option value=II>II  || Investment Income</option>";
                                $cd_coa.="<option value=PUC>PUC || Paid Up Capital</option>";
                                $cd_coa.="<option value=SH>SH  || Share Holder</option>";
                                $cd_coa.="<option value=OTD>OTD || Others (debit)</option>";
                                $cd_coa.="<option value style= background-color:orange;>- CASH OUTFLOW -</option>";
                                $cd_coa.="<option value=LD>LD  || Loan Disbursement </option>";
                                $cd_coa.="<option value=WD>WD  || Withdrawal</option>";
                                $cd_coa.="<option value=SB>SB  || Salary&Benefit </option>";
                                $cd_coa.="<option value=ME>ME  || Marketing Expenses</option>";
                                $cd_coa.="<option value=INS>INS  || Insurance </option>";
                                $cd_coa.="<option value=TE>TE  || Transaction Expenses</option>";
                                $cd_coa.="<option value=OOE>OOE  || Other Operating Expenses </option>";
                                $cd_coa.="<option value=FAA>FAA  || Fix Assets Acquisition </option>";
                                $cd_coa.="<option value=SHR>SHR  || Shae Holder Loan Repayment </option>";
                                $cd_coa.="<option value=OTC>OTC  || Others (Credit) </option>";
                               
                                    //   // var_dump($cashflow_entry->cashflow_code_status);
                                    // // $cashflow_code_status = $cashflow_entry->cashflow_code_status;
                                     
                                $cd_coa.="</select>";
                            ?>
                            


                <div class="form-group" align="right">
                        <a href="<?php echo $back_url; ?>" class="btn btn-warning btn-sm btnwdt">Back</a>
                        <a class="btn btn-primary btn-sm"  onclick="addRincian('<?php echo $sl_coa;?>','<?php echo $cd_coa;?>'); return false;"><i class="glyphicon glyphicon-plus"></i> Add</a>
                </div> 
     
               <table id="" class="table table-bordered table-striped" width="100%">
                    <thead>

                      <tr>
                           <th style="width: 40%;">Account</th>
                           <!-- <th style="width: 30%;">Description</th> -->
                           <th style="width: 20%;">Debit</th>
                           <th style="width: 20%;">Credit</th>   
                           <th style="width: 20%;">Cashflow Code</th>   
                      </tr>
                    </thead>

                    <tbody id="itemlist">
                    <?php
                        $total_debit = 0;
                        $total_kredit = 0;

                        foreach ($data_journal as $journal_entry){
                    ?>  
                        <tr>
                            <td>
                            <?php
                                $default_coa="<select name=id_param_coa_e[] class=form-control select2 style=width: 100%; required>";
                                $default_coa.="<option value=>- Choose Account -</option>";

                                $this->load->model('General_Ledger/journal_model'); 
                                $dropdown_coa_a = $this->journal_model->get_coa_a();
                                foreach ($dropdown_coa_a as $coa_entry_a) {
                                    $coa_name_a = $coa_entry_a->coa_name_a;
                                    $default_coa.="<optgroup label=$coa_name_a>";

                                        $dropdown_coa_b = $this->journal_model->get_dropdown_coa_b($coa_entry_a->id_param_coa_a);
                                        foreach ($dropdown_coa_b as $coa_entry_b) {

                                            $dropdown_coa_c = $this->journal_model->get_dropdown_coa_c($coa_entry_b->id_param_coa_b);
                                            foreach ($dropdown_coa_c as $coa_entry_c) {

                                                $dropdown_coa_d = $this->journal_model->get_dropdown_coa_d($coa_entry_c->id_param_coa_c);
                                                foreach ($dropdown_coa_d as $coa_entry_d) {

                                                    $dropdown_coa_e = $this->journal_model->get_dropdown_coa_e($coa_entry_d->id_param_coa_d);
                                                    foreach ($dropdown_coa_e as $coa_entry) {
                                                       $id_param_coa_e = $coa_entry->id_param_coa_e;
                                                       $default_id_param_coa_e = $journal_entry->id_param_coa_e;

                                                       if ($id_param_coa_e == $default_id_param_coa_e){
                                                        $default_coa.="<option value=$id_param_coa_e selected>".$coa_entry->coa_code_e." - ".$coa_entry->coa_name_e."</option>";
                                                       } else {
                                                        $default_coa.="<option value=$id_param_coa_e>".$coa_entry->coa_code_e." - ".$coa_entry->coa_name_e."</option>";
                                                       }                                                       

                                                    }
                                    
                                                }
                                            }
                                        }  
                                    $default_coa.="</optgroup>";  
                                }
                                $default_coa.="</select>";
                              echo $default_coa;
                            ?>
                           </td> 
                          <!--   <td align="left"><input type='text' class='form-control' name='journal_description_form[]' value='<?php echo @$journal_entry->journal_description_form; ?>' style="text-align: left;"></td> -->

                            <td align="right"><input type='text' onkeyup="sumJournalDebit(this)" counter='"+counter+"' id='journal-debit-"+counter+"' class='form-control journal_debit' name='journal_debit[]' value='<?php echo number_format($journal_entry->journal_debit,0); ?>' style="text-align: right;"></td>
                            <td align="right"><input type='text' onkeyup="sumJournalKredit(this)" counter='"+counter+"' id='journal-kredit-"+counter+"' class='form-control journal_kredit' name='journal_kredit[]' value='<?php echo number_format($journal_entry->journal_kredit,0); ?>' style="text-align: right;"></td>
               <!--               <td align="left"><input type='text' class='form-control' name='cashflow_code_status[]' value='<?php echo @$journal_entry->cashflow_code_status; ?>' style="text-align: left;"></td> -->
                            <!-- <td align="right"><?php echo number_format($journal_entry->journal_kredit,2); ?></td> -->
                            <td> <input type="hidden" id="idf" name="idf" value="1" required="true">
                            <?php
                                $this->load->model('General_Ledger/journal_model'); 
                                $default_cash="<select name=cashflow_code_status[] class=form-control select2 style=width: 80%; 
                                required>";
                                
                                $default_cash.="<option value style= background-color:orange;>- Choose Code -</option>";
                                if($journal_entry->cashflow_code_status==0){
                                  $default_cash.="<option selected='selected' value=0>0 || Empty Code</option>";
                                }else{
                                  $default_cash.="<option value=0>0 || Empty Code</option>";
                                }



                                $default_cash.="<option value style= background-color:orange;>- CASH INFLOW -</option>";
                                if($journal_entry->cashflow_code_status=="ID>ID"){
                                  $default_cash.="<option selected='selected' value=ID>ID  || Investor Deposit</option>";
                                }else{
                                  $default_cash.="<option value=ID>ID  || Investor Deposit</option>";
                                }
                                if($journal_entry->cashflow_code_status=="LR>LR"){
                                  $default_cash.="<option selected='selected' value=LR>LR  || Loan Repayment</option>";
                                }else{
                                  $default_cash.="<option value=LR>LR  || Loan Repayment</option>";
                                }
                                if($journal_entry->cashflow_code_status=="LIP>LIP"){
                                  $default_cash.="<option selected='selected' value=LIP>LIP || Loan Interest Payment</option>";
                                }else{
                                  $default_cash.="<option value=LIP>LIP || Loan Interest Payment</option>";
                                }
                                if($journal_entry->cashflow_code_status=="PEN>PEN"){
                                  $default_cash.="<option selected='selected' value=PEN>PEN || Penalty</option>";
                                }else{
                                  $default_cash.="<option value=PEN>PEN || Penalty</option>";
                                }
                                if($journal_entry->cashflow_code_status=="IP>IP"){
                                  $default_cash.="<option selected='selected' value=IP>IP  || Insurance Payment</option>";
                                }else{
                                  $default_cash.="<option value=IP>IP  || Insurance Payment</option>";
                                }
                                if($journal_entry->cashflow_code_status=="TF>TF"){
                                  $default_cash.="<option selected='selected' value=TF>TF  || Transaction Fee</option>";
                                }else{
                                  $default_cash.="<option value=TF>TF  || Transaction Fee</option>";
                                }
                                if($journal_entry->cashflow_code_status=="II"){
                                  $default_cash.="<option selected='selected' value=II>II  || Investment Income</option>";
                                }else{
                                  $default_cash.="<option value=II>II  || Investment Income</option>";
                                }
                                if($journal_entry->cashflow_code_status=="PUC>PUC"){
                                  $default_cash.="<option selected='selected' value=PUC>PUC || Paid Up Capital</option>";
                                }else{
                                  $default_cash.="<option value=PUC>PUC || Paid Up Capital</option>";
                                }
                                if($journal_entry->cashflow_code_status=="SH>SH"){
                                  $default_cash.="<option selected='selected' value=SH>SH  || Share Holder</option>";
                                }else{
                                  $default_cash.="<option value=SH>SH  || Share Holder</option>";
                                }
                                if($journal_entry->cashflow_code_status=="OTD>OTD"){
                                  $default_cash.="<option selected='selected' value=OTD>OTD || Others (debit)</option>";
                                }else{
                                  $default_cash.="<option value=OTD>OTD || Others (debit)</option>";
                                }
                              
                                $default_cash.="<option value style= background-color:orange;>- CASH OUTFLOW -</option>";
                                
                                if($journal_entry->cashflow_code_status=="LD>LD"){
                                  $default_cash.="<option selected='selected' value=LD>LD  || Loan Disbursement </option>";
                                }else{
                                  $default_cash.="<option value=LD>LD  || Loan Disbursement </option>";
                                }
                                if($journal_entry->cashflow_code_status=="WD>WD"){
                                  $default_cash.="<option selected='selected' value=WD>WD  || Withdrawal</option>";
                                }else{
                                  $default_cash.="<option value=WD>WD  || Withdrawal</option>";
                                }
                                if($journal_entry->cashflow_code_status=="SB>SB"){
                                  $default_cash.="<option selected='selected' value=SB>SB  || Salary&Benefit </option>";
                                }else{
                                  $default_cash.="<option value=SB>SB  || Salary&Benefit </option>";
                                }
                                if($journal_entry->cashflow_code_status=="ME>ME"){
                                  $default_cash.="<option selected='selected' value=ME>ME  || Marketing Expenses</option>";
                                }else{
                                  $default_cash.="<option value=ME>ME  || Marketing Expenses</option>";
                                }
                                if($journal_entry->cashflow_code_status=="INS>INS"){
                                  $default_cash.="<option selected='selected' value=INS>INS  || Insurance </option>";
                                }else{
                                  $default_cash.="<option value=INS>INS  || Insurance </option>";
                                }
                                if($journal_entry->cashflow_code_status=="TE>TE"){
                                  $default_cash.="<option selected='selected' value=TE>TE  || Transaction Expenses</option>";
                                }else{
                                  $default_cash.="<option value=TE>TE  || Transaction Expenses</option>";
                                }
                                if($journal_entry->cashflow_code_status=="OOE>OOE"){
                                  $default_cash.="<option selected='selected' value=OOE>OOE  || Other Operating Expenses </option>";
                                }else{
                                  $default_cash.="<option value=OOE>OOE  || Other Operating Expenses </option>";
                                }
                                if($journal_entry->cashflow_code_status=="FAA>FAA"){
                                  $default_cash.="<option selected='selected' value=FAA>FAA  || Fix Assets Acquisition </option>";
                                }else{
                                  $default_cash.="<option value=FAA>FAA  || Fix Assets Acquisition </option>";
                                }
                                if($journal_entry->cashflow_code_status=="SHR>SHR"){
                                  $default_cash.="<option selected='selected' value=SHR>SHR  || Shae Holder Loan Repayment </option>";
                                }else{
                                  $default_cash.="<option value=SHR>SHR  || Shae Holder Loan Repayment </option>";
                                }
                                if($journal_entry->cashflow_code_status=="OTC>OTC"){
                                  $default_cash.="<option selected='selected' value=OTC>OTC  || Others (Credit) </option>";
                                }else{
                                  $default_cash.="<option value=OTC>OTC  || Others (Credit) </option>";
                                }
                                
                                
                               
                                    //   // var_dump($cashflow_entry->cashflow_code_status);
                                    // // $cashflow_code_status = $cashflow_entry->cashflow_code_status;
                                     
                                $default_cash.="</select>";
                                echo "$default_cash";
                            ?></td>

                        </tr>

                    <?php
                        $total_debit = $total_debit + $journal_entry->journal_debit;
                        $total_kredit = $total_kredit + $journal_entry->journal_kredit;
                      }
                    ?>

                    </tbody>
                    <tbody>
                        <tr>
                            <td align="center"><strong>TOTAL</strong></td>
                            <!-- <td></td> -->
                            <td><input type='text' class='form-control' name='total_debit' id="sum-debit" value='<?php echo number_format($total_debit,0); ?>' disabled="true" style="text-align: right;"></td>   
                            <td><input type='text' class='form-control' name='total_kredit' id="sum-kredit" value='<?php echo number_format($total_kredit,0); ?>' disabled="true" style="text-align: right;"></td>  
                            <td></td>
                        </tr>
                    </tbody>
                   </table>
              </div>
              <div class="box-footer text-right">  
                <button type="submit" name="submit" value="Temporary" class="btn btn-warning btnbig">Save Temporary</button>
                <button <?php if($total_debit!=$total_kredit): echo "style='display:none'"; endif;   ?> id="posting-btn" type="submit" name="submit" value="Posting" class="btn btn-success btnbig">Posting</button>
              </div>
          </div>
        </div>
      </div>
    </form>
    </section>
  </div>


<script type="text/javascript"> 


function sumJournalKredit(params){
  var sumKredit = 0;
  $('.journal_kredit').each(function(){
    sumKredit += parseFloat($(this).val().replace(/\D/g,'')); 
  });

  $(".journal_kredit").blur(function() {
    if ($(this).val() == "") {
      $(this).val('0')
    }
  })

  var currentCounter = params.getAttribute('counter');

  // if($('#journal-kredit-'+currentCounter).val()!='0'){
  //   $('#journal-debit-'+currentCounter).attr('readonly', true);
  // }else{
  //   $('#journal-debit-'+currentCounter).removeAttr('readonly');
  // }

  $('#sum-kredit').val(numberFormat(sumKredit));
  // console.log(numberFormat(sumKredit));

  checkPostingButton();
}

function sumJournalDebit(params){
  var sumDebit = 0;
  console.log(params);
  $('.journal_debit').each(function(){
    sumDebit += parseFloat($(this).val().replace(/\D/g,'')); 
  });

  $(".journal_debit").blur(function() {
    if ($(this).val() == "") {
      $(this).val('0')
    }
  })
  
  var currentCounter = params.getAttribute('counter');
  
  // if($('#journal-debit-'+currentCounter).val()!='0'){
  //   $('#journal-kredit-'+currentCounter).attr('readonly', true);
  // }else{
  //   $('#journal-kredit-'+currentCounter).removeAttr('readonly');
  // }

  $('#sum-debit').val(numberFormat(sumDebit));
  // console.log(numberFormat(sumDebit));

  checkPostingButton();
}

/* format number */
function numberFormat(bilangan){
  var number_string = bilangan.toString(),
    sisa  = number_string.length % 3,
    rupiah  = number_string.substr(0, sisa),
    ribuan  = number_string.substr(sisa).match(/\d{3}/g);
      
  if (ribuan) {
    separator = sisa ? '.' : '';
    rupiah += separator + ribuan.join('.');
  }

  return rupiah;
}

function checkPostingButton(){
  if($('#sum-debit').val() != $('#sum-kredit').val()){
    $('#posting-btn').hide();
  }else if ($('#sum-debit').val() == 0 && $('#sum-kredit').val() == 0){
    $('#posting-btn').hide();
  }else{
    $('#posting-btn').show();
  }
}


var counter = 0;
function addRincian(sl_coa,cd_coa) {
    counter++;
    var idf = document.getElementById("idf").value;
        stre="<tr id='srow" + idf + "'>";
        stre=stre+"<td>";
        stre=stre+sl_coa;
        stre=stre+"</td>";
        // stre=stre+"<td><input type='text' class='form-control' name='journal_description_form[]'  style='text-align: left;'></td>";
        stre=stre+"<td><input type='number' counter='"+counter+"' id='journal-debit-"+counter+"' class='form-control journal_debit' min='0' onkeyup='sumJournalDebit(this)' name='journal_debit[]' value='0'  required='true' style='text-align: right;'></td>";
        stre=stre+"<td><input type='number' counter='"+counter+"' id='journal-kredit-"+counter+"' class='form-control journal_kredit' min='0' onkeyup='sumJournalKredit(this)' name='journal_kredit[]' value='0' required='true' style='text-align: right;'></td>";
        stre=stre+"<td>";
        stre=stre+cd_coa;
        stre=stre+"</td>";
        stre=stre+"<td align='center'><button type='button' class='btn btn-danger btn-sm' onclick='removeFormField(\"#srow" + idf + "\"); return false;'><i class='glyphicon glyphicon-remove'></i></button></td>";
        stre=stre+"</tr>";
    $("#itemlist").append(stre);
    idf = (idf-1) + 2;
    document.getElementById("idf").value = idf;
}

function removeFormField(idf) {
    $(idf).remove();
    document.getElementById("sum-debit").value = 0;
    document.getElementById("sum-kredit").value = 0;
    checkPostingButton();
}
</script>

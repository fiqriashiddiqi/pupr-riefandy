<?php date_default_timezone_set("Asia/Jakarta"); ?>

<style type="text/css">
#overflow_1, #overflow_2{width: 300px; border: none 0px RED;
overflow-x: scroll; overflow-y:hidden;}
#overflow_1{height: 20px; }
#overflow_2{height: 100px; }
#div1 {width:1000px; height: 20px; }
#div2 {width:1000px; height: 100px; background-color: #88FF88;
overflow: auto;}
</style>
<!-- Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title;?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
           <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>

          
       <div class="box" id="">
            <div class="box-header with-border">  
              <div class="row">
              <div class="col-lg-12 col-xs-12">
               <form method="get" action="#"> 
                  <div class="col-lg-6 col-xs-12">
                    <?php 
                      $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : null;
                      $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
                      $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');
                    ?>
                    <div class="form-group">
                    <label for="">Start Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="start_date" class="form-control pull-right datepicker" value="<?php echo @$start_date;?>" placeholder="Start Date" id="start_date">
       
                    </div>
                  </div>
               
                  </div>
                  <div class="col-lg-6 col-xs-12">
                    <div class="form-group">
                    <label for="">End Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="end_date" class="form-control pull-right datepicker" value="<?php echo @$end_date; ?>" placeholder="End Date" id="end_date">
       
                    </div>
                    </div>
                  </div>

                  <div class="col-lg-12 col-xs-12" align="right">
                    <button type="submit" class="btn btn-warning">Search !</button>
                  </div>
              </form>
              </div>
              </div>               
            </div>
        </div>      
          <div class="box">
          
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-lg-6 col-xs-12">
                 <?php 
                   $id_journal = isset($_REQUEST['id_journal']) ? $_REQUEST['id_journal'] : NULL;
                ?>
                </div>
                <div class="col-lg-6 col-xs-12 text-right">
              
                <a href="<?php echo $excel_url; ?>?start_date=<?php echo @$start_date;?>&end_date=<?php echo @$end_date;?>" class="btn-success btn-sm btn btnbig2">Export Excel</a>
                </div>
              <div class="col-xs-12 col-lg-12">
              <div class="col-xs-12 col-lg-12"  style="padding-top: 15px;">
                  <table id="" class="table table-bordered table-striped" width="100%">
                    <thead>
                    <tr>
                         <th>No</th>
                         <th>Number Journal</th>
                         <th style="width: 15%">Tittle</th>
                         <th style="width: 15%">Date Entry</th>
                         <th style="width: 15%">Date Posting</th>
                         <th text-align: center;">Action</th>
                         
                        
                    </tr>
                    </thead>
                    <tbody>
                   <?php
                    // $limit   = 6;
                    // $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;

                    
                    // if(empty($page)){
                    //     $position  = 0;
                    //     $page = 1;
                    // } else {
                    //     $position = ($page-1) * $limit;
                    // }

                    $this->load->model('General_Ledger/journal_model');
                    // $data_journal = $this->journal_model->get_journal_list($limit,$position)->result();
                    $data_journal = $this->journal_model->get_journal_temp_group(@$start_date,@$end_date);

                    // $no = $position+1;
                    // $data_journal = $this->journal_model->get_journal();

                    $no=0;
                    $saldo = 0;
                       foreach ($data_journal as $journal_entry){
                    $no++;
                    ?>
                    <tr>
                      <td><?php echo $no; ?></td>
                      <!-- <td><?php echo $journal_entry->coa_code_e; ?> || <?php echo $journal_entry->coa_name_e; ?> </td> -->
                      <td><?php echo $journal_entry->journal_no; ?></td>
                       <td><?php echo $journal_entry->journal_description; ?></td>
                      <td><?php echo $journal_entry->journal_entry; ?></td>
                      <td><?php echo $journal_entry->journal_date; ?></td>
                      <td style="text-align: center;">

                          <a href="<?php echo $info_url; ?>/<?php echo $journal_entry->id_temp_journal; ?>" id="info" class="btn btn-info btn-sm btnwdt">Edit</a>
                          
                       

                      </td>
                    </tr>
                    <?php 
                    // $no++;
                    } 
                    ?>

                    </tbody>
                   </table>
             <!--  <?php
                $data_rows = $this->journal_model->get_journal_list()->num_rows();
                $all_page  = ceil($data_rows/$limit);
                ?>
                <center>
                <ul class="pagination">
                    <li>
                        <?php
                            if($page > 1){
                                $prev = $page-1;
                                echo "<a href='".base_url()."General_Ledger/b_journal?page=$prev'>Previous</a>";
                            }
                        ?>
                    </li>
                    <li>
                        <?php
                            for($i=1;$i<=$all_page;$i++)
                                if ($i != $page){
                                    echo "<a href='".base_url()."General_Ledger/b_journal?page=$i'>$i</a>";
                                }
                        ?>
                        </li>
                        <li>
                        <?php
                            if($page < $all_page){
                                $next=$page+1;
                                echo "<a href='".base_url()."General_Ledger/b_journal?page=$next'>Next</a>";
                            }
                        ?>
                    </li>
                </ul>
                </center>  -->
              </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>

        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<script type="text/javascript">
function delete_data(id_journal)
{
    bootbox.confirm({
    title: "Deleting Data?",
    message: "Do you want to delete this data?",
    buttons: {
        cancel: {
            label: '<i class="fa fa-times"></i> Cancel',
            className: 'btn-default'
        },
        confirm: {
            label: '<i class="fa fa-check"></i> Delete',
            className: 'btn-danger'
        }
    },
    callback: function (result) {
        if (result == true){
            window.location = "<?php echo $delete_url; ?>/" + id_journal;
        } else {
            event.preventDefault();
        }
    }
    });
}

var overflow_1 = document.getElementById('overflow_1');
var overflow_2 = document.getElementById('overflow_2');
overflow_1.onscroll = function() {
  overflow_2.scrollLeft = overflow_1.scrollLeft;
};
overflow_2.onscroll = function() {
  overflow_1.scrollLeft = overflow_2.scrollLeft;
};
</script>


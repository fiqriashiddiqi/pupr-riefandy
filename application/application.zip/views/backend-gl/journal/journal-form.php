<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
                <?php if ($this->session->flashdata('alert_success')) { ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-check"></i>
                <?php echo $this->session->flashdata('alert_success'); ?></p>
                </div>
                <?php } ?>

                <?php if ($this->session->flashdata('alert_error')) { ?>
                <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><i class="icon fa fa-ban"></i>
                <?php echo $this->session->flashdata('alert_error'); ?></p>
                </div>
                <?php } ?>

        <div class="box" id="">  
            <div class="box-header with-border">
              <?php 
                $this->load->model('General_Ledger/journal_model');   

                $get_closing_date = $this->journal_model->get_closing_journal();

                $date_r = $get_closing_date[0]->closing_date;
                $date_r2 = date('Y-m-t', strtotime($date_r));
                $date_r3 = new DateTime ($date_r2);
                $date_r3->modify('+1 days');
                $closing_date_r = $date_r3->format('Y-m-d');

                if (empty($date_r)){
                    $closing_date_r = date('Y-m-d');
                }
                //var_dump($closing_date_r);
              ?>
            </div>
            <form action="<?php echo $form_url; ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group" style="width: 42%";>
                  <label for="journal_date">Entry Date</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                     <input name="journal_entry" class="form-control pull-right" value="<?php echo date('d-m-Y');?>" disabled>
                  </div>
                </div> 
           
                <div class="form-group" style="width: 42%";>
                  <label for="journal_date">Posting Date</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                     <input type="date" name="journal_date" class="form-control pull-right months_only_past_disable" value="<?php echo @$closing_date_r;?>" placeholder="Postdate" id=""  required="true" >
                  </div>
                </div>

                <div class="form-group" style="width: 42%;">
                  <label>No Journal </label>
                  <input type="hidden" name="journal_no" value="<?php echo @$newID;?>" required="true" >
                  <input type="text"  class="form-control" value="<?php echo @$newID;?>" disabled="true" > 
                </div>

                <div class="form-group" >
                    <label>Journal Description</label>
                    <input type="text"  class="form-control" name="journal_description"  placeholder="" required="true" > 
                </div>  
   
                <input type="hidden" id="idf" name="idf" value="1" required="true">
                            <?php
                                $sl_coa="<select name=id_param_coa_e[] class=form-control select2 style=width: 100%; required>";
                                $sl_coa.="<option value=>- Choose Account -</option>";

                                $this->load->model('General_Ledger/journal_model'); 
                                $dropdown_coa_a = $this->journal_model->get_coa_a();
                                foreach ($dropdown_coa_a as $coa_entry_a) {
                                    $coa_name_a = $coa_entry_a->coa_name_a;
                                    $sl_coa.="<optgroup label=$coa_name_a>";

                                        $dropdown_coa_b = $this->journal_model->get_dropdown_coa_b($coa_entry_a->id_param_coa_a);
                                        foreach ($dropdown_coa_b as $coa_entry_b) {

                                            $dropdown_coa_c = $this->journal_model->get_dropdown_coa_c($coa_entry_b->id_param_coa_b);
                                            foreach ($dropdown_coa_c as $coa_entry_c) {

                                                $dropdown_coa_d = $this->journal_model->get_dropdown_coa_d($coa_entry_c->id_param_coa_c);
                                                foreach ($dropdown_coa_d as $coa_entry_d) {

                                                    $dropdown_coa_e = $this->journal_model->get_dropdown_coa_e($coa_entry_d->id_param_coa_d);
                                                    foreach ($dropdown_coa_e as $coa_entry) {
                                                       $id_param_coa_e = $coa_entry->id_param_coa_e;
                                                       $sl_coa.="<option value=$id_param_coa_e>".$coa_entry->coa_code_e." - ".$coa_entry->coa_name_e."</option>";

                                                    }
                                    
                                                }
                                            }
                                        }  
                                    $sl_coa.="</optgroup>";  
                                }
                                $sl_coa.="</select>";
                            ?>

                             <!-- <input type="hidden" id="idf" name="idf" value="1" required="true"> -->
                            <?php
                                $this->load->model('General_Ledger/journal_model'); 

                                $cd_coa="<select name=cashflow_code_status[] class=form-control select2 style=width: 100%; required>";
                                // $cd_coa.="<option value style= background-color:orange;>- Choose Code -</option>";
                                $cd_coa.="<option value=0>0 || Empty Code</option>";
                                $cd_coa.="<option value style= background-color:orange;>- CASH INFLOW -</option>";
                                $cd_coa.="<option value=ID>ID  || Investor Deposit</option>";
                                $cd_coa.="<option value=LR>LR  || Loan Repayment</option>";
                                $cd_coa.="<option value=LIP>LIP || Loan Interest Payment</option>";
                                $cd_coa.="<option value=PEN>PEN || Penalty</option>";
                                $cd_coa.="<option value=IP>IP  || Insurance Payment</option>";
                                $cd_coa.="<option value=TF>TF  || Transaction Fee</option>";
                                $cd_coa.="<option value=II>II  || Investment Income</option>";
                                $cd_coa.="<option value=PUC>PUC || Paid Up Capital</option>";
                                $cd_coa.="<option value=SH>SH  || Share Holder</option>";
                                $cd_coa.="<option value=OTD>OTD || Others (debit)</option>";
                                $cd_coa.="<option value style= background-color:orange;>- CASH OUTFLOW -</option>";
                                $cd_coa.="<option value=LD>LD  || Loan Disbursement </option>";
                                $cd_coa.="<option value=WD>WD  || Withdrawal</option>";
                                $cd_coa.="<option value=SB>SB  || Salary&Benefit </option>";
                                $cd_coa.="<option value=ME>ME  || Marketing Expenses</option>";
                                $cd_coa.="<option value=INS>INS  || Insurance </option>";
                                $cd_coa.="<option value=TE>TE  || Transaction Expenses</option>";
                                $cd_coa.="<option value=OOE>OOE  || Other Operating Expenses </option>";
                                $cd_coa.="<option value=FAA>FAA  || Fix Assets Acquisition </option>";
                                $cd_coa.="<option value=SHR>SHR  || Shae Holder Loan Repayment </option>";
                                $cd_coa.="<option value=OTC>OTC  || Others (Credit) </option>";
                               
                                    //   // var_dump($cashflow_entry->cashflow_code_status);
                                    // // $cashflow_code_status = $cashflow_entry->cashflow_code_status;
                                     
                                $cd_coa.="</select>";
                            ?>


                <div class="form-group" align="right">
                        <a class="btn btn-primary btn-sm"  onclick="addRincian('<?php echo $sl_coa;?>','<?php echo $cd_coa;?>'); return false;"><i class="glyphicon glyphicon-plus"></i> Add</a>
                </div> 

                <table width="100%" class="table table-bordered table-striped">
                    <thead style="background-color: lightgray;">
                        <tr>
                            <th style="width: 35%; text-align: center;">Account</th>
                            <!-- <th style="width: 25%; text-align: center;">Description</th> -->
                            <th style="width: 20%; text-align: center;">Debit</th>
                            <th style="width: 20%; text-align: center;">Credit</th> 
                            <th style="width: 25%; text-align: center;">Cashflow Code</th>  
                            <th style="width: 5%; text-align: center;">Action</th>  
                        </tr>
                    </thead>
                    <tbody id="itemlist">

                    </tbody>

                    <tbody>
                        <tr>
                            <td align="center"><strong>TOTAL</strong></td>
                            <!-- <td></td> -->
                             <td><input type='text' class='form-control' name='total_debit' id="sum-debit" value='Rp. <?php echo number_format(0,0); ?>' disabled="true" style="text-align: right;"></td>   
                            <td><input type='text' class='form-control' name='total_kredit' id="sum-kredit" value='Rp. <?php echo number_format(0,0); ?>' disabled="true" style="text-align: right;"></td>  
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
              </div>
              <div class="box-footer text-right">

                <button type="submit" name="submit" value="Temporary" class="btn btn-warning btnbig">Save Temporary</button>
                <button style='display:none' id="posting-btn" type="submit" name="submit" value="Posting" class="btn btn-success btnbig">Posting</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
<script type="text/javascript">

/* Auto Count */
function sumJournalKredit(params){
  var sumKredit = 0;
  $('.journal_kredit').each(function(){
    sumKredit += parseFloat($(this).val().replace(/\D/g,'')); 
  });

  $(".journal_kredit").blur(function() {
    if ($(this).val() == "") {
      $(this).val('0')
    }
  })

  var currentCounter = params.getAttribute('counter');

  if($('#journal-kredit-'+currentCounter).val()!='0'){
    $('#journal-debit-'+currentCounter).attr('readonly', true);
  }else{
    $('#journal-debit-'+currentCounter).removeAttr('readonly');
  }

  $('#sum-kredit').val(numberFormat(sumKredit));
  // console.log(numberFormat(sumKredit));

  checkPostingButton();
}

function sumJournalDebit(params){
  var sumDebit = 0;
  $('.journal_debit').each(function(){
    sumDebit += parseFloat($(this).val().replace(/\D/g,'')); 
  });

  $(".journal_debit").blur(function() {
    if ($(this).val() == "") {
      $(this).val('0')
    }
  })
  
  var currentCounter = params.getAttribute('counter');
  
  if($('#journal-debit-'+currentCounter).val()!='0'){
    $('#journal-kredit-'+currentCounter).attr('readonly', true);
  }else{
    $('#journal-kredit-'+currentCounter).removeAttr('readonly');
  }

  $('#sum-debit').val(numberFormat(sumDebit));
  // console.log(numberFormat(sumDebit));

  checkPostingButton();
}

/* format number */
function numberFormat(bilangan){
  var number_string = bilangan.toString(),
    sisa  = number_string.length % 3,
    rupiah  = number_string.substr(0, sisa),
    ribuan  = number_string.substr(sisa).match(/\d{3}/g);
      
  if (ribuan) {
    separator = sisa ? '.' : '';
    rupiah += separator + ribuan.join('.');
  }

  return rupiah;
}

function checkPostingButton(){
  if($('#sum-debit').val() != $('#sum-kredit').val()){
    $('#posting-btn').hide();
  }else if ($('#sum-debit').val() == 0 && $('#sum-kredit').val() == 0){
    $('#posting-btn').hide();
  }else{
    $('#posting-btn').show();
  }
}

var counter = 0;
function addRincian(sl_coa,cd_coa) {
    counter++;
    var idf = document.getElementById("idf").value;
        stre="<tr id='srow" + idf + "'>";
        stre=stre+"<td>";
        stre=stre+sl_coa;
        stre=stre+"</td>";
        // stre=stre+"<td><input type='text' class='form-control' name='journal_description_form[]'  style='text-align: left;'></td>";
        stre=stre+"<td><input type='number' counter='"+counter+"' id='journal-debit-"+counter+"' class='form-control journal_debit' min='0' onkeyup='sumJournalDebit(this)' name='journal_debit[]' value='0'  required='true' style='text-align: right;'></td>";
        stre=stre+"<td><input type='number' counter='"+counter+"' id='journal-kredit-"+counter+"' class='form-control journal_kredit' min='0' onkeyup='sumJournalKredit(this)' name='journal_kredit[]' value='0' required='true' style='text-align: right;'></td>";
           stre=stre+"<td>";
          stre=stre+cd_coa;
        stre=stre+"</td>";
        stre=stre+"<td align='center'><button type='button' class='btn btn-danger btn-sm' onclick='removeFormField(\"#srow" + idf + "\"); return false;'><i class='glyphicon glyphicon-remove'></i></button></td>";
        stre=stre+"</tr>";
    $("#itemlist").append(stre);
    idf = (idf-1) + 2;
    document.getElementById("idf").value = idf;
}

function removeFormField(idf) {
    $(idf).remove();
    document.getElementById("sum-debit").value = 0;
    document.getElementById("sum-kredit").value = 0;
    checkPostingButton();
}
</script>
<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
        <div class="box" id="">  
            <div class="box-header with-border">
            </div>
              <div class="box-body">
                <div class="form-group" style="width: 50%";>
                  <label for="journal_entry">Entry Date</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                     <input type="text" class="form-control pull-right" value="<?php echo date('d-m-Y', strtotime($data_journal[0]->journal_entry));?>" disabled="true">
                  </div>
                </div> 
           
                <div class="form-group" style="width: 50%";>
                  <label for="journal_date">Posting Date</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                     <input type="text" class="form-control pull-right" value="<?php echo date('d-m-Y', strtotime($data_journal[0]->journal_date));?>" disabled="true">
                  </div>
                </div> 

                <div class="form-group" style="width: 50%;">
                  <label>No Journal </label>
                  <input type="text"  class="form-control" name="journal_no" value="<?php echo @$data_journal[0]->journal_no; ?>" disabled="true"> 
                </div>

                <div class="form-group" >
                    <label>Journal Tittle</label>
                    <input type="text"  class="form-control" value="<?php echo @$data_journal[0]->journal_description; ?>"  disabled="true"> 
                </div>  
             
               <table id="" class="table table-bordered table-striped" width="100%">
                    <thead>

                      <tr >
                           <th style="width: 35%; text-align: center;">Account</th>
                           <!-- <th style="width: 30%; text-align: center;">Description</th> -->
                           <th style="width: 25%;text-align: center;">Debit</th>
                           <th style="width: 25%;text-align: center;">Credit</th>   
                           <th style="width: 15%;text-align: center;">Cashflow Code</th>   
                      </tr>
                    </thead>

                    <tbody id="itemlist">
                    <?php
                        $total_debit = 0;
                        $total_kredit = 0;

                        foreach ($data_journal as $journal_entry){
                    ?>
                        <tr>
                            <td><?php echo $journal_entry->coa_code_e; ?> || <?php echo $journal_entry->coa_name_e; ?> </td> 
                            <!-- <td align="left"><?php echo ($journal_entry->journal_description_form); ?></td> -->
                            <td align="right"><?php echo number_format($journal_entry->journal_debit); ?></td>
                            <td align="right"><?php echo number_format($journal_entry->journal_kredit); ?></td>
                            <td align="right"><?php echo($journal_entry->cashflow_code_status); ?></td>
                        </tr>

                    <?php
                        $total_debit = $total_debit + $journal_entry->journal_debit;
                        $total_kredit = $total_kredit + $journal_entry->journal_kredit;
                      }
                    ?>

                    </tbody>
                    <tbody>
                        <tr>
                            <td align="center"><strong>TOTAL</strong></td>
                            <!-- <td></td> -->
                            <td><input type='text' class='form-control' name='total_debit' value='<?php echo number_format($total_debit); ?>' disabled="true" style="text-align: right;"></td>   
                            <td><input type='text' class='form-control' name='total_kredit' value='<?php echo number_format($total_kredit); ?>' disabled="true" style="text-align: right;"></td>  
                            <td></td>
                        </tr>
                    </tbody>
                   </table>
              </div>
              <div class="box-footer text-right">
                <a href="<?php echo $back_url; ?>" class="btn btn-warning btn-sm btnwdt">Back</a>
              </div>
          </div>
        </div>
      </div>
    </section>
  </div>
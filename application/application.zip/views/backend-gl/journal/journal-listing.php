<?php date_default_timezone_set("Asia/Jakarta"); ?>
<!-- Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title; ?>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active"><a href="<?php echo $brd_title_url; ?>"><i class="fa fa-dashboard"></i> <?php echo $brd_title_main; ?></a></li>
        <!-- <li><a href="<?php echo $brd_title_url_sub; ?>"></i> <?php echo $brd_title_sub; ?></a></li> -->
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

       <div class="box" id="">
            <div class="box-header with-border">  
              <div class="row">
              <div class="col-lg-12 col-xs-12">
               <form method="get" action="#"> 
                  <div class="col-lg-6 col-xs-12">
                    <?php 
                      $id_param_coa_e = isset($_REQUEST['id_param_coa_e']) ? $_REQUEST['id_param_coa_e'] : null;
                      $start_date = isset($_REQUEST['start_date']) ? $_REQUEST['start_date'] : date('Y-m-d');
                      $end_date = isset($_REQUEST['end_date']) ? $_REQUEST['end_date'] : date('Y-m-d');
                    ?>
                    <div class="form-group">
                    <label for="">Start Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="start_date" class="form-control pull-right datepicker" value="<?php echo @$start_date;?>" placeholder="Start Date" id="start_date">
       
                    </div>
                  </div>
               
                  </div>
                  <div class="col-lg-6 col-xs-12">
                    <div class="form-group">
                    <label for="">End Date</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                       <input type="text" name="end_date" class="form-control pull-right datepicker" value="<?php echo @$end_date; ?>" placeholder="End Date" id="end_date">
       
                    </div>
                    </div>
                  </div>

                  <div class="col-lg-12 col-xs-12" align="right">
                    <button type="submit" class="btn btn-warning">Search !</button>
                  </div>
              </form>
              </div>
              </div>               
            </div>
        </div>
        
      <div class="row">
        <div class="col-xs-12">
        <div class="box" id="">  
            <div class="box-header with-border">
              <div class="col-lg-6 col-xs-12">
            
                </div>
                <div class="col-lg-6 col-xs-12 text-right">
              
                 <a href="<?php echo $excel_url; ?>?start_date=<?php echo @$start_date;?>&end_date=<?php echo @$end_date;?>" class="btn-success btn-sm btn btnbig2">Export Excel</a>
                </div>
            </div>
              <div class="box-body">
            
             
               <table id="" class="table table-bordered table-striped" width="100%">
                    <thead>

                      <tr>

                           <th style="width: 5px; text-align: center;">Journal Number</th>
                           <th style="width: 10px; text-align: center;">Entry Date</th>
                           <th style="width: 10px; text-align: center">Posting Date</th>
                           <th style="width: 40px; text-align: center">Journal Description</th>
                           <th style="width: 10px; text-align: center" >Account</th>
                           <th style="width: 10px;text-align: center" >Debit</th>
                           <th style="width: 10px;text-align: center" >Credit</th>   
                           <th style="width: 5px;text-align: center" >Cashflow Code</th>   
                      </tr>
                    </thead>

                    <tbody id="itemlist">
                    <?php
                      $data_journal = $this->journal_model->get_journal_detail(null,@$start_date,@$end_date);
                        $total_debit = 0;
                        $total_kredit = 0;

                        foreach ($data_journal as $journal_entry){
                    ?>
                        <tr>
                            <td align="center"><?php echo($journal_entry->journal_no); ?></td>
                            <td align="right"><?php echo($journal_entry->journal_entry); ?></td>
                            <td align="right"><?php echo($journal_entry->journal_date); ?></td>
                            <td align="left"><?php echo($journal_entry->journal_description); ?></td>
                            <td><?php echo $journal_entry->coa_code_e; ?> || <?php echo $journal_entry->coa_name_e; ?> </td> 
                            <td align="right"><?php echo number_format($journal_entry->journal_debit,0,".","."); ?></td>
                            <td align="right"><?php echo number_format($journal_entry->journal_kredit,0,".","."); ?></td>
                            <td align="right"><?php echo($journal_entry->cashflow_code_status); ?></td>
                        </tr>

                    <?php
                        $total_debit = $total_debit + $journal_entry->journal_debit;
                        $total_kredit = $total_kredit + $journal_entry->journal_kredit;
                      }
                    ?>

                    </tbody>
                    <tbody>
                        <tr>
                            <!-- <td></td> -->
                            <td></td>
                            <td></td>
                            <td></td>
                            <td align="center"><strong>TOTAL</strong></td>
                            <td></td>
                            <td><input type='text' class='form-control' name='total_debit' value='<?php echo number_format($total_debit); ?>' disabled="true" style="text-align: right;"></td>   
                            <td><input type='text' class='form-control' name='total_kredit' value='<?php echo number_format($total_kredit); ?>' disabled="true" style="text-align: right;"></td>  
                            <td></td>
                        </tr>
                    </tbody>
                   </table>
              </div>
              <div class="box-footer text-right">
                <!-- <a href="<?php echo $back_url; ?>" class="btn btn-warning btn-sm btnwdt">Back</a> -->
              </div>
          </div>
        </div>
      </div>
    </section>
  </div>
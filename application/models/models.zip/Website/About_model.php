<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class About_model extends CI_Model {

    public function get_about()
    {   
        $this->db->select("ta.*")
          ->from("tb_website_about ta");

    return $this->db->get()->result();
    }

    public function get_aboutmenu($id_website_about)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_about_menu tam")
          ->join("tb_website_about ta","ta.id_website_about = tam.id_website_about");

        $this->db->where("ta.id_website_about", $id_website_about);
        $this->db->order_by("tam.id_website_about_menu", "ASC");

    return $this->db->get()->result();
    }
    
    public function get_aboutmenu_list($limit = null, $position = null)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_about_menu tam")
          ->join("tb_website_about ta","ta.id_website_about = tam.id_website_about");

        // $this->db->where("ta.id_website_about", $id_website_about);
        
        if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("tam.id_website_about_menu", "ASC");

    return $this->db->get();
    }

    public function get_aboutmenu_front($limit = null, $start = null)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_about_menu tam");

        $this->db->where("tam.about_menu_access_status", "Activated");

        if (!empty($limit)){
            if ($start == null){
                $start = 0;
            }
        $this->db->limit($limit, $start);
        }   
        $this->db->order_by("tam.about_menu_orders", "ASC");

    return $this->db->get()->result();
    }

    public function get_aboutmenu_by_id($id_website_about_menu)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_about_menu tam");

        $this->db->where("tam.id_website_about_menu", $id_website_about_menu);

    return $this->db->get()->result();
    }

}
?>
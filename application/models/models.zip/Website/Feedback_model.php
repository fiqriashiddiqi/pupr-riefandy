<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Feedback_model extends CI_Model {

	public function get_feedback($access_status = null)
    {   
        $this->db->select("twc.*")
          ->from("tb_website_feedback twc");
     

        if (!empty($access_status)){
          $this->db->where("twc.feedback_access_status", $feedback_access_status);
        }

        $this->db->order_by("twc.id_website_feedback", "ASC");

        return $this->db->get()->result();
    }

    public function get_feedback_list($limit = null, $position = null)
    {   
        $this->db->select("twc.*")
          ->from("tb_website_feedback twc");
     

         if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twc.id_website_feedback", "ASC");

        return $this->db->get();
    }


    public function get_feedback_by_id($id_website_feedback)
    {   
        $this->db->select("tam.*")
          ->from("tb_website_feedback tam");

        $this->db->where("tam.id_website_feedback", $id_website_feedback);

    return $this->db->get()->result();
    }

    public function get_feedback_by_limit($limit,$start)
    {   
    $this->db->select("ta.*")
          ->from("tb_website_feedback ta");
    $this->db->where("ta.feedback_access_status = 'Activated'");
    $this->db->order_by("ta.feedback_orders", "ASC");
    $this->db->limit($limit, $start);
    return $this->db->get()->result();

    }


  
}
?>
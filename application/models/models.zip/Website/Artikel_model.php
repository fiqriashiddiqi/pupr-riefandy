<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Artikel_model extends CI_Model {

	public function get_data($table)
	{	
		return $this->db->get($table);
    
	}

  public function get_artikel()
    {   
        $this->db->select("twa.*")
          ->from("tb_website_blog twa");

    return $this->db->get()->result();
    }

    public function get_artikel_list($limit = null, $position = null)
    {   
        $this->db->select("twa.*")
          ->from("tb_website_blog twa");

           if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

    return $this->db->get();
    }

  public function get_artikel_by_limit($limit,$start)
  {   
    $this->db->select("twa.*")
          ->from("tb_website_blog twa");
    $this->db->where("twa.blog_display_status = 'Blog'");
    $this->db->where("twa.blog_access_status = 'Activated'");
    $this->db->order_by("twa.blog_orders", "ASC");
    $this->db->limit($limit, $start);
    return $this->db->get()->result();

  }

    public function get_artikel_by_display_status($blog_display_status)
    {   
        $this->db->select("twa.*")
          ->from("tb_website_blog twa");
        $this->db->where("twa.blog_display_status", $blog_display_status);
        $this->db->where("twa.blog_access_status = 'Activated'");
        $this->db->order_by("twa.blog_postdate", "DESC");

        return $this->db->get()->result();
    }

      public function get_artikel_by_display_status_id($blog_display_status, $id_artikel)
      {   
        $this->db->select("twa.*")
              ->from("tb_website_blog twa");
        $this->db->where("twa.blog_display_status", $blog_display_status);
        $this->db->where("twa.id_website_blog", $id_artikel);
        $this->db->where("twa.blog_access_status = 'Activated'");
        $this->db->order_by("twa.blog_postdate", "DESC");

        return $this->db->get()->result();
      }

      public function get_artikel_by_id($id_website_blog)
      {   
          $this->db->select("tam.*")
            ->from("tb_website_blog tam");

          $this->db->where("tam.id_website_blog", $id_website_blog);

        return $this->db->get()->result();
      }


      public function get_data_all($id_news = null)
      { 
        $this->db->select("tn.*")
          ->from("tb_website_blog tn");

        if (!empty($id_blog)){
          $this->db->where("tn.id_website_blog", $id_blog);
        }

        $this->db->order_by("tn.blog_postdate", "DESC");

        return $this->db->get()->result();

      }
	
}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Journal_model extends CI_Model {


  public function get_data($table)
  { 
    return $this->db->get($table);
    
  }

    public function sum_journal_by_coa_e($param_coa_e = null, $start_date = null, $end_date = null)
    {   
        $this->db->select('tc.id_param_coa_e, SUM(tc.journal_debit) AS debit, SUM(tc.journal_kredit) AS credit')
                 ->from("tb_general_ledger_journal tc");

        if (!empty($param_coa_e)){
          $this->db->where("tc.id_param_coa_e", $param_coa_e);
        }

        if (!empty($start_date)){
          $this->db->where('tc.journal_date >=', $start_date);
        }
        if (!empty($end_date)){
          $this->db->where('tc.journal_date <=', $end_date);
        }
        
        return $this->db->get()->result();
    }

    public function sum_journal_by_coa_comparison($param_coa_e = null, $start_date_comparison =null, $end_date_comparison=null)
    {   
        $this->db->select('tc.id_param_coa_e, SUM(tc.journal_debit) AS debit, SUM(tc.journal_kredit) AS credit')
                 ->from("tb_general_ledger_journal tc");

        if (!empty($param_coa_e)){
          $this->db->where("tc.id_param_coa_e", $param_coa_e);
        }

        if (!empty($start_date_comparison)){
          $this->db->where('tc.journal_date >=', $start_date_comparison);
        }
        if (!empty($end_date_comparison)){
          $this->db->where('tc.journal_date <=', $end_date_comparison);
        }
        
        return $this->db->get()->result();
    }

    public function get_coa_a()
    {   
        $this->db->select("tc.*")
          ->from("tb_param_coa_a tc");
    
        $this->db->order_by("tc.coa_code_a", "ASC");

        return $this->db->get()->result();

    }

    public function get_dropdown_coa_b($id_param_coa_a = null)
    {   
        $this->db->select("tc.*")
          ->from("tb_param_coa_b tc");

        if (!empty($id_param_coa_a)){
          $this->db->where("tc.id_param_coa_a", $id_param_coa_a);
        }

        $this->db->order_by("tc.coa_code_b", "ASC");

        return $this->db->get()->result();

    }

    public function get_dropdown_coa_c($id_param_coa_b = null)
    {   
     
       $this->db->select("tc.*")
          ->from("tb_param_coa_c tc");

        if (!empty($id_param_coa_b)){
          $this->db->where("tc.id_param_coa_b", $id_param_coa_b);
        }

        $this->db->order_by("tc.coa_code_c", "ASC");

        return $this->db->get()->result();
    }

    public function get_dropdown_coa_d($id_param_coa_c = null)
    {   
        $this->db->select("td.*")
          ->from("tb_param_coa_d td");

        if (!empty($id_param_coa_c)){
          $this->db->where("td.id_param_coa_c", $id_param_coa_c);
        }

        $this->db->order_by("td.coa_code_d", "ASC");

        return $this->db->get()->result();
    }

    public function get_dropdown_coa_e($id_param_coa_d = null)
    {   
       $this->db->select("te.*")
          ->from("tb_param_coa_e te");

        if (!empty($id_param_coa_d)){
          $this->db->where("te.id_param_coa_d", $id_param_coa_d);
        }

        $this->db->order_by("te.coa_code_e", "ASC");

        return $this->db->get()->result();

    }

    public function get_cashflow_code($cashflow_code_status)
    {   
        $this->db->select("tc. cashflow_code_status, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');


        $this->db->order_by("ta.coa_code_e", "ASC");

        return $this->db->get()->result();

    }

    public function get_journal($id_param_coa_e = null , $journal_no=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($id_param_coa_e)){
          $this->db->where("ta.id_param_coa_e", $id_param_coa_e);
        }

        if (!empty($journal_no)){
          $this->db->where("tc.journal_no", $journal_no);
        }

        $this->db->order_by("ta.coa_code_e", "ASC");

        return $this->db->get()->result();

    }
    public function get_assets($id_param_coa_e = null )
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_assets tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($id_param_coa_e)){
          $this->db->where("ta.id_param_coa_e", $id_param_coa_e);
        }

        $this->db->order_by("tc.assets_date", "ASC");

        return $this->db->get()->result();

    }
    public function get_assets_detail($id_assets)
    {   
        $this->db->select("tc.* ")
          ->from("tb_general_ledger_assets tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

      
        $this->db->where("tc.id_assets",$id_assets);


        $this->db->order_by("tc.id_assets", "ASC");

        return $this->db->get()->result();

    }
    public function get_cashflow_begining($cashflow_code_status,$start_date=null)
    {   
    $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e, sum(tc.journal_debit) as debit, sum(tc.journal_kredit) as kredit")
          ->from("tb_general_ledger_journal tc");
    $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

    $this->db->where("tc.cashflow_code_status != '0'");
      if (!empty($start_date)){
          $this->db->where("tc.journal_date < '$start_date'" );
        }

        //  if (!empty($end_date)){
        //   $this->db->where("tc.journal_date <= '$end_date'");
        // }

    // $this->db->where("ta.slideshow_access_status = 'Activated'");
    // $this->db->order_by("ta.slideshow_orders ", "ASC");
    // $this->db->limit($limit, $start);
    return $this->db->get()->result();

    }

    public function get_cashflow($cashflow_code_status,$start_date=null,$end_date=null )
    {   
    $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e, sum(tc.journal_debit) as debit, sum(tc.journal_kredit) as kredit")
          ->from("tb_general_ledger_journal tc");
    $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

    $this->db->where("tc.cashflow_code_status", $cashflow_code_status);
    
      if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }

    // $this->db->where("ta.slideshow_access_status = 'Activated'");
    // $this->db->order_by("ta.slideshow_orders ", "ASC");
    // $this->db->limit($limit, $start);
    return $this->db->get()->result();

    }

 
    
    public function get_journaldate_status($start_date=null,$end_date=null)
    {


      $isExists = $this->db->select("count(journal_date) as count")
                  ->from("tb_general_ledger_journal")
                  ->where("journal_date", $start_date)
                  ->limit(1)
                  ->get()
                  ->result();


      $firstDate = $this->db->select("journal_date")
                  ->from("tb_general_ledger_journal ")
                  ->order_by("journal_date asc")
                  ->limit(1)
                  ->get()
                  ->result();       

      $getDate = $this->db->select("journal_date")
                    ->from("tb_general_ledger_journal ")
                    ->order_by("journal_date desc")
                    ->limit(1)
                    ->get()
                    ->result();              

      if ($start_date == date('Y-m-01') && $end_date == date("Y-m-t", strtotime($end_date))) {
 // echo "a";
          return "0";
      }else{
          if($start_date < $firstDate[0]->journal_date){
             // echo "b";
             return "0";
          }
          else if($start_date > $firstDate[0]->journal_date && $start_date < $getDate[0]->journal_date){
              // echo "c";
              // return $firstDate[0]->journal_date;
            return "0";
          }
          else if($start_date > $firstDate[0]->journal_date && $start_date > $getDate[0]->journal_date){
              // echo "e";
              return $getDate[0]->journal_date;
              // return "0";
          }
          else{
         // echo "d";
              return "0";
          }
      }
    }

    public function get_trialbalance($id_param_coa_e = null , $coa_code_e=null, $start_date=null, $end_date=null, $month=null)
    {   

      $isExists = $this->get_journaldate_status($start_date,$end_date); 

      $YEARS = date("Y", strtotime($month));
      $MONTHS = date("m", strtotime($month));

      if($isExists != "0")  $start_date = $isExists;   

        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e , ( SELECT sum(a.journal_debit) from tb_general_ledger_journal as a WHERE a.id_param_coa_e=tc.id_param_coa_e AND `a`.`journal_date` >= '$start_date' AND `a`.`journal_date` <= '$end_date') as debit , ( SELECT sum(a.journal_kredit) from tb_general_ledger_journal as a WHERE a.id_param_coa_e=tc.id_param_coa_e AND `a`.`journal_date` >= '$start_date' AND `a`.`journal_date` <= '$end_date') as kredit")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($id_param_coa_e)){
          $this->db->where("ta.id_param_coa_e", $id_param_coa_e);
        }

        if (!empty($coa_code_e)){
          $this->db->where("ta.coa_code_e", $coa_code_e);
        }

        // if (!empty($start_date)){
        //   $this->db->where("tc.journal_date >= '$start_date'" );
        // }

        // if (!empty($end_date)){
        //   $this->db->where("tc.journal_date <= '$end_date'");
        // }
        
        if (!empty($month)){
          $this->db->where("MONTH(tc.journal_date) = '".$MONTHS."'");
          $this->db->where("YEAR(tc.journal_date) = '".$YEARS."'");
        }

        $this->db->group_by("ta.coa_code_e");

        $this->db->order_by("ta.coa_code_e", "ASC");

        return $this->db->get()->result();

    }

    public function get_journal_closing($YEARS, $MONTHS)
    {   

        $this->db->select("tc.*")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        $this->db->where("MONTH(tc.journal_date) = '".$MONTHS."'");
        $this->db->where("YEAR(tc.journal_date) = '".$YEARS."'");

        return $this->db->get();

    }

    public function get_journal_closing_before($YEARS, $MONTHS)
    {   

        $this->db->select("tc.*")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        $this->db->where("MONTH(tc.journal_date) < '".$MONTHS."'");
        $this->db->where("YEAR(tc.journal_date) <= '".$YEARS."'");
        $this->db->where("tc.journal_status = '0'");

        return $this->db->get();

    }

    public function get_journal_closing_before_temp($YEARS, $MONTHS)
    {   

        $this->db->select("tc.*")
          ->from("tb_general_ledger_journal_temp tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        $this->db->where("MONTH(tc.journal_date) < '".$MONTHS."'");
        $this->db->where("YEAR(tc.journal_date) <= '".$YEARS."'");

        return $this->db->get();

    }

    public function get_journal_temp_closing($YEARS, $MONTHS)
    {   

        $this->db->select("tc.*")
          ->from("tb_general_ledger_journal_temp tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        $this->db->where("MONTH(tc.journal_date) = '".$MONTHS."'");
        $this->db->where("YEAR(tc.journal_date) = '".$YEARS."'");

        return $this->db->get();

    }

    public function get_saldo_akhir_trial($id_param_coa_e = null, $start_date=null,$end_date=null,$month=null)
    {   

        $YEARS = date("Y", strtotime($month));
        $MONTHS = date("m", strtotime($month));
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e, sum(tc.journal_debit) as debit, sum(tc.journal_kredit) as kredit")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e', 'right');

        if (!empty($id_param_coa_e)){
          $this->db->where("ta.id_param_coa_e", $id_param_coa_e);
        }

        if (!empty($start_date)){
          $this->db->where("tc.journal_date < '$start_date'" );
        }

        if (!empty($month)){
          $this->db->where("MONTH(tc.journal_date) < '".$MONTHS."'");
          $this->db->where("YEAR(tc.journal_date) < '".$YEARS."'");
        }
        
        $this->db->group_by("ta.coa_code_e");

        $this->db->order_by("ta.coa_code_e", "ASC");

        return $this->db->get()->result();

    }

    public function get_ledger($id_param_coa_e = null, $start_date=null, $end_date=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($id_param_coa_e)){
          $this->db->where("ta.id_param_coa_e", $id_param_coa_e);
        }

        if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }

        $this->db->order_by("ta.coa_code_e", "ASC");

        return $this->db->get()->result();

    }

    public function get_tableledger($id_param_coa_e=null, $start_date=null, $end_date=null)
    {   
        
         $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

         if (!empty($id_param_coa_e)){
          $this->db->where('tc.id_param_coa_e', $id_param_coa_e);
        }

        if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }
        
        $this->db->group_by("tc.id_param_coa_e");
        
         $this->db->order_by("ta.coa_code_e", "ASC");

        return $this->db->get()->result();

    }

    public function get_journal_detail($journal_no=null, $start_date=null, $end_date=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($journal_no)){
          $this->db->where("tc.journal_no", $journal_no);
        }
        if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }

        $this->db->order_by("tc.journal_no", "ASC");

        return $this->db->get()->result();

    }

    public function get_journal_temp_detail($journal_no=null, $cashflow_code_status=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal_temp tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($journal_no)){
          $this->db->where("tc.journal_no", $journal_no);
        }
        if (!empty($cashflow_code_status)){
          $this->db->where("tc.cashflow_code_status", $cashflow_code_status);
        }

        $this->db->order_by("tc.journal_no", "ASC");

        return $this->db->get()->result();

    }

    public function get_journal_temp($journal_no=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal_temp tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');


        if (!empty($journal_no)){
          $this->db->where("tc.journal_no", $journal_no);
        }

        $this->db->order_by("tc.journal_no", "desc");

        return $this->db->get()->result();

    }
    public function get_journal_by_id($id_param_coa_e)
    {   
        $this->db->select("tam.*")
        ->from("tb_general_ledger_journal tam");

        $this->db->where("tam.id_param_coa_e", $id_param_coa_e);

        $this->db->order_by("tam.journal_date", "ASC");

      return $this->db->get()->result();
    }
    public function get_journal_by_id_a($id_param_coa_a)
    {   
        $this->db->select("tam.*, ce.coa_code_e, ce.coa_name_e")
        ->from("tb_general_ledger_journal tam")
        ->join("tb_param_coa_e ce","ce.id_param_coa_e = tam.id_param_coa_e")
        ->join("tb_param_coa_d cd","cd.id_param_coa_d = ce.id_param_coa_d")
        ->join("tb_param_coa_c cc","cc.id_param_coa_c = cd.id_param_coa_c")
        ->join("tb_param_coa_b cb","cb.id_param_coa_b = cc.id_param_coa_b")
        ->join("tb_param_coa_a ca","ca.id_param_coa_a = cb.id_param_coa_a")
        ;

        $this->db->where("ca.id_param_coa_a", $id_param_coa_a);

        $this->db->order_by("tam.journal_date", "ASC");

      return $this->db->get()->result();
    }

    public function get_coa_e_by_coa_a($id_param_coa_a)
    {   
        $this->db->select("ce.*")
        ->from("tb_param_coa_e ce")
        ->join("tb_param_coa_d cd","cd.id_param_coa_d = ce.id_param_coa_d")
        ->join("tb_param_coa_c cc","cc.id_param_coa_c = cd.id_param_coa_c")
        ->join("tb_param_coa_b cb","cb.id_param_coa_b = cc.id_param_coa_b")
        ->join("tb_param_coa_a ca","ca.id_param_coa_a = cb.id_param_coa_a")
        ;

        $this->db->where("ca.id_param_coa_a", $id_param_coa_a);

        $this->db->order_by("ce.id_param_coa_e", "ASC");

      return $this->db->get()->result();
    }

    public function get_journal_id_journal($id_journal = null)
    {   
        $this->db->select("tc.*,tb.*")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e tb', 'tb.id_param_coa_e = tc.id_param_coa_e');  

        if (!empty($id_journal)){
          $this->db->where("tc.id_journal", $id_journal);
        }

         $this->db->order_by("tc.journal_entry", "DESC");

        return $this->db->get()->result();

    }

    public function get_journal_temp_id_journal($id_temp_journal = null)
    {   
        $this->db->select("tc.*,tb.*")
          ->from("tb_general_ledger_journal_temp tc");

        $this->db->join('tb_param_coa_e tb', 'tb.id_param_coa_e = tc.id_param_coa_e');  

        if (!empty($id_temp_journal)){
          $this->db->where("tc.id_temp_journal", $id_temp_journal);
        }

         $this->db->order_by("tc.journal_entry", "DESC");

        return $this->db->get()->result();

    }

    public function get_journal_group($start_date=null, $end_date=null, $YEARS = null, $MONTHS = null, $status = null)
    {   
        $this->db->select("tc.*")
          ->from("tb_general_ledger_journal tc");

        $this->db->group_by("tc.journal_no");

        if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

        if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }

        if (!empty($MONTHS)){
          $this->db->where("MONTH(tc.journal_date) = '".$MONTHS."'");
          $this->db->where("YEAR(tc.journal_date) = '".$YEARS."'");
        }

        if (!empty($status)){
          $this->db->where("tc.journal_status", $status);
        }

        $this->db->order_by("tc.journal_no", "DESC");

        return $this->db->get()->result();

    }

    public function get_journal_group_temp($start_date=null, $end_date=null, $YEARS = null, $MONTHS = null, $status = null)
    {   
        $this->db->select("tc.*")
          ->from("tb_general_ledger_journal_temp tc");

        $this->db->group_by("tc.journal_no");

        if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

        if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }

        if (!empty($MONTHS)){
          $this->db->where("MONTH(tc.journal_date) = '".$MONTHS."'");
          $this->db->where("YEAR(tc.journal_date) = '".$YEARS."'");
        }

        if (!empty($status)){
          $this->db->where("tc.journal_status", $status);
        }

        $this->db->order_by("tc.journal_no", "DESC");

        return $this->db->get()->result();

    }



    public function get_journal_temp_group($start_date=null, $end_date=null)
    {   
        $this->db->select("tc.*")
          ->from("tb_general_ledger_journal_temp tc");

        $this->db->group_by("tc.journal_no");
        
         if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }

        return $this->db->get()->result();

    }

     public function get_journal_list($limit = null, $position = null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

       if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("tc.id_journal", "ASC");

        return $this->db->get();

    }

    public function get_saldo_akhir($id_param_coa_e = null, $start_date=null)
    {   
        $this->db->select("tc.journal_debit,tc.journal_kredit")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($id_param_coa_e)){
          $this->db->where("ta.id_param_coa_e", $id_param_coa_e);
        }

        if (!empty($start_date)){
          $this->db->where("tc.journal_date < '$start_date'" );
        }

        return $this->db->get()->result();

    }
   

    public function journal_code() 
    {   
        return $this->db->query("SELECT max(journal_no) as maxID 
        FROM tb_general_ledger_journal WHERE journal_no")->result();
    }
    public function journal_temp_code() 
    {   
        return $this->db->query("SELECT max(journal_no) as maxID 
        FROM tb_general_ledger_journal_temp WHERE journal_no")->result();
    }

     public function get_journal_list_report($id_journal=null, $start_date=null,$end_date=null,$journal_no=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($id_journal)){
        $this->db->where("tc.id_journal", $id_journal);
        }
         if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }
        $this->db->group_by("tc.journal_no");
      
        $this->db->order_by("tc.id_journal", "DESC");

        return $this->db->get()->result();

    }

    public function get_journal_temp_list_report($id_temp_journal=null, $start_date=null,$end_date=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal_temp tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($id_temp_journal)){
        $this->db->where("tc.id_temp_journal", $id_temp_journal);
        }
         if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }
      
        $this->db->order_by("tc.id_temp_journal", "ASC");

        return $this->db->get()->result();

    }

    public function  get_ledger_list_report( $id_journal=null, $id_param_coa_e= null, $start_date=null, $end_date=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        if (!empty($id_param_coa_e)){
          $this->db->where("ta.id_param_coa_e", $id_param_coa_e);
        }

        if (!empty($id_journal)){
          $this->db->where("tc.id_journal", $id_journal);
        }
         if (!empty($start_date)){
          $this->db->where("tc.journal_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.journal_date <= '$end_date'");
        }
      

        $this->db->order_by("ta.coa_code_e", "ASC");

        return $this->db->get()->result();

    }

    public function  get_balance_list_report( $journal_no=null)
    {   
        $this->db->select("tc.*, ta.coa_code_e, ta.coa_name_e")
          ->from("tb_general_ledger_journal tc");

        $this->db->join('tb_param_coa_e ta', 'tc.id_param_coa_e = ta.id_param_coa_e');

        // if (!empty($id_param_coa_e)){
        //   $this->db->where("ta.id_param_coa_e", $id_param_coa_e);
        // }

        if (!empty($journal_no)){
          $this->db->where("tc.journal_no", $journal_no);
        }

        $this->db->group_by("tc.id_param_coa_e");

        return $this->db->get()->result();

    }

    public function  update_status_gl($month,$years)
    {   
        $this->db->query("UPDATE tb_general_ledger_journal SET journal_status = 'Closed' WHERE MONTH(journal_date) = '$month' AND YEAR(journal_date) = '$years'");

    }

    public function  update_status_gl_open($month,$years)
    {   
        $this->db->query("UPDATE tb_general_ledger_journal SET journal_status = '0' WHERE MONTH(journal_date) = '$month' AND YEAR(journal_date) = '$years'");

    }

    public function get_closing_journal()
    {   
        $this->db->select('MAX(tc.journal_date) AS closing_date, MIN(tc.journal_date) AS closing_date_min')
                 ->from("tb_general_ledger_journal tc");

        $this->db->where('tc.journal_status','Closed');
        
        return $this->db->get()->result();
    }

    public function get_closing_journal_list()
    {   
        $this->db->select('tc.*')
                 ->from("tb_general_ledger_journal tc");

        $this->db->where('tc.journal_status','Closed');
        
        $this->db->group_by("DATE_FORMAT(tc.journal_date, '%Y%m')");

        $this->db->order_by("tc.journal_date", "ASC");
        return $this->db->get()->result();
    }

    public function get_closing_journal_list_open()
    {   
        $this->db->select('tc.*')
                 ->from("tb_general_ledger_journal tc");

        $this->db->where("tc.journal_status",'0');

        $this->db->group_by("DATE_FORMAT(tc.journal_date, '%Y%m')");

        $this->db->order_by("tc.journal_date", "ASC");
        return $this->db->get()->result();
    }
   
}   
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auto_model extends CI_Model {

    public function get_loan($register_code)
    {   
        $this->db->select("tbg.*")
          ->from("tb_fintech_lender_automation tbg");

        $this->db->where("tbg.register_code", $register_code);
        return $this->db->get()->result();
    }

    public function get_auto()
    {   
        $this->db->select("ta.*")
          ->from("tb_fintech_lender_automation ta");
          $this->db->order_by("ta.id_lender_automation", "ASC");

        return $this->db->get()->result();
    }

    public function get_auto_front()
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_automation tam");

        $this->db->where("tam.automation_status", "Activated");
        $this->db->order_by("tam.id_lender_automation", "ASC");

        return $this->db->get()->result();
    }

    public function get_auto_by_id($id_lender_automation)
    {   
        $this->db->select("tbm.*")
          ->from("tb_fintech_lender_automation tbm");

        $this->db->where("tbm.id_lender_automation", $id_lender_automation);

        return $this->db->get()->result();
    }

    public function get_auto_purchase()
    {   
        $this->db->select("ta.*")
          ->from("tb_fintech_lender_automation ta");

        $this->db->where("ta.automation_status", "Activated");

        $this->db->order_by("ta.id_lender_automation", "ASC");

        return $this->db->get()->result();
    }

}
?>
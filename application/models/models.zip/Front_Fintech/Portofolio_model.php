<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Portofolio_model extends CI_Model {


    public function get_rating($register_code,$rating)
    {   
        $this->db->select("loan_rating, count(*) as total_rating")
          ->from("tb_fintech_borrower_loan tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);
        
        $this->db->where("tc.loan_rating", $rating);


        return $this->db->get()->result();

    }

    public function get_loan_type($register_code,$type)
    {   
        $this->db->select("loan_type, count(*) as total_type")
          ->from("tb_fintech_borrower_loan tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);
        
        $this->db->where("tc.loan_type", $type);


        return $this->db->get()->result();

    }

    public function get_count_loan($register_code)
    {   
        $this->db->select("count(ta.register_code) as total_loan")
          ->from("tb_fintech_lender_investment ta");
        $this->db->join('tb_fintech_borrower_loan tc', 'ta.id_borrower_loan = tc.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);
        
        // $this->db->where("tc.loan_type", $type);
        $this->db->where("tc.loan_status","Disbursed");


        return $this->db->get()->result();

    }

}

?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Payment_model extends CI_Model {

    public function get_payment_borrower($register_code, $limit = null, $position = null)
    {   
        $this->db->select("tp.*")
          ->from("tb_fintech_borrower_payment tp");

        $this->db->where("tp.register_code", $register_code);

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("tp.payment_date", "DESC");

    return $this->db->get();
    }

    public function get_realtime_loan()
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        $this->db->where("tw.loan_status", "Disbursed");
        $this->db->order_by("tw.loan_date", "ASC");

        return $this->db->get()->result();
    }

    public function get_realtime_loan_crowdfunding()
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        //$this->db->where("tw.loan_status", "Crowdfunding");

        return $this->db->get()->result();
    }

    public function get_realtime_loan_payment($id_borrower_loan)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_payment_periode tw");

        $this->db->where("tw.id_borrower_loan", $id_borrower_loan);
        $this->db->order_by("tw.id_payment_periode", "ASC");

        return $this->db->get()->result();
    }

    public function get_realtime_loan_payment_count($id_borrower_loan)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_payment_periode tw");

        $this->db->where("tw.id_borrower_loan", $id_borrower_loan);
        $this->db->where("tw.payment_periode_status_interest != 'default'");
        $this->db->where("tw.payment_periode_status_pinalty != 'default'");
        $this->db->order_by("tw.payment_periode_date", "DESC");

        return $this->db->get();
    }

    public function get_realtime_loan_payment_sum_principal($id_borrower_loan)
    {   
        $this->db->select("sum(tw.payment_periode_principal) as principal")
          ->from("tb_fintech_borrower_payment_periode tw");

        $this->db->where("tw.id_borrower_loan", $id_borrower_loan);
        $this->db->where("tw.payment_periode_status_interest != 'default'");
        $this->db->where("tw.payment_periode_status_pinalty != 'default'");
        $this->db->order_by("tw.id_payment_periode", "ASC");

        return $this->db->get()->result();
    }

    public function get_realtime_loan_payment_count_mct_1($id_borrower_loan,$date_now)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_payment_periode tw");

        $this->db->where("tw.id_borrower_loan", $id_borrower_loan);
        $this->db->where("tw.payment_periode_status_principal = 'Late, Not Yet Paid' AND tw.payment_periode_status_interest = 'Late, Not Yet Paid' AND tw.payment_periode_status_pinalty = 'Late, Not Yet Paid'");
        $this->db->where("tw.payment_periode_date <= '".$date_now."'");
        $this->db->order_by("tw.payment_periode_date", "DESC");

        return $this->db->get();
    }

    public function get_realtime_loan_payment_count_mct_2($id_borrower_loan,$date_now)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_payment_periode tw");

        $this->db->where("tw.id_borrower_loan", $id_borrower_loan);
        $this->db->where("tw.payment_periode_status_interest = 'Late, Not Yet Paid' AND tw.payment_periode_status_pinalty = 'Late, Not Yet Paid'");
        $this->db->where("tw.payment_periode_date <= '".$date_now."'");
        $this->db->order_by("tw.payment_periode_date", "DESC");

        return $this->db->get();
    }

    public function get_realtime_loan_payment_by_id($id_payment_periode)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_payment_periode tw");

        $this->db->where("tw.id_payment_periode", $id_payment_periode);

        return $this->db->get()->result();
    }

    public function get_realtime_loan_payment_periode()
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_payment_periode tw");

          $this->db->where("tw.status_periode_email","No");

        return $this->db->get()->result();
    }

    public function get_realtime_investor($id_borrower_loan)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_lender_investment tw");

        $this->db->where("tw.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();
    }

    public function get_realtime_borrower_fund($register_code)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_fund tw");

        $this->db->where("tw.register_code", $register_code);

        return $this->db->get()->result();
    }

    public function get_realtime_lender_fund($register_code)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_lender_fund tw");

        $this->db->where("tw.register_code", $register_code);

        return $this->db->get()->result();
    }

    public function get_realtime_fee()
    {   
        $this->db->select("tw.*")
          ->from("tb_setting tw");

        return $this->db->get()->result();
    }

     public function get_loan($id_borrower_loan)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");

          $this->db->where("tw.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();
    }

    public function get_payment_periode($id_payment_periode = null,$limit = null, $position = null,$id_borrower_loan=null)
    {   

        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_payment_periode twb");
        // $this->db->join('tb_fintech_borrower_payment ta','twb.id_payment_periode = ta.id_payment_periode');

          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        // $this->db->where("ta.id_payment_periode",$id_payment_periode);
        $this->db->where("twb.id_borrower_loan",$id_borrower_loan);
        $this->db->where("twb.payment_periode_status_principal != 'default '");

        return $this->db->get();

    }

    public function get_invest_payment($investment_code = null,$limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_lender_investment_payment twb");
        $this->db->join('tb_fintech_lender_investment ta','twb.investment_code = ta.investment_code');
        
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->where("ta.investment_code",$investment_code);

        return $this->db->get();

    }

}
?>
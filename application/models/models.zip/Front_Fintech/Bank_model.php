<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bank_model extends CI_Model {

    public function get_personal()
    {   
        $this->db->select("ta.*")
          ->from("tb_fintech_borrower_bio ta");

    return $this->db->get()->result();
    }

    public function get_bank_borrower($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_borrower_bank tam");

        $this->db->where("tam.register_code", $register_code);

    return $this->db->get()->result();
    }

    public function get_bank_lender($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_bank tam");

        $this->db->where("tam.register_code", $register_code);

    return $this->db->get()->result();
    }

    public function get_deposit_sum($register_code)
    {   
        $this->db->select("sum(deposit_amount) as deposit_sum")
          ->from("tb_fintech_lender_deposit tam");

        $this->db->where("tam.register_code", $register_code);

    return $this->db->get()->result();
    }

    public function get_bank_deposit($register_code, $limit = null, $position = null)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_deposit tam");

        $this->db->where("tam.register_code", $register_code);

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("tam.deposit_date", "DESC");

    return $this->db->get();
    }

    public function get_bank_payment($register_code, $limit = null, $position = null)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_deposit tam");

        $this->db->where("tam.register_code", $register_code);

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("tam.deposit_date", "DESC");

    return $this->db->get();
    }

    public function get_withdrawal_lender($register_code, $limit = null, $position = null)
    {   
        $this->db->select("wl.*")
          ->from("tb_fintech_lender_withdrawal wl");

        $this->db->where("wl.register_code", $register_code);

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("wl.withdrawal_date", "DESC");

    return $this->db->get();
    }

    public function get_withdrawal_borrower($register_code, $limit = null, $position = null)
    {   
        $this->db->select("wb.*")
          ->from("tb_fintech_borrower_withdrawal wb");

        $this->db->where("wb.register_code", $register_code);

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("wb.withdrawal_date", "DESC");

    return $this->db->get();
    }

    public function get_fund_lender($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_lender_fund tam");

        $this->db->where("tam.register_code", $register_code);

    return $this->db->get()->result();
    }

    public function get_fund_borrower($register_code)
    {   
        $this->db->select("tam.*")
          ->from("tb_fintech_borrower_fund tam");

        $this->db->where("tam.register_code", $register_code);

    return $this->db->get()->result();
    }

}
?>
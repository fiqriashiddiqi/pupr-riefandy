<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report_model extends CI_Model {

    public function get_cashflow($register_code, $start_date=null, $end_date=null)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_lender_cashflow tc");
        
        if (!empty($start_date)){
          $this->db->where("tc.cashflow_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.cashflow_date <= '$end_date'");
        }

        $this->db->where("tc.register_code", $register_code);

        

        return $this->db->get()->result();
    }

    public function get_total_amount($register_code)
    {   
        $this->db->select("tc.total_amount")
          ->from("tb_fintech_lender_cashflow tc");
        
        // if (!empty($id_lender_cashflow)){
        //   $this->db->where("tc.id_lender_cashflow", $id_lender_cashflow);
        // }

        $this->db->order_by("tc.cashflow_date","DESC");
        $this->db->limit("1");
        $this->db->where("tc.register_code", $register_code);

        // $this->db->group_by('tc.cashflow_date');

        return $this->db->get()->result();
    }

    public function get_data_loan($register_code,$start_date=null, $end_date=null)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_loan tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        if (!empty($start_date)){
          $this->db->where("tc.loan_start_date >= '$start_date'" );
        }

         if (!empty($end_date)){
          $this->db->where("tc.loan_start_date <= '$end_date'");
        }

        $this->db->where("ta.register_code", $register_code);

        return $this->db->get()->result();

    }


}
?>
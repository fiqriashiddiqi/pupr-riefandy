<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Connection_model extends CI_Model {

	public function get_register()
	{   
	        $this->db->select("ts.*")
	          ->from("tb_fintech_register ts");

	        $this->db->order_by("ts.register_code", "ASC");

	        return $this->db->get()->result();

	}

	public function get_point_lender($register_code, $limit = null, $position = null)
    {   
        $this->db->select("wb.*")
          ->from("tb_fintech_lender_reference wb");

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("wb.reference_date", "DESC");
        // $this->db->limit("1");
        $this->db->where("wb.register_code", $register_code);

    return $this->db->get();
    }

    public function get_point_borrower($register_code, $limit = null, $position = null)
    {   
        $this->db->select("wb.*")
          ->from("tb_fintech_borrower_reference wb");

        if(!empty($limit)){
        $this->db->limit($limit, $position);
        }

        $this->db->order_by("wb.reference_date", "DESC");
        // $this->db->limit("1");
        $this->db->where("wb.register_code", $register_code);

    return $this->db->get();
    }
}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Score_model extends CI_Model {

	public function get_score($access_status = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_param_score twb");
     

        if (!empty($access_status)){
          $this->db->where("twb.score_status", $access_status);
        }

        $this->db->order_by("twb.id_score", "ASC");

        return $this->db->get()->result();

    }

    public function get_score_list($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_param_score twb");
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_score", "ASC");

        return $this->db->get();

    }

    public function get_score_by_id($id_score)
    {   
        $this->db->select("tf.*")
          ->from("tb_param_score tf");

        $this->db->where("tf.id_score", $id_score);

      return $this->db->get()->result();
    }
  
}

?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Loan_model extends CI_Model {

    public function loan_code() 
    {   
         return $this->db->query("SELECT max(id_borrower_loan) as maxID 
         FROM tb_fintech_borrower_loan WHERE id_borrower_loan LIKE 'LN%'")->result();
    }

    public function invest_code() 
    {   
         return $this->db->query("SELECT max(investment_code) as maxID 
         FROM tb_fintech_lender_investment WHERE investment_code LIKE 'INV%'")->result();
    }

    public function get_loan_by_id($id_borrower_loan)
    {   
        $this->db->select("tam.*")
            ->from("tb_fintech_borrower_loan tam");
        $this->db->where("tam.id_borrower_loan", $id_borrower_loan);
        return $this->db->get()->result();
    }

    public function get_loan_consumtive()
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        $this->db->where("tw.loan_type", "Personal Loan");
        $this->db->order_by("tw.loan_date", "DESC");

        return $this->db->get()->result();
    }

    public function get_loan_commercial()
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        $this->db->where("tw.loan_type != 'Personal Loan'");
        $this->db->order_by("tw.loan_date", "DESC");

        return $this->db->get()->result();
    }
    
    public function get_all_loan($id_borrower_loan = null, $register_code = null)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");

        if (!empty($id_borrower_loan)){
            $this->db->where("tw.id_borrower_loan", $id_borrower_loan);
        }

        if (!empty($register_code)){
            $this->db->where("tw.register_code", $register_code);
        }

        $this->db->order_by("tw.loan_date", "DESC");

        return $this->db->get()->result();
    }

    public function get_crowdfunding_list($limit = null, $position = null, $register_code = null)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        //$this->db->where("tw.loan_status = 'Crowdfunding'");
        
        $this->db->where("tw.loan_status = 'Crowdfunding' AND tw.register_code = '".$register_code."' OR tw.loan_status = 'On Proses' AND tw.register_code = '".$register_code."'");
        // $this->db->where("tw.loan_status = 'Crowdfunding' AND tw.loan_status = 'On Proses'");
        // $this->db->where("tw.register_code", $register_code);

        if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("tw.loan_date", "DESC");
        return $this->db->get();
    }

    public function get_closed_list($limit = null, $position = null, $register_code = null)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        $this->db->where("tw.loan_status = 'Closed'");
        $this->db->where("tw.register_code", $register_code);
     
        if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("tw.loan_date", "DESC");
        return $this->db->get();
    }

    public function get_ongoing_list($limit = null, $position = null, $register_code = null)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        // $this->db->where("tw.loan_status = 'Disbursed' OR tw.loan_status = 'Closed'");
        // $this->db->where("tw.register_code", $register_code);

        $this->db->where("tw.loan_status = 'Disbursed' AND tw.register_code = '".$register_code."' OR tw.loan_status = 'Closed' AND tw.register_code = '".$register_code."'");
        
        if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("tw.loan_date", "DESC");
        return $this->db->get();

    }

    public function get_loan_scoring($register_code, $commersial = null)
    {   
        $this->db->select("tw.*, sum(loan_montly) as loan_total")
          ->from("tb_fintech_borrower_loan tw");
        $this->db->where("tw.loan_status != 'Done'");
        $this->db->where("tw.register_code", $register_code);

        if (!empty($commersial)){
          $this->db->where("tw.loan_type != 'Personal Loan'");
        } else {
          $this->db->where("tw.loan_type = 'Personal Loan'");  
        }

        return $this->db->get()->result();
    }

    public function get_check_closed($register_code)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        $this->db->where("tw.loan_status = 'Closed'");
        $this->db->where("tw.register_code", $register_code);

        return $this->db->get();
    }

    public function get_avg_loan($register_code)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_borrower_loan tw");
        $this->db->where("tw.register_code", $register_code);

        return $this->db->get()->result();
    }

    public function get_sum_loan($register_code)
    {   
        $this->db->select("sum(tw.loan_amount) as amount")
          ->from("tb_fintech_borrower_loan tw");
        $this->db->where("tw.register_code", $register_code);

        return $this->db->get()->result();
    }

    public function get_periode()
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_periode tw");

        $this->db->where("tw.periode_access_status", 'Activated');
        return $this->db->get()->result();
    }

    public function get_periode_scoring_by_periode($periode)
    {   
        $this->db->select("tw.*")
          ->from("tb_fintech_periode tw");

        $this->db->where("tw.periode_access_status", 'Activated');
        $this->db->where("tw.periode", $periode);

        return $this->db->get()->result();
    }
}
?>
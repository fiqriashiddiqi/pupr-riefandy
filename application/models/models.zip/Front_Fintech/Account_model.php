<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account_model extends CI_Model {

    public function get_total_invest_sum($register_code)
    {   
        $this->db->select("sum(tc.amount_invest) as total_invest")
          ->from("tb_fintech_lender_investment tc");
        $this->db->join('tb_fintech_borrower_loan ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.loan_status","Disbursed");
        $this->db->where("tc.register_code", $register_code);

    return $this->db->get()->result();
    }

    public function get_total_reserved_sum($register_code)
    {   
        $this->db->select("sum(tc.amount_invest) as total_reserved")
          ->from("tb_fintech_lender_investment tc");
        $this->db->join('tb_fintech_borrower_loan ta', 'tc.id_borrower_loan = ta.id_borrower_loan');
        
        $this->db->where("ta.loan_status","On Proses");
        $this->db->where("tc.register_code", $register_code);

        return $this->db->get()->result();

    }

    public function get_total_funding_sum($register_code)
    {   
        $this->db->select("sum(tc.amount_invest) as total_funding")
          ->from("tb_fintech_lender_investment tc");
        $this->db->join('tb_fintech_borrower_loan ta', 'tc.id_borrower_loan = ta.id_borrower_loan');
        
        $this->db->where("ta.loan_status != 'Closed'");
        $this->db->where("tc.register_code", $register_code);

        return $this->db->get()->result();

    }
    
    public function get_data_loan($register_code,$id_borrower_loan=null)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_loan tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        if (!empty($id_borrower_loan)){
          $this->db->where("tc.id_borrower_loan", $id_borrower_loan);
        }
        
        $this->db->where("tc.loan_status !='Closed'");
        $this->db->where("ta.register_code", $register_code);

        return $this->db->get()->result();

    }

    public function get_pay_realization_sum($register_code,$id_borrower_loan)
    {   
        $this->db->select("sum(tc.payment_amount) as total_realization")
          ->from("tb_fintech_lender_investment_payment tc");


        $this->db->join('tb_fintech_lender_investment ta', 'tc.investment_code = ta.investment_code');
        $this->db->join('tb_fintech_borrower_loan tb', 'ta.id_borrower_loan = tb.id_borrower_loan');
        
        $this->db->where("ta.register_code", $register_code);
        $this->db->where("tb.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();

    }

    public function get_sum_interest_lender($register_code)
    {   
        $this->db->select("sum(tc.payment_periode_interest) as total_interest_lender")
          ->from("tb_fintech_borrower_payment_periode tc");

        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("tc.payment_periode_status_interest != 'default'");
        $this->db->where("ta.register_code", $register_code);

        return $this->db->get()->result();

    }

     public function get_sum_penalty_lender($register_code,$id_borrower_loan)
    {   
        $this->db->select("sum(tc.payment_periode_pinalty) as total_pinalty_lender")
          ->from("tb_fintech_borrower_payment_periode tc");

        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("tc.payment_periode_status_pinalty != 'default'");
        $this->db->where("ta.register_code", $register_code);
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();

    }

    public function get_pay_realization_sum_borrower_principal($id_borrower_loan)
    {   
        $this->db->select("sum(tc.payment_periode_principal) as total_principal")
          ->from("tb_fintech_borrower_payment_periode tc");

        $this->db->where("tc.payment_periode_status_principal != 'default'");
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();

    }

    public function get_pay_realization_sum_borrower_int_pen($id_borrower_loan)
    {   
        $this->db->select("sum(tc.payment_periode_interest) + sum(tc.payment_periode_pinalty) as total_int_pen")
          ->from("tb_fintech_borrower_payment_periode tc");

        $this->db->where("tc.payment_periode_status_interest != 'default'");
        $this->db->where("tc.payment_periode_status_pinalty != 'default'");
        
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();

    }

    public function get_pay_realization_sum_borrower_fee($id_borrower_loan)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");

        $this->db->where("tc.payment_periode_status_interest != 'default'");
        $this->db->where("tc.payment_periode_status_pinalty != 'default'");
        
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);

        return $this->db->get();

    }

    public function get_invest_by_id($register_code,$id_borrower_loan)
    {   
        $this->db->select("ta.*")
          ->from("tb_fintech_borrower_loan tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.id_borrower_loan", $id_borrower_loan);
        $this->db->where("ta.register_code", $register_code);

        return $this->db->get()->result();

    }    

    public function get_invest_by_id_nreg($register_code,$id_borrower_loan)
    {   
        $this->db->select("sum(ta.amount_invest) as amount_invest")
          ->from("tb_fintech_borrower_loan tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("tc.loan_status !='Closed'");
        $this->db->where("ta.id_borrower_loan", $id_borrower_loan);
        $this->db->where("ta.register_code", $register_code);

        return $this->db->get()->result();

    }


    public function get_invest_by_id_nreg_borrower($register_code,$id_borrower_loan)
    {   
        $this->db->select("sum(ta.amount_invest) as amount_invest")
          ->from("tb_fintech_lender_investment ta");

        $this->db->where("ta.id_borrower_loan", $id_borrower_loan);
        $this->db->where("ta.borrower_reg_code", $register_code);

        return $this->db->get()->result();

    }

    public function get_term_by_id_nreg_borrower($id_borrower_loan)
    {   
        $this->db->select("ta.*")
          ->from("tb_fintech_term_borrower ta");

        $this->db->where("ta.id_borrower_loan", $id_borrower_loan);
        
        return $this->db->get()->result();

    }

    public function get_term_by_id_nreg_lender($register_code)
    {   
        $this->db->select("ta.*")
          ->from("tb_fintech_term_lender ta");

        $this->db->where("ta.register_code", $register_code);
        
        return $this->db->get()->result();

    }

    public function get_data_loan_period($register_code,$id_borrower_loan)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);       
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);
       

        return $this->db->get()->result();

    }

    public function get_data_loan_period_month($register_code,$id_borrower_loan,$date_now)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);       
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);
        $this->db->where("MONTH(tc.payment_periode_date) = MONTH('".$date_now."') AND YEAR(tc.payment_periode_date) = YEAR('".$date_now."')"); 

        return $this->db->get()->result();

    }

    public function get_data_loan_period_month_borrower($id_borrower_loan,$date_now)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
     
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);
        $this->db->where("MONTH(tc.payment_periode_date) = MONTH('".$date_now."') AND YEAR(tc.payment_periode_date) = YEAR('".$date_now."')"); 

        return $this->db->get()->result();

    }

    public function get_data_loan_period_borrower_porto($id_borrower_loan)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
    
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);
        return $this->db->get()->result();

    }

    public function get_data_loan_period_sort($register_code,$id_borrower_loan = null)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        if (!empty($id_borrower_loan)){
          $this->db->where("tc.id_borrower_loan", $id_borrower_loan);
        }

        $this->db->where("ta.register_code", $register_code);       
        // $this->db->where("tc.id_borrower_loan", $id_borrower_loan);

        $this->db->order_by("tc.payment_periode_date","ASC");
        $this->db->group_by("ta.id_borrower_loan");
       

        return $this->db->get()->result();

    }

    public function get_data_loan_period_sort_borrower($register_code,$id_borrower_loan)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_borrower_loan ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);       
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);

        // $this->db->order_by("tc.payment_periode_date","ASC");
        $this->db->group_by("ta.id_borrower_loan");
       

        return $this->db->get()->result();

    }

    public function get_data_loan_period_enddate($register_code, $id_borrower_loan)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);       
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);

        $this->db->order_by("tc.payment_periode_date","DESC");
       
        return $this->db->get()->row();

    }

    public function get_data_loan_period_enddate_borrower($register_code, $id_borrower_loan)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.borrower_reg_code", $register_code);       
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);

        $this->db->order_by("tc.payment_periode_date","DESC");
       
        return $this->db->get()->row();

    }

     public function get_data_loan_period_borrower($register_code,$id_borrower_loan)
    {   
        $this->db->select("tc.*")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_borrower_loan ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);       
        $this->db->where("tc.id_borrower_loan", $id_borrower_loan);
       

        return $this->db->get()->result();

    }

    public function get_investment($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_lender_investment twb");
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_lender_investment", "ASC");

        return $this->db->get();

    }

    public function get_payment($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_payment twb");
          
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_borrower_payment", "ASC");
        $this->db->group_by("twb.id_borrower_loan");


        return $this->db->get();

    }

    public function get_deposit($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_lender_deposit twb");
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_lender_deposit", "ASC");

        return $this->db->get();

    }

    public function get_loan($id_borrower_loan)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_borrower_loan twb");
        $this->db->join("tb_fintech_borrower_payment ta", "twb.register_code = ta.register_code");
          
        $this->db->where("twb.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();

    }

    public function get_loan_length_tenor($register_code)
    {
        $this->db->select("tc.payment_periode_date")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.register_code", $register_code);
        $this->db->order_by("tc.payment_periode_date", "ASC");

        return $this->db->get()->result();
    }

    public function get_loan_length_tenor_borrower($id_borrower_loan)
    {
        $this->db->select("tc.payment_periode_date")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_borrower_loan ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        $this->db->where("ta.id_borrower_loan", $id_borrower_loan);
        $this->db->order_by("tc.payment_periode_date", "ASC");

        return $this->db->get()->result();
    }

    public function get_loan_max_date($register_code,$id_borrower_loan=null)
    {
        
        $this->db->select("max(tc.payment_periode_date) as max_date")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_borrower_loan tl', 'tc.id_borrower_loan = tl.id_borrower_loan');
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        if (!empty($id_borrower_loan)){
          $this->db->where("tc.id_borrower_loan",$id_borrower_loan);
        }
        $this->db->where("tl.loan_status", "Disbursed");
        $this->db->where("ta.register_code", $register_code);

        return $this->db->get()->result();
    }

    public function get_loan_min_date($register_code, $id_borrower_loan=null)
    {
        $this->db->select("min(tc.payment_periode_date) as min_date")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_borrower_loan tl', 'tc.id_borrower_loan = tl.id_borrower_loan');
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');

        if (!empty($id_borrower_loan)){
          $this->db->where("tc.id_borrower_loan",$id_borrower_loan);
        }
        $this->db->where("tl.loan_status", "Disbursed");
        $this->db->where("ta.register_code", $register_code);

        return $this->db->get()->result();
    }

    public function get_loan_max_date_borrower($register_code,$id_borrower_loan)
    {
        $this->db->select("max(tc.payment_periode_date) as max_date")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_borrower_loan tl', 'tc.id_borrower_loan = tl.id_borrower_loan');
        $this->db->where("tl.loan_status", "Disbursed");
        $this->db->where("tl.register_code", $register_code);
        $this->db->where("tl.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();
    }

    public function get_loan_min_date_borrower($register_code,$id_borrower_loan)
    {
        $this->db->select("min(tc.payment_periode_date) as min_date")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_borrower_loan tl', 'tc.id_borrower_loan = tl.id_borrower_loan');
        $this->db->where("tl.loan_status", "Disbursed");
        $this->db->where("tl.register_code", $register_code);
        $this->db->where("tl.id_borrower_loan", $id_borrower_loan);

        return $this->db->get()->result();
    }

    public function get_loan_periode_by_date($register_code,$date)
    {
        $this->db->select("tc.payment_periode_principal, tc.payment_periode_interest, tc.payment_periode_interest")
          ->from("tb_fintech_borrower_payment_periode tc");
        $this->db->join('tb_fintech_borrower_loan tl', 'tc.id_borrower_loan = tl.id_borrower_loan');
        $this->db->join('tb_fintech_lender_investment ta', 'tc.id_borrower_loan = ta.id_borrower_loan');
        $this->db->where("tl.loan_status", "Disbursed");
        $this->db->where("ta.register_code", $register_code);
        $this->db->where("tc.payment_periode_date", $date);

        return $this->db->get()->result();
    }
}
?>
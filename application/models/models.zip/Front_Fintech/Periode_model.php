<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Periode_model extends CI_Model {

	public function get_periode($access_status = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_periode twb");
     

        if (!empty($access_status)){
          $this->db->where("twb.periode_access_status", $access_status);
        }

        $this->db->order_by("twb.id_periode", "ASC");

        return $this->db->get()->result();

    }

    public function get_periode_list($limit = null, $position = null)
    {   
        $this->db->select("twb.*")
          ->from("tb_fintech_periode twb");
     
          if (!empty($limit)){
          $this->db->limit($limit, $position);
        }

        $this->db->order_by("twb.id_periode", "ASC");

        return $this->db->get();

    }

    public function get_periode_by_id($id_periode)
    {   
        $this->db->select("tf.*")
          ->from("tb_fintech_periode tf");

        $this->db->where("tf.id_periode", $id_periode);

      return $this->db->get()->result();
    }
  
}
?>
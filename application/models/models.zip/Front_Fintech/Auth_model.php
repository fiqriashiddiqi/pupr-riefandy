<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auth_model extends CI_Model {

	public function get_access($reg_code, $reg_password, $reg_access_status, $reg_activation_status, $reg_status)
  	{   
	    $this->db->select("tfr.*")
	      ->from("tb_fintech_register tfr");

	    $this->db->where("tfr.register_code", $reg_code);
	    $this->db->where("tfr.register_password", $reg_password);
        $this->db->where("tfr.register_access_status", $reg_access_status);
        $this->db->where("tfr.register_activation_status", $reg_activation_status);
        $this->db->where("tfr.register_status", $reg_status);

	    return $this->db->get()->result();

  	}

    public function check_validate($reg_code, $reg_password)
    {   
        $this->db->select("tfr.*")
          ->from("tb_fintech_register tfr");

        $this->db->where("tfr.register_password", $reg_password);
        $this->db->where("tfr.register_access_status", 'Activated');
        $this->db->where("tfr.register_activation_status", 'Activated');
        $this->db->where("(tfr.register_code = '$reg_code' OR tfr.register_email = '$reg_code')");

        return $this->db->get();

    }

    public function data_validate($reg_code, $reg_password)
    {   
        $this->db->select("tfr.*")
          ->from("tb_fintech_register tfr");

        $this->db->where("tfr.register_password", $reg_password);
        $this->db->where("tfr.register_access_status", 'Activated');
        $this->db->where("tfr.register_activation_status", 'Activated');
        $this->db->where("(tfr.register_code = '$reg_code' OR tfr.register_email = '$reg_code')");

        return $this->db->get()->result();

    }
}
?>